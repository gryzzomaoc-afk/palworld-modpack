-- Multi-generation breeding planner (V1.2).
-- Species-level BFS closure over the verified 1.0 breeding rules: child
-- species is deterministic, so reachability is a plain graph problem.
-- Reads the player's owned pals (palbox pages + party container) live and
-- reconstructs a dedup'ed step list (DAG: each intermediate bred once).
-- Read-only: only reads storage/party state; never mutates anything.
local M = {}

-- Display-string translator (i18n phase 4, codex i18n-p2 #4): the planner
-- emits a handful of USER-FACING notes (gender notes, route warnings).
-- They ride the same shared i18n module the UI configures — require()
-- caches a single instance, so M.lang set by ui.lua applies here too.
-- Offline/older installs fall back to identity (Chinese), never an error.
local i18n_ok, i18n = pcall(require, "i18n")
local function T(zh)
    if i18n_ok and i18n and i18n.t then return i18n.t(zh) end
    return zh
end
local function disp_name(pal)
    if i18n_ok and i18n and pal then
        if i18n.lang == "en" and pal.en and pal.en ~= "" then return pal.en end
        if i18n.lang == "zht" then
            local names = i18n.pal_names_zht
            local t = names and names[pal.id]
            if t then return t end
        end
    end
    return pal and pal.zh or "?"
end

local data = require("data")

-- ---------------------------------------------------------------------------
-- species index (mirrors ui.lua; kept local so the planner stays standalone)
-- ---------------------------------------------------------------------------
local by_id, by_tribe, by_lower, pool = {}, {}, {}, {}
for _, p in ipairs(data.pals) do
    by_id[p.id] = p
    by_lower[p.id:lower()] = p
    if by_tribe[p.tribe] == nil or p.id:lower() == p.tribe:lower() then
        by_tribe[p.tribe] = p
    end
    if p.pool then pool[#pool + 1] = p end
end
table.sort(pool, function(a, b) return a.r < b.r end)

local recipe, gendered = {}, {}
local function pair_key(a, b)
    if a < b then return a .. "|" .. b end
    return b .. "|" .. a
end
for _, u in ipairs(data.unique) do
    if u.ga ~= "None" or u.gb ~= "None" then
        -- keep the FULL entry: each direction (ga/gb) yields a different child
        local k = pair_key(u.a, u.b)
        gendered[k] = gendered[k] or {}
        table.insert(gendered[k], u)
    else
        recipe[pair_key(u.a, u.b)] = u.c
    end
end

-- nearest pool entry by rank: binary search + tie -> higher rank side (dp)
local function nearest(target)
    local lo, hi = 1, #pool
    while lo < hi do
        local mid = math.floor((lo + hi) / 2)
        if pool[mid].r < target then lo = mid + 1 else hi = mid end
    end
    -- candidates: pool[lo] and pool[lo-1]
    local best = pool[lo]
    if lo > 1 then
        local alt = pool[lo - 1]
        local d1, d2 = math.abs(best.r - target), math.abs(alt.r - target)
        if d2 < d1 or (d2 == d1 and alt.dp > best.dp) then best = alt end
    end
    return best
end

-- children of an unordered species pair; takes and returns species IDs.
-- The BFS runs in ID space but recipes/rank data are keyed in TRIBE space,
-- and id ~= tribe for a few pals (BluePlatypus/Blueplatypus case difference,
-- PlantSlime_Flower shares tribe PlantSlime) -- resolve records first.
local child_cache = {} -- id -> other id -> immutable result list
local NO_CHILDREN = {}
local function children_of(ia, ib)
    if not ia or not ib then return NO_CHILDREN end
    local row = child_cache[ia]
    local cached = row and row[ib]
    if cached then return cached end

    local a, b = by_id[ia], by_id[ib]
    local out = {}
    if a and b then
        local key = pair_key(a.tribe, b.tribe)
        local g = gendered[key]
        if g then
            local seen = {}
            for _, u in ipairs(g) do
                if not seen[u.c] then seen[u.c] = true out[#out + 1] = u.c end
            end
        else
            local hit = recipe[key]
            if hit then
                out[1] = hit
            elseif a.tribe == b.tribe then
                -- same tribe -> the tribe's canonical species (a NEW species
                -- only when a skin variant breeds, e.g. Flower x2 -> base)
                local c = by_tribe[a.tribe]
                if c then out[1] = c.id end
            else
                local target = math.floor((a.r + b.r + 1) / 2)
                out[1] = nearest(target).id
            end
        end
    end

    row = row or {}
    child_cache[ia] = row
    row[ib] = out
    local back = child_cache[ib]
    if not back then back = {} child_cache[ib] = back end
    back[ia] = out
    return out
end

-- ---------------------------------------------------------------------------
-- owned pals (live reads; every step pcall-guarded)
-- ---------------------------------------------------------------------------
local function normalize(cid)
    local base = cid:gsub("^BOSS_", ""):gsub("^Boss_", "")
    local p = by_id[base] or by_lower[base:lower()]
    return p and p.id or nil
end

local function unwrap(v)
    if v == nil then return nil end
    local out = v
    pcall(function() out = v:get() end)
    return out
end

local guid_library, guid_library_checked

local function guid_string(v)
    v = unwrap(v)
    if v == nil then return nil end
    local out
    pcall(function() out = v:ToString() end)
    -- FGuid is a reflected struct, not an object with a reliable :ToString()
    -- in UE4SS. Use the engine's canonical Blueprint conversion before ever
    -- falling back to Lua tostring(), whose "table: 0x..." value compares by
    -- wrapper address and made equal BaseCampIds look different.
    if out == nil then
        if not guid_library_checked then
            guid_library_checked = true
            pcall(function()
                guid_library = StaticFindObject("/Script/Engine.Default__KismetGuidLibrary")
            end)
        end
        if guid_library then
            pcall(function() out = guid_library:Conv_GuidToString(v) end)
        end
    end
    if out == nil then
        local fields, complete = {}, true
        for _, name in ipairs({ "A", "B", "C", "D" }) do
            local ok, field = pcall(function() return unwrap(v[name]) end)
            if not ok or field == nil then complete = false break end
            fields[#fields + 1] = tostring(field)
        end
        if complete then out = table.concat(fields, "-") end
    end
    if out == nil then return nil end
    if type(out) ~= "string" then
        local converted
        pcall(function() converted = out:ToString() end)
        out = converted or tostring(out)
    end
    if out == "" or out == "nil" or out == "None" then return nil end
    return out
end

local function value_string(v)
    v = unwrap(v)
    if v == nil then return nil end
    local out
    pcall(function() out = v:ToString() end)
    if out == nil then out = tostring(v) end
    if out == "" or out == "nil" or out == "None" then return nil end
    return out
end

-- FPalInstanceID is NOT an FGuid. It contains PlayerUId + InstanceId GUIDs;
-- passing the whole struct to KismetGuidLibrary aliases every Pal to the same
-- key. Serialize both nested GUIDs explicitly so the same individual also
-- deduplicates correctly when visible through two containers.
local function pal_instance_id_string(v)
    v = unwrap(v)
    if v == nil then return nil end
    local player_guid, instance_guid
    pcall(function() player_guid = guid_string(v.PlayerUId) end)
    pcall(function() instance_guid = guid_string(v.InstanceId) end)
    if instance_guid then return (player_guid or "world") .. ":" .. instance_guid end
    return nil
end

-- The LOCAL player's controller (1.7.1). FindFirstOf returns ANY
-- controller — on a listen host every connected player's controller lives
-- in this process, and grabbing a guest's meant reading THEIR box and
-- pushing cursor state at THEIR controller (EP1 field reports 2026-07-19:
-- host saw a guest's storage, mouse never appeared). The engine guarantees
-- GameInstance.LocalPlayers holds only OUR player in every net mode; the
-- FindFirstOf fallback keeps singleplayer / pure-client behavior identical
-- (they only ever have the one controller).
function M.local_player_controller()
    local found
    pcall(function()
        local gi = FindFirstOf("PalGameInstance")
        if not (gi and gi:IsValid()) then gi = FindFirstOf("GameInstance") end
        if not (gi and gi:IsValid()) then return end
        local lp = gi.LocalPlayers and gi.LocalPlayers[1]
        pcall(function() lp = lp:get() end)
        local pc = lp and lp.PlayerController
        if pc and pc:IsValid() then found = pc end
    end)
    if found then return found end
    pcall(function()
        local pc = FindFirstOf("PalPlayerController")
        if pc and pc:IsValid() then found = pc end
    end)
    return found
end

-- session sync manager (1.2.0). Optional: everything below degrades to the
-- 1.1.x behavior when the module is missing. The id converter is injected so
-- dimension-cache records carry EXACTLY the same persistent key a live handle
-- would produce -- roster locks/exclusions must survive the source switch.
local sync_ok, sync = pcall(require, "sync")
if not (sync_ok and type(sync) == "table") then sync = nil end
if sync and sync.set_id_converter then
    sync.set_id_converter(pal_instance_id_string)
end
M._sync = sync

local function value_number(v)
    v = unwrap(v)
    if v == nil then return nil end
    if type(v) == "number" then return v end
    local s = value_string(v)
    if not s then return nil end
    return tonumber(s) or tonumber(s:match("(-?%d+%.?%d*)"))
end

local function save_value(param, name)
    local v
    pcall(function() v = param.SaveParameter[name] end)
    return v
end

local function array_strings(arr)
    local out = {}
    if arr == nil then return out end
    pcall(function()
        arr:ForEach(function(_, pe)
            local s = value_string(pe)
            if s then out[#out + 1] = s end
        end)
    end)
    return out
end

-- Prefer the game's persistent individual id. Method names differ between
-- UE reflection builds, so every known spelling is attempted independently.
-- A source/slot fallback still gives a unique identity for the current live
-- snapshot; projects only treat persistent ids as stable across refreshes.
local function individual_id(handle, param)
    local tries = {
        function() return handle and handle:GetIndividualId() end,
        function() return handle and handle:GetIndividualID() end,
        function() return param and param:GetIndividualId() end,
        function() return param and param:GetIndividualID() end,
        function() return param and param.SaveParameter.IndividualId end,
        function() return param and param.SaveParameter.IndividualID end,
    }
    for _, get in ipairs(tries) do
        local ok, v = pcall(get)
        if ok then
            local s = pal_instance_id_string(v) or value_string(v)
            if s then return s, true end
        end
    end
    return nil, false
end

local function record(owned, snapshot, param, meta)
    meta = meta or {}
    local cid
    pcall(function() cid = value_string(param:GetCharacterID()) end)
    if not cid then return nil end
    local id = normalize(cid)
    if not id then return nil end

    local gender_num
    pcall(function() gender_num = value_number(param:GetGenderType()) end)
    if gender_num == nil then gender_num = value_number(save_value(param, "Gender")) end
    local gender = gender_num == 2 and "F" or "M"

    local passives = array_strings(save_value(param, "PassiveSkillList"))
    local equipped = array_strings(save_value(param, "EquipWaza"))
    local mastered = array_strings(save_value(param, "MasteredWaza"))
    for i, skill in ipairs(equipped) do equipped[i] = skill:match("::(.+)$") or skill end
    for i, skill in ipairs(mastered) do mastered[i] = skill:match("::(.+)$") or skill end
    local persistent_id, stable_id
    if meta.persistent_id then
        -- dimension-cache records precompute the key at harvest time (the
        -- underlying struct memory is transient); format is identical to
        -- pal_instance_id_string so dedup and roster keys keep working
        persistent_id, stable_id = meta.persistent_id, true
    else
        persistent_id, stable_id = individual_id(meta.handle, param)
    end
    local fallback = string.format("%s:%s:%s", meta.source or "unknown",
        tostring(meta.page or "-"), tostring(meta.slot or "-"))
    local key = persistent_id or fallback
    if snapshot.by_key[key] then return snapshot.by_key[key], false end

    local inst = {
        key = key,
        persistent_id = persistent_id,
        stable_id = stable_id,
        species = id,
        raw_species = cid,
        gender = gender,
        passives = passives,
        iv = {
            hp = value_number(save_value(param, "Talent_HP")),
            melee = value_number(save_value(param, "Talent_Melee")),
            shot = value_number(save_value(param, "Talent_Shot")),
            defense = value_number(save_value(param, "Talent_Defense")),
        },
        equipped_skills = equipped,
        mastered_skills = mastered,
        alpha = cid:match("^[Bb][Oo][Ss][Ss]_") ~= nil,
        rank = value_number(save_value(param, "Rank")),
        level = value_number(save_value(param, "Level")),
        source = meta.source or "unknown",
        page = meta.page,
        slot = meta.slot,
        location = meta.location or fallback,
        expedition = (function()
            -- pals assigned to an expedition are physically absent: they
            -- must not be offered as plan parents (owner report 2026-07-24 —
            -- dispatch to a breeding farm cannot reach them)
            local exped = false
            pcall(function() exped = param:IsAssignedToExpedition() == true end)
            if exped then return true end
            -- second channel (field report: 94 dispatched, only 77 flagged —
            -- the function can lag/miss on a networked client): the save
            -- parameter replicates the assigned expedition instance id; a
            -- non-zero guid means assigned
            local g = save_value(param, "MapObjectConcreteInstanceIdAssignedToExpedition")
            if g ~= nil then
                pcall(function()
                    exped = (tonumber(g.A) or 0) ~= 0 or (tonumber(g.B) or 0) ~= 0
                        or (tonumber(g.C) or 0) ~= 0 or (tonumber(g.D) or 0) ~= 0
                end)
                if not exped then
                    pcall(function()
                        -- string-marshalled guids only: strip separators and
                        -- accept exactly 32 hex chars ("FGuid: 0x…" ADDRESS
                        -- forms must never count — an address is never zero)
                        local hex = tostring(g):gsub("[%-{}%s]", "")
                        if #hex == 32 and not hex:match("[^0-9a-fA-F]") then
                            exped = hex:match("[^0]") ~= nil
                        end
                    end)
                end
            end
            return exped
        end)(),
        base_coord = meta.base_coord,   -- in-game map coords of the camp (base pals only)
    }
    snapshot.instances[#snapshot.instances + 1] = inst
    snapshot.by_key[key] = inst
    local species_list = snapshot.by_species[id]
    if not species_list then species_list = {} snapshot.by_species[id] = species_list end
    species_list[#species_list + 1] = inst
    snapshot.counts[inst.source] = (snapshot.counts[inst.source] or 0) + 1

    local e = owned[id] or { male = 0, female = 0, pv = {}, list = species_list }
    if gender == "F" then e.female = e.female + 1 else e.male = e.male + 1 end
    for _, passive in ipairs(passives) do e.pv[passive] = true end
    e.list = species_list
    owned[id] = e
    return inst, true
end

-- One box page into (owned, snapshot). Shared by the sliced full scan and
-- the incremental page patch (1.7.0) so the two can never drift. Returns
-- (struct_ok, page_gap, added): a failed GetSlotsInPage or slot exception
-- poisons struct_ok; an occupied-but-unmaterialized slot flags page_gap.
local function scan_one_box_page(storage, pg, owned, snapshot)
    local slots = {}
    local page_gap, added, slot_errors = false, 0, 0
    if not pcall(function() storage:GetSlotsInPage(pg, slots) end) then
        return false, false, 0, 1
    end
    local struct_ok = true
    for slot_index, s in ipairs(slots) do
        local sok = pcall(function()
            local slot = s
            pcall(function() slot = s:get() end)
            -- EMPTY slots first (field 2026-07-19: GetHandle on empty slots
            -- throws in this environment — 277 "poisons" were exactly the
            -- box's empty cells, and only the sync cross-check kept the
            -- census alive). The sync manager's own sweep always asked
            -- IsEmpty first, which is why it never had the problem. An
            -- unreadable IsEmpty falls through to the old conservative path.
            local empty = false
            pcall(function() empty = slot:IsEmpty() end)
            if empty then return end
            local handle = slot:GetHandle()
            if handle then
                local param = handle:TryGetIndividualParameter()
                if param and param:IsValid() then
                    local inst, was_added = record(owned, snapshot, param, {
                        handle = handle,
                        source = "box",
                        page = pg,
                        slot = slot_index - 1,
                        location = string.format("box:%d:%d", pg, slot_index - 1),
                    })
                    if inst and was_added then added = added + 1 end
                else
                    -- occupied slot (handle replicated) with no
                    -- materialized parameter: needs sync
                    page_gap = true
                end
            end
        end)
        if not sok then
            struct_ok = false
            slot_errors = slot_errors + 1
        end
    end
    return struct_ok, page_gap, added, slot_errors
end

-- rest of the scan (party/base/dimension/diag) on a job whose box phase was
-- already driven by M._scan_step. Runs in ONE call: these sources are ~50
-- records vs the box's ~500, so slicing them buys nothing.
local function scan_rest(job)
    local owned, snapshot = job.owned, job.snapshot
    local box = job.box
    local party, base = 0, 0
    local local_ps, local_pc = job.local_ps, job.local_pc
    local function breathe() end   -- box-era yield points are no-ops here
    local function diag(text) snapshot.diagnostics[#snapshot.diagnostics + 1] = tostring(text) end
    -- (the box was scanned page-by-page in M._scan_step before we got here;
    -- snapshot.box_missing was published there under the same three-state
    -- rules as before)
    -- party via player's otomo holder container
    pcall(function()
        local target
        for _, h in ipairs(FindAllOf("PalOtomoHolderComponentBase") or {}) do
            local owner = ""
            pcall(function() owner = h:GetOwner():GetFullName() end)
            if owner:find("PalPlayerController") then target = h end
        end
        local outbox = {}
        target:TryGetContainer(outbox)
        local container = outbox.Container
        local n = container:Num()
        for i = 0, n - 1 do
            pcall(function()
                local slot = container:Get(i)
                if slot and slot:IsValid() then
                    local handle = slot:GetHandle()
                    if handle and handle:IsValid() then
                        local param = handle:TryGetIndividualParameter()
                        if param and param:IsValid() then
                            local inst, added = record(owned, snapshot, param, {
                                handle = handle,
                                source = "party",
                                slot = i,
                                location = string.format("party:%d", i),
                            })
                            if inst and added then party = party + 1 end
                        end
                    end
                end
            end)
        end
    end)
    -- Base workers via the local guild's base-camp models. Comparing the
    -- camp's GroupIdBelongTo with the local PlayerState.GuildBelongTo ID is
    -- essential in multiplayer: FindAllOf also sees nearby foreign camps.
    breathe()   -- party scanned; yield before the base sweep
    -- The 1.0 runtime path is BaseCampModel.WorkerDirector
    -- -> GetCharacterHandleSlots -> slot handle -> individual parameter.
    local base_ok, base_err = pcall(function()
        if not (local_ps and local_ps:IsValid()) then
            local pc = M.local_player_controller()
            if pc then local_pc, local_ps = pc, pc.PlayerState end
        end
        local guild = local_ps and local_ps.GuildBelongTo
        local guild_source = "PlayerState.GuildBelongTo"
        local guild_valid = false
        pcall(function() guild_valid = guild and guild:IsValid() end)
        if not guild_valid then
            pcall(function()
                local util = StaticFindObject("/Script/Pal.Default__PalGroupUtility")
                local world = local_pc and local_pc:GetWorld()
                if util and world then guild = util:GetLocalPlayerGuild(world) end
            end)
            guild_source = "PalGroupUtility.GetLocalPlayerGuild"
            pcall(function() guild_valid = guild and guild:IsValid() end)
        end
        diag("guild_source=" .. guild_source .. " valid=" .. tostring(guild_valid))
        if not guild_valid then return end
        local guild_id = guid_string(guild:GetId())
        local base_ids = {}
        local base_id_count = 0
        pcall(function()
            guild.BaseCampIds:ForEach(function(_, entry)
                local id = guid_string(entry)
                if id and not base_ids[id] then base_ids[id] = true base_id_count = base_id_count + 1 end
            end)
        end)
        diag("guild_id=" .. tostring(guild_id) .. " base_ids=" .. tostring(base_id_count))
        for id in pairs(base_ids) do diag("guild_base_id=" .. tostring(id)) end
        if not guild_id and base_id_count == 0 then return end

        -- In-game map coordinates from the camp's world transform. The
        -- world->map affine is community-established (palworldlol/
        -- palworld-coord; constants are the higher-precision fit from the
        -- save-tools ecosystem): displayed axes are SWAPPED, scaled by
        -- ~460, offset to the original Palpagos center. 1.0 map expansions
        -- extend the displayed range without rebasing it. Property reads
        -- only (no UFunction call); any failure just omits the coords.
        local function camp_map_coord(camp)
            local coord
            pcall(function()
                local loc = camp.Transform.Translation
                local wx, wy = loc.X, loc.Y
                if type(wx) == "number" and type(wy) == "number" then
                    coord = string.format("%d,%d",
                        math.floor((wy - 157664.396) / 459.9968 + 0.5),
                        math.floor((wx + 123467.233) / 459.9968 + 0.5))
                end
            end)
            return coord
        end

        local seen_director = {}
        local director_count, slot_count = 0, 0
        local function process_director(director, camp_name, camp_id, camp_coord)
            if not director then return end
            local valid = false
            pcall(function() valid = director:IsValid() end)
            if not valid then return end
            local key = tostring(director)
            pcall(function() key = director:GetFullName() end)
            if seen_director[key] then return end
            seen_director[key] = true
            director_count = director_count + 1
            local slots = {}
            local ok_slots, err_slots = pcall(function() director:GetCharacterHandleSlots(slots) end)
            local character_container
            pcall(function() character_container = director.CharacterContainer end)
            if (not ok_slots or #slots == 0) and character_container then
                -- Client replication can expose the container before the
                -- WorkerDirector UFunction returns its out-array. Reading the
                -- same slots directly is still read-only and avoids a false
                -- "base 0" during that replication state.
                local ok_container, container_err = pcall(function()
                    local count = character_container:Num()
                    for i = 0, count - 1 do slots[#slots + 1] = character_container:Get(i) end
                end)
                diag(string.format("director_container_fallback=%s slots=%d err=%s",
                    tostring(ok_container), #slots, ok_container and "" or tostring(container_err)))
                if ok_container then ok_slots, err_slots = true, nil end
            end
            diag(string.format("director=%s slots_ok=%s slots=%d err=%s",
                key, tostring(ok_slots), #slots, ok_slots and "" or tostring(err_slots)))
            if not ok_slots then return end
            for slot_index, entry in ipairs(slots) do
                pcall(function()
                    local slot = unwrap(entry)
                    local handle = slot and slot:GetHandle()
                    if not (handle and handle:IsValid()) then return end
                    local param = handle:TryGetIndividualParameter()
                    if not (param and param:IsValid()) then return end
                    slot_count = slot_count + 1
                    local _, added = record(owned, snapshot, param, {
                        handle = handle,
                        source = "base",
                        page = camp_id,
                        slot = slot_index - 1,
                        location = string.format("base:%s:%d", camp_name or camp_id or "?", slot_index - 1),
                        base_coord = camp_coord,
                    })
                    if added then base = base + 1 end
                end)
            end
        end

        local camps = FindAllOf("PalBaseCampModel") or {}
        local matched_camps = 0
        for _, camp in ipairs(camps) do
            pcall(function()
                if not (camp and camp:IsValid()) then return end
                local camp_name = value_string(camp:GetBaseCampName()) or "base"
                local camp_id = guid_string(camp:GetId()) or camp_name
                local camp_group = guid_string(camp:GetGroupIdBelongTo())
                diag(string.format("camp_id=%s group_id=%s", tostring(camp_id), tostring(camp_group)))
                if (guild_id and camp_group == guild_id) or base_ids[camp_id] then
                    matched_camps = matched_camps + 1
                    local camp_coord = camp_map_coord(camp)
                    diag("camp_coord=" .. tostring(camp_coord))
                    process_director(camp.WorkerDirector, camp_name, camp_id, camp_coord)
                end
            end)
        end
        diag(string.format("camp_models=%d matched=%d", #camps, matched_camps))

        -- Some client builds do not replicate BaseCampModel.WorkerDirector,
        -- while the directors themselves are present. Match their BaseCampId
        -- against the local guild's BaseCampIds as a second authoritative path.
        local directors = FindAllOf("PalBaseCampWorkerDirector") or {}
        for _, director in ipairs(directors) do
            pcall(function()
                local camp_id = guid_string(director.BaseCampId)
                diag("director_base_id=" .. tostring(camp_id))
                if camp_id and base_ids[camp_id] then
                    process_director(director, camp_id, camp_id)
                end
            end)
        end
        diag(string.format("director_objects=%d matched_directors=%d slot_records=%d added=%d",
            #directors, director_count, slot_count, base))
    end)
    if not base_ok then diag("base_error=" .. tostring(base_err)) end
    breathe()   -- base scanned; dimension source is cheap (plain Lua cache)
    -- 帕鲁次元仓库 (DimensionPalStorage). Preferred source (1.2.0): the sync
    -- manager's harvested cache — a COMPLETE headless read of every page via
    -- the open/page/close RPC cycle (probe v3 proven on netmode=Client).
    -- Fallback (1.1.x behavior): transient UI handle objects from browsed
    -- pages only (PalIndividualCharacterHandleDimensionLocker; single-page
    -- replication, "翻过的页才读得到"). Scanned LAST so an individual that
    -- also appears in box/party/base keeps its primary location via the
    -- persistent-id dedup.
    local dimension = 0
    local dimension_via = "handles"
    -- dps_cache_valid, never dps_cache_ready: the Lua state outlives world
    -- switches, and a previous world's locker must not leak into this one
    if sync and sync.dps_cache_valid and sync.dps_cache_valid() then
        dimension_via = "sync_cache+handles"
        pcall(function()
            for di, rec in ipairs(sync.dps_cache) do
                pcall(function()
                    local inst, added = record(owned, snapshot,
                        M._dps_mock_param(rec), {
                            persistent_id = rec.persistent_id,
                            source = "dimension",
                            page = rec.page,
                            slot = rec.slot or di,
                            location = (rec.page ~= nil and rec.slot ~= nil)
                                and string.format("dimension:%d:%d", rec.page, rec.slot)
                                or "dimension",
                        })
                    if inst and added then dimension = dimension + 1 end
                end)
            end
        end)
    end
    -- browsed-page transient handles ALWAYS merge in (persistent-id dedup
    -- absorbs overlaps with the cache): with the early-stop sweep, a pal
    -- stored beyond the stop gap becomes visible by browsing its page once
    do
        pcall(function()
            for hi, h in ipairs(FindAllOf("PalIndividualCharacterHandleDimensionLocker") or {}) do
                pcall(function()
                    local param
                    pcall(function() param = h.MyParameter end)
                    local pvalid = false
                    pcall(function() pvalid = param and param:IsValid() end)
                    if not pvalid then
                        param = h:TryGetIndividualParameter()
                        pvalid = param and param:IsValid()
                    end
                    if pvalid then
                        local inst, added = record(owned, snapshot, param, {
                            handle = h,
                            source = "dimension",
                            -- slot = scan index: only consumed by the FALLBACK
                            -- key when the persistent id fails — without it every
                            -- such pal would collide on "dimension:-:-"
                            slot = hi,
                            location = "dimension",
                        })
                        if inst and added then dimension = dimension + 1 end
                    end
                end)
            end
        end)
    end
    diag("dimension_added=" .. tostring(dimension) .. " via=" .. dimension_via)
    -- sync-manager health lands in the diag file so field failures are
    -- diagnosable from a single log request
    pcall(function()
        if sync then
            diag(string.format(
                "sync box_incomplete=%s box_requested=%s dps_valid=%s dps_ok=%s dps_err=%s cache_n=%d",
                tostring(sync.box_incomplete()),
                tostring(sync.state.box.requested),
                tostring(sync.dps_cache_valid()),
                tostring(sync.state.dps.ok),
                tostring(sync.state.dps.err),
                #sync.dps_cache))
        end
    end)
    pcall(function()
        if (job.slot_errors or 0) > 0 then
            diag(string.format("box slot_errors=%d pages=%s census_via=%s",
                job.slot_errors,
                table.concat(job.slot_error_pages or {}, ","),
                tostring(job.snapshot.census_via or "own")))
        end
    end)
    job.box, job.party, job.base, job.dimension = box, party, base, dimension
end

function M._scan_begin()
    return {
        phase = "box",
        owned = {}, box = 0, party = 0, base = 0, dimension = 0,
        snapshot = {
            instances = {},
            by_key = {},
            by_species = {},
            counts = { box = 0, party = 0, base = 0 },
            diagnostics = {},
            -- box_missing: THREE-STATE, published only after a structurally
            -- clean full box sweep (codex r15/r16 rules carried over)
        },
        box_pg = 0, box_pages = nil,
        box_struct_ok = true, box_miss = 0, box_scan_done = false,
    }
end

-- one time-slice of the scan; call repeatedly (each call is a plain function
-- invocation on the MAIN lua state — the coroutine route is forbidden, UE4SS
-- C functions only recognize registered states). Returns true when done.
function M._scan_step(job, max_pages)
    if job.phase == "box" then
        local ok = pcall(function()
            -- re-resolve the storage every slice: wrappers must not be held
            -- across frames (world switches invalidate them)
            local ps
            pcall(function()
                local pc = M.local_player_controller()
                if pc then job.local_pc, ps = pc, pc.PlayerState end
            end)
            if not (ps and ps:IsValid()) then ps = FindFirstOf("PalPlayerState") end
            job.local_ps = ps
            -- bind the sweep to the identity captured on the FIRST slice: a
            -- world/player switch mid-scan must poison the census, never
            -- blend two worlds into one "complete" snapshot (codex r21)
            local ident
            pcall(function() ident = ps:GetFullName() end)
            -- an UNREADABLE identity poisons immediately: two worlds both
            -- failing the read must not compare equal and slip a mixed
            -- snapshot through as complete (codex r22)
            if type(ident) ~= "string" or ident == "" then
                error("player identity unreadable mid-scan")
            end
            if job.scan_ident == nil then
                job.scan_ident = ident
                -- the snapshot remembers its world: the incremental page
                -- patch (1.7.0) must refuse to splice another world's pages
                job.snapshot.scan_ident = ident
            elseif ident ~= job.scan_ident then
                error("player identity changed mid-scan")
            end
            local storage = ps:GetPalStorage()
            if job.box_pages == nil then
                local pages = storage:GetPageNum()
                -- an invalid page count must poison the census, not publish
                -- an empty-loop "0 missing" (codex r16)
                if type(pages) ~= "number" or pages < 0 or pages % 1 ~= 0 then
                    error("bad box page count: " .. tostring(pages))
                end
                job.box_pages = pages
            end
            local owned, snapshot = job.owned, job.snapshot
            local last = math.min(job.box_pg + (max_pages or 4), job.box_pages) - 1
            for pg = job.box_pg, last do
                local ok_page, page_gap, added, slot_errors =
                    scan_one_box_page(storage, pg, owned, snapshot)
                if not ok_page then
                    job.box_struct_ok = false
                    job.slot_errors = (job.slot_errors or 0) + slot_errors
                    job.slot_error_pages = job.slot_error_pages or {}
                    job.slot_error_pages[#job.slot_error_pages + 1] = pg
                end
                job.box = job.box + added
                if page_gap then
                    job.box_miss = job.box_miss + 1
                end
            end
            job.box_pg = last + 1
        end)
        if not ok then
            job.box_struct_ok = false
            job.phase = "rest"
        elseif job.box_pg >= (job.box_pages or 0) then
            job.box_scan_done = true
            job.phase = "rest"
        end
        return false
    end
    if job.phase == "rest" then
        if job.box_scan_done and job.box_struct_ok then
            job.snapshot.box_missing = job.box_miss
        elseif job.box_scan_done then
            -- Slot-level poisons made this census UNKNOWN — which used to
            -- cost only the "已同步" hint, but under the 1.7.0 cache it
            -- forces a full rescan on EVERY open (field report 2026-07-19:
            -- a stray unreadable slot looped a 681-pal box forever). The
            -- sync manager keeps an INDEPENDENT per-page census on a
            -- different code path with lenient slot handling: adopt our
            -- count only when that second opinion also reads the box as
            -- complete; otherwise stay honestly UNKNOWN (fail-closed, and
            -- a party/base identity failure still poisons via the outer
            -- pcall path as before).
            pcall(function()
                if sync and sync.box_incomplete() == 0 then
                    job.snapshot.box_missing = job.box_miss
                    job.snapshot.census_via = "sync-cross-check"
                end
            end)
        end
        pcall(scan_rest, job)
        job.phase = "done"
    end
    return true
end

-- synchronous wrapper: behavior identical to the pre-slicing scan. `step`
-- (optional) is invoked between slices with (pages_done, pages_total).
function M.read_owned(step)
    local job = M._scan_begin()
    while not M._scan_step(job, 4) do
        if step then pcall(step, job.box_pg, job.box_pages or 0) end
    end
    return job.owned, job.box, job.party, job.snapshot, job.base, job.dimension
end

-- Incremental box refresh (1.7.0, owner request): re-scan ONLY the pages
-- the background sync actually pulled and patch the RAW session snapshot in
-- place — the ~500-pal full sweep stays on first open / manual sync. The
-- caller re-filters through _set_scoped_snapshot, which rebuilds the owned
-- aggregate from raw instances, so only the four raw structures are
-- maintained here. `census_missing` (the sync's own residual count)
-- replaces snapshot.box_missing — a delta scan can only vouch for its own
-- pages. Returns false whenever a patch would be unsafe (no storage, world
-- identity mismatch, structural scan failure): the caller must then fall
-- back to the full rescan. Known limit (accepted): an individual visible
-- through BOTH the box and another container was dedup-claimed by the box
-- entry; removing that entry drops it until the next full scan.
function M.rescan_box_pages(snapshot, pages, census_missing)
    if not (snapshot and snapshot.by_key and snapshot.instances
        and type(pages) == "table") then
        return false
    end
    -- an UNKNOWN-census baseline (box_missing == nil: the full scan failed
    -- structurally somewhere) must NEVER be laundered to "complete" by a
    -- few patched pages + the sync residual — pages the broken scan missed
    -- would stay missing while the snapshot claims completeness (codex r16;
    -- same fail-closed rule the census has carried since codex r15/r16 of
    -- the 1.2.x era). The caller falls back to the honest full rescan.
    if snapshot.box_missing == nil then return false end
    local storage, ident
    pcall(function()
        local pc = M.local_player_controller()
        local ps = pc and pc.PlayerState
        if not (ps and ps:IsValid()) then ps = FindFirstOf("PalPlayerState") end
        if ps and ps:IsValid() then
            ident = ps:GetFullName()
            storage = ps:GetPalStorage()
        end
    end)
    if not storage then return false end
    if type(ident) ~= "string" or ident == ""
        or snapshot.scan_ident ~= ident then
        return false
    end
    local wanted, total = {}, 0
    for _, pg in ipairs(pages) do
        if type(pg) == "number" then
            if not wanted[pg] then total = total + 1 end
            wanted[pg] = true
        end
    end
    if total == 0 then
        if type(census_missing) == "number" and census_missing >= 0 then
            snapshot.box_missing = census_missing
        end
        return true
    end
    -- drop every box instance on a touched page (all four raw structures)
    local kept, touched_species = {}, {}
    for _, inst in ipairs(snapshot.instances) do
        if inst.source == "box" and wanted[inst.page] then
            snapshot.by_key[inst.key] = nil
            touched_species[inst.species] = true
            snapshot.counts.box = math.max(0, (snapshot.counts.box or 1) - 1)
        else
            kept[#kept + 1] = inst
        end
    end
    snapshot.instances = kept
    for id in pairs(touched_species) do
        local list = {}
        for _, inst in ipairs(snapshot.by_species[id] or {}) do
            if snapshot.by_key[inst.key] then list[#list + 1] = inst end
        end
        snapshot.by_species[id] = #list > 0 and list or nil
    end
    -- re-scan the touched pages; the aggregate table is scratch — the
    -- caller's re-filter rebuilds the real one from raw instances
    local scratch_owned = {}
    local struct_ok = true
    for pg in pairs(wanted) do
        local ok_page = scan_one_box_page(storage, pg, scratch_owned, snapshot)
        struct_ok = struct_ok and ok_page
    end
    if not struct_ok then return false end
    if type(census_missing) == "number" and census_missing >= 0 then
        snapshot.box_missing = census_missing
    end
    return true
end

-- Wrap a harvested dimension-cache record in the param shape record() reads
-- (same contract the offline fixtures use). Exposed for the test harness.
function M._dps_mock_param(rec)
    local function atom(s) return { ToString = function() return s end } end
    local function arr(vals)
        return {
            ForEach = function(_, cb)
                for i, v in ipairs(vals or {}) do
                    cb(i - 1, { get = function() return atom(v) end })
                end
            end,
        }
    end
    return {
        IsValid = function() return true end,
        GetCharacterID = function() return atom(rec.cid) end,
        GetGenderType = function() return rec.gender end,
        SaveParameter = {
            Gender = rec.gender,
            PassiveSkillList = arr(rec.passives),
            EquipWaza = arr(rec.equipped),
            MasteredWaza = arr(rec.mastered),
            Talent_HP = rec.iv_hp,
            Talent_Melee = rec.iv_melee,
            Talent_Shot = rec.iv_shot,
            Talent_Defense = rec.iv_defense,
            Rank = rec.rank,
            Level = rec.level,
        },
    }
end

-- Build a planning-only view from an immutable live snapshot. Keeping base
-- workers out here (rather than merely hiding their rows in UI) guarantees
-- calculator ownership, planner seeds, lock choices and project refreshes all
-- use exactly the same scope. Individual tables are reused read-only.
-- `excluded` (optional): set of instance keys the player banned from
-- breeding via the roster page. Filtering here — the single funnel every
-- consumer (calculator ownership, quick plan, precise planner) drinks from —
-- is what makes 排除 mean "它不存在", not merely "planner skips it".
-- `include_dimension` (2.2, owner request): nil/true keeps dimension-locker
-- pals (legacy behavior); false scopes them out exactly like 忽略据点.
function M.filter_snapshot(raw_snapshot, include_base, excluded, include_dimension)
    local owned = {}
    local snapshot = {
        instances = {},
        by_key = {},
        by_species = {},
        counts = { box = 0, party = 0, base = 0 },
        excluded_count = 0,
        diagnostics = raw_snapshot and raw_snapshot.diagnostics or {},
    }
    local excluded_base = 0
    local excluded_dimension = 0
    local excluded_expedition = 0
    for _, inst in ipairs(raw_snapshot and raw_snapshot.instances or {}) do
        -- source-scope removal takes precedence: a scoped-out pal that is
        -- ALSO on the exclusion list counts as source-scope, so "另排除 N 只"
        -- never inflates with pals that would not have participated anyway
        if include_base == false and inst.source == "base" then
            excluded_base = excluded_base + 1
        elseif include_dimension == false and inst.source == "dimension" then
            -- source scopes outrank the expedition flag: a scoped-out
            -- dimension pal that is ALSO away must not double-report (the
            -- status line already shows the whole dimension as ignored)
            excluded_dimension = excluded_dimension + 1
        elseif inst.expedition then
            -- physically absent (expedition roster): never a plan parent,
            -- regardless of the manual exclusion list
            excluded_expedition = excluded_expedition + 1
        elseif excluded and inst.key and excluded[inst.key] then
            snapshot.excluded_count = snapshot.excluded_count + 1
        else
            snapshot.instances[#snapshot.instances + 1] = inst
            snapshot.by_key[inst.key] = inst
            local species_list = snapshot.by_species[inst.species]
            if not species_list then
                species_list = {}
                snapshot.by_species[inst.species] = species_list
            end
            species_list[#species_list + 1] = inst
            snapshot.counts[inst.source] = (snapshot.counts[inst.source] or 0) + 1
            local entry = owned[inst.species]
            if not entry then
                entry = { male = 0, female = 0, pv = {}, list = species_list }
                owned[inst.species] = entry
            end
            if inst.gender == "F" then entry.female = entry.female + 1 else entry.male = entry.male + 1 end
            for _, passive in ipairs(inst.passives or {}) do entry.pv[passive] = true end
        end
    end
    return owned, snapshot, excluded_base, excluded_dimension, excluded_expedition
end

-- ---------------------------------------------------------------------------
-- BFS closure + path reconstruction
-- ---------------------------------------------------------------------------
-- Wave-limited BFS closure. 12 waves is a fixpoint guard, not a product
-- limit: real breeding closures converge in <=5 waves, so plan(),
-- suggest_catch() and reaches_with() all see the SAME reachable set
-- (a mismatch here once made suggestions the planner could not fulfil).
local MAX_WAVES = 12

-- `owned` is an immutable snapshot for the lifetime of one panel instance.
-- Cache the expensive, target-independent work by that table's identity:
-- one full closure serves every planner/decomposition target, and one direct
-- pair index serves every "can my box breed this immediately?" query.
-- Weak keys ensure closing/reopening the panel releases the whole snapshot.
local closure_cache = setmetatable({}, { __mode = "k" })
local depth_cache = setmetatable({}, { __mode = "k" })
local direct_pair_cache = setmetatable({}, { __mode = "k" })
local cache_stats = { closure_builds = 0, direct_pair_builds = 0 }

local function build_closure(owned, max_depth, stop_at)
    max_depth = max_depth or MAX_WAVES
    local known = {}          -- id -> false (owned) | {a, b}
    local depths = {}         -- id -> minimum generation depth (owned = 0)
    local all, frontier = {}, {}
    for id in pairs(owned) do
        known[id] = false
        depths[id] = 0
        all[#all + 1] = id
        frontier[#frontier + 1] = id
    end
    if #all == 0 then return known, depths end
    for wave = 1, max_depth do
        local new = {}
        for i = 1, #all do
            local a = all[i]
            for j = 1, #frontier do
                local b = frontier[j]
                for _, c in ipairs(children_of(a, b)) do
                    if known[c] == nil and new[c] == nil then
                        new[c] = { a, b }
                    end
                end
            end
        end
        local added = {}
        for c, par in pairs(new) do
            known[c] = par
            depths[c] = wave
            all[#all + 1] = c
            added[#added + 1] = c
        end
        if #added == 0 then break end
        if stop_at and known[stop_at] then break end
        frontier = added
    end
    return known, depths
end

local function cached_closure(owned)
    local known = closure_cache[owned]
    if known then return known end
    local depths
    known, depths = build_closure(owned, MAX_WAVES)
    closure_cache[owned] = known
    depth_cache[owned] = depths
    cache_stats.closure_builds = cache_stats.closure_builds + 1
    return known
end

local function cached_depths(owned)
    if not depth_cache[owned] then cached_closure(owned) end
    return depth_cache[owned]
end

function M.plan(owned, target_id, max_depth)
    if owned[target_id] then return {} end
    -- A caller-supplied depth is a distinct query and must retain its exact
    -- limit. Normal UI calls share the full cached closure instead of running
    -- the same BFS again for every candidate row or tab switch.
    local known = max_depth and build_closure(owned, max_depth, target_id)
        or cached_closure(owned)
    if next(known) == nil then return nil end
    if known[target_id] == nil then return nil end
    -- reconstruct steps, dedup intermediates
    local steps, done = {}, {}
    local function expand(sp)
        local par = known[sp]
        if par == false or par == nil or done[sp] then return end
        done[sp] = true
        expand(par[1])
        expand(par[2])
        steps[#steps + 1] = { a = par[1], b = par[2], c = sp }
    end
    expand(target_id)
    return steps
end

-- ---------------------------------------------------------------------------
-- Constraint-aware route optimizer (Stage 1/2 core)
-- ---------------------------------------------------------------------------
-- The legacy plan() above remains the fast zero-configuration path. This
-- optimizer is invoked only after the user adds passives/IV/skill/lock
-- constraints. It keeps exact individuals at the leaves, retains a bounded
-- Pareto-like beam for every reachable species, then ranks final routes by
-- expected eggs rather than by generation count alone.

local producer_index
local function get_producer_index()
    if producer_index then return producer_index end
    producer_index = {}
    for i = 1, #data.pals do
        local a = data.pals[i].id
        for j = i, #data.pals do
            local b = data.pals[j].id
            -- direction-locked recipes: remember which SPECIES must be the
            -- male parent for each child, so the search cannot claim a child
            -- from exact individuals whose genders contradict the direction
            local pa, pb = by_id[a], by_id[b]
            local direction_by_child
            if pa and pb then
                local g = gendered[pair_key(pa.tribe, pb.tribe)]
                if g then
                    direction_by_child = {}
                    for _, u in ipairs(g) do
                        local side_a = by_tribe[u.a] or pa   -- u.a/u.b are tribes
                        local side_b = by_tribe[u.b] or pb
                        direction_by_child[u.c] =
                            (u.ga == "Male") and side_a.id or side_b.id
                    end
                end
            end
            for _, c in ipairs(children_of(a, b)) do
                local list = producer_index[c]
                if not list then list = {} producer_index[c] = list end
                local entry = { a = a, b = b }
                if direction_by_child and direction_by_child[c] then
                    entry.male_species = direction_by_child[c]
                end
                list[#list + 1] = entry
            end
        end
    end
    return producer_index
end

local target_distance_cache = {}
local function target_parent_distances(target_id, horizon)
    local cache_key = target_id .. ":" .. tostring(horizon)
    local cached = target_distance_cache[cache_key]
    if cached then return cached end
    local producers = get_producer_index()
    local dist, frontier = { [target_id] = 0 }, { target_id }
    for depth = 1, math.max(0, horizon - 1) do
        local next_frontier = {}
        for _, child in ipairs(frontier) do
            for _, pair in ipairs(producers[child] or {}) do
                local pa, pb = pair.a, pair.b
                if dist[pa] == nil then
                    dist[pa] = depth
                    next_frontier[#next_frontier + 1] = pa
                end
                if dist[pb] == nil then
                    dist[pb] = depth
                    next_frontier[#next_frontier + 1] = pb
                end
            end
        end
        frontier = next_frontier
        if #frontier == 0 then break end
    end
    target_distance_cache[cache_key] = dist
    return dist
end

local function set_from_list(list)
    local out = {}
    for _, v in ipairs(list or {}) do out[v] = true end
    return out
end

local function set_copy(src)
    local out = {}
    for k in pairs(src or {}) do out[k] = true end
    return out
end

local function map_copy(src)
    local out = {}
    for k, v in pairs(src or {}) do out[k] = v end
    return out
end

local function set_union(a, b)
    local out = set_copy(a)
    for k in pairs(b or {}) do out[k] = true end
    return out
end

local function set_count(src)
    local n = 0
    for _ in pairs(src or {}) do n = n + 1 end
    return n
end

local function sorted_set_values(src)
    local out = {}
    for value in pairs(src or {}) do out[#out + 1] = value end
    table.sort(out)
    return out
end

local function set_contains_all(have, wanted)
    for k in pairs(wanted or {}) do if not have[k] then return false end end
    return true
end


local function set_intersection(a, b)
    local out = {}
    for k in pairs(a or {}) do if b and b[k] then out[k] = true end end
    return out
end

local SOURCE_POLICY_DEFAULTS = {
    direct = true,
    reusable = true,
    consumable = true,
    random = true,
    lucky = true,
    fishing = true,
    mutation = true,
    world = true,
}

local function source_enabled(c, key)
    return not c.sources or c.sources[key] ~= false
end

local function normalize_constraints(raw)
    raw = raw or {}
    local function sorted_unique(list)
        local out, seen = {}, {}
        for _, value in ipairs(list or {}) do
            if value ~= nil and not seen[value] then
                seen[value] = true
                out[#out + 1] = value
            end
        end
        table.sort(out)
        return out
    end
    local source_policy = {}
    for key, default in pairs(SOURCE_POLICY_DEFAULTS) do
        local value = raw.sources and raw.sources[key]
        source_policy[key] = value == nil and default or value ~= false
    end
    local c = {
        passives = set_from_list(raw.passives),
        optional_passives = set_from_list(raw.optional_passives),
        skills = set_from_list(raw.skills),
        iv = raw.iv or {},
        locked = set_from_list(raw.locked),
        allow_junk = raw.allow_junk ~= false,
        -- 再配一只: individuals that ALREADY satisfy every hard constraint
        -- stop counting as an answer (the zero-step "you own it" route) but
        -- remain fully usable as parents/surgery bases inside new routes.
        rebreed = raw.rebreed == true,
        -- 性转药 (2.10.0): gender mismatches between owned parents relax to
        -- potion marks; normalize_constraints is a WHITELIST copy, so the
        -- flag must be carried explicitly (the e2e test caught it dropped)
        gender_potion = raw.gender_potion == true,
        -- talent gate (2.16.x): normalize is a WHITELIST copy — same lesson
        -- as gender_potion above, the flag must be carried explicitly (the
        -- gate e2e caught it dropped on the first draft too)
        iv_hidden = raw.iv_hidden == true,
        final_gender = raw.final_gender or "Any",
        cake = raw.cake or "normal",
        batch = math.max(1, tonumber(raw.batch) or 1),
        max_steps = math.max(1, math.min(MAX_WAVES, tonumber(raw.max_steps) or 10)),
        max_iterations = math.max(1, math.min(MAX_WAVES, tonumber(raw.max_iterations) or 3)),
        sources = source_policy,
    }
    c.passive_ids = sorted_unique(raw.passives)
    c.optional_passive_ids = sorted_unique(raw.optional_passives)
    c.skill_ids = sorted_unique(raw.skills)
    c.locked_ids = sorted_unique(raw.locked)
    c.iv_ids = {}
    for stat in pairs(c.iv) do c.iv_ids[#c.iv_ids + 1] = stat end
    table.sort(c.iv_ids)
    return c
end

local passive_meta_by_id = {}
for _, entry in ipairs(data.pdb or {}) do passive_meta_by_id[entry.id] = entry end
local skill_meta_by_id = {}
for _, entry in ipairs(data.skills or {}) do skill_meta_by_id[entry.id] = entry end

-- Junk = real passives on an exact individual that are neither required nor
-- optional. They dilute inheritance (the union the child draws from grows),
-- so routes carry the junk total of their owned leaves: the beam keeps the
-- cleaner parent at equal capability and the final ordering breaks ties on it.
local function instance_junk(inst, c)
    local n = 0
    for _, id in ipairs(inst and inst.passives or {}) do
        if not (c.passives[id] or c.optional_passives[id]) then n = n + 1 end
    end
    return n
end

-- Soft IV preference (2.16.0): the three panel-relevant talents. Melee is
-- excluded on the datamined + PalCalc-consensus grounds that pals never
-- auto-attack, so Talent_Melee feeds no displayed stat; the raw value stays
-- in inst.iv for the day the game changes.
local IV_SOFT_STATS = { "hp", "shot", "defense" }
local function instance_iv_sum(inst)
    local n = 0
    for _, stat in ipairs(IV_SOFT_STATS) do
        n = n + (inst and inst.iv and tonumber(inst.iv[stat]) or 0)
    end
    return n
end
M._instance_iv_sum = instance_iv_sum   -- pinned by tools/test_v13.py (2.16.0)
M._IV_SOFT_STATS = IV_SOFT_STATS       -- shared with ui.lua's IV formatters

local function instance_caps(inst, c)
    local cap = { passives = {}, iv = {}, skills = {}, locks = {} }
    if not inst then return cap end
    for _, id in ipairs(inst.passives or {}) do
        if c.passives[id] or c.optional_passives[id] then cap.passives[id] = true end
    end
    for stat, threshold in pairs(c.iv) do
        local value = inst.iv and inst.iv[stat]
        if value ~= nil and value >= threshold then cap.iv[stat] = true end
    end
    for _, id in ipairs(inst.equipped_skills or {}) do
        if c.skills[id] then cap.skills[id] = true end
    end
    if inst.key and c.locked[inst.key] then cap.locks[inst.key] = true end
    return cap
end

local function merge_caps(a, b)
    return {
        passives = set_union(a.passives, b.passives),
        iv = set_union(a.iv, b.iv),
        skills = set_union(a.skills, b.skills),
        locks = set_union(a.locks, b.locks),
    }
end

local function missing_caps(cap, c)
    local n = 0
    for id in pairs(c.passives) do if not cap.passives[id] then n = n + 1 end end
    for id in pairs(c.skills) do if not cap.skills[id] then n = n + 1 end end
    for id in pairs(c.locked) do if not cap.locks[id] then n = n + 2 end end
    return n
end

local function cap_key(cap, c)
    local out = {}
    for _, id in ipairs(c.passive_ids) do out[#out + 1] = cap.passives[id] and "1" or "0" end
    out[#out + 1] = "/"
    for _, id in ipairs(c.optional_passive_ids) do out[#out + 1] = cap.passives[id] and "1" or "0" end
    out[#out + 1] = "/"
    -- IV thresholds affect the final probability estimate, but not breeding
    -- reachability. Keeping four IV bits in the semantic state multiplied the
    -- working set by up to 16 for little practical value.
    for _, id in ipairs(c.skill_ids) do out[#out + 1] = cap.skills[id] and "1" or "0" end
    out[#out + 1] = "/"
    for _, id in ipairs(c.locked_ids) do out[#out + 1] = cap.locks[id] and "1" or "0" end
    return table.concat(out)
end

local function label_less(a, b)
    if a.acquire_count ~= b.acquire_count then return a.acquire_count < b.acquire_count end
    if (a.operation_count or 0) ~= (b.operation_count or 0) then
        return (a.operation_count or 0) < (b.operation_count or 0)
    end
    if a.max_capture_score ~= b.max_capture_score then return a.max_capture_score < b.max_capture_score end
    if a.rng_traits ~= b.rng_traits then return a.rng_traits < b.rng_traits end
    if a.step_count ~= b.step_count then return a.step_count < b.step_count end
    -- bh-035 owner ruling: potions rank strictly BELOW generation depth —
    -- a potion that saves a generation wins (step decided above), and at
    -- equal depth the potion-free route wins (decided here). Surgery ops
    -- keep their historical pre-depth position on purpose.
    if (a.potion_count or 0) ~= (b.potion_count or 0) then
        return (a.potion_count or 0) < (b.potion_count or 0)
    end
    if (a.junk_traits or 0) ~= (b.junk_traits or 0) then
        return (a.junk_traits or 0) < (b.junk_traits or 0)
    end
    -- Soft IV preference (2.16.0 owner ruling): IVs rank BELOW every trait/
    -- resource dimension — they break ties only, and deliberately stay OUT
    -- of dominates/beam state: a maximize axis in the Pareto front would
    -- inflate it with "worse plan but shinier parents" survivors (PalCalc's
    -- issue #22 landed on the same tiebreaker-only shape).
    if (a.iv_sum or 0) ~= (b.iv_sum or 0) then
        return (a.iv_sum or 0) > (b.iv_sum or 0)
    end
    return a.signature < b.signature
end

local function dominates(a, b)
    local no_worse = a.acquire_count <= b.acquire_count
        and (a.operation_count or 0) <= (b.operation_count or 0)
        and a.max_capture_score <= b.max_capture_score
        and a.rng_traits <= b.rng_traits
        and a.step_count <= b.step_count
        and (a.potion_count or 0) <= (b.potion_count or 0)
        and (a.junk_traits or 0) <= (b.junk_traits or 0)
    if not no_worse then return false end
    return a.acquire_count < b.acquire_count
        or (a.operation_count or 0) < (b.operation_count or 0)
        or a.max_capture_score < b.max_capture_score
        or a.rng_traits < b.rng_traits
        or a.step_count < b.step_count
        or (a.potion_count or 0) < (b.potion_count or 0)
        or (a.junk_traits or 0) < (b.junk_traits or 0)
end
M._label_less = label_less   -- pinned by tools/test_v13.py (bh-035 ordering)

local function flatten_bucket(bucket)
    local out = {}
    if not bucket then return out end
    for _, list in pairs(bucket.by_state) do
        for _, route in ipairs(list) do out[#out + 1] = route end
    end
    return out
end

-- Insert a semantic label. Exact capability states keep a small Pareto front;
-- this is the crucial difference from the old "first four routes" beam.
local function insert_label(work, route, c, per_state, per_species)
    if route.step_count > c.max_steps then return false end
    local bucket = work[route.species]
    if not bucket then bucket = { by_state = {}, count = 0 } work[route.species] = bucket end
    local key = route.state_key or cap_key(route.cap, c)
    route.state_key = key
    local list = bucket.by_state[key]
    if not list then list = {} bucket.by_state[key] = list end
    for _, old in ipairs(list) do
        if old.signature == route.signature then return false end
    end
    -- Keep a few varied routes even when one Pareto-dominates another. This
    -- gives the UI meaningful alternatives (different exact individuals or
    -- bridges) while the hard per-state cap still prevents cyclic explosion.
    if #list >= per_state then
        local dominated = false
        for _, old in ipairs(list) do if dominates(old, route) then dominated = true break end end
        if dominated then return false end
    end
    list[#list + 1] = route
    route.in_work = true   -- cleared on every eviction: the delta wave must
                           -- never keep breeding descendants of pruned routes
    bucket.count = bucket.count + 1
    table.sort(list, label_less)
    while #list > per_state do
        list[#list].in_work = false
        table.remove(list)
        bucket.count = bucket.count - 1
    end
    local survived = false
    for _, kept in ipairs(list) do
        if kept.signature == route.signature then survived = true break end
    end
    if not survived then return false end
    if bucket.count > per_species then
        -- the bucket holds exactly per_species+1 routes here, so dropping the
        -- single worst under (missing_caps, label_less) is byte-identical to
        -- the old flatten+sort(49)+rebuild, without the churn. missing_caps
        -- is state-derived, so caching it per route is sound.
        local worst_state, worst_index, worst_route
        for state, routes in pairs(bucket.by_state) do
            for i, kept in ipairs(routes) do
                if kept.missing_count == nil then
                    kept.missing_count = missing_caps(kept.cap, c)
                end
                if not worst_route then
                    worst_state, worst_index, worst_route = state, i, kept
                else
                    local worse
                    if kept.missing_count ~= worst_route.missing_count then
                        worse = kept.missing_count > worst_route.missing_count
                    else
                        worse = label_less(worst_route, kept)
                    end
                    if worse then
                        worst_state, worst_index, worst_route = state, i, kept
                    end
                end
            end
        end
        worst_route.in_work = false
        table.remove(bucket.by_state[worst_state], worst_index)
        if #bucket.by_state[worst_state] == 0 then bucket.by_state[worst_state] = nil end
        bucket.count = bucket.count - 1
        return worst_route ~= route
    end
    return true
end

local function virtual_instance(species)
    return {
        key = "species:" .. species,
        stable_id = false,
        virtual = true,   -- species-level stand-in, NOT an exact individual:
                          -- exempt from the same-individual pairing guard
        species = species,
        gender = "Any",
        passives = {}, iv = {}, equipped_skills = {},
        source = "legacy", location = "legacy",
    }
end

local function leaf_route(species, inst, c)
    local cap = instance_caps(inst, c)
    local pure = cap_key(cap, c)
    return {
        species = species,
        kind = "owned",
        inst = inst,
        cap = cap,
        -- gender participates in the per-state front for EXACT leaves: with
        -- identical caps the beam could otherwise evict the only male, and
        -- consider_pair would then find no feasible pairing at all. The
        -- union key stays pure so bred children's states are unaffected.
        state_key = pure .. "|" .. (inst.gender or "Any"),
        union_key = pure,
        step_count = 0,
        acquire_count = 0,
        operation_count = 0,
        potion_count = 0,
        max_capture_score = 0,
        rng_traits = 0,
        junk_traits = instance_junk(inst, c),
        -- talent gate (owner ruling 2026-07-27): before the Ability Glasses
        -- tech the planner must behave as if IVs do not exist — a zero sum
        -- makes every IV comparison a tie, which falls through to the exact
        -- pre-2.16 ordering
        iv_sum = c.iv_hidden and 0 or instance_iv_sum(inst),
        signature = "O:" .. tostring(inst.key),
    }
end

local function acquire_route(species, cap, acquisition, c)
    local key = cap_key(cap, c)
    -- copy the descriptor before annotating it: mutating the shared input
    -- object would leak this route's passive list into every other route
    -- built from the same acquisition source
    local own = {}
    for k, v in pairs(acquisition) do own[k] = v end
    acquisition = own
    acquisition.passives, acquisition.skills = {}, {}
    for id in pairs(cap.passives) do acquisition.passives[#acquisition.passives + 1] = id end
    for id in pairs(cap.skills) do acquisition.skills[#acquisition.skills + 1] = id end
    table.sort(acquisition.passives)
    table.sort(acquisition.skills)
    return {
        species = species,
        kind = "acquire",
        inst = acquisition.base_inst,
        acquisition = acquisition,
        cap = cap,
        -- exact-surgery roots mirror owned-leaf state semantics (bh-035
        -- codex r2): gendered state bucket so M/F variants of one body
        -- shape don't crowd a single pure-capability slot pair, plus the
        -- pure union key so pairing still competes head-to-head on
        -- capability. Promise-style acquisitions keep state_key nil and
        -- fall back to insert_label's computed capability bucket.
        state_key = acquisition.kind == "surgery" and acquisition.base_inst
            and (key .. "|" .. (acquisition.base_inst.gender or "Any")) or nil,
        union_key = acquisition.kind == "surgery" and acquisition.base_inst
            and key or nil,
        step_count = 0,
        acquire_count = acquisition.count or 1,
        operation_count = 0,
        potion_count = 0,
        max_capture_score = acquisition.score or 999,
        rng_traits = acquisition.rng_traits or 0,
        -- surgery on an EXACT owned individual keeps that body's real junk;
        -- promised captures are assumed clean (their randomness is priced
        -- separately through rng_traits)
        junk_traits = instance_junk(acquisition.base_inst, c),
        -- promises carry no body, so no IV information: 0 is neutral — any
        -- owned-vs-promise contest is decided long before the IV tiebreak
        -- (acquire_count ranks first in every comparator)
        iv_sum = c.iv_hidden and 0 or instance_iv_sum(acquisition.base_inst),
        -- exact-surgery variants are per-INDIVIDUAL (bh-035 codex r1: the
        -- pairing gates now read gender/identity off them) — without the
        -- body's key two same-cap bodies of different gender collapse into
        -- one label and the survivor's gender wins by enumeration order
        signature = "A:" .. species .. ":" .. key .. ":" .. tostring(acquisition.kind)
            .. (acquisition.kind == "surgery" and acquisition.base_inst
                and acquisition.base_inst.key
                and (":" .. tostring(acquisition.base_inst.key)) or "")
            .. (acquisition.source_key and (":" .. acquisition.source_key) or ""),
    }
end

local function breed_route(child, left, right, state_key, pair_potion)
    local sa, sb = left.signature, right.signature
    if sb < sa then sa, sb = sb, sa end
    return {
        species = child,
        kind = "breed",
        left = left,
        right = right,
        cap = merge_caps(left.cap, right.cap),
        step_count = left.step_count + right.step_count + 1,
        acquire_count = left.acquire_count + right.acquire_count,
        operation_count = (left.operation_count or 0) + (right.operation_count or 0),
        -- bh-035 owner ruling: the potion is priced as its own dimension —
        -- a same-gender EXACT pair costs one potion AT THIS STEP; the count
        -- never trades against surgery ops and ranks strictly below
        -- generation depth in every comparator (potions may buy depth,
        -- never the other way round)
        potion_count = (left.potion_count or 0) + (right.potion_count or 0)
            + (pair_potion or 0),
        max_capture_score = math.max(left.max_capture_score, right.max_capture_score),
        rng_traits = left.rng_traits + right.rng_traits,
        junk_traits = (left.junk_traits or 0) + (right.junk_traits or 0),
        iv_sum = (left.iv_sum or 0) + (right.iv_sum or 0),
        signature = child .. "(" .. sa .. "," .. sb .. ")",
        state_key = state_key,
    }
end

-- bh-035 (codex r1 MAJOR): the EXACT-individual view of a parent node.
-- Three shapes carry a concrete body whose identity and gender are fixed:
-- owned leaves; operate wrappers (defensive alignment only — today they
-- wrap ONLY bred bases (post_breed_surgery_variants hard-gates on
-- kind=="breed"), so the unwrap loop cannot reach an owned leaf; opus r1
-- pinned that, keep the loop for structural honesty not as a live gate);
-- and exact-surgery acquisitions (add_surgery_variants tags
-- acquisition.kind="surgery" ONLY when base_inst is a real owned body,
-- while "capture-surgery" promises a NEW individual and stays gender-free).
-- consider_pair's identity/gender/direction gates and the display pass
-- (apply_intermediate_gender) must share this one definition, or the two
-- sides disagree about which pairs exist and which need the potion.
local function exact_inst(node)
    while node and node.kind == "operate" do node = node.base end
    if not node then return nil end
    if node.kind == "owned" then return node.inst end
    if node.kind == "acquire" and node.acquisition
        and node.acquisition.kind == "surgery" then
        return node.inst
    end
    return nil
end
M._exact_inst = exact_inst   -- pinned by tools/test_v13.py (bh-035)

-- A query has very few semantic capability states (three requested passives
-- means only eight masks), while a dense breeding wave can examine hundreds
-- of thousands of exact route pairs.  Cache state union by the compact key so
-- rejected pairs do not allocate four capability maps and a full tree string.
local state_union_cache = {}
local function union_state_key(a, b)
    a, b = tostring(a or ""), tostring(b or "")
    if b < a then a, b = b, a end
    -- two-level table lookup instead of a concatenated string key: this runs
    -- once per raw pair, and the concat was interning a fresh string each time
    local row = state_union_cache[a]
    if not row then row = {} state_union_cache[a] = row end
    local cached = row[b]
    if cached then return cached end
    local out = {}
    for i = 1, math.max(#a, #b) do
        local ca, cb = a:sub(i, i), b:sub(i, i)
        if ca == "1" or cb == "1" then
            out[i] = "1"
        elseif ca == "/" or cb == "/" then
            out[i] = "/"
        else
            out[i] = "0"
        end
    end
    cached = table.concat(out)
    row[b] = cached
    return cached
end

local function pair_less(a, b)
    if a.acquire_count ~= b.acquire_count then return a.acquire_count < b.acquire_count end
    if (a.operation_count or 0) ~= (b.operation_count or 0) then
        return (a.operation_count or 0) < (b.operation_count or 0)
    end
    if a.max_capture_score ~= b.max_capture_score then return a.max_capture_score < b.max_capture_score end
    if a.rng_traits ~= b.rng_traits then return a.rng_traits < b.rng_traits end
    if a.step_count ~= b.step_count then return a.step_count < b.step_count end
    -- bh-035: potion strictly below depth (see label_less)
    if (a.potion_count or 0) ~= (b.potion_count or 0) then
        return (a.potion_count or 0) < (b.potion_count or 0)
    end
    if (a.junk_traits or 0) ~= (b.junk_traits or 0) then
        return (a.junk_traits or 0) < (b.junk_traits or 0)
    end
    -- soft IV tiebreak, same slot as label_less (below junk, above signature)
    if (a.iv_sum or 0) ~= (b.iv_sum or 0) then
        return (a.iv_sum or 0) > (b.iv_sum or 0)
    end
    if a.sa ~= b.sa then return a.sa < b.sa end
    return a.sb < b.sb
end

local function pair_dominates(a, b)
    local no_worse = a.acquire_count <= b.acquire_count
        and (a.operation_count or 0) <= (b.operation_count or 0)
        and a.max_capture_score <= b.max_capture_score
        and a.rng_traits <= b.rng_traits
        and a.step_count <= b.step_count
        and (a.potion_count or 0) <= (b.potion_count or 0)
        and (a.junk_traits or 0) <= (b.junk_traits or 0)
    if not no_worse then return false end
    return a.acquire_count < b.acquire_count
        or (a.operation_count or 0) < (b.operation_count or 0)
        or a.max_capture_score < b.max_capture_score
        or a.rng_traits < b.rng_traits
        or a.step_count < b.step_count
        or (a.potion_count or 0) < (b.potion_count or 0)
        or (a.junk_traits or 0) < (b.junk_traits or 0)
end
M._pair_less = pair_less   -- pinned by tools/test_v13.py (bh-035 ordering)
-- dominance stays IV-free BY RULING (2.16.0): exported so the suite can pin
-- that a shinier-parents route never dominates (only outranks ties)
M._dominates = dominates
M._pair_dominates = pair_dominates

local retain_pair_candidate   -- defined below; forward-declared so the
                              -- reference inside consider_pair binds the
                              -- LOCAL, not a nil global

-- Scalar-first pair consideration. The overwhelming majority of raw pairs
-- die against the local front, so nothing is allocated until a candidate has
-- actually earned a slot (2026-07-15 analysis: the per-pair ten-field table
-- was the largest CPU/GC term after frame scheduling). Outcome is exactly
-- retain_pair_candidate over pair_candidate -- rejection order mirrors it.
local function consider_pair(candidates, left, right, c, limit, male_side)
    local steps = left.step_count + right.step_count + 1
    if steps > c.max_steps then return end
    -- Gender feasibility for EXACT owned leaves (bred intermediates roll
    -- their gender, acquisitions pick one, so only kind=="owned" is strict):
    -- the same individual cannot be both parents, two known same-gender
    -- individuals cannot pair, and a direction-locked recipe pins which side
    -- must be male. Bred/acquired branches stay flexible by design.
    -- bh-035 audit (codex r1 MAJOR): read the gates off the shared
    -- exact-individual view — surgery keeps the same body and gender, so a
    -- surgery variant (operate wrapper OR exact-surgery acquire) must pass
    -- the same identity/gender/direction gates as its base leaf. Before
    -- this, exact-surgery acquire nodes slipped past ALL three gates as
    -- "not owned" and paid no potion.
    local li = exact_inst(left)
    local ri = exact_inst(right)
    if li and ri then
        if li.key == ri.key and not (li.virtual or ri.virtual) then return end
        -- 2.10.0 gender-potion mode (owner promise, top-voted request): a
        -- same-gender pair IS pairable — the player reassigns one at the
        -- OperatingTable (帕鲁性转药). Planning relaxes; dispatch stays
        -- strict (resolve_step_parents still refuses live same-gender).
        if not c.gender_potion
            and li.gender ~= "Any" and li.gender == ri.gender then return end
    end
    if male_side then
        -- direction-locked recipes stay STRICT even in potion mode (codex
        -- 2.10 r1 MAJOR): every gendered recipe on 1.0 data is a MIRRORED
        -- pair, so the direction matching the actual genders is already
        -- enumerated as its sibling recipe — softening this gate produced
        -- candidates whose real offspring is the SIBLING's child (CatMage♀
        -- × FoxMage♂ listed as the FoxMage_Dark route, actually breeds
        -- CatMage_Fire), with no potion mark and a dispatchable pair.
        if li and li.gender ~= "Any" then
            if male_side == "left" and li.gender ~= "M" then return end
            if male_side == "right" and li.gender ~= "F" then return end
        end
        if ri and ri.gender ~= "Any" then
            if male_side == "right" and ri.gender ~= "M" then return end
            if male_side == "left" and ri.gender ~= "F" then return end
        end
    end
    local acquire = left.acquire_count + right.acquire_count
    local ops = (left.operation_count or 0) + (right.operation_count or 0)
    -- bh-035: a same-gender EXACT pair only exists because the player will
    -- spend one 性转药 on it — price that potion into the pair so M+M never
    -- beats an equally-deep M+F for free (the old zero-cost tie let the
    -- signature tiebreak "prefer" same-gender pairs).
    local pair_potion = 0
    -- explicit M/F check = display-side leaf_gender's predicate (opus r1
    -- NIT-5): any future third gender value must price NO ghost potion
    -- rather than a priced-but-unmarked one
    if li and ri and c.gender_potion
        and (li.gender == "M" or li.gender == "F")
        and li.gender == ri.gender then
        pair_potion = 1
    end
    local potion = (left.potion_count or 0) + (right.potion_count or 0) + pair_potion
    local capture = math.max(left.max_capture_score, right.max_capture_score)
    local rng = left.rng_traits + right.rng_traits
    local junk = (left.junk_traits or 0) + (right.junk_traits or 0)
    local ivs = (left.iv_sum or 0) + (right.iv_sum or 0)
    local state = union_state_key(left.union_key or left.state_key or cap_key(left.cap, c),
                                  right.union_key or right.state_key or cap_key(right.cap, c))
    local sa, sb = left.signature, right.signature
    if sb < sa then sa, sb = sb, sa end
    local list = candidates[state]
    if list then
        local dominates_some = false
        for _, old in ipairs(list) do
            if old.sa == sa and old.sb == sb then return end
            local o_ops = old.operation_count or 0
            local o_pot = old.potion_count or 0
            local o_junk = old.junk_traits or 0
            if old.acquire_count <= acquire and o_ops <= ops
                    and old.max_capture_score <= capture and old.rng_traits <= rng
                    and old.step_count <= steps and o_pot <= potion and o_junk <= junk
                    and (old.acquire_count < acquire or o_ops < ops
                         or old.max_capture_score < capture or old.rng_traits < rng
                         or old.step_count < steps or o_pot < potion or o_junk < junk) then
                return
            end
            if not dominates_some
                    and acquire <= old.acquire_count and ops <= o_ops
                    and capture <= old.max_capture_score and rng <= old.rng_traits
                    and steps <= old.step_count and potion <= o_pot and junk <= o_junk
                    and (acquire < old.acquire_count or ops < o_ops
                         or capture < old.max_capture_score or rng < old.rng_traits
                         or steps < old.step_count or potion < o_pot or junk < o_junk) then
                dominates_some = true
            end
        end
        if #list >= limit and not dominates_some then
            -- the list stays sorted by pair_less, so unless the new values
            -- beat the current worst, append+sort+trim would drop them again
            local worst = list[#list]
            local better
            if acquire ~= worst.acquire_count then better = acquire < worst.acquire_count
            elseif ops ~= (worst.operation_count or 0) then better = ops < (worst.operation_count or 0)
            elseif capture ~= worst.max_capture_score then better = capture < worst.max_capture_score
            elseif rng ~= worst.rng_traits then better = rng < worst.rng_traits
            elseif steps ~= worst.step_count then better = steps < worst.step_count
            elseif potion ~= (worst.potion_count or 0) then better = potion < (worst.potion_count or 0)
            elseif junk ~= (worst.junk_traits or 0) then better = junk < (worst.junk_traits or 0)
            elseif ivs ~= (worst.iv_sum or 0) then better = ivs > (worst.iv_sum or 0)
            elseif sa ~= worst.sa then better = sa < worst.sa
            else better = sb < worst.sb end
            if not better then return end
        end
    end
    retain_pair_candidate(candidates, {
        left = left,
        right = right,
        state_key = state,
        step_count = steps,
        acquire_count = acquire,
        operation_count = ops,
        potion_count = potion,
        pair_potion = pair_potion,
        max_capture_score = capture,
        rng_traits = rng,
        junk_traits = junk,
        iv_sum = ivs,
        sa = sa,
        sb = sb,
    }, limit)
end
M._consider_pair = consider_pair   -- pinned by tools/test_v13.py (bh-035
                                   -- gate unit fixtures hit the exact layer)

function retain_pair_candidate(candidates, candidate, limit)
    local list = candidates[candidate.state_key]
    if not list then list = {} candidates[candidate.state_key] = list end
    for _, old in ipairs(list) do
        if old.sa == candidate.sa and old.sb == candidate.sb then return end
        if pair_dominates(old, candidate) then return end
    end
    for i = #list, 1, -1 do
        if pair_dominates(candidate, list[i]) then table.remove(list, i) end
    end
    list[#list + 1] = candidate
    table.sort(list, pair_less)
    while #list > limit do table.remove(list) end
end

local function choose(n, k)
    if k < 0 or k > n then return 0 end
    if k == 0 or k == n then return 1 end
    k = math.min(k, n - k)
    local v = 1
    for i = 1, k do v = v * (n - k + i) / i end
    return v
end

-- P(a SPECIFIC set of `wanted_count` passives out of the `union_count`-sized
-- parents' union all inherit). Same math as ui.lua inherit_prob — the verified
-- law: inherited count k ~ weights [4,3,2,1] over 1..4, uniform subset of the
-- union, and a roll above the union size inherits the WHOLE union (this clamp
-- is what reproduces the community-verified 40/24/12/10 exact-set table; the
-- old open-form here silently disagreed with the calculator page at u<4).
-- 特制蛋糕 locks k=4, which still leaves a subset draw when the union is
-- larger than the four slots.
local INHERIT_COUNT_P = { [1] = 0.4, [2] = 0.3, [3] = 0.2, [4] = 0.1 }
local function passive_step_prob(union_count, wanted_count, special)
    if wanted_count == 0 then return 1 end
    if union_count < wanted_count or wanted_count > 4 then return 0 end
    if special then
        local k = math.min(4, union_count)
        if k < wanted_count then return 0 end
        return choose(union_count - wanted_count, k - wanted_count)
            / choose(union_count, k)
    end
    local p = 0
    for k = 1, 4 do
        local ke = math.min(k, union_count)
        if ke >= wanted_count then
            p = p + INHERIT_COUNT_P[k]
                * choose(union_count - wanted_count, ke - wanted_count)
                / choose(union_count, ke)
        end
    end
    return p
end
M._passive_step_prob = passive_step_prob   -- pinned by tools/test_v13.py

local IV_STATS = { "hp", "melee", "shot", "defense" }
local function talent_success(value, threshold, cake, random_roll)
    local boosted = cake == "mushroom" or cake == "deluxe"
    local bonuses = boosted and { 1, 2, 3, 4, 5 } or { 0 }
    local p = 0
    for _, bonus in ipairs(bonuses) do
        if random_roll then
            p = p + math.max(0, math.min(101, 101 - threshold + bonus)) / 101
        else
            p = p + ((value or -1) + bonus >= threshold and 1 or 0)
        end
    end
    return p / #bonuses
end

local function iv_subset_prob(left_values, right_values, thresholds, inherited, cake)
    local p = 1
    for _, stat in ipairs(IV_STATS) do
        local threshold = thresholds[stat]
        if threshold ~= nil then
            if inherited[stat] then
                p = p * (talent_success(left_values[stat], threshold, cake, false)
                    + talent_success(right_values[stat], threshold, cake, false)) / 2
            else
                p = p * talent_success(nil, threshold, cake, true)
            end
        end
    end
    return p
end

local function iv_step_prob(left_values, right_values, thresholds, cake)
    if next(thresholds) == nil then return 1 end
    local p = 0
    for _, stat in ipairs(IV_STATS) do
        p = p + 0.5 / 4 * iv_subset_prob(left_values, right_values, thresholds,
            { [stat] = true }, cake)
    end
    for _, stat in ipairs({ "melee", "shot", "defense" }) do
        p = p + 0.2 / 3 * iv_subset_prob(left_values, right_values, thresholds,
            { hp = true, [stat] = true }, cake)
    end
    p = p + 0.3 * iv_subset_prob(left_values, right_values, thresholds,
        { hp = true, melee = true, shot = true, defense = true }, cake)
    return p
end

local function evaluate_route(route, c, is_root, steps)
    if route.kind == "operate" then
        -- Surgery/implant is deterministic after the wrapped breeding step.
        -- Evaluate only what the child must inherit first, then expose the
        -- augmented capability set to every later generation.
        local base = evaluate_route(route.base, c, is_root, steps)
        base.passives = set_copy(route.cap.passives)
        base.iv = set_copy(route.cap.iv)
        base.skills = set_copy(route.cap.skills)
        base.pool_passives = set_union(base.pool_passives, route.cap.passives)
        return base
    end
    if route.kind == "owned" or route.kind == "acquire" then
        local inst = route.inst
        -- pool_passives = EVERY real passive on this body (junk included),
        -- not just the requested capabilities: the child rolls its inherit
        -- subset from the parents' full union, so junk dilutes every wanted
        -- trait. Promised captures have no known body -> capability set only.
        local pool = set_copy(route.cap.passives)
        for _, id in ipairs(inst and inst.passives or {}) do pool[id] = true end
        -- soft IV interval seed (2.16.0): an exact body pins each panel stat
        -- to a point range; promised captures/virtual leaves have no body,
        -- their stats stay absent (= unknown, renders as "?" downstream).
        -- Talent gate: hidden IVs seed NOTHING, so every step's hatch span
        -- stays fully unknown and the formatters print no readout at all.
        local leaf_lo, leaf_hi
        if inst and inst.iv and not c.iv_hidden then
            leaf_lo, leaf_hi = {}, {}
            for _, stat in ipairs(IV_SOFT_STATS) do
                local v = tonumber(inst.iv[stat])
                if v then leaf_lo[stat], leaf_hi[stat] = v, v end
            end
        end
        return {
            passives = set_copy(route.cap.passives),
            pool_passives = pool,
            iv = set_copy(route.cap.iv),
            iv_values = map_copy(inst and inst.iv or {}),
            iv_lo = leaf_lo,
            iv_hi = leaf_hi,
            skills = set_copy(route.cap.skills),
            eggs = 0,
            cakes = 0,
            probability = 1,
            path_probability = 1,
            leaf = inst,
        }
    end
    local left = evaluate_route(route.left, c, false, steps)
    local right = evaluate_route(route.right, c, false, steps)
    local out_passives = set_intersection(set_union(left.passives, right.passives), c.passives)
    local out_skills = set_union(left.skills, right.skills)
    local special = c.cake == "special"
    -- The union the child draws from includes the parents' junk/optional
    -- passives. Bred intermediates count as carrying exactly their step's
    -- acceptance set ("至少带" verified before use) — their possible extra
    -- junk is the remaining unmodeled optimism, now confined to intermediates.
    local union_pool = set_union(left.pool_passives or left.passives,
        right.pool_passives or right.passives)
    local pp = passive_step_prob(set_count(union_pool), set_count(out_passives), special)
    local ip = iv_step_prob(left.iv_values or {}, right.iv_values or {}, c.iv, c.cake)
    local sp = 1
    if next(out_skills) ~= nil and not special then sp = 0 end
    local gp = 1
    if is_root and c.final_gender ~= "Any" then gp = 0.5 end
    local success = pp * ip * sp * gp
    local attempts = success > 0 and (1 / success) or math.huge
    local eggs_per_cake = c.cake == "vegetable" and 2 or 1
    -- Soft IV interval (2.16.0): per panel stat, the child's INHERITED-case
    -- span is the parents' merged range (PalCalc IV_Value.Merge semantics).
    -- The reroll case (uniform 0-100; marginal miss rate 37.5% HP / 50.8%
    -- others under the verified three-mode law) is deliberately NOT folded
    -- in — the span answers "what can inheritance hand down"; any unknown
    -- parent poisons the stat to unknown (renders as "?").
    local child_lo, child_hi = {}, {}
    for _, stat in ipairs(IV_SOFT_STATS) do
        local ll = left.iv_lo and left.iv_lo[stat]
        local rl = right.iv_lo and right.iv_lo[stat]
        if ll and rl then
            child_lo[stat] = math.min(ll, rl)
            child_hi[stat] = math.max(left.iv_hi[stat], right.iv_hi[stat])
        end
    end
    local step = {
        a = route.left.species,
        b = route.right.species,
        c = route.species,
        route_signature = route.signature,
        a_key = left.leaf and left.leaf.key or nil,
        b_key = right.leaf and right.leaf.key or nil,
        passives = sorted_set_values(out_passives),
        skills = sorted_set_values(out_skills),
        iv = map_copy(c.iv),
        iv_range = { lo = child_lo, hi = child_hi },
        allow_junk = c.allow_junk,
        probability = success,
        expected_eggs = attempts,
        expected_cakes = attempts / eggs_per_cake,
        cake = c.cake,
        union_count = set_count(union_pool),
    }
    steps[#steps + 1] = step
    local out_iv = {}
    for stat in pairs(c.iv) do out_iv[stat] = true end
    return {
        passives = out_passives,
        pool_passives = set_copy(out_passives),
        iv = out_iv,
        iv_values = map_copy(c.iv),
        iv_lo = child_lo,
        iv_hi = child_hi,
        skills = out_skills,
        eggs = left.eggs + right.eggs + attempts,
        cakes = left.cakes + right.cakes + attempts / eggs_per_cake,
        probability = success,
        path_probability = left.path_probability * right.path_probability * success,
    }
end

local CAPTURE_TYPE_PENALTY = {
    Common = 0, RandomDungeonBoss = 8, FieldBoss = 14,
    ImprisonmentBoss = 16, RaidBoss = 24,
}

-- World Tree spawner rows live in a SEPARATE map canvas: their world
-- coords through the overworld affine print a plausible open-sea square
-- (field report 波鲁杰克斯 "(-725, 478)"). Filter at the SELECTION sites so
-- every downstream formatter inherits honesty (opus marker r1 M1: fixing
-- two render surfaces left three more printing the same wrong square).
local function is_worldtree_spot(spot)
    return spot and tostring(spot.name or ""):lower():find("worldtree", 1, true) ~= nil
end
M._is_worldtree_spot = is_worldtree_spot   -- offline test hooks
-- (capture_profile exported right below its definition)

local function capture_profile(species)
    local entry = data.capture and data.capture[species]
    local best
    for _, spot in ipairs(entry and entry.spots or {}) do
        if not is_worldtree_spot(spot) then
            local score = (tonumber(spot.min) or 99) + (CAPTURE_TYPE_PENALTY[spot.type] or 5)
            if not best or score < best.score then
                best = { score = score, level = tonumber(spot.min) or 99, spot = spot }
            end
        end
    end
    return best
end
M._capture_profile = capture_profile   -- offline test hook (worldtree filter)

-- World-Tree wild pool lookup (codex marker r2 MAJOR / opus r2 MINOR-1:
-- filtering worldtree rows out of capture_profile erased the LEGITIMATE
-- World Tree catch lane for the 24 tree-only species — 波鲁杰克斯 planned
-- ZERO routes). data.source_pals.world is the authoritative "spawns in the
-- tree" table; the index is built once on first use.
local worldtree_pal_index
local function worldtree_pal(species)
    if not worldtree_pal_index then
        worldtree_pal_index = {}
        for _, e in ipairs(data.source_pals and data.source_pals.world or {}) do
            worldtree_pal_index[e.id] = e
        end
    end
    return worldtree_pal_index[species]
end
M._worldtree_pal = worldtree_pal   -- shared with ui.lua's honest renderer

local function born_on(meta, species)
    for _, raw in ipairs(meta and meta.born or {}) do
        if normalize(raw) == species then return true end
    end
    return false
end

local function empty_cap()
    return { passives = {}, iv = {}, skills = {}, locks = {} }
end

local function copy_cap(cap)
    return {
        passives = set_copy(cap and cap.passives or {}),
        iv = set_copy(cap and cap.iv or {}),
        skills = set_copy(cap and cap.skills or {}),
        locks = set_copy(cap and cap.locks or {}),
    }
end

local function surgery_procedure(id, meta)
    local best_percent = 0
    for _, relic in ipairs(meta.relic or {}) do
        best_percent = math.max(best_percent, tonumber(relic.percent) or 0)
    end
    local expected_relics = best_percent > 0 and 100 / best_percent or nil
    local score
    if meta.surg == "direct" then
        score = 1 + (tonumber(meta.gold) or 0) / 50000
    elseif meta.surg == "reusable" then
        -- The implant is a one-time unlock; keep its score below repeatedly
        -- farming a disposable implant, but above a free direct operation.
        score = 8 + (tonumber(meta.mprice) or 0) / 4
    else
        score = 40 + (expected_relics or 200)
    end
    return {
        id = id,
        name = meta.zh or id,
        mode = meta.surg,
        gold = tonumber(meta.gold) or 0,
        item = meta.item or "",
        item_name = meta.itemzh or "",
        merchant = meta.merchant or "",
        currency = meta.currencyzh ~= "" and meta.currencyzh or meta.currency or "",
        merchant_price = tonumber(meta.mprice) or 0,
        relics = meta.relic or {},
        expected_relics = expected_relics,
        score = score,
    }
end

-- Four passive slots cap the subset space. Keeping every subset for one to
-- three available operations lets a route use, for example, two implants
-- while a locked parent contributes the third trait. With all four slots
-- surgical, retain singles, all-minus-one and all: enough useful trade-offs
-- without multiplying the hot search loop by the full 15-state power set.
local function surgery_variant_sets(available)
    local variants, count = {}, #available
    if count <= 3 then
        for mask = 1, 2 ^ count - 1 do
            local variant = {}
            for i = 1, count do
                if mask % (2 ^ i) >= 2 ^ (i - 1) then
                    variant[#variant + 1] = available[i]
                end
            end
            variants[#variants + 1] = variant
        end
        return variants
    end
    for i = 1, count do variants[#variants + 1] = { available[i] } end
    for omitted = 1, count do
        local variant = {}
        for i = 1, count do
            if i ~= omitted then variant[#variant + 1] = available[i] end
        end
        variants[#variants + 1] = variant
    end
    variants[#variants + 1] = available
    return variants
end

-- bh-035 representative picker (pure function, exported for tests): group
-- per-body capability entries by cap key, rank groups by (missing caps, cap
-- key), keep the historical FOUR capability states, then emit one
-- smallest-body-key representative per KNOWN gender inside each kept state.
-- raw entries: { cap=, key=, missing=, gender=, inst= }.
local function pick_surgery_reps(raw, iv_hidden)
    local groups, order = {}, {}
    for _, e in ipairs(raw) do
        local g = groups[e.key]
        if not g then
            g = { key = e.key, missing = e.missing, by_gender = {} }
            groups[e.key] = g
            order[#order + 1] = g
        end
        -- keep the WHOLE winning entry, not just the body: cap_key does not
        -- encode per-body payloads (iv, junk), so the emitted cap must come
        -- from the chosen representative or first-seen order leaks through
        -- the cap payload (codex r4)
        -- 2.16.0 soft IV preference: among same-cap same-gender bodies the
        -- highest IV total wins the slot; the key ordering stays as the
        -- final tiebreak so box iteration order still never matters
        local cur = g.by_gender[e.gender]
        if not cur then
            g.by_gender[e.gender] = e
        else
            -- talent gate: hidden IVs force the pure key ordering (the
            -- exact pre-2.16 pick), so the gate leaks nothing through
            -- WHICH body the plan happens to choose
            local ei = iv_hidden and 0 or instance_iv_sum(e.inst)
            local ci = iv_hidden and 0 or instance_iv_sum(cur.inst)
            if ei > ci or (ei == ci
                    and tostring(e.inst.key) < tostring(cur.inst.key)) then
                g.by_gender[e.gender] = e
            end
        end
    end
    table.sort(order, function(a, b)
        if a.missing ~= b.missing then return a.missing < b.missing end
        return a.key < b.key
    end)
    local out = {}
    for i = 1, math.min(4, #order) do
        local g = order[i]
        local genders = {}
        for gd in pairs(g.by_gender) do genders[#genders + 1] = gd end
        table.sort(genders)
        for _, gd in ipairs(genders) do
            local e = g.by_gender[gd]
            out[#out + 1] = { cap = e.cap, key = g.key, gender = gd,
                inst = e.inst }
        end
    end
    return out
end
M._pick_surgery_reps = pick_surgery_reps   -- pinned by tools/test_v13.py

local function add_surgery_variants(out, species, base_cap, base_inst, profile, c, base_source)
    local available = {}
    for _, id in ipairs(c.passive_ids) do
        if not base_cap.passives[id] and not (c.locked_passives and c.locked_passives[id]) then
            local meta = passive_meta_by_id[id]
            if meta and (meta.surg == "direct" or meta.surg == "reusable"
                    or meta.surg == "consumable")
                    and source_enabled(c, meta.surg) then
                available[#available + 1] = { id = id, meta = meta }
            end
        end
    end
    if #available == 0 then return end
    base_source = base_source or {}

    for _, variant in ipairs(surgery_variant_sets(available)) do
        local cap = copy_cap(base_cap)
        local template = base_source.acquisition or {}
        local procedures, total_gold = {}, tonumber(template.gold) or 0
        for _, procedure in ipairs(template.procedures or {}) do procedures[#procedures + 1] = procedure end
        local max_score = math.max(tonumber(template.score) or 0, profile and profile.score or 0)
        local random_passives = {}
        for id in pairs(base_source.random_passives or {}) do random_passives[#random_passives + 1] = id end
        table.sort(random_passives)
        local rng_traits = tonumber(template.rng_traits) or #random_passives
        local source_bits = { tostring(template.source_key or template.kind or "capture") }
        for _, entry in ipairs(variant) do
            cap.passives[entry.id] = true
            local procedure = surgery_procedure(entry.id, entry.meta)
            procedures[#procedures + 1] = procedure
            total_gold = total_gold + procedure.gold
            max_score = math.max(max_score, procedure.score)
            if procedure.mode == "consumable" then rng_traits = rng_traits + 1 end
            source_bits[#source_bits + 1] = procedure.mode .. "=" .. entry.id
        end
        table.sort(source_bits)
        local existing_slots = base_inst and #(base_inst.passives or {}) or 0
        local acquisition = {}
        for key, value in pairs(template) do acquisition[key] = value end
        local reasons = {}
        for key, value in pairs(template.reasons or {}) do reasons[key] = value end
        reasons.surgery = true
        acquisition.species = species
        acquisition.kind = base_inst and "surgery"
            or (template.kind or "capture-surgery")
        acquisition.count = tonumber(template.count) or 1
        acquisition.base_inst = base_inst or template.base_inst
        acquisition.score = max_score
        acquisition.level = template.level or (profile and profile.level or nil)
        acquisition.spot = template.spot or (profile and profile.spot or nil)
        acquisition.rng_traits = rng_traits
        acquisition.reasons = reasons
        acquisition.procedures = procedures
        acquisition.gold = total_gold
        acquisition.random_passives = random_passives
        acquisition.capture_passives = {}
        for id in pairs(base_cap.passives or {}) do
            acquisition.capture_passives[#acquisition.capture_passives + 1] = id
        end
        table.sort(acquisition.capture_passives)
        acquisition.source_key = table.concat(source_bits, "+")
        acquisition.replace_slots = math.max(0, existing_slots + #variant - 4)
        out[#out + 1] = acquire_route(species, cap, acquisition, c)
    end
end

-- Surgery is not only an acquisition-time action. Any child bred by the
-- solver can be operated on before it is used in the next generation. Keep a
-- unary wrapper in the route tree so the underlying step still asks for only
-- the passives it must inherit, while later steps see the implanted passives.
-- The subset helper keeps source composition exact for up to three surgical
-- traits while retaining a bounded Pareto-oriented set for four slots.
local function post_breed_surgery_variants(base, c)
    if not base or base.kind ~= "breed" then return {} end
    local available = {}
    for _, id in ipairs(c.passive_ids) do
        if not base.cap.passives[id] and not (c.locked_passives and c.locked_passives[id]) then
            local meta = passive_meta_by_id[id]
            if meta and (meta.surg == "direct" or meta.surg == "reusable"
                    or meta.surg == "consumable")
                    and source_enabled(c, meta.surg) then
                available[#available + 1] = { id = id, meta = meta }
            end
        end
    end
    if #available == 0 then return {} end

    local out = {}
    for _, variant in ipairs(surgery_variant_sets(available)) do
        local cap = copy_cap(base.cap)
        local procedures, added, source_bits = {}, {}, {}
        local total_gold, max_score, rng_traits = 0, base.max_capture_score, base.rng_traits
        for _, entry in ipairs(variant) do
            cap.passives[entry.id] = true
            added[#added + 1] = entry.id
            local procedure = surgery_procedure(entry.id, entry.meta)
            procedures[#procedures + 1] = procedure
            source_bits[#source_bits + 1] = procedure.mode .. "=" .. entry.id
            total_gold = total_gold + procedure.gold
            max_score = math.max(max_score, procedure.score)
            if procedure.mode == "consumable" then rng_traits = rng_traits + 1 end
        end
        table.sort(added)
        table.sort(source_bits)
        local required, inherited = sorted_set_values(cap.passives), sorted_set_values(base.cap.passives)
        local operation = {
            kind = "post-breed-surgery",
            species = base.species,
            passives = added,
            required_passives = required,
            inherited_passives = inherited,
            skills = {},
            procedures = procedures,
            gold = total_gold,
            score = max_score,
            rng_traits = rng_traits - base.rng_traits,
            source_key = table.concat(source_bits, "+"),
            base_signature = base.signature,
            replace_slots = math.max(0, set_count(base.cap.passives) + #variant - 4),
        }
        out[#out + 1] = {
            species = base.species,
            kind = "operate",
            base = base,
            operation = operation,
            cap = cap,
            step_count = base.step_count,
            acquire_count = base.acquire_count,
            operation_count = (base.operation_count or 0) + 1,
            potion_count = base.potion_count or 0,
            max_capture_score = max_score,
            rng_traits = rng_traits,
            junk_traits = base.junk_traits or 0,
            -- surgery never touches talents: the wrapper carries the base's
            -- IV payload through unchanged
            iv_sum = base.iv_sum or 0,
            signature = "S:" .. base.species .. ":" .. base.signature .. ":" .. operation.source_key,
            state_key = cap_key(cap, c),
        }
    end
    return out
end

local function special_source_profile(species, kind, entry)
    local level = tonumber(entry and entry.min) or 99
    local spot
    if kind == "world-tree" then
        for _, candidate in ipairs(data.capture and data.capture[species]
                and data.capture[species].spots or {}) do
            if tostring(candidate.name or ""):lower():find("worldtree", 1, true) then
                if not spot or (tonumber(candidate.min) or 99) < (tonumber(spot.min) or 99) then
                    spot = candidate
                end
            end
        end
    end
    return {
        level = level,
        spot = spot,
        score = level + (kind == "world-tree" and 45 or 25),
    }
end

local function add_special_acquisition(out, species, passive_id, kind, c, details)
    local cap = empty_cap()
    cap.passives[passive_id] = true
    details = details or {}
    local acquisition = {
        species = species,
        kind = kind,
        count = 1,
        score = details.score or 80,
        level = details.level,
        spot = details.spot,
        rng_traits = details.rng_traits or 1,
        reasons = { [kind] = true },
        source_parents = details.source_parents,
        normal_child = details.normal_child,
        expected_source_eggs = details.expected_source_eggs,
        expected_source_cakes = details.expected_source_cakes,
        expected_attempts = details.expected_attempts,
        source_note = details.source_note,
        source_key = kind .. "=" .. passive_id,
    }
    out[#out + 1] = acquire_route(species, cap, acquisition, c)
    -- Once a special carrier exists, enabled surgery/implant sources may add
    -- the remaining requested passives to that same individual. Without this
    -- composition the planner incorrectly forced every other trait through a
    -- second capture/breeding chain.
    add_surgery_variants(out, species, cap, nil, nil, c, { acquisition = acquisition })
end

local function relevant_special_pals(entries, target_id, target_distance, limit)
    local out, seen = {}, {}
    for _, entry in ipairs(entries or {}) do
        local species = normalize(entry.id)
        if species and not seen[species]
                and (species == target_id or target_distance[species] ~= nil) then
            seen[species] = true
            out[#out + 1] = {
                id = species,
                min = tonumber(entry.min) or 99,
                max = tonumber(entry.max) or tonumber(entry.min) or 99,
                distance = target_distance[species] or 0,
            }
        end
    end
    table.sort(out, function(a, b)
        if a.distance ~= b.distance then return a.distance < b.distance end
        if a.min ~= b.min then return a.min < b.min end
        return a.id < b.id
    end)
    while #out > (limit or 6) do table.remove(out) end
    return out
end

local function can_breed_owned_pair(owned, a, b)
    local oa, ob = owned[a] or {}, owned[b] or {}
    if a == b then return (oa.male or 0) > 0 and (oa.female or 0) > 0 end
    return ((oa.male or 0) > 0 and (ob.female or 0) > 0)
        or ((oa.female or 0) > 0 and (ob.male or 0) > 0)
end

-- Mutation species are not arbitrary: the verified 1.0 rule selects the
-- nearest normal-pool species around regular-child rank x [0.5, 0.6]. The two
-- endpoints plus every pool rank inside the interval enumerate all nearest-
-- neighbour cells without guessing a sampling stride.
local function mutation_source_candidates(owned, target_id, target_distance, limit)
    local ids = {}
    for species in pairs(owned or {}) do
        if by_id[species] then ids[#ids + 1] = species end
    end
    table.sort(ids)
    local outcomes = {}
    for i = 1, #ids do
        for j = i, #ids do
            local a, b = ids[i], ids[j]
            if can_breed_owned_pair(owned, a, b) then
                for _, regular in ipairs(children_of(a, b)) do
                    local child = by_id[regular]
                    if child then
                        local low, high = child.r * 0.5, child.r * 0.6
                        local targets = { low, high }
                        for _, candidate in ipairs(pool) do
                            if candidate.r >= low and candidate.r <= high then
                                targets[#targets + 1] = candidate.r
                            end
                        end
                        for _, target_rank in ipairs(targets) do
                            local species = nearest(target_rank).id
                            if (species == target_id or target_distance[species] ~= nil)
                                    and not outcomes[species] then
                                outcomes[species] = {
                                    id = species,
                                    a = a,
                                    b = b,
                                    normal_child = regular,
                                    distance = target_distance[species] or 0,
                                }
                            end
                        end
                    end
                end
            end
        end
    end
    local out = {}
    for _, entry in pairs(outcomes) do out[#out + 1] = entry end
    table.sort(out, function(a, b)
        if a.distance ~= b.distance then return a.distance < b.distance end
        if a.id ~= b.id then return a.id < b.id end
        if a.a ~= b.a then return a.a < b.a end
        return a.b < b.b
    end)
    while #out > (limit or 8) do table.remove(out) end
    return out
end

local function add_special_source_variants(out, owned, target_id, c, target_distance)
    if source_enabled(c, "mutation") then
        local wanted = {}
        for _, id in ipairs(c.passive_ids) do
            local meta = passive_meta_by_id[id]
            if not (c.locked_passives and c.locked_passives[id]) and meta and meta.mut then
                wanted[#wanted + 1] = id
            end
        end
        if #wanted > 0 then
            local mutation_rate = c.cake == "deluxe" and 0.03 or 0.01
            local expected = 1 / (mutation_rate / 5)
            local source_eggs_per_cake = c.cake == "vegetable" and 2 or 1
            for _, carrier in ipairs(mutation_source_candidates(
                    owned, target_id, target_distance, 8)) do
                for _, id in ipairs(wanted) do
                    add_special_acquisition(out, carrier.id, id, "mutation", c, {
                        score = 30 + expected / 10,
                        rng_traits = 1,
                        source_parents = { carrier.a, carrier.b },
                        normal_child = carrier.normal_child,
                        expected_source_eggs = expected,
                        expected_source_cakes = expected / source_eggs_per_cake,
                        source_note = "指定突变词条按五种等权计算；物种还受 0.5~0.6 选种带影响",
                    })
                end
            end
        end
    end

    for _, spec in ipairs({
        { flag = "world", meta = "world", kind = "world-tree", list = "world", tries = 7 },
        { flag = "fishing", meta = "fish", kind = "fishing", list = "fishing" },
    }) do
        if source_enabled(c, spec.flag) then
            local carriers = relevant_special_pals(
                data.source_pals and data.source_pals[spec.list] or {},
                target_id, target_distance, 6)
            for _, id in ipairs(c.passive_ids) do
                local meta = passive_meta_by_id[id]
                if not (c.locked_passives and c.locked_passives[id]) and meta and meta[spec.meta] then
                    for _, carrier in ipairs(carriers) do
                        local profile = special_source_profile(carrier.id, spec.kind, carrier)
                        add_special_acquisition(out, carrier.id, id, spec.kind, c, {
                            score = profile.score,
                            level = carrier.min,
                            spot = profile.spot,
                            rng_traits = 1,
                            expected_attempts = spec.tries,
                        })
                    end
                end
            end
        end
    end

    if source_enabled(c, "lucky") then
        local lucky_ids = {}
        for _, id in ipairs(c.passive_ids) do
            local meta = passive_meta_by_id[id]
            if not (c.locked_passives and c.locked_passives[id]) and meta and meta.lucky then
                lucky_ids[#lucky_ids + 1] = id
            end
        end
        if #lucky_ids > 0 then
            local carriers = {}
            for _, pal in ipairs(data.pals) do
                if pal.id == target_id or target_distance[pal.id] ~= nil then
                    local profile = capture_profile(pal.id)
                    if profile then carriers[#carriers + 1] = { id = pal.id, profile = profile } end
                end
            end
            table.sort(carriers, function(a, b)
                if a.profile.score ~= b.profile.score then
                    return a.profile.score < b.profile.score
                end
                return a.id < b.id
            end)
            while #carriers > 8 do table.remove(carriers) end
            for _, carrier in ipairs(carriers) do
                for _, id in ipairs(lucky_ids) do
                    add_special_acquisition(out, carrier.id, id, "lucky", c, {
                        score = carrier.profile.score + 30,
                        level = carrier.profile.level,
                        spot = carrier.profile.spot,
                        rng_traits = 1,
                    })
                end
            end
        end
    end
end

local function acquisition_sources(owned, snapshot, target_id, c)
    local candidates, profiles = {}, {}
    local target_distance = target_parent_distances(target_id, c.max_iterations)
    local function add_species(species, reason)
        if not species then return end
        local profile = profiles[species]
        if profile == nil then
            profile = capture_profile(species)
            if not profile then
                -- worldtree-only species: no overworld row survives the
                -- filter, but the World Tree pool IS a legitimate catch
                -- lane — restore an honestly-labelled candidate (spot=nil
                -- so no formatter can print an overworld square; +45
                -- mirrors special_source_profile's tree penalty)
                local wt = worldtree_pal(species)
                if wt then
                    profile = {
                        score = (tonumber(wt.min) or 99) + 45,
                        level = tonumber(wt.min) or 99,
                        spot = nil,
                    }
                end
            end
            profiles[species] = profile or false
        end
        if not profile then return end
        local entry = candidates[species]
        if not entry then
            entry = { species = species, profile = profile, reasons = {} }
            candidates[species] = entry
        end
        entry.reasons[reason or "bridge"] = true
    end

    -- Direct capture is the minimum-generation option when the target exists
    -- in the verified spawner table.
    add_species(target_id, "direct")

    -- Fixed/native carriers are authoritative acquisition roots.
    for _, id in ipairs(c.passive_ids) do
        local meta = passive_meta_by_id[id]
        if not (c.locked_passives and c.locked_passives[id]) then
            for _, raw in ipairs(meta and meta.born or {}) do add_species(normalize(raw), "passive") end
        end
    end
    for _, id in ipairs(c.skill_ids) do
        local meta = skill_meta_by_id[id]
        for _, carrier in ipairs(meta and meta.born or {}) do add_species(normalize(carrier.pal), "skill") end
    end

    -- For random-add passives, add only the easiest target-relevant wild
    -- species. This bounds the state space while still enabling the intended
    -- "easy carrier, then bridge" plan.
    local has_random_missing = false
    if source_enabled(c, "random") then
        for _, id in ipairs(c.passive_ids) do
            local meta = passive_meta_by_id[id]
            if not (c.locked_passives and c.locked_passives[id]) and meta and meta.add then
                has_random_missing = true break
            end
        end
    end
    if has_random_missing then
        local easy = {}
        for _, pal in ipairs(data.pals) do
            if not owned[pal.id] then
                local profile = capture_profile(pal.id)
                if profile then easy[#easy + 1] = { id = pal.id, profile = profile } end
            end
        end
        table.sort(easy, function(a, b)
            if a.profile.score ~= b.profile.score then return a.profile.score < b.profile.score end
            return a.id < b.id
        end)
        for i = 1, math.min(10, #easy) do add_species(easy[i].id, "random-passive") end
    end

    -- When the target species itself is unreachable, include the verified
    -- one-catch unlocks chosen by the existing exact species solver.
    local suggestions = M.suggest_catch(owned, target_id)
    for i = 1, math.min(10, suggestions and #suggestions or 0) do
        add_species(suggestions[i].id, "species-entry")
    end

    local out = {}
    for species, candidate in pairs(candidates) do
        local possible = empty_cap()
        local random_traits = 0
        local possible_random = {}
        for _, id in ipairs(c.passive_ids) do
            local meta = passive_meta_by_id[id]
            if not (c.locked_passives and c.locked_passives[id]) then
                if born_on(meta, species) then
                    possible.passives[id] = true
                elseif meta and meta.add and source_enabled(c, "random") then
                    possible.passives[id] = true
                    possible_random[id] = true
                    random_traits = random_traits + 1
                end
            end
        end
        for _, id in ipairs(c.skill_ids) do
            local meta = skill_meta_by_id[id]
            for _, carrier in ipairs(meta and meta.born or {}) do
                if normalize(carrier.pal) == species then possible.skills[id] = true break end
            end
        end
        local base = {
            species = species, kind = "blank", score = candidate.profile.score,
            level = candidate.profile.level, spot = candidate.profile.spot,
            rng_traits = 0, reasons = candidate.reasons,
        }
        out[#out + 1] = acquire_route(species, empty_cap(), base, c)
        if next(possible.passives) or next(possible.skills) then
            local full = {
                species = species, kind = "trait", score = candidate.profile.score,
                level = candidate.profile.level, spot = candidate.profile.spot,
                rng_traits = random_traits, reasons = candidate.reasons,
                random_passives = {},
            }
            for id in pairs(possible_random) do full.random_passives[#full.random_passives + 1] = id end
            table.sort(full.random_passives)
            full.source_key = "trait=" .. table.concat(full.random_passives, ",")
            out[#out + 1] = acquire_route(species, possible, full, c)
            -- Single-trait roots give the low-RNG planner a bridgeable option.
            for id in pairs(possible.passives) do
                local one = empty_cap()
                one.passives[id] = true
                local meta = passive_meta_by_id[id]
                local acquisition = {
                    species = species, kind = "trait", score = candidate.profile.score,
                    level = candidate.profile.level, spot = candidate.profile.spot,
                    rng_traits = (meta and meta.add and not born_on(meta, species)) and 1 or 0,
                    reasons = candidate.reasons,
                    random_passives = possible_random[id] and { id } or {},
                    source_key = (possible_random[id] and "random=" or "native=") .. id,
                }
                out[#out + 1] = acquire_route(species, one, acquisition, c)
            end
        end
        -- A captured blank/trait carrier can be operated on before entering
        -- the breeding chain. This exposes the fast "catch then implant"
        -- family without generating surgery roots for every Pal in the game.
        add_surgery_variants(out, species, empty_cap(), nil, candidate.profile, c)
        -- Prefer enabled deterministic operations for every passive they can
        -- provide, and ask random capture only for the remaining gaps. This is
        -- the actionable mixed plan (for example: capture 灵活, then implant
        -- 运动健将 + 神速), while the full-random root above remains an
        -- explicitly higher-RNG alternative.
        local mixed_base, mixed_random = empty_cap(), {}
        for id in pairs(possible.skills) do mixed_base.skills[id] = true end
        for _, id in ipairs(c.passive_ids) do
            local meta = passive_meta_by_id[id]
            if not (c.locked_passives and c.locked_passives[id]) then
                if born_on(meta, species) then
                    mixed_base.passives[id] = true
                else
                    local surgical = meta and (meta.surg == "direct" or meta.surg == "reusable"
                        or meta.surg == "consumable") and source_enabled(c, meta.surg)
                    if not surgical and meta and meta.add and source_enabled(c, "random") then
                        mixed_base.passives[id] = true
                        mixed_random[id] = true
                    end
                end
            end
        end
        if next(mixed_base.passives) or next(mixed_base.skills) then
            add_surgery_variants(out, species, mixed_base, nil, candidate.profile, c,
                { random_passives = mixed_random })
        end
    end

    -- Mutation eggs, fishing glow, World Tree glow and Lucky Pals are real
    -- acquisition roots, not post-hoc prose. Each toggle suppresses the root
    -- entirely, shrinking both the candidate set and later pair expansion.
    add_special_source_variants(out, owned, target_id, c, target_distance)


    -- Surgery can also upgrade an exact Pal the player already owns. Collapse
    -- identical semantic capability states per species before creating roots;
    -- hundreds of box individuals otherwise add no new planning information.
    -- bh-035 (codex r2 MAJOR + r3 MAJOR): gates read gender off exact-surgery
    -- roots, so the collapse must keep BOTH genders of a capability state —
    -- but capability coverage owns the four slots (r3: letting gender split
    -- eat the cap quota halved coverage). pick_surgery_reps keeps the two
    -- concerns separate: top-4 CAP states first, then one smallest-body-key
    -- representative per gender inside each (max 8 roots), all orderings
    -- fully deterministic — box iteration order must never matter.
    for species, instances in pairs(snapshot and snapshot.by_species or {}) do
        if species == target_id or target_distance[species] ~= nil then
            local raw = {}
            for _, inst in ipairs(instances) do
                local cap = instance_caps(inst, c)
                raw[#raw + 1] = { cap = cap, key = cap_key(cap, c),
                    missing = missing_caps(cap, c),
                    gender = inst.gender or "Any", inst = inst }
            end
            for _, rep in ipairs(pick_surgery_reps(raw, c.iv_hidden)) do
                add_surgery_variants(out, species, rep.cap, rep.inst, nil, c)
            end
        end
    end
    return out
end

local function work_lists(work)
    local out = {}
    for species, bucket in pairs(work) do
        local list = flatten_bucket(bucket)
        table.sort(list, label_less)
        out[species] = list
    end
    return out
end

local function combine_labels(work, next_delta, child, lefts, rights, c, per_state, per_species,
        checkpoint, skip_left, symmetric_delta, male_side)
    if not lefts or not rights then return end
    local candidates = {}
    -- The pair-candidate funnel must be as wide as the insert quota below:
    -- with a hard 2 the target's third per-state slot was unreachable inside
    -- one wave call, silently dropping the deeper-but-cheaper alternative
    -- plan (2026-07-22 fixture: 2-step junky pair vs 3-step clean chain).
    local keep = child == c.target_id and math.max(3, per_state) or per_state
    -- checkpoint batching: a closure call + modulo per raw pair was real
    -- overhead at millions of pairs; count locally, report every 256
    local pending = 0
    for _, left in ipairs(lefts) do
        if not (skip_left and skip_left[left.signature]) then
            for _, right in ipairs(rights) do
                -- For a same-species recipe delta x all already covers both
                -- orientations. Keep one ordering only when both are delta.
                local symmetric_duplicate = symmetric_delta and symmetric_delta[right.signature]
                    and right.signature < left.signature
                if not symmetric_duplicate then
                    if checkpoint then
                        pending = pending + 1
                        if pending >= 256 then
                            checkpoint(pending)
                            pending = 0
                        end
                    end
                    consider_pair(candidates, left, right, c, keep, male_side)
                end
            end
        end
    end
    if pending > 0 and checkpoint then checkpoint(pending) end
    for state_key, list in pairs(candidates) do
        for _, candidate in ipairs(list) do
            local route = breed_route(child, candidate.left, candidate.right,
                state_key, candidate.pair_potion)
            local delta_list = next_delta[child]
            if insert_label(work, route, c, keep, per_species) then
                if not delta_list then delta_list = {} next_delta[child] = delta_list end
                delta_list[#delta_list + 1] = route
            end
            -- surgery variants live in DIFFERENT capability states: they must
            -- be offered even when the unoperated base was beaten in its own
            -- state (pruning before a state-changing transform is unsound)
            for _, operated in ipairs(post_breed_surgery_variants(route, c)) do
                if insert_label(work, operated, c, keep, per_species) then
                    if not delta_list then delta_list = {} next_delta[child] = delta_list end
                    delta_list[#delta_list + 1] = operated
                end
            end
        end
    end
end

local function goal_route_count(work, target_id, c)
    local count = 0
    for _, route in ipairs(flatten_bucket(work[target_id])) do
        -- 再配一只: a bare owned leaf IS the individual the player already
        -- has — it must not satisfy the search. Bred/operated/acquired routes
        -- all produce a NEW finished individual and still count.
        if not (c.rebreed and route.kind == "owned")
                and set_contains_all(route.cap.passives, c.passives)
                and set_contains_all(route.cap.skills, c.skills)
                and set_contains_all(route.cap.locks, c.locked) then
            -- finalize-lite: a raw capability goal the finalizer would later
            -- reject (zero probability / infinite eggs) must NOT stop the
            -- search. The acquisition phase never revisits owned bridges the
            -- early exit skipped, so stopping here was a completeness hole.
            if route.goal_feasible == nil then
                local ok, ev = pcall(evaluate_route, route, c, true, {})
                route.goal_feasible = (ok and ev and ev.probability > 0
                    and ev.eggs < math.huge) or false
            end
            if route.goal_feasible then count = count + 1 end
        end
    end
    return count
end

local function run_workset(owned, snapshot, target_id, c, extra_sources, goal_limit, existing_work, report, phase)
    local work, delta = existing_work or {}, {}
    local per_state, per_species = 2, 48
    c.target_id = target_id
    goal_limit = goal_limit or 1
    local function seed(route)
        if insert_label(work, route, c, per_state, per_species) then
            local list = delta[route.species]
            if not list then list = {} delta[route.species] = list end
            list[#list + 1] = route
        end
    end
    if not existing_work then
        for species in pairs(owned) do
            local instances = snapshot and snapshot.by_species and snapshot.by_species[species]
            if instances and #instances > 0 then
                for _, inst in ipairs(instances) do seed(leaf_route(species, inst, c)) end
            else
                seed(leaf_route(species, virtual_instance(species), c))
            end
        end
    end
    for _, route in ipairs(extra_sources or {}) do seed(route) end
    -- compact the SEED delta too: a later seed can evict an earlier one from
    -- its bucket, and the first wave must not breed from ghosts (the wave-end
    -- compaction below only ever sees next_delta)
    for species, routes in pairs(delta) do
        local kept = {}
        for _, r in ipairs(routes) do
            if r.in_work then kept[#kept + 1] = r end
        end
        delta[species] = #kept > 0 and kept or nil
    end

    if report then report({ phase = phase, fraction = 0.01, detail = "准备配方索引" }) end
    local producers = get_producer_index()
    local target_distance = target_parent_distances(target_id, c.max_iterations)
    local iteration, exhausted, total_combinations, total_executed = 0, false, 0, 0
    local CHECKPOINT_COMBINATIONS = 2048
    -- Yield by CPU time, not by a fixed pair count: a 2048-pair chunk cost up
    -- to ~270ms in the offline benchmark -- one long game-thread hitch per
    -- chunk. A short slice keeps frames smooth; the hard ceiling keeps
    -- progress ticking even if os.clock resolution is coarse.
    local SLICE_SECONDS = 0.0015
    local HARD_YIELD_COMBINATIONS = 8192
    local function signature_set(list)
        local out = {}
        for _, route in ipairs(list or {}) do out[route.signature] = true end
        return out
    end
    local goals = goal_route_count(work, target_id, c)
    while goals < goal_limit and next(delta) and iteration < c.max_iterations do
        iteration = iteration + 1
        local all = work_lists(work)
        local next_delta = {}
        local children = { { child = target_id, pairs = producers[target_id] or {} } }
        local max_distance = c.max_iterations - iteration
        for child, pairs_for_child in pairs(producers) do
            local distance = target_distance[child]
            if child ~= target_id and distance ~= nil and distance <= max_distance then
                children[#children + 1] = { child = child, pairs = pairs_for_child }
            end
        end
        table.sort(children, function(a, b)
            -- a valid strict weak ordering: equal keys must compare false
            if a.child == b.child then return false end
            if a.child == target_id then return true end
            if b.child == target_id then return false end
            return a.child < b.child
        end)
        local function pair_units(pair)
            local da, db = delta[pair.a], delta[pair.b]
            local aa, ab = all[pair.a], all[pair.b]
            local nda, ndb = da and #da or 0, db and #db or 0
            local naa, nab = aa and #aa or 0, ab and #ab or 0
            if pair.a == pair.b then
                -- delta x old plus one orientation of delta x delta.
                return nda * naa - nda * math.max(0, nda - 1) / 2
            end
            -- The overlap deltaA x deltaB is handled by the first direction.
            return nda * nab + naa * ndb - nda * ndb
        end
        local iteration_total = 0
        for _, entry in ipairs(children) do
            entry.units = 0
            for _, pair in ipairs(entry.pairs) do entry.units = entry.units + pair_units(pair) end
            iteration_total = iteration_total + entry.units
        end
        total_combinations = total_combinations + iteration_total
        local child_done, child_total, iteration_done = 0, math.max(1, #children), 0
        local last_reported_work = 0
        local function emit(detail)
            if not report then return end
            last_reported_work = iteration_done
            local wave_fraction = iteration_total > 0 and iteration_done / iteration_total
                or child_done / child_total
            local local_fraction = ((iteration - 1) + wave_fraction) / c.max_iterations
            report({ phase = phase, fraction = math.min(0.98, local_fraction),
                iteration = iteration, max_iterations = c.max_iterations,
                work_done = iteration_done, work_total = iteration_total,
                detail = detail })
        end
        emit(string.format(T("第 %d/%d 轮"), iteration, c.max_iterations))
        local slice_deadline = os.clock() + SLICE_SECONDS
        local next_hard_yield = HARD_YIELD_COMBINATIONS
        local function expand_child(child, pairs_for_child)
            for _, pair in ipairs(pairs_for_child) do
                local da, db = delta[pair.a], delta[pair.b]
                -- direction lock only meaningful across two distinct species:
                -- for a same-species pair the symmetric skip keeps one
                -- orientation only, which must stay gender-flexible
                local male_side
                if pair.male_species and pair.a ~= pair.b then
                    male_side = pair.male_species == pair.a and "left" or "right"
                end
                local function checkpoint(n)
                    iteration_done = iteration_done + n
                    if iteration_done >= next_hard_yield or os.clock() >= slice_deadline then
                        local pal = by_id[child]
                        emit(string.format(T("第 %d/%d 轮 · 扩展 %s"), iteration,
                            c.max_iterations, pal and disp_name(pal) or child))
                        -- these lines run AFTER the async coroutine has been
                        -- resumed, so the next slice starts from fresh time
                        slice_deadline = os.clock() + SLICE_SECONDS
                        next_hard_yield = iteration_done + HARD_YIELD_COMBINATIONS
                    end
                end
                if pair.a == pair.b then
                    if da and all[pair.a] then
                        combine_labels(work, next_delta, child, da, all[pair.a], c,
                            per_state, per_species, checkpoint, nil, signature_set(da))
                    end
                else
                    local delta_a_signatures
                    if da and all[pair.b] then
                        combine_labels(work, next_delta, child, da, all[pair.b], c,
                            per_state, per_species, checkpoint, nil, nil, male_side)
                        if db then delta_a_signatures = signature_set(da) end
                    end
                    if db and all[pair.a] then
                        combine_labels(work, next_delta, child, all[pair.a], db, c,
                            per_state, per_species, checkpoint, delta_a_signatures, nil, male_side)
                    end
                end
            end
            child_done = child_done + 1
            -- Rounding and defensive skips must not make progress move back.
            iteration_done = math.min(iteration_total, iteration_done)
            if child == target_id or child_done == child_total
                    or iteration_done - last_reported_work >= CHECKPOINT_COMBINATIONS then
                emit(string.format(T("第 %d/%d 轮 · 已检查 %d/%d 个候选物种"),
                    iteration, c.max_iterations, child_done, child_total))
            end
        end
        -- The target is expanded first. After the first global wave has built
        -- bridge states, a later wave can usually finish here without filling
        -- every unrelated species/capability combination.
        expand_child(children[1].child, children[1].pairs)
        goals = goal_route_count(work, target_id, c)
        if goals < goal_limit then
            for i = 2, #children do
                expand_child(children[i].child, children[i].pairs)
            end
        end
        -- compact the delta: routes evicted after their insertion must not
        -- breed descendants next wave (they are no longer in `all`, which
        -- also broke the pair-count formulas into negative totals)
        for species, routes in pairs(next_delta) do
            local kept = {}
            for _, r in ipairs(routes) do
                if r.in_work then kept[#kept + 1] = r end
            end
            next_delta[species] = #kept > 0 and kept or nil
        end
        total_executed = total_executed + iteration_done
        delta = next_delta
        goals = goal_route_count(work, target_id, c)
    end
    if report then report({ phase = phase, fraction = 1.0, detail = "搜索阶段完成" }) end
    if goals < goal_limit and next(delta) then exhausted = true end
    -- `combinations` = pairs actually examined; `planned_combinations` keeps
    -- the pre-expansion estimates (which include work skipped by the
    -- target-first early exit and can therefore overstate)
    return work, { iterations = iteration, exhausted = exhausted, goals = goals,
        combinations = total_executed, planned_combinations = total_combinations }
end

local function collect_acquisitions(node, out, seen)
    if node.kind == "acquire" then
        if not seen[node.signature] then seen[node.signature] = true out[#out + 1] = node.acquisition end
        return
    end
    if node.kind == "owned" then return end
    if node.kind == "operate" then
        collect_acquisitions(node.base, out, seen)
        return
    end
    collect_acquisitions(node.left, out, seen)
    collect_acquisitions(node.right, out, seen)
end

local function collect_operations(node, out, seen)
    if not node or node.kind == "owned" or node.kind == "acquire" then return end
    if node.kind == "operate" then
        collect_operations(node.base, out, seen)
        if not seen[node.signature] then
            seen[node.signature] = true
            out[#out + 1] = node.operation
        end
        return
    end
    collect_operations(node.left, out, seen)
    collect_operations(node.right, out, seen)
end

-- Structural signature for route diversity (owner decision 2026-07-17: offer
-- at most TWO plans and only when they differ structurally). Two routes that
-- differ only in WHICH interchangeable pal fills a slot share one signature;
-- tree shape, acquisition KIND (owned / capture / mutation egg / fishing /
-- world tree ...) and surgery modes stay distinguishing. Species names are
-- deliberately absent: "换一个等价帕鲁" is presentation noise, not a plan.
local function struct_signature(node)
    if node.kind == "breed" then
        local a, b = struct_signature(node.left), struct_signature(node.right)
        if b < a then a, b = b, a end
        return "B(" .. a .. "," .. b .. ")"
    end
    if node.kind == "operate" then
        local modes = {}
        for _, procedure in ipairs(node.operation and node.operation.procedures or {}) do
            modes[#modes + 1] = tostring(procedure.mode)
        end
        table.sort(modes)
        return "S[" .. table.concat(modes, "+") .. "](" .. struct_signature(node.base) .. ")"
    end
    if node.kind == "acquire" then
        return "A:" .. tostring(node.acquisition and node.acquisition.kind or "?")
    end
    return "O"
end
M._struct_signature = struct_signature   -- pinned by tools/test_v13.py

-- Keep the best-ranked representative of every structure, up to max_keep.
-- list must already be sorted by the desired objective.
local function dedupe_by_structure(list, max_keep)
    local out, seen = {}, {}
    for _, route in ipairs(list) do
        local sig = route.structural_signature or struct_signature(route.tree)
        if not seen[sig] then
            seen[sig] = true
            out[#out + 1] = route
            if #out >= max_keep then break end
        end
    end
    return out
end

-- Intermediate-gender pass (codex diagnosis 2026-07-18): when a breed step's
-- co-parent is a FIXED individual (owned leaf, known gender), the bred
-- intermediate must come out the OPPOSITE gender — the same-gender pairing
-- guard that forced the extra step would reject the wrong-gender child at
-- execution time. The beam search prices only the root's final_gender, so
-- these steps carried no gender cost (3.33 eggs displayed where the 50%
-- gender model says 6.67), no UI marker, and the step matcher accepted
-- useless same-gender children. Pricing happens here, POST evaluation:
-- in-beam pruning still compares the un-priced cost (conservative — a
-- gendered branch is never pruned in favor of a pricier-looking one; the
-- final ordering below uses the corrected totals).
-- Two-intermediate pairings stay unpriced: either gender works as long as
-- the two come out opposite, and pricing that needs a joint model.
-- potion_mode (2.10.0): instead of demanding a gender (cost ×2 + hard
-- filter), MARK the affected steps — the player solves a mismatch with one
-- 帕鲁性转药 at the OperatingTable. potion_gender = "this intermediate may
-- need reassigning to pair with its fixed-gender co-parent";
-- potion_pair = "these two owned parents are the SAME gender, reassign
-- one first". No probability/egg scaling in potion mode.
local function apply_intermediate_gender(entry, potion_mode)
    local steps = entry.steps
    -- The route is a DAG: ONE bred-intermediate node can be shared by two
    -- branches (rawequal tables), while evaluate_route appends a SEPARATE
    -- step per OCCURRENCE. Steps therefore map to breed-node occurrences in
    -- postorder — never to node identity (codex r4: an identity map let the
    -- second occurrence overwrite the first) and never to signatures
    -- (codex r3: structural twins share those). The single walk below
    -- replays evaluate_route's exact append order: left recursion, right
    -- recursion, self. A count mismatch refuses the whole pass — no labels
    -- are better than misplaced ones.
    local total = 0
    local function count_occurrences(node)
        if not node then return end
        if node.kind == "operate" then count_occurrences(node.base) return end
        if node.kind ~= "breed" then return end
        count_occurrences(node.left)
        count_occurrences(node.right)
        total = total + 1
    end
    count_occurrences(entry.tree)
    if total ~= #steps then return end
    local gendered = 0
    local function demand(step, fixed_gender)
        if potion_mode then
            if step and not step.potion_gender then
                step.potion_gender = fixed_gender == "F" and "M" or "F"
            end
            return
        end
        if step and not step.required_gender then
            step.required_gender = fixed_gender == "F" and "M" or "F"
            gendered = gendered + 1
            entry.expected_eggs = entry.expected_eggs + (step.expected_eggs or 0)
            entry.breeding_expected_eggs = entry.breeding_expected_eggs
                + (step.expected_eggs or 0)
            entry.expected_cakes = entry.expected_cakes + (step.expected_cakes or 0)
            entry.breeding_expected_cakes = entry.breeding_expected_cakes
                + (step.expected_cakes or 0)
            step.probability = (step.probability or 0) * 0.5
            step.expected_eggs = (step.expected_eggs or 0) * 2
            step.expected_cakes = (step.expected_cakes or 0) * 2
        end
    end
    local function leaf_gender(node)
        -- shared exact-individual semantics (bh-035): owned, operate-wrapped
        -- AND exact-surgery acquire parents all pin a real body's gender.
        -- Only a KNOWN M/F counts: aggregate-mode virtual leaves carry
        -- gender="Any" and must not fabricate a hard demand (codex r3 #2)
        local fixed = exact_inst(node)
        local g = fixed and fixed.gender or nil
        return (g == "M" or g == "F") and g or nil
    end
    local pos = 0
    local function walk(node)
        if not node then return nil end
        if node.kind == "operate" then return walk(node.base) end
        if node.kind ~= "breed" then return nil end
        local left_index = walk(node.left)
        local right_index = walk(node.right)
        pos = pos + 1
        local my_index = pos
        local lg, rg = leaf_gender(node.left), leaf_gender(node.right)
        -- two KNOWN same-gender owned parents (only reachable in potion
        -- mode — consider_pair refuses the pair otherwise)
        if potion_mode and lg and rg and lg == rg and steps[my_index] then
            steps[my_index].potion_pair = true
        end
        if lg and right_index then demand(steps[right_index], lg) end
        if rg and left_index then demand(steps[left_index], rg) end
        return my_index
    end
    walk(entry.tree)
    if gendered > 0 then
        entry.path_probability = entry.path_probability * (0.5 ^ gendered)
    end
end
M._apply_intermediate_gender = apply_intermediate_gender   -- offline test hook

local function finalize_routes(work, target_id, c)
    local out = {}
    for _, route in ipairs(flatten_bucket(work[target_id])) do
        -- 再配一只: same rule as goal_route_count — the zero-step "you
        -- already own it" answer is exactly what the player asked to hide.
        if not (c.rebreed and route.kind == "owned")
                and set_contains_all(route.cap.passives, c.passives)
                and set_contains_all(route.cap.skills, c.skills)
                and set_contains_all(route.cap.locks, c.locked) then
            local steps = {}
            local ev = evaluate_route(route, c, true, steps)
            if ev.probability > 0 and ev.eggs < math.huge then
                local acquisitions = {}
                collect_acquisitions(route, acquisitions, {})
                local operations = {}
                collect_operations(route, operations, {})
                local step_by_signature = {}
                for i, step in ipairs(steps) do
                    if step.route_signature then step_by_signature[step.route_signature] = i end
                end
                for _, operation in ipairs(operations) do
                    operation.step_index = step_by_signature[operation.base_signature]
                end
                local source_eggs, source_cakes = 0, 0
                for _, acquisition in ipairs(acquisitions) do
                    source_eggs = source_eggs + (acquisition.expected_source_eggs or 0)
                    source_cakes = source_cakes + (acquisition.expected_source_cakes or 0)
                end
                local batch_p = 1 - (1 - ev.probability) ^ c.batch
                local mutation_p = c.cake == "deluxe" and 0.03 or 0.01
                out[#out + 1] = {
                    target = target_id, tree = route, steps = steps, step_count = #steps,
                    structural_signature = struct_signature(route),
                    expected_eggs = ev.eggs + source_eggs,
                    expected_cakes = ev.cakes + source_cakes,
                    breeding_expected_eggs = ev.eggs,
                    breeding_expected_cakes = ev.cakes,
                    source_expected_eggs = source_eggs,
                    source_expected_cakes = source_cakes,
                    success_probability = ev.probability, path_probability = ev.path_probability,
                    batch_success_probability = batch_p, mutation_probability = mutation_p,
                    batch_mutation_probability = 1 - (1 - mutation_p) ^ c.batch,
                    alpha_probability = 0.05, batch_alpha_probability = 1 - 0.95 ^ c.batch,
                    constraints = c, acquisitions = acquisitions, operations = operations,
                    acquisition_count = #acquisitions,
                    operation_count = #operations,
                    potion_count = route.potion_count or 0,
                    max_capture_score = route.max_capture_score,
                    rng_traits = route.rng_traits,
                    junk_traits = route.junk_traits or 0,
                    iv_sum = route.iv_sum or 0,
                    warnings = c.allow_junk and {}
                        or { "随机附加词条概率尚未计入；无杂词条结果为乐观估计" },
                }
                apply_intermediate_gender(out[#out], c.gender_potion)
                local has_unpriced_random = false
                for _, acquisition in ipairs(acquisitions) do
                    if acquisition.kind == "trait" and (acquisition.rng_traits or 0) > 0 then
                        has_unpriced_random = true break
                    end
                end
                if has_unpriced_random then
                    out[#out].warnings[#out[#out].warnings + 1] =
                        "野外随机词条没有已验证的精确出现率；这里只比较随机负担，不伪造预计次数"
                end
                for _, acquisition in ipairs(acquisitions) do
                    if acquisition.source_note then
                        out[#out].warnings[#out[#out].warnings + 1] = acquisition.source_note
                    elseif acquisition.kind == "fishing" then
                        out[#out].warnings[#out[#out].warnings + 1] =
                            "钓鱼发光词条的精确发光率尚未确认；不伪造总钓鱼次数"
                    elseif acquisition.kind == "lucky" then
                        out[#out].warnings[#out[#out].warnings + 1] =
                            "幸运帕鲁出现率未纳入预计次数"
                    end
                end
            end
        end
    end
    return out
end

local function direct_target_source_routes(snapshot, target_id, c, limit)
    if not (snapshot and snapshot.by_species and snapshot.by_species[target_id]) then return {} end
    local roots = {}
    for _, inst in ipairs(snapshot.by_species[target_id]) do
        local eligible = c.final_gender == "Any" or inst.gender == c.final_gender
        if eligible then
            for stat, threshold in pairs(c.iv) do
                if not inst.iv or inst.iv[stat] == nil or inst.iv[stat] < threshold then
                    eligible = false break
                end
            end
        end
        if eligible then
            add_surgery_variants(roots, target_id, instance_caps(inst, c), inst, nil, c)
        end
    end
    if #roots == 0 then return {} end
    local work = {}
    for _, root in ipairs(roots) do insert_label(work, root, c, 6, 24) end
    local routes = finalize_routes(work, target_id, c)
    table.sort(routes, function(a, b)
        if a.max_capture_score ~= b.max_capture_score then
            return a.max_capture_score < b.max_capture_score
        end
        if (a.junk_traits or 0) ~= (b.junk_traits or 0) then
            return (a.junk_traits or 0) < (b.junk_traits or 0)
        end
        if (a.iv_sum or 0) ~= (b.iv_sum or 0) then
            return (a.iv_sum or 0) > (b.iv_sum or 0)
        end
        return a.tree.signature < b.tree.signature
    end)
    routes = dedupe_by_structure(routes, limit or 2)
    for _, route in ipairs(routes) do route.plan_profile = "现有目标直改" end
    return routes
end

-- Owned-route ordering (owner priority 2026-07-22): fewer generations first —
-- a one-step plan beats a two-step plan outright; within the same generation
-- count the junk-priced egg expectation ranks pair quality (clean 2+0/1+1
-- parents beat full-slot mongrels), raw junk count breaks exact-egg ties.
local function owned_route_less(a, b)
    if a.step_count ~= b.step_count then return a.step_count < b.step_count end
    -- bh-035 owner ruling: at EQUAL generation depth the potion-free route
    -- wins outright; a potion only earns its keep by cutting a generation
    -- (decided by step_count above). Ranks immediately after depth in every
    -- final comparator.
    if (a.potion_count or 0) ~= (b.potion_count or 0) then
        return (a.potion_count or 0) < (b.potion_count or 0)
    end
    if a.expected_eggs ~= b.expected_eggs then return a.expected_eggs < b.expected_eggs end
    if (a.junk_traits or 0) ~= (b.junk_traits or 0) then
        return (a.junk_traits or 0) < (b.junk_traits or 0)
    end
    -- soft IV preference (2.16.0): higher parent talents win the last tie
    if (a.iv_sum or 0) ~= (b.iv_sum or 0) then
        return (a.iv_sum or 0) > (b.iv_sum or 0)
    end
    return a.tree.signature < b.tree.signature
end
M._owned_route_less = owned_route_less   -- pinned by tools/test_v13.py

local function fastest_less(a, b)
    -- Unknown multi-trait wild RNG and a new capture are usually slower than
    -- one deterministic breeding step from parents already in the player's
    -- snapshot. Prefer actionable owned routes before raw generation count.
    if a.rng_traits ~= b.rng_traits then return a.rng_traits < b.rng_traits end
    if a.acquisition_count ~= b.acquisition_count then return a.acquisition_count < b.acquisition_count end
    if (a.operation_count or 0) ~= (b.operation_count or 0) then
        return (a.operation_count or 0) < (b.operation_count or 0)
    end
    if a.step_count ~= b.step_count then return a.step_count < b.step_count end
    if (a.potion_count or 0) ~= (b.potion_count or 0) then
        return (a.potion_count or 0) < (b.potion_count or 0)
    end
    if a.expected_eggs ~= b.expected_eggs then return a.expected_eggs < b.expected_eggs end
    if (a.junk_traits or 0) ~= (b.junk_traits or 0) then
        return (a.junk_traits or 0) < (b.junk_traits or 0)
    end
    if (a.iv_sum or 0) ~= (b.iv_sum or 0) then
        return (a.iv_sum or 0) > (b.iv_sum or 0)
    end
    return a.tree.signature < b.tree.signature
end

local function easiest_less(a, b)
    if a.rng_traits ~= b.rng_traits then return a.rng_traits < b.rng_traits end
    if a.max_capture_score ~= b.max_capture_score then return a.max_capture_score < b.max_capture_score end
    if a.acquisition_count ~= b.acquisition_count then return a.acquisition_count < b.acquisition_count end
    if (a.operation_count or 0) ~= (b.operation_count or 0) then
        return (a.operation_count or 0) < (b.operation_count or 0)
    end
    if a.expected_eggs ~= b.expected_eggs then return a.expected_eggs < b.expected_eggs end
    if a.step_count ~= b.step_count then return a.step_count < b.step_count end
    if (a.potion_count or 0) ~= (b.potion_count or 0) then
        return (a.potion_count or 0) < (b.potion_count or 0)
    end
    if (a.junk_traits or 0) ~= (b.junk_traits or 0) then
        return (a.junk_traits or 0) < (b.junk_traits or 0)
    end
    if (a.iv_sum or 0) ~= (b.iv_sum or 0) then
        return (a.iv_sum or 0) > (b.iv_sum or 0)
    end
    return a.tree.signature < b.tree.signature
end

-- Acquisition-route selection: profile picks dedupe by STRUCTURE — a
-- same-shape co-parent swap must not occupy the second slot; when every
-- candidate shares one structure the planner legitimately returns a single
-- plan. Split out (and exported for tests) so the seen-key contract has a
-- direct regression hook instead of a data-dependent integration fixture.
local function select_diverse_routes(candidates, k)
    local selected, seen = {}, {}
    local function take(profile, less)
        table.sort(candidates, less)
        for _, route in ipairs(candidates) do
            if not seen[route.structural_signature] then
                seen[route.structural_signature] = true
                route.plan_profile = profile
                selected[#selected + 1] = route
                return
            end
        end
    end
    take("最快成型", fastest_less)
    if #selected < k then take("最容易", easiest_less) end
    table.sort(candidates, function(a, b)
        -- potion weighs 1 (one egg's worth): real cost, but strictly cheaper
        -- than the 2-per-generation step weight per the bh-035 owner ruling
        local aa = a.expected_eggs + a.step_count * 2 + a.rng_traits * 8
            + (a.operation_count or 0) * 2 + (a.potion_count or 0)
            + a.max_capture_score / 10
        local bb = b.expected_eggs + b.step_count * 2 + b.rng_traits * 8
            + (b.operation_count or 0) * 2 + (b.potion_count or 0)
            + b.max_capture_score / 10
        if aa ~= bb then return aa < bb end
        -- the weighted blend prices junk NOWHERE, so equal blends can hide
        -- a junk gap — the ruling's ordering must be restated before the IV
        -- tiebreak or high IVs would buy junk here (codex 2.16.0 r1, lupa
        -- reproduced: 1-junk/300-IV outranked 0-junk/0-IV at equal blend)
        if (a.junk_traits or 0) ~= (b.junk_traits or 0) then
            return (a.junk_traits or 0) < (b.junk_traits or 0)
        end
        -- IVs are not commensurable with eggs/steps, so they stay out of
        -- the weighted blend and only break exact ties
        if (a.iv_sum or 0) ~= (b.iv_sum or 0) then
            return (a.iv_sum or 0) > (b.iv_sum or 0)
        end
        return a.tree.signature < b.tree.signature
    end)
    while #selected < k do
        local before = #selected
        for _, route in ipairs(candidates) do
            if not seen[route.structural_signature] then
                seen[route.structural_signature] = true
                route.plan_profile = "均衡"
                selected[#selected + 1] = route
                break
            end
        end
        if #selected == before then break end
    end
    return selected
end
M._select_diverse_routes = select_diverse_routes   -- pinned by tools/test_v13.py

local last_plan_meta = {}

-- Returns executable owned-only routes first. If none exist, acquisition roots
-- are injected and the solver returns distinct minimum-generation and
-- minimum-difficulty plans from the same Pareto label set.
local function plan_weighted_impl(owned, snapshot, target_id, raw_constraints, k, report)
    if not owned or not target_id then return {} end
    -- at most two plans, and only when structurally different (owner decision
    -- 2026-07-17): rank-adjacent co-parent swaps read as the same plan
    k = math.max(1, math.min(10, tonumber(k) or 2))
    local c = normalize_constraints(raw_constraints)
    last_plan_meta = { target = target_id, status = "searching", exhausted = false }

    if next(c.skills) and c.cake ~= "special" then
        last_plan_meta.status = "skill-cake-blocked"
        return {}
    end
    if #c.passive_ids > 4 then
        last_plan_meta.status = "passive-slot-overflow"
        return {}
    end
    for key in pairs(c.locked) do
        if not (snapshot and snapshot.by_key and snapshot.by_key[key]) then
            last_plan_meta.status = "missing-lock"
            return {}
        end
    end
    -- A locked individual is mandatory in every valid final route. Its
    -- requested passives are therefore already supplied by one branch and
    -- must not be redundantly requested from a capture or implant root.
    c.locked_passives = {}
    for key in pairs(c.locked) do
        local inst = snapshot.by_key[key]
        for _, id in ipairs(inst.passives or {}) do
            if c.passives[id] then c.locked_passives[id] = true end
        end
    end


    -- Explicitly-enabled surgery/implant sources can make the existing target
    -- a finished carrier without any breeding. Resolve that before expanding
    -- the dense owned-species graph; this is both the most actionable answer
    -- and the largest source-policy performance win.
    local direct_routes = direct_target_source_routes(snapshot, target_id, c, k)
    if #direct_routes > 0 then
        last_plan_meta = { target = target_id, status = "direct-source-route",
            exhausted = false, route_count = #direct_routes, combinations = 0 }
        if report then report({ phase = "done", fraction = 1.0,
            detail = "现有目标可直接通过手术/植入成型" }) end
        return direct_routes
    end

    if report then report({ phase = "prepare", fraction = 1.0, detail = "正在整理现有个体" }) end
    local work, meta = run_workset(owned, snapshot, target_id, c, nil, 1, nil, report, "owned")
    if report then report({ phase = "finalize-owned", fraction = 0.5, detail = "正在整理现有家底方案" }) end
    local routes = finalize_routes(work, target_id, c)
    if #routes > 0 then
        table.sort(routes, owned_route_less)
        routes = dedupe_by_structure(routes, k)
        for _, route in ipairs(routes) do route.plan_profile = "现有家底" end
        last_plan_meta = { target = target_id, status = "owned-route", exhausted = meta.exhausted,
            iterations = meta.iterations, combinations = meta.combinations,
            planned_combinations = meta.planned_combinations, route_count = #routes }
        if report then report({ phase = "done", fraction = 1.0, detail = "方案已生成" }) end
        return routes
    end

    local sources = acquisition_sources(owned, snapshot, target_id, c)
    if report then report({ phase = "acquisition-prepare", fraction = 0.1,
        detail = "正在整理捕获、手术、植入与特殊词条来源" }) end
    local acquired_work, acquired_meta = run_workset(owned, snapshot, target_id, c, sources, 2, work,
        report, "acquisition")
    if report then report({ phase = "finalize", fraction = 0.5, detail = "正在比较候选方案" }) end
    local candidates = finalize_routes(acquired_work, target_id, c)
    local selected = select_diverse_routes(candidates, k)
    last_plan_meta = {
        target = target_id,
        status = #selected > 0 and "acquisition-route" or "no-route",
        exhausted = meta.exhausted or acquired_meta.exhausted,
        owned_iterations = meta.iterations,
        owned_combinations = meta.combinations,
        owned_planned_combinations = meta.planned_combinations,
        acquisition_iterations = acquired_meta.iterations,
        acquisition_combinations = acquired_meta.combinations,
        acquisition_planned_combinations = acquired_meta.planned_combinations,
        acquisition_sources = #sources,
        route_count = #selected,
    }
    if report then report({ phase = "done", fraction = 1.0, detail = "方案已生成" }) end
    return selected
end

function M.plan_weighted(owned, snapshot, target_id, raw_constraints, k)
    return plan_weighted_impl(owned, snapshot, target_id, raw_constraints, k, nil)
end

-- Coroutine-backed planner for UIs. The synchronous API above stays intact for
-- tests and non-UMG callers; every yielded value is a real search checkpoint.
function M.plan_weighted_async(owned, snapshot, target_id, raw_constraints, k)
    return coroutine.create(function()
        return plan_weighted_impl(owned, snapshot, target_id, raw_constraints, k, function(progress)
            coroutine.yield(progress)
        end)
    end)
end

function M.last_plan_meta()
    return last_plan_meta
end

function M.instance_satisfies(inst, raw_constraints)
    if not inst then return false end
    local c = normalize_constraints(raw_constraints)
    if c.final_gender ~= "Any" and inst.gender ~= c.final_gender then return false end
    local passives, skills = set_from_list(inst.passives), set_from_list(inst.equipped_skills)
    if not set_contains_all(passives, c.passives) then return false end
    if not set_contains_all(skills, c.skills) then return false end
    for stat, threshold in pairs(c.iv) do
        if not inst.iv or inst.iv[stat] == nil or inst.iv[stat] < threshold then return false end
    end
    return true
end

local function carrier_species(raw_born)
    local out, seen = {}, {}
    for _, raw in ipairs(raw_born or {}) do
        local id = normalize(raw)
        if id and not seen[id] then
            seen[id] = true
            local capture = data.capture and data.capture[id]
            -- first NON-worldtree row (spots[1] is a worldtree row for 26
            -- species — printing its converted square is the M1 bug)
            local spot = nil
            for _, s in ipairs(capture and capture.spots or {}) do
                if not is_worldtree_spot(s) then spot = s break end
            end
            out[#out + 1] = {
                id = id,
                level = spot and spot.min or math.huge,
                spot = spot,
            }
        end
    end
    table.sort(out, function(a, b)
        if a.level ~= b.level then return a.level < b.level end
        return a.id < b.id
    end)
    return out
end

-- Explain WHY a precise route is empty. This deliberately distinguishes
-- species reachability from breeding-property reachability: telling a player
-- to catch the target species is useless when the actual missing input is a
-- passive or active-skill carrier.
function M.constraint_gaps(snapshot, raw_constraints)
    local c = normalize_constraints(raw_constraints)
    local gaps = { passives = {}, skills = {}, ivs = {}, locks = {}, all_present = true,
        cake = c.cake, final_gender = c.final_gender }
    local instances = snapshot and snapshot.instances or {}
    for id in pairs(c.passives) do
        local owned_carriers = {}
        for _, inst in ipairs(instances) do
            for _, passive in ipairs(inst.passives or {}) do
                if passive == id then owned_carriers[#owned_carriers + 1] = inst break end
            end
        end
        local meta = passive_meta_by_id[id]
        local entry = {
            id = id,
            owned = owned_carriers,
            random_add = meta and (meta.rnd or meta.add) or false,
            lucky = meta and meta.lucky or false,
            mutation = meta and meta.mut or false,
            world_tree = meta and meta.world or false,
            fishing = meta and meta.fish or false,
            surgery = meta and meta.surg or "none",
            gold = meta and meta.gold or 0,
            item_name = meta and meta.itemzh or "",
            merchant = meta and meta.merchant or "",
            currency = meta and (meta.currencyzh ~= "" and meta.currencyzh or meta.currency) or "",
            merchant_price = meta and meta.mprice or 0,
            relics = meta and meta.relic or {},
            species = carrier_species(meta and meta.born or {}),
            source_allowed = {
                random = source_enabled(c, "random"),
                lucky = source_enabled(c, "lucky"),
                mutation = source_enabled(c, "mutation"),
                world = source_enabled(c, "world"),
                fishing = source_enabled(c, "fishing"),
                surgery = meta and source_enabled(c, meta.surg) or false,
            },
        }
        if #owned_carriers == 0 then gaps.all_present = false entry.missing = true end
        gaps.passives[#gaps.passives + 1] = entry
    end
    table.sort(gaps.passives, function(a, b) return a.id < b.id end)

    for id in pairs(c.skills) do
        local owned_carriers = {}
        for _, inst in ipairs(instances) do
            for _, skill in ipairs(inst.equipped_skills or {}) do
                if skill == id then owned_carriers[#owned_carriers + 1] = inst break end
            end
        end
        local meta = skill_meta_by_id[id]
        local born = {}
        for _, carrier in ipairs(meta and meta.born or {}) do born[#born + 1] = carrier.pal end
        local entry = { id = id, owned = owned_carriers, species = carrier_species(born),
            needs_special_cake = c.cake ~= "special" }
        if #owned_carriers == 0 then gaps.all_present = false entry.missing = true end
        if entry.needs_special_cake then gaps.all_present = false end
        gaps.skills[#gaps.skills + 1] = entry
    end
    table.sort(gaps.skills, function(a, b) return a.id < b.id end)

    for stat, threshold in pairs(c.iv) do
        local carriers = {}
        for _, inst in ipairs(instances) do
            local value = inst.iv and inst.iv[stat]
            if value and value >= threshold then carriers[#carriers + 1] = inst end
        end
        gaps.ivs[#gaps.ivs + 1] = { stat = stat, threshold = threshold, owned = carriers }
    end
    table.sort(gaps.ivs, function(a, b) return a.stat < b.stat end)

    for key in pairs(c.locked) do
        local inst = snapshot and snapshot.by_key and snapshot.by_key[key]
        gaps.locks[#gaps.locks + 1] = { key = key, inst = inst, missing = inst == nil }
        if not inst then gaps.all_present = false end
    end
    table.sort(gaps.locks, function(a, b) return a.key < b.key end)
    return gaps
end

-- Does an individual satisfy a breeding step's hard requirements (passives /
-- equipped skills / IV floors / required_gender)? Shared by project_status
-- (box-side done detection) and the farm-dispatch parent resolver. A nil
-- field on `inst` reads as the empty set / no data, so a step that demands
-- something from it is refused — "cannot vouch" must never claim success.
local function has_step_requirements(inst, step)
    if not inst then return false end
    -- required_gender (codex diagnosis 2026-07-18): an intermediate that
    -- must pair with a fixed same-gender co-parent is USELESS in the wrong
    -- gender — done detection and the egg preview must both refuse it. An
    -- unreadable gender (nil, possible on egg entries) refuses too. Old
    -- saved routes lack the field and keep their legacy behavior.
    if step and step.required_gender and inst.gender ~= step.required_gender then
        return false
    end
    local passives = set_from_list(inst.passives)
    local skills = set_from_list(inst.equipped_skills)
    if not set_contains_all(passives, set_from_list(step and step.passives)) then return false end
    if not set_contains_all(skills, set_from_list(step and step.skills)) then return false end
    for stat, threshold in pairs((step and step.iv) or {}) do
        if not inst.iv or inst.iv[stat] == nil or inst.iv[stat] < threshold then return false end
    end
    return true
end
M._has_step_requirements = has_step_requirements   -- offline test hook

-- Why is step `index` still undone? Name the closest near-miss (2.10.x,
-- field feedback: the pass rules — post-baseline + gender + full trait set
-- — were invisible, so a refresh that changed nothing read as broken).
-- Pure snapshot logic. Returns:
--   { kind = "baseline" }                    a FULLY qualifying instance
--                                            exists but predates the plan
--   { kind = "gender", need = "M"/"F" }      bred, ONLY the gender is off
--   { kind = "traits", missing = {ids} }     bred, closest one lacks these
--   { kind = "other" }                       bred, fails skills/IV gates
--   { kind = "none" }                        no post-baseline instance yet
function M.step_refresh_diagnosis(route, index, snapshot, baseline_keys)
    local step = route and route.steps and route.steps[index]
    if not step then return nil end
    baseline_keys = baseline_keys or {}
    local list = snapshot and snapshot.by_species
        and snapshot.by_species[step.c] or {}
    -- a fully qualifying but PRE-PLAN instance is the single most
    -- misleading miss — report it before anything else
    for _, inst in ipairs(list) do
        if baseline_keys[inst.key] and has_step_requirements(inst, step) then
            return { kind = "baseline" }
        end
    end
    -- skills + IV gates, the part of the requirements not covered by the
    -- caller's own passives/gender checks
    local function rest_gates_pass(inst)
        if not set_contains_all(set_from_list(inst.equipped_skills),
            set_from_list(step.skills)) then return false end
        for stat, threshold in pairs(step.iv or {}) do
            if not inst.iv or inst.iv[stat] == nil or inst.iv[stat] < threshold then
                return false
            end
        end
        return true
    end
    local best
    local RANK = { gender = 1, traits = 2, other = 3 }
    for _, inst in ipairs(list) do
        if not baseline_keys[inst.key] then
            -- "wrong gender" is only the verdict when everything ELSE
            -- passes (opus refresh r1 M2): a blank wrong-gender pal must
            -- not shadow the trait hint on a nearly-done right-gender one
            -- — gender is a coin flip per egg, missing traits are the
            -- thing the player actually has to fix first.
            local have = set_from_list(inst.passives)
            local missing = {}
            for _, id in ipairs(step.passives or {}) do
                if not have[id] then missing[#missing + 1] = id end
            end
            local cand
            if #missing > 0 then
                cand = { kind = "traits", missing = missing }
            elseif not rest_gates_pass(inst) then
                cand = { kind = "other" }
            elseif step.required_gender
                and inst.gender ~= step.required_gender then
                cand = { kind = "gender", need = step.required_gender }
            end
            -- all four gates passing is unreachable while the step is
            -- undone; nil cand just skips the instance defensively
            if cand and (not best
                or (RANK[cand.kind] or 9) < (RANK[best.kind] or 9)
                or (cand.kind == "traits" and best.kind == "traits"
                    and #cand.missing < #best.missing)) then
                best = cand
            end
        end
    end
    return best or { kind = "none" }
end

-- (Egg-preview reading/matching lived here 2026-07-18 and was withdrawn the
-- same day: produced/picked-up egg item entries keep their SaveParameter at
-- default zeroes long past construction — two field rounds read 0/0/0/0 IVs
-- and empty traits with a 2s maturity delay, so the "announce the egg before
-- it hatches" premise does not hold on live entries. Box-side tracking is
-- the authority; see git history for the implementation.)

-- Live-handle identity for the farm-dispatch re-resolver: same persistent
-- key the snapshot records, so a box/base sweep can find "that exact pal".
function M.handle_key(handle, param)
    return (individual_id(handle, param))
end

-- Walk to the Nth breed-node OCCURRENCE in postorder — the step<->node
-- mapping rule shared with apply_intermediate_gender: the route is a DAG,
-- occurrences map to steps, node identity does not.
local function breed_node_at(tree, want)
    local pos, found = 0, nil
    local function walk(node)
        if not node or found then return end
        if node.kind == "operate" then walk(node.base) return end
        if node.kind ~= "breed" then return end
        walk(node.left)
        walk(node.right)
        pos = pos + 1
        if pos == want and not found then found = node end
    end
    walk(tree)
    return found
end

local function count_breed_occurrences(node)
    if not node then return 0 end
    if node.kind == "operate" then return count_breed_occurrences(node.base) end
    if node.kind ~= "breed" then return 0 end
    return count_breed_occurrences(node.left) + count_breed_occurrences(node.right) + 1
end

-- Farm dispatch (1.6.0): resolve WHICH two concrete individuals step
-- `index` should breed right now. Pure snapshot logic, no engine calls —
-- the UI re-resolves live handles at dispatch time. Returns
-- { a = inst, b = inst } or { error = "..." } (user-facing text).
function M.resolve_step_parents(route, snapshot, baseline_keys, index)
    if not (route and route.tree and route.steps and snapshot) then
        return { error = "方案数据不完整，无法定位亲代。" }
    end
    local step = route.steps[index]
    local node = step and breed_node_at(route.tree, index)
    if not node then return { error = "方案树与步骤不对应，请重新生成方案。" } end
    baseline_keys = baseline_keys or {}
    local function unwrap_node(n)
        while n and n.kind == "operate" do n = n.base end
        return n
    end
    -- postorder: [left subtree][right subtree][self] — the producing step
    -- of each child subtree is that subtree's LAST occurrence
    local right_count = count_breed_occurrences(node.right)
    local left_root = count_breed_occurrences(node.left) > 0
        and (index - 1 - right_count) or nil
    local right_root = right_count > 0 and (index - 1) or nil
    local function resolve_side(child, produced_index, exclude_key, prefer_gender)
        child = unwrap_node(child)
        if not child then return nil, "方案树缺少亲代节点。" end
        if child.kind == "owned" then
            local key = child.inst and child.inst.key
            local live = key and snapshot.by_key and snapshot.by_key[key]
            if not live then
                return nil, string.format("找不到亲代（%s）——可能已被移动或消耗；点「刷新进度」后重试。",
                    tostring(child.inst and child.inst.species or "?"))
            end
            if exclude_key and live.key == exclude_key then
                return nil, "两侧解析到同一只帕鲁，无法配种。"
            end
            return live, nil
        end
        if child.kind == "breed" then
            local pstep = produced_index and route.steps[produced_index]
            local fallback
            for _, inst in ipairs((snapshot.by_species and snapshot.by_species[child.species]) or {}) do
                if not baseline_keys[inst.key] and inst.key ~= exclude_key
                    and has_step_requirements(inst, pstep) then
                    if not prefer_gender or inst.gender == prefer_gender then
                        return inst, nil
                    end
                    fallback = fallback or inst
                end
            end
            if fallback then return fallback, nil end
            return nil, string.format("第 %d 步的中间代（%s）尚未配出或不满足词条要求。",
                produced_index or 0, tostring(child.species or "?"))
        end
        return nil, "该步骤的亲代需要先完成捕获/来源操作。"
    end
    local a, err_a = resolve_side(node.left, left_root, nil, nil)
    if not a then return { error = err_a } end
    local prefer = (a.gender == "F" and "M") or (a.gender == "M" and "F") or nil
    local b, err_b = resolve_side(node.right, right_root, a.key, prefer)
    if not b then return { error = err_b } end
    if a.gender and b.gender and a.gender == b.gender then
        -- dispatch stays STRICT even in gender-potion mode — a same-gender
        -- pair on a live farm never lays an egg; the potion route is
        -- always named so every player learns the mechanic (2.10.0)
        return { error = string.format(T("两只亲代同为%s，无法配种；请先配出另一性别，或在手术台对其中一只使用帕鲁性转药后再送。"),
            a.gender == "F" and "♀" or "♂") }
    end
    return { a = a, b = b }
end

-- ---------- breeding-farm discovery (2.13.0, bh-001 single-player fix) ----------

-- Work classes every KNOWN breeding facility runs (probed live 2026-07-19):
-- plain pen = AndWalkAround, ancient hatch+breed combo = Invisible. Shared
-- with ui.lua so every farm surface sweeps the same set.
M.BREED_WORK_CLASSES = { "PalWorkOnlyJoinAndWalkAround", "PalWorkOnlyJoinInvisible" }

-- Uppercase-normalized guid text. Membership sets built here get compared
-- against keys produced by ui.lua's own Kismet conversion; both sides call
-- KismetGuidLibrary underneath, the normalization just removes any residual
-- case doubt from set lookups.
function M.norm_guid(v)
    local s = guid_string(v)
    if not s then return nil end
    s = s:upper()
    -- Kismet Digits shape ONLY (32 hex, no dashes). guid_string has non-
    -- Kismet fallback branches whose output ui.guid_text can never produce;
    -- letting such a key into the roster would fail every set lookup and
    -- silently filter ALL farms. Rejecting it instead collapses the roster
    -- to empty -> the worker-heuristic fallback -> at worst the pre-2.13
    -- behaviour (opus 2.13.0 r1 MINOR-3: degrade open, never blank).
    if #s ~= 32 or not s:match("^[0-9A-F]+$") then return nil end
    return s
end

-- The local guild's own base-camp roster: (guild_id, set-of-camp-id, count).
-- This is the OWNERSHIP truth for camps — a freshly built camp joins its
-- guild's roster immediately, workers or not. The old farm-surface proxy
-- ("a camp holding one of my working pals is mine") voted new/unmanned
-- camps foreign and silently ate their farms: field cluster bh-001 — camps
-- rebuilt after a base move, worker-less "index>4" camps, and farms that
-- only came alive after a pal was manually stationed once. Resolution
-- mirrors the proven snapshot-scan recipe (PlayerState.GuildBelongTo first,
-- PalGroupUtility fallback); both are field-exercised on every net mode.
function M.local_guild_camp_ids()
    local guild_id, ids, n = nil, {}, 0
    pcall(function()
        local pc = M.local_player_controller()
        local ps = pc and pc.PlayerState
        local guild = ps and ps.GuildBelongTo
        local ok = false
        pcall(function() ok = guild and guild:IsValid() end)
        if not ok then
            pcall(function()
                local util = StaticFindObject("/Script/Pal.Default__PalGroupUtility")
                local world = pc and pc:GetWorld()
                if util and world then guild = util:GetLocalPlayerGuild(world) end
            end)
            pcall(function() ok = guild and guild:IsValid() end)
        end
        if not ok then return end
        pcall(function() guild_id = M.norm_guid(guild:GetId()) end)
        pcall(function()
            guild.BaseCampIds:ForEach(function(_, entry)
                local id = M.norm_guid(entry)
                if id and not ids[id] then
                    ids[id] = true
                    n = n + 1
                end
            end)
        end)
    end)
    return guild_id, ids, n
end

-- Union sweep for breeding-work objects over two independent channels:
--   class: FindAllOf on the known work classes — the original channel, and
--     the only one that answers on a pure multiplayer client (the work map
--     below is server-side).
--   camp:  BaseCampModel -> WorkCollection.WorkIds -> WorkProgressManager
--     :GetWork(id). Alive on standalone/host, where this process IS the
--     server; class-name agnostic, so a farm work running an OnlyJoin
--     variant the class list doesn't know still surfaces. On a pure client
--     GetWork simply misses and the channel yields nothing.
-- The camp channel keeps only works whose full name carries the OnlyJoin
-- family marker: every known breeding work is an OnlyJoin*, and running the
-- map-object-model hop on the hundreds of ordinary works per camp would
-- turn a menu open into a hitch. dbg.camp_skipped counts what the marker
-- dropped, so a field trace can prove if a farm ever runs outside the
-- family. Dedup is by WorkId text — wrapper identity is not stable across
-- channels.
-- INTEGRITY CONTRACT (codex 2.13.0 r1 BLOCKER): dbg.complete=false whenever
-- the returned list may be MISSING a live work — any engine read that THREW,
-- or a work that could not even be identified for dedup. Structural absences
-- (FindAllOf nil, wpm/collection unavailable, GetWork map miss) stay
-- complete: they are indistinguishable from legitimately-empty state, the
-- class channel remains the pre-2.13 authority baseline there, and poisoning
-- on them would leave the farm-keys cache permanently stale. Consumers whose
-- correctness depends on coverage (M._farm_keys re-dispatch lockout) must
-- treat complete=false exactly like a per-farm read failure.
function M.collect_breed_works()
    local works = {}
    local seen = {}
    local dbg = { class_hits = 0, camps = 0, camp_ids = 0, resolved = 0,
                  camp_extra = 0, camp_skipped = 0, camp_dup = 0,
                  wpm = false, complete = true }
    local function keep(w)
        local key
        pcall(function() key = guid_string(w:GetWorkId()) end)
        -- an all-zero id is a replication-window placeholder, not an
        -- identity: two works in that window would silently dedupe into
        -- one (opus 2.13.0 r1 MINOR-2) — send it to the FullName fallback
        if key and key:gsub("[0%-]", "") == "" then key = nil end
        if not key then pcall(function() key = w:GetFullName() end) end
        if not key then
            -- a work we cannot IDENTIFY is a work this sweep cannot vouch
            -- for: drop it, but never pretend the list is whole
            dbg.complete = false
            return false
        end
        if seen[key] then return false end
        seen[key] = true
        works[#works + 1] = w
        return true
    end
    local ok_class = pcall(function()
        for _, cls in ipairs(M.BREED_WORK_CLASSES) do
            for _, w in ipairs(FindAllOf(cls) or {}) do
                local ok_w = pcall(function()
                    if w and w:IsValid() then
                        dbg.class_hits = dbg.class_hits + 1
                        keep(w)
                    end
                end)
                if not ok_w then dbg.complete = false end
            end
        end
    end)
    if not ok_class then dbg.complete = false end
    local ok_camp = pcall(function()
        local pc = M.local_player_controller()
        local util = StaticFindObject("/Script/Pal.Default__PalUtility")
        local wpm
        if util and pc then wpm = util:GetWorkProgressManager(pc) end
        local wpm_ok = false
        pcall(function() wpm_ok = wpm and wpm:IsValid() end)
        if not wpm_ok then return end
        dbg.wpm = true
        for _, camp in ipairs(FindAllOf("PalBaseCampModel") or {}) do
            local ok_c = pcall(function()
                if not (camp and camp:IsValid()) then return end
                dbg.camps = dbg.camps + 1
                local col = camp.WorkCollection
                local col_ok = false
                pcall(function() col_ok = col and col:IsValid() end)
                if not col_ok then return end
                col.WorkIds:ForEach(function(_, entry)
                    dbg.camp_ids = dbg.camp_ids + 1
                    local ok_i = pcall(function()
                        -- already-seen ids skip the GetWork/GetFullName pair
                        -- entirely (opus MAJOR-2: the class channel already
                        -- carries most farm works — resolving them again
                        -- was pure game-thread waste). A pre-check miss is
                        -- harmless: keep() still dedupes by the work's own
                        -- id after resolution.
                        local pre
                        pcall(function() pre = guid_string(entry) end)
                        if pre and seen[pre] then
                            dbg.camp_dup = dbg.camp_dup + 1
                            return
                        end
                        local w = wpm:GetWork(unwrap(entry))
                        if not (w and w:IsValid()) then return end
                        dbg.resolved = dbg.resolved + 1
                        local full
                        local name_ok = pcall(function() full = w:GetFullName() end)
                        if not (name_ok and type(full) == "string") then
                            -- resolved a live work but cannot classify it:
                            -- identification failure, not a structural miss
                            dbg.complete = false
                            return
                        end
                        if not full:find("PalWorkOnlyJoin", 1, true) then
                            dbg.camp_skipped = dbg.camp_skipped + 1
                            return
                        end
                        if keep(w) then dbg.camp_extra = dbg.camp_extra + 1 end
                    end)
                    if not ok_i then dbg.complete = false end
                end)
            end)
            if not ok_c then dbg.complete = false end
        end
    end)
    if not ok_camp then dbg.complete = false end
    return works, dbg
end

-- Live breeding pens, resolved back to the exact local-guild individuals in
-- the current snapshot. Foreign farms are discarded because their instance
-- ids are absent from the local snapshot. Sweeps the union channel so pens
-- in cold/unmanned camps (standalone) are covered; the name gate keeps the
-- original pen-only scope — the ancient combo's occupancy semantics stay
-- out of progress judgement, unchanged from every release before 2.13.0.
function M.read_breeding_farms(snapshot)
    local out = {}
    if not snapshot then return out end
    local union = M.collect_breed_works()
    for _, work in ipairs(union) do
        pcall(function()
            local full_name = ""
            pcall(function() full_name = work:GetFullName() end)
            if not full_name:find("JoinAndWalkAround", 1, true) then return end
            local slots = {}
            work:GetAssignedCharacters(slots)
            local parents = {}
            for _, entry in ipairs(slots) do
                pcall(function()
                    local slot = unwrap(entry)
                    local handle = slot and slot:GetHandle()
                    if not (handle and handle:IsValid()) then return end
                    local param = handle:TryGetIndividualParameter()
                    if not (param and param:IsValid()) then return end
                    local key = individual_id(handle, param)
                    local inst = key and snapshot.by_key and snapshot.by_key[key]
                    if inst then parents[#parents + 1] = inst end
                end)
            end
            if #parents >= 2 then
                local name = "breeding-farm"
                pcall(function() name = work:GetFullName() end)
                out[#out + 1] = { name = name, a = parents[1], b = parents[2] }
            end
        end)
    end
    return out
end

function M.project_status(route, snapshot, baseline_keys, raw_constraints)
    local statuses = {}
    if not (route and snapshot) then return statuses, false end
    baseline_keys = baseline_keys or {}
    local farms = M.read_breeding_farms(snapshot)
    local project_complete = false
    local function has_source_requirements(inst, acquisition)
        if not inst then return false end
        local passives, skills = set_from_list(inst.passives), set_from_list(inst.equipped_skills)
        return set_contains_all(passives, set_from_list(acquisition.passives))
            and set_contains_all(skills, set_from_list(acquisition.skills))
    end
    for _, acquisition in ipairs(route.acquisitions or {}) do
        local done, detail = false, "尚未完成来源操作"
        if acquisition.kind == "surgery" and acquisition.base_inst then
            local current = snapshot.by_key and snapshot.by_key[acquisition.base_inst.key]
            done = has_source_requirements(current, acquisition)
            detail = done and "现有个体已完成手术" or "等待对指定现有个体做手术"
        else
            for _, inst in ipairs((snapshot.by_species and snapshot.by_species[acquisition.species]) or {}) do
                if not baseline_keys[inst.key] and has_source_requirements(inst, acquisition) then
                    done = true
                    local done_text = {
                        ["capture-surgery"] = "已发现捕获并完成手术的新个体",
                        mutation = "已发现符合要求的新突变个体",
                        ["world-tree"] = "已发现符合要求的世界树词条个体",
                        fishing = "已发现符合要求的钓鱼词条个体",
                        lucky = "已发现符合要求的幸运个体",
                    }
                    detail = done_text[acquisition.kind] or "已发现符合来源要求的新个体"
                    break
                end
            end
        end
        acquisition.status = done and "done" or "blocked"
        acquisition.status_detail = detail
    end
    for _, operation in ipairs(route.operations or {}) do
        local status, detail = "blocked", "先完成对应的中间代配种"
        local requirement = {
            passives = operation.required_passives or operation.passives,
            skills = operation.skills or {},
        }
        for _, inst in ipairs((snapshot.by_species and snapshot.by_species[operation.species]) or {}) do
            if not baseline_keys[inst.key] then
                if has_source_requirements(inst, requirement) then
                    status, detail = "done", "已发现完成手术的中间代"
                    break
                elseif status == "blocked" then
                    status, detail = "active", "中间代已配出，等待手术/植入"
                end
            end
        end
        operation.status = status
        operation.status_detail = detail
    end
    local target_list = snapshot.by_species and snapshot.by_species[route.target] or {}
    for _, inst in ipairs(target_list or {}) do
        if M.instance_satisfies(inst, raw_constraints)
                and (route.step_count == 0 or not baseline_keys[inst.key]) then
            project_complete = true
            break
        end
    end
    for i, step in ipairs(route.steps or {}) do
        local status, detail = "blocked", "缺少可用亲代"
        for _, inst in ipairs((snapshot.by_species and snapshot.by_species[step.c]) or {}) do
            if not baseline_keys[inst.key] and has_step_requirements(inst, step) then
                status, detail = "done", "已发现满足本步词条/技能要求的新个体"
                break
            end
        end
        if status ~= "done" then
            for _, farm in ipairs(farms) do
                if (farm.a.species == step.a and farm.b.species == step.b)
                        or (farm.a.species == step.b and farm.b.species == step.a) then
                    status, detail = "active", "牧场双亲已匹配"
                    break
                end
            end
        end
        if status == "blocked" then
            local aa = snapshot.by_species and snapshot.by_species[step.a]
            local bb = snapshot.by_species and snapshot.by_species[step.b]
            if aa and #aa > 0 and bb and #bb > 0 then
                status, detail = "ready", "亲代已在你的家底中"
            end
        end
        statuses[i] = { status = status, detail = detail }
    end
    if project_complete then
        -- The fixed route is a means to the requested target, not an audit log
        -- of how that target was obtained. Once a qualifying post-baseline
        -- target exists, no source action, surgery or breeding step remains;
        -- marking only the last step produced the contradictory "已完成 / 1/N".
        for i = 1, #(route.steps or {}) do
            statuses[i] = { status = "done", detail = "目标个体已达成全部硬约束" }
        end
        for _, acquisition in ipairs(route.acquisitions or {}) do
            acquisition.status = "done"
            acquisition.status_detail = "目标已达成，无需继续来源操作"
        end
        for _, operation in ipairs(route.operations or {}) do
            operation.status = "done"
            operation.status_detail = "目标已达成，无需继续手术/植入"
        end
    end
    return statuses, project_complete
end

-- ---------------------------------------------------------------------------
-- V1.3: reverse solve / verify / catch suggestions / trait pool / work lookup
-- ---------------------------------------------------------------------------

-- all species that pair with `a_id` to yield `c_id`; owned candidates first,
-- then ascending rank. Exact inverse of children_of (linear scan, ~300 calls)
function M.reverse_solve(a_id, c_id, owned)
    local out = {}
    for _, p in ipairs(data.pals) do
        for _, k in ipairs(children_of(a_id, p.id)) do
            if k == c_id then
                out[#out + 1] = p
                break
            end
        end
    end
    table.sort(out, function(x, y)
        local ox = (owned and owned[x.id]) and 1 or 0
        local oy = (owned and owned[y.id]) and 1 or 0
        if ox ~= oy then return ox > oy end
        return x.r < y.r
    end)
    return out
end

-- Every species that can appear on either side of a DIRECT recipe for the
-- requested child. This is the calculator's context dropdown; it deliberately
-- does not include multi-generation bridges (the decomposition panel owns
-- that job). Owned species are green in the UI and sorted first.
function M.direct_parents(c_id, owned)
    local out, seen = {}, {}
    for _, pair in ipairs(get_producer_index()[c_id] or {}) do
        for _, id in ipairs({ pair.a, pair.b }) do
            if not seen[id] and by_id[id] then
                seen[id] = true
                out[#out + 1] = by_id[id]
            end
        end
    end
    table.sort(out, function(a, b)
        local ao = owned and owned[a.id] and 1 or 0
        local bo = owned and owned[b.id] and 1 or 0
        if ao ~= bo then return ao > bo end
        if a.r ~= b.r then return a.r < b.r end
        return a.id < b.id
    end)
    return out
end

-- Every direct recipe pair yielding c_id that the player could run from
-- CURRENT species, plus the total recipe count. Community request: typing
-- only the wanted child must immediately show runnable pairs — no second
-- input, no passive constraints. Gender-ready pairs sort before pairs with
-- a gender gap; within a group easier (lower combined rarity) pals first.
-- Returns (owned_pairs, total): owned_pairs = { {a=id, b=id, note=str} }.
function M.direct_pairs(c_id, owned)
    local all = get_producer_index()[c_id] or {}
    local out = {}
    for _, pair in ipairs(all) do
        if owned and owned[pair.a] and owned[pair.b] then
            local note, ready = M.gender_note(owned, pair.a, pair.b, c_id)
            out[#out + 1] = {
                a = pair.a,
                b = pair.b,
                note = note or "",
                ready = ready and true or false,
            }
        end
    end
    local function rarity_sum(p)
        local pa, pb = by_id[p.a], by_id[p.b]
        return ((pa and pa.rar) or 99) + ((pb and pb.rar) or 99)
    end
    table.sort(out, function(x, y)
        local gx = x.ready and 0 or 1
        local gy = y.ready and 0 or 1
        if gx ~= gy then return gx < gy end
        local rx, ry = rarity_sum(x), rarity_sum(y)
        if rx ~= ry then return rx < ry end
        if x.a ~= y.a then return x.a < y.a end
        return x.b < y.b
    end)
    return out, #all
end

function M.verify_pair(a_id, b_id, c_id)
    for _, k in ipairs(children_of(a_id, b_id)) do
        if k == c_id then return true end
    end
    return false
end

-- recipe rows producing c_id (both gendered directions included)
function M.producers(c_id)
    local out = {}
    for _, u in ipairs(data.unique) do
        if u.c == c_id then out[#out + 1] = u end
    end
    return out
end

-- Species that can ONLY be bred from a same-species pair (2.2, owner
-- request): every producer pair is (species, species) — the legendaries
-- excluded from the normal child pool by IgnoreCombi, etc. The player must
-- CATCH one first; the plan texts and habitat marking call this out.
-- Species with no producers at all return false: "not breedable" is a
-- different, already-handled message.
function M.self_breed_only(species_id)
    local pairs_for = get_producer_index()[species_id]
    if not pairs_for or #pairs_for == 0 then return false end
    for _, pair in ipairs(pairs_for) do
        if pair.a ~= species_id or pair.b ~= species_id then return false end
    end
    return true
end

-- does closure(base + extra) reach target? incremental: only pair the new
-- frontier against base+new, so a full suggest_catch sweep stays affordable
local function reaches_with(base, extra, target)
    if extra == target then return true end
    local known = { [extra] = true }
    local all, frontier = { extra }, { extra }
    for id in pairs(base) do all[#all + 1] = id end
    for _ = 1, MAX_WAVES do
        local new = {}
        for i = 1, #all do
            local a = all[i]
            for j = 1, #frontier do
                for _, c in ipairs(children_of(a, frontier[j])) do
                    if base[c] == nil and known[c] == nil and new[c] == nil then
                        if c == target then return true end
                        new[c] = true
                    end
                end
            end
        end
        local added = {}
        for c in pairs(new) do
            known[c] = true
            all[#all + 1] = c
            added[#added + 1] = c
        end
        if #added == 0 then return false end
        frontier = added
    end
    return false
end

-- single-catch suggestions: species X (not yet obtainable) such that owning X
-- makes target reachable. Sorted by rarity (easier catches first). Runs one
-- full closure + up to ~290 incremental closures -- only call on demand.
function M.suggest_catch(owned, target_id)
    local known = cached_closure(owned)
    if known[target_id] ~= nil then return nil end   -- already reachable
    local out = {}
    for _, p in ipairs(data.pals) do
        if known[p.id] == nil and reaches_with(known, p.id, target_id) then
            out[#out + 1] = p
        end
    end
    table.sort(out, function(x, y)
        if (x.rar or 99) ~= (y.rar or 99) then return (x.rar or 99) < (y.rar or 99) end
        return x.r > y.r
    end)
    return out
end

-- all owned pairs that directly yield target_id (exact, via children_of over
-- owned x owned; ~2k calls for a 60-species box -- fine on demand)
function M.owned_pairs_for(target_id, owned)
    if not owned then return {} end
    local index = direct_pair_cache[owned]
    if not index then
        local ids = {}
        for id in pairs(owned) do ids[#ids + 1] = id end
        table.sort(ids)
        index = {}
        for i = 1, #ids do
            for j = i, #ids do
                local seen_child = {}
                for _, c in ipairs(children_of(ids[i], ids[j])) do
                    if not seen_child[c] then
                        seen_child[c] = true
                        local out = index[c]
                        if not out then out = {} index[c] = out end
                        out[#out + 1] = { a = ids[i], b = ids[j] }
                    end
                end
            end
        end
        direct_pair_cache[owned] = index
        cache_stats.direct_pair_builds = cache_stats.direct_pair_builds + 1
    end
    return index[target_id] or {}
end

-- shortest breeding chain that STARTS FROM species e_id as a parent and ends
-- at target_id: e x q1 -> c1, c1 x q2 -> c2, ..., ck = target. The co-parents
-- are existentially chosen during BFS; each hop then lists ALL alternatives
-- (owned-first) so the player can pick what they actually have. Use case:
-- "I want THIS pal (good passives) in the chain even if it takes 2-3 hops."
function M.bridge(e_id, target_id, owned, max_hops)
    max_hops = max_hops or 3
    if e_id == target_id then return {} end
    local prev = { [e_id] = false }
    local frontier, found = { e_id }, false
    for _ = 1, max_hops do
        local nxt = {}
        for _, p in ipairs(frontier) do
            for _, q in ipairs(data.pals) do
                for _, c in ipairs(children_of(p, q.id)) do
                    if prev[c] == nil then
                        prev[c] = p
                        nxt[#nxt + 1] = c
                        if c == target_id then found = true break end
                    end
                end
                if found then break end
            end
            if found then break end
        end
        if found then break end
        frontier = nxt
        if #frontier == 0 then break end
    end
    if not found then return nil end
    local chain, cur = {}, target_id
    while cur ~= e_id do
        local p = prev[cur]
        table.insert(chain, 1, { p = p, c = cur })
        cur = p
    end
    for _, hop in ipairs(chain) do
        hop.alts = M.reverse_solve(hop.p, hop.c, owned)
    end
    return chain
end

-- plan as if one extra species were owned (used to preview "catch X -> N
-- steps" for suggest_catch results)
function M.plan_with_extra(owned, extra_id, target_id)
    local o2 = { [extra_id] = { male = 1, female = 1, pv = {} } }
    for k, v in pairs(owned) do o2[k] = v end
    -- This synthetic snapshot is used once per catch suggestion, so a full
    -- reusable closure would be wasted work. Stop as soon as its one target
    -- is reached and do not populate the weak cache.
    return M.plan(o2, target_id, MAX_WAVES)
end

-- Test/diagnostic hooks. Production code never needs to invalidate because
-- read_owned() returns a fresh immutable table on every panel open.
function M._cache_counts()
    return cache_stats.closure_builds, cache_stats.direct_pair_builds
end

function M._clear_cache(owned)
    if owned then
        closure_cache[owned] = nil
        depth_cache[owned] = nil
        direct_pair_cache[owned] = nil
    else
        closure_cache = setmetatable({}, { __mode = "k" })
        depth_cache = setmetatable({}, { __mode = "k" })
        direct_pair_cache = setmetatable({}, { __mode = "k" })
    end
end

-- Pure-data test hook for the runtime reflection reader. The production UI
-- only consumes read_owned(); exposing this keeps fake UE objects out of the
-- planner implementation and lets offline tests lock every captured field.
function M._record_snapshot(owned, snapshot, param, meta)
    local inst = record(owned, snapshot, param, meta)
    return inst
end

-- trait pool of a plan: union of passives on the OWNED species the steps
-- consume (inherited passives can only come from the parents' union,
-- applied recursively down the tree)
function M.passive_pool(owned, steps)
    local pool, list, leaves, seen = {}, {}, {}, {}
    for _, s in ipairs(steps) do
        for _, pid in ipairs({ s.a, s.b }) do
            if owned[pid] and not seen[pid] then
                seen[pid] = true
                leaves[#leaves + 1] = pid
                for pv in pairs(owned[pid].pv or {}) do
                    if not pool[pv] then
                        pool[pv] = true
                        list[#list + 1] = pv
                    end
                end
            end
        end
    end
    table.sort(list)
    return list, leaves
end

-- pals with work suitability `work_key` at level >= min_lv, best first
function M.work_lookup(work_key, min_lv)
    min_lv = min_lv or 1
    local out = {}
    for _, p in ipairs(data.pals) do
        local lv = p.w and p.w[work_key]
        if lv and lv >= min_lv then out[#out + 1] = { p = p, lv = lv } end
    end
    table.sort(out, function(x, y)
        if x.lv ~= y.lv then return x.lv > y.lv end
        if (x.p.rar or 99) ~= (y.p.rar or 99) then return (x.p.rar or 99) < (y.p.rar or 99) end
        return x.p.r > y.p.r
    end)
    return out
end

-- gender guidance for a step (a x b -> c):
--  * direction-locked recipes always state the required direction (which
--    parent must be male), plus a warning when owned genders cannot satisfy it
--  * plain steps with both parents owned: warn when no M/F pairing exists
-- Returns (note, ready). `ready` is the machine-readable verdict: the note
-- TEXT is not a proxy for it — direction-locked recipes always carry a
-- 限定 note even when the player's genders already fit (codex review
-- blocker: grouping on `note == ""` sorted perfectly runnable direction
-- recipes behind gender-gapped pairs). Existing single-value callers keep
-- working; direct_pairs consumes the second value.
function M.gender_note(owned, a, b, c)
    local pa, pb = by_id[a], by_id[b]
    if pa and pb then
        local g = gendered[pair_key(pa.tribe, pb.tribe)]
        if g then
            for _, u in ipairs(g) do
                if u.c == c then
                    local ma = by_tribe[u.a] or pa   -- u.a/u.b are tribes
                    local mb = by_tribe[u.b] or pb
                    local male, female = ma, mb
                    if u.ga ~= "Male" then male, female = mb, ma end
                    local note = string.format(T("（限定 %s♂ × %s♀）"), disp_name(male), disp_name(female))
                    local em, ef = owned[male.id], owned[female.id]
                    if em and ef and not (em.male > 0 and ef.female > 0) then
                        return note .. T("（现有性别不符，需先补出对应性别）"), false
                    end
                    return note, true
                end
            end
        end
    end
    local ea, eb = owned[a], owned[b]
    if not (ea and eb) then return "", true end  -- involves bred intermediates
    if a == b then
        if ea.male > 0 and ea.female > 0 then return "", true end
        return T("（需补齐公母）"), false
    end
    if (ea.male > 0 and eb.female > 0) or (ea.female > 0 and eb.male > 0) then
        return "", true
    end
    return T("（现有性别不配对，需先孵/抓一只异性）"), false
end

M.by_id = by_id
M.by_tribe = by_tribe
M.children_of = children_of   -- exported for ui.lua + tools/verify_impls.py
M.nearest = nearest

-- test probe: the producer index must be warm straight out of require()
function M._producer_index_ready()
    return producer_index ~= nil
end

-- Warm the producer index at require time: mod load runs during game
-- startup where the ~100ms full build (289 species, ~42k pairs) is
-- invisible, while the old lazy build landed on the UI thread as a visible
-- first-use hitch (codex review probe: 77-102ms cold, ~4ms warm).
get_producer_index()

return M

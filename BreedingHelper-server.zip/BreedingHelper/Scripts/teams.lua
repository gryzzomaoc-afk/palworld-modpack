-- 帕鲁阵容 (team loadouts): gap detection over the built-in presets from
-- teams_data.lua plus (later) player-defined teams. PURE logic only -- no
-- widget access, no game-object access -- so tools/test_v13.py can drive
-- every path offline. The UI tab (ui.lua) renders what these functions
-- return; the in-place planning button reuses the planner's compute entry.
local data_ok, tdata = pcall(require, "teams_data")

local M = {}

M.data_ok = data_ok and tdata ~= nil

function M.builtin()
    return (M.data_ok and tdata.builtin) or {}
end

-- owned_tribes: set { [tribe] = truthy } -- tribe-level like the calculator's
-- single-parent query (owning a skin variant still counts as having the pal).
--
-- Returns a report the UI can render directly:
--   slots_total / slots_done  -- completion is counted in SLOTS: a member
--     and its alt_of upgrades share one slot, owning either fills it
--   members[i] = { m = <member>, have = bool, slot_done = bool }
--     have      = this exact member's tribe is owned
--     slot_done = the slot this member belongs to is filled (self or alt)
function M.gap_check(team, owned_tribes)
    owned_tribes = owned_tribes or {}
    local report = { slots_total = 0, slots_done = 0, members = {} }
    if not team or not team.members then return report end
    -- slot key = the root member id (alt_of target if present)
    local slot_have = {}
    for _, m in ipairs(team.members) do
        local slot = m.alt_of or m.id
        if slot_have[slot] == nil then slot_have[slot] = false end
        if owned_tribes[m.id] then slot_have[slot] = true end
    end
    for slot, have in pairs(slot_have) do
        report.slots_total = report.slots_total + 1
        if have then report.slots_done = report.slots_done + 1 end
    end
    for _, m in ipairs(team.members) do
        report.members[#report.members + 1] = {
            m = m,
            have = owned_tribes[m.id] and true or false,
            slot_done = slot_have[m.alt_of or m.id] and true or false,
        }
    end
    return report
end

-- Build the tribe-level owned set from the panel's raw snapshot instances
-- (each { species = <id>, ... }). Kept here so ui.lua has one call to make.
function M.owned_tribes_of(instances, by_id)
    local owned = {}
    for _, inst in ipairs(instances or {}) do
        local rec = by_id and by_id[inst.species]
        owned[(rec and rec.tribe) or inst.species] = true
    end
    return owned
end

-- ---------------------------------------------------------------------------
-- r21 custom teams (player-defined, cross-save). PURE string<->table logic
-- lives here so the suite can pin it; file io stays in ui.lua like the
-- preset/plan libraries. A custom member is { id, zh } — no place/skill/
-- alt_of semantics, so gap_check counts one slot per member unchanged.
-- ---------------------------------------------------------------------------
M.MAX_CUSTOM_TEAMS = 6
M.MAX_CUSTOM_MEMBERS = 10
M.MAX_CUSTOM_PV = 4   -- r23: wished passives per member (game slot cap)

-- v2 line: "v2|name|id:pv1+pv2:note;id2::note2"  — member fields are
-- colon-separated (pv joined by '+', note free text). Separators and
-- newlines are stripped from names/notes on serialize so player input can
-- never corrupt the format. v1 lines ("name|id1,id2") still parse.
function M.serialize_custom(team)
    local members = {}
    for _, m in ipairs(team.members or {}) do
        local pv = table.concat(m.pv or {}, "+")
        local note = tostring(m.note or ""):gsub("[|;:\r\n]", "")
        members[#members + 1] = m.id .. ":" .. pv .. ":" .. note
    end
    local name = tostring(team.name or ""):gsub("[|\r\n]", "")
    return "v2|" .. name .. "|" .. table.concat(members, ";")
end

-- passives validate against the pdb index when given; unknown ids drop
local function parse_member(rec, pv_csv, note, passive_ok)
    local member = { id = rec.tribe or rec.id, zh = rec.zh,
                     pv = {}, note = note or "" }
    for pid in tostring(pv_csv or ""):gmatch("[^+]+") do
        if (not passive_ok or passive_ok[pid])
                and #member.pv < M.MAX_CUSTOM_PV then
            member.pv[#member.pv + 1] = pid
        end
    end
    return member
end

function M.parse_custom(line, by_id, passive_ok)
    line = tostring(line or "")
    -- v2 requires all THREE fields in one match (codex r22 #4: a v1 team
    -- literally NAMED "v2" must fall through to the v1 branch, not vanish)
    local v2_name, member_csv = line:match("^v2|([^|]*)|(.*)$")
    if v2_name then
        if v2_name == "" then return nil end
        local team = { name = v2_name, custom = true, members = {} }
        for chunk in member_csv:gmatch("[^;]+") do
            local id, pv_csv, note = chunk:match("^([^:]*):([^:]*):(.*)$")
            id = id or chunk   -- tolerate a bare id chunk
            local rec = by_id and by_id[id]
            if rec and #team.members < M.MAX_CUSTOM_MEMBERS then
                team.members[#team.members + 1] =
                    parse_member(rec, pv_csv, note, passive_ok)
            end
        end
        return team
    end
    -- v1 fallback: name|id1,id2 (no pv/note fields)
    local name, id_csv = line:match("^([^|]*)|(.*)$")
    if not name or name == "" then return nil end
    local team = { name = name, custom = true, members = {} }
    for id in id_csv:gmatch("[^,]+") do
        local rec = by_id and by_id[id]
        if rec and #team.members < M.MAX_CUSTOM_MEMBERS then
            team.members[#team.members + 1] = parse_member(rec, "", "", nil)
        end
    end
    return team
end

-- append with dedup + cap; returns false + reason when refused
function M.custom_add_member(team, id, by_id)
    local rec = by_id and by_id[id]
    if not rec then return false, "unknown" end
    for _, m in ipairs(team.members) do
        if m.id == (rec.tribe or id) then return false, "duplicate" end
    end
    if #team.members >= M.MAX_CUSTOM_MEMBERS then return false, "full" end
    team.members[#team.members + 1] = { id = rec.tribe or id, zh = rec.zh,
                                        pv = {}, note = "" }
    return true
end

-- r23: wish-passive append with dedup + cap; pure so the suite pins it
function M.custom_add_pv(member, passive_id)
    member.pv = member.pv or {}
    for _, pid in ipairs(member.pv) do
        if pid == passive_id then return false, "duplicate" end
    end
    if #member.pv >= M.MAX_CUSTOM_PV then return false, "full" end
    member.pv[#member.pv + 1] = passive_id
    return true
end

-- Data self-check, exported for the test suite: every member id must exist
-- in the pal index, alt_of must point at a member of the SAME team, and
-- place must be one of the three legal effect locations.
local LEGAL_PLACE = { party = true, base = true, ride = true }

function M.validate(by_id)
    local errs = {}
    for _, team in ipairs(M.builtin()) do
        local ids = {}
        for _, m in ipairs(team.members) do ids[m.id] = true end
        for _, m in ipairs(team.members) do
            if by_id and not by_id[m.id] then
                errs[#errs + 1] = team.key .. ": unknown pal id " .. tostring(m.id)
            end
            if not LEGAL_PLACE[m.place or ""] then
                errs[#errs + 1] = team.key .. ": bad place for " .. tostring(m.id)
            end
            if m.alt_of and not ids[m.alt_of] then
                errs[#errs + 1] = team.key .. ": alt_of dangling for " .. tostring(m.id)
            end
        end
    end
    return errs
end

return M

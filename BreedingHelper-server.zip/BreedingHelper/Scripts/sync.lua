-- BreedingHelper 1.2.0: session container-sync manager.
-- Probe-proven mechanics (2026-07-16, netmode=Client, logs in git history):
--   * Box: APalPlayerState:RequestPalBoxSyncPage_ToServer(page) materializes
--     that page's IndividualParameters (30 -> 455/455 in the field test);
--     synced pages stay synced for the session. ForceSyncPalBoxSlot is inert.
--   * Dimension storage: APalPlayerController RequestOpenDimensionStorage
--     (wants the concrete model's GetInstanceId(), NOT GetModelInstanceId())
--     -> RequestChangeDimensionStoragePage per page (server answers ~80ms)
--     -> harvest PageReplicationData.PageData -> RequestClose. Works headless.
-- Read-only boundary: these are replication/sync REQUESTS; nothing is ever
-- written to saves or game values. Close is always sent after an open.
-- PageData struct memory is transient (overwritten by the next page), so
-- harvest COPIES plain-Lua records immediately; nothing retains userdata.
--
-- Hardened per codex review r1 (2026-07-16):
--   * auto_start stop condition no longer trusts async writes (kicked flag)
--   * ticker has an in-flight latch (game-thread stalls can't batch ticks)
--     and per-page timeouts use wall-clock deadlines, not tick counts
--   * dps page arrival requires a PageReplicationData CHANGE (dirty toggle /
--     page transition), never a bare pageIndex match against stale state;
--     the end-of-cycle "restore page 0" was removed (it planted exactly that
--     stale state for the next cycle)
--   * every dps exit path (success, timeout, candidate retry, tick error)
--     funnels through _dps_finalize, which closes an opened session and only
--     publishes the cache on a structurally clean, fully harvested run
--   * the cache is bound to a world/player session id; consumers must use
--     dps_cache_valid(), never dps_cache_ready alone
--   * harvested records without a stable persistent id are DROPPED (an
--     unstable fallback key would break roster locks and double-count)
--   * scheduler failures disable the manager and report request() = false so
--     the UI falls back to 1.1.x behavior instead of waiting forever

local M = {}

M.TIMEOUT_S = 3.0        -- per-page wall-clock deadline (patient pass)
M.SETTLE_S = 2.0         -- post-stream settle before re-checking
M.FORCE_DWELL_S = 0.3    -- fixed per-page dwell on a force walk: the wait
                         -- predicate (param>=filled) is instantly true on a
                         -- content-stale page — the very thing the force
                         -- pass exists to distrust — so releasing on it
                         -- paces ~200ms/page, inside the measured drop zone
                         -- (opus dispatch r1 minor). 300ms drops zero.
local MAX_BOX_PASSES = 2
local MAX_GUID_CANDS = 4

M.state = {
    ticker_armed = false,
    tick_inflight = false,
    tick_inflight_since = 0,
    tick_gen = 0,
    running = false,
    completed_flag = false,
    disabled = false,       -- ASYNC channel dead (fuse); gt_pump still works
    last_gt_pump = 0,       -- os.clock() of the last heartbeat-driven pump
    last_gt_tick = 0,
    dps_dangling = false,   -- fuse aborted an OPEN locker session unclosed
    dangle_retry_at = 0,    -- throttle for the dangling-close retry
    progress = "",
    box = { stage = "idle", queue = {}, qi = 1, pages = 0, passes = 0,
            deadline = 0, residual = -1, requested = 0 },
    dps = { stage = "idle", page = 0, pages = 0, cands = {}, open_try = 1,
            deadline = 0, temp = {}, expect = nil, opened = false,
            parse_err = false, dropped = 0, ok = false, err = "",
            order = {}, oi = 1 },
}
M.dps_cache = {}
M.dps_cache_ready = false
M.dps_cache_time = 0        -- os.clock() of the last successful harvest
M.dps_cache_session = nil   -- session id the cache belongs to
-- box pages this manager actually pulled since the last consume: the
-- incremental snapshot patch (1.7.0) re-scans exactly these instead of the
-- ~500-pal full sweep. Reset on every new box run; consumed by the UI.
M.touched_pages = {}

function M.consume_touched()
    local out = {}
    for pg in pairs(M.touched_pages) do out[#out + 1] = pg end
    table.sort(out)
    M.touched_pages = {}
    return out
end
M.dps_cache_changed = false -- last publish differed from the previous cache
-- injected by planner so cache keys match the live-handle key format exactly
M._id_conv = nil
M._session_override = nil   -- offline-harness hook

function M.set_id_converter(fn) M._id_conv = fn end

-- flight recorder: tiny append-only trace (~30 lines/session) so field
-- failures are diagnosable from one log instead of guess-deploy-restart
-- loops. Overridable no-op in the offline harness.
M._trace_t0 = os.clock()
function M._trace(text)
    local f = io.open("BreedingHelper_sync.log", "ab")
    if f then
        f:write(string.format("%s +%07.2f %s\n",
            os.date("%H:%M:%S"), os.clock() - M._trace_t0, tostring(text)))
        f:close()
    end
end

-- ---------------------------------------------------------------------------
-- world accessors (same resolution order as planner.read_owned)
-- ---------------------------------------------------------------------------
function M._get_pc()
    -- LOCAL player only (1.7.1, same rule as planner.local_player_controller
    -- - inlined because sync must not require planner): on a listen host
    -- FindFirstOf can return a guest's controller and the whole sync chain
    -- would run against THEIR storage.
    --
    -- Beat-scoped memo (perf audit 2026-07-24): one active-sync beat walks
    -- through here 2-4 times (send page, read storage, close locker), each
    -- a fresh GUObjectArray lookup at 10 Hz. _tick() clears the memo on
    -- entry AND exit, so its lifetime is exactly one beat — outside a beat
    -- every call still resolves fresh (the fail-closed rule the whole test
    -- suite pins; a wall-clock TTL here broke all 32 dps fixtures).
    if M._pc_memo_open and M._pc_memo ~= nil then return M._pc_memo end
    local pc
    pcall(function()
        local gi = FindFirstOf("PalGameInstance")
        if not (gi and gi:IsValid()) then gi = FindFirstOf("GameInstance") end
        if not (gi and gi:IsValid()) then return end
        local lp = gi.LocalPlayers and gi.LocalPlayers[1]
        pcall(function() lp = lp:get() end)
        local cand = lp and lp.PlayerController
        if cand and cand:IsValid() then pc = cand end
    end)
    if not pc then
        pcall(function()
            local cand = FindFirstOf("PalPlayerController")
            if cand and cand:IsValid() then pc = cand end
        end)
    end
    if M._pc_memo_open then M._pc_memo = pc end
    return pc
end

function M._get_ps()
    -- LOCAL controller only: in multiplayer every player's PalPlayerState
    -- replicates to us, so a global FindFirstOf could hand back a foreign
    -- one and poison the whole chain downstream (codex r13). Only the local
    -- controller exists client-side, so this is unambiguous.
    local ps
    pcall(function()
        local pc = M._get_pc()
        if pc then ps = pc.PlayerState end
    end)
    if ps then
        local ok = false
        pcall(function() ok = ps:IsValid() end)
        if ok then return ps end
    end
    return nil
end

function M._get_storage()
    local storage
    pcall(function()
        local ps = M._get_ps()
        if ps then storage = ps:GetPalStorage() end
    end)
    return storage
end

-- resolve the LOCAL player's dimension-storage data object, fail-closed.
-- Structural path (field-verified 2026-07-16): the box storage we already
-- resolve through OUR PlayerState holds it directly, so it is the local
-- player's BY CONSTRUCTION — no FindAllOf lottery (stale instances after a
-- restart, one instance per player in multiplayer) and no OwnerPlayerUId
-- matching (that field never replicates to clients; it read as zero in the
-- field and a strict match bricked the run with no_pdata).
function M._resolve_pdata()
    local storage = M._get_storage()
    if storage then
        local pd
        pcall(function() pd = storage:GetDimensionStorage() end)
        if pd == nil then
            pcall(function() pd = storage.PalDimensionStorage end)
        end
        local ok = false
        pcall(function() ok = pd ~= nil and pd:IsValid() end)
        if ok then return pd end
    end
    -- SDK fallback: PalUtility.GetDimensionStorageDataByPlayerUID
    local pd2
    pcall(function()
        local util = StaticFindObject("/Script/Pal.Default__PalUtility")
        local UEHelpers = require("UEHelpers")
        pd2 = util:GetDimensionStorageDataByPlayerUID(
            UEHelpers.GetWorld(), M._get_ps().PlayerUId)
    end)
    local ok2 = false
    pcall(function() ok2 = pd2 ~= nil and pd2:IsValid() end)
    if ok2 then return pd2 end
    return nil
end

-- pinned accessor: the instance chosen at find-time is used for the WHOLE
-- cycle and re-validated on every read; it going bad never re-picks silently
-- (ownership is structural — it came off our own PlayerState's storage)
function M._get_pdata()
    local p = M.state.dps.pdata
    if not p then return nil end
    local ok = false
    pcall(function() ok = p:IsValid() end)
    if not ok then return nil end
    return p
end

-- identity of the current world+player; nil when unknown. The cache must
-- never survive a world/server switch (the Lua state does).
function M.session_id()
    if M._session_override then return M._session_override end
    local wid
    pcall(function()
        local UEHelpers = require("UEHelpers")
        local world = UEHelpers.GetWorld()
        if world and world:IsValid() then wid = world:GetFullName() end
    end)
    if not wid then return nil end
    local psn
    pcall(function()
        local ps = M._get_ps()
        if ps then psn = ps:GetFullName() end
    end)
    -- a weak "world|" id must never bind a cache: same-map reconnects or a
    -- momentarily missing PlayerState would defeat the isolation (codex r2)
    if not psn or psn == "" then return nil end
    return wid .. "|" .. psn
end

function M.dps_cache_valid()
    if not M.dps_cache_ready then return false end
    if not M.dps_cache_session then return false end
    return M.dps_cache_session == M.session_id()
end

-- filled vs parameter-valid counts for one box page, plus a structural-ok
-- flag. Failures must never be folded into "0/0 = complete" (codex r4): the
-- inner param probe failing is the SIGNAL we scan for, but the page/slot
-- containers being unreadable is a broken census, not an empty one.
function M._page_stats(storage, pg)
    local filled, param, ok = 0, 0, true
    local slots = {}
    if not pcall(function() storage:GetSlotsInPage(pg, slots) end) then
        return filled, param, false
    end
    for _, s in ipairs(slots) do
        local slot = s
        pcall(function() slot = s:get() end)   -- opportunistic unwrap
        local empty
        local oke = pcall(function() empty = slot:IsEmpty() end)
        if not oke or type(empty) ~= "boolean" then
            -- IsEmpty unreadable = broken slot layout, not an empty slot
            ok = false
        elseif not empty then
            filled = filled + 1
            -- the handle CHAIN throwing is structural; an invalid parameter
            -- returned cleanly is the "not yet synced" signal we scan for
            local okh = pcall(function()
                local h = slot:GetHandle()
                if h then
                    local p = h:TryGetIndividualParameter()
                    if p and p:IsValid() then param = param + 1 end
                end
            end)
            if not okh then ok = false end
        end
    end
    return filled, param, ok
end

-- pages that still have parameter-less pals + structural validity.
-- stop_after_first: gate-style callers only need "is anything missing" —
-- bail on the first hit instead of sweeping the rest of the box (the full
-- census is ~1000+ reflection calls on the game thread; perf audit 2026-07-24)
function M._missing_pages(stop_after_first)
    local missing, pages = {}, 0
    local storage = M._get_storage()
    if not storage then return missing, 0, false end
    local okp = pcall(function() pages = storage:GetPageNum() end)
    if not okp or type(pages) ~= "number" or pages < 0 or pages % 1 ~= 0 then
        return missing, 0, false   -- negative/fractional counts are junk
    end
    local ok = true
    for pg = 0, pages - 1 do
        local filled, param, pok = M._page_stats(storage, pg)
        if not pok then ok = false end
        if filled > param then
            missing[#missing + 1] = pg
            if stop_after_first and ok then return missing, pages, ok end
        end
    end
    return missing, pages, ok
end

-- -1 = census unreadable (callers must treat as "not complete", never as
-- "nothing to do succeeded"). Early-exits on the first missing page: every
-- caller only compares against 0, so the count past 1 is never needed.
-- Second return = page count, for callers that must tell "genuinely
-- complete" from "storage not populated yet" (codex 2026-07-24 MAJOR:
-- GetPageNum()==0 sails through the loop as a structurally-clean zero).
function M.box_incomplete()
    local missing, pages, ok = M._missing_pages(true)
    if not ok then return -1, pages end
    return #missing, pages
end

-- ---------------------------------------------------------------------------
-- dimension-storage harvest: copy one PageData entry into a plain record.
-- Empty slots carry CharacterID "None" -> nil (legal). Records that cannot
-- produce a stable persistent id are dropped -- an unstable fallback key
-- would break roster locks and double-count against the box copy.
-- ---------------------------------------------------------------------------
-- returns (rec, dropped, read_err). A legal empty slot (CharacterID "None")
-- is (nil, nil, nil); a record without a stable id is (nil, true, nil); ANY
-- read exception is reported as read_err so the caller can poison the run —
-- a silently truncated record must never reach the published cache.
function M._extract(entry)
    local err_fields = {}
    local function mark(field) err_fields[#err_fields + 1] = field end
    local cid, cid_ok
    pcall(function()
        cid = entry.SaveParameter.CharacterID:ToString()
        cid_ok = true
    end)
    -- only a SUCCESSFUL ToString that returned an actual string counts;
    -- tostring() of anything else would be "table: 0x..." garbage (codex r4)
    if not cid_ok or type(cid) ~= "string" then
        return nil, nil, true, "CharacterID"
    end
    if cid == "" or cid == "None" then return nil end
    local rec = { cid = cid, gender = 1, passives = {}, equipped = {}, mastered = {} }
    if M._id_conv then
        -- an EXCEPTION while reading/converting the id is a read error; the
        -- converter cleanly returning nil is the legitimate "no stable id"
        -- drop case (codex r6)
        local okc = pcall(function() rec.persistent_id = M._id_conv(entry.InstanceId) end)
        if not okc then return nil, nil, true, "InstanceId" end
    end
    if not rec.persistent_id then return nil, true end  -- dropped, not empty
    if not pcall(function()
        local g = entry.SaveParameter.Gender
        rec.gender = tonumber(g) or tonumber(tostring(g):match("(%d+)")) or 1
    end) then mark("Gender") end
    local function strs(field, out, allow_num)
        local ok = pcall(function()
            entry.SaveParameter[field]:ForEach(function(_, pe)
                local v = pe
                pcall(function() v = pe:get() end)   -- unwrap when wrapped
                local s
                if type(v) == "string" then
                    s = v
                elseif allow_num and type(v) == "number"
                    and v == v and v % 1 == 0
                    and v ~= math.huge and v ~= -math.huge then
                    -- enum arrays (EPalWazaID in EquipWaza/MasteredWaza)
                    -- surface as plain FINITE INTEGERS on the live build
                    -- (field-traced 2026-07-16: the strict rule poisoned
                    -- every real locker record). The exception is scoped to
                    -- the waza fields only and rejects NaN/fractions —
                    -- a number inside PassiveSkillList is layout drift,
                    -- not data (codex r14)
                    s = tostring(v)
                else
                    -- only a SUCCESSFUL ToString counts: falling back to
                    -- tostring() would write "table: 0x..." garbage into a
                    -- published record with no error raised (codex r3)
                    local okS, str = pcall(function() return v:ToString() end)
                    if okS and type(str) == "string" then
                        s = str
                    else
                        mark(field .. ".elem")
                        return
                    end
                end
                if s ~= "" and s ~= "None" then out[#out + 1] = s end
            end)
        end)
        if not ok then mark(field) end
    end
    strs("PassiveSkillList", rec.passives)
    strs("EquipWaza", rec.equipped, true)
    strs("MasteredWaza", rec.mastered, true)
    local function num(field)
        local n
        if not pcall(function()
            local v = entry.SaveParameter[field]
            n = tonumber(v) or tonumber(tostring(v):match("(-?%d+)"))
        end) then mark(field) end
        return n
    end
    rec.iv_hp, rec.iv_melee = num("Talent_HP"), num("Talent_Melee")
    rec.iv_shot, rec.iv_defense = num("Talent_Shot"), num("Talent_Defense")
    rec.rank, rec.level = num("Rank"), num("Level")
    if #err_fields > 0 then
        return rec, nil, true, table.concat(err_fields, ",")
    end
    return rec, nil, false
end

-- snapshot the replication state we must see CHANGE before trusting a page.
-- An unreadable baseline is marked invalid: without it freshness can never
-- be verified, so the page can never "arrive" (codex r4: a swallowed
-- baseline with page=-1 made ANY stale index look like a change).
function M._dps_mark_expect()
    local d = M.state.dps
    -- per-field validity (codex r5 #1): a page that read fine next to a
    -- toggle that threw must NOT let "nil ~= false" count as a change later
    local snap = { page = nil, toggle = nil, toggle_known = false, valid = false }
    local pdata = M._get_pdata()
    if pdata then
        local okp = pcall(function() snap.page = pdata.PageReplicationData.pageIndex end)
        snap.valid = okp and type(snap.page) == "number"
        local okt = pcall(function()
            snap.toggle = pdata.PageReplicationData.bDirtyToggle
        end)
        -- a cleanly-read nil is NOT a known toggle: "nil ~= false" must
        -- never count as a change (codex r6)
        snap.toggle_known = okt and type(snap.toggle) == "boolean"
    end
    d.expect = snap
end

-- returns false after finalizing when the send itself failed: freshness
-- only proves the page CHANGED after our baseline, not that OUR request
-- caused it — a late response from a previous candidate or the player's own
-- UI could flip it, so a failed send can never be waited on (codex r8)
function M._dps_send_page(pg)
    M._dps_mark_expect()
    local oks = pcall(function()
        M._get_pc():RequestChangeDimensionStoragePage_ToServer(pg)
    end)
    if not oks then
        M._dps_finalize(false, "page_send_failed")
        return false
    end
    M.state.dps.deadline = os.clock() + M.TIMEOUT_S
    return true
end

-- true only when PageReplicationData shows FRESH data for `target`:
-- pageIndex matches AND the state visibly changed since we sent the request
-- (dirty toggle flip or a page transition). A bare pageIndex match could be
-- last cycle's leftovers. Structural read failures poison the run
-- (parse_err) so a broken/renamed layout can never publish a bogus cache.
function M._harvest_page(target)
    local d = M.state.dps
    local arrived = false
    local okH = pcall(function()
        local pdata = M._get_pdata()
        if not pdata then return end
        local pidx, toggle = -1, nil
        pcall(function() pidx = pdata.PageReplicationData.pageIndex end)
        local toggle_ok = pcall(function()
            toggle = pdata.PageReplicationData.bDirtyToggle
        end)
        toggle_ok = toggle_ok and type(toggle) == "boolean"
        if pidx ~= target then return end
        -- no valid baseline = freshness unverifiable = never arrived; the
        -- page deadline then fails the run instead of publishing stale data
        if d.expect == nil or not d.expect.valid then return end
        -- a toggle comparison only counts when BOTH sides read cleanly
        local changed = (pidx ~= d.expect.page)
            or (d.expect.toggle_known and toggle_ok and toggle ~= d.expect.toggle)
        if not changed then return end
        arrived = true
        local n
        local okn = pcall(function()
            n = pdata.PageReplicationData.PageData:GetArrayNum()
        end)
        if not okn or type(n) ~= "number" or n < 0 or n % 1 ~= 0 then
            d.parse_err = true   -- negative/fractional counts are layout junk
            M._trace(string.format("parse_err page=%d arraynum ok=%s n=%s",
                target, tostring(okn), tostring(n)))
            return
        end
        for i = 1, n do
            local okE, rec, dropped, xerr, xfields = pcall(function()
                return M._extract(pdata.PageReplicationData.PageData[i])
            end)
            if not okE or xerr then
                d.parse_err = true
                d.parse_err_n = (d.parse_err_n or 0) + 1
                if d.parse_err_n <= 5 then
                    M._trace(string.format(
                        "parse_err page=%d entry=%d okE=%s fields=%s",
                        target, i, tostring(okE), tostring(xfields)))
                end
            end
            if okE then
                if rec then
                    -- absolute page/slot so plans and the roster can point
                    -- the player at the pal's real locker position
                    rec.page = target
                    rec.slot = i - 1
                    d.temp[#d.temp + 1] = rec
                elseif dropped then
                    d.dropped = d.dropped + 1
                end
            end
        end
    end)
    -- the harvest body itself blowing up (e.g. a non-numeric loop bound)
    -- must poison the run, not vanish into a discarded pcall (codex r3)
    if not okH then d.parse_err = true end
    return arrived
end

-- single exit funnel: close an opened session, publish only on a clean full
-- harvest, and remember the outcome for the UI
function M._dps_finalize(ok, err)
    local d = M.state.dps
    if d.opened then
        local okc = pcall(function()
            M._get_pc():RequestCloseDimensionStorage_ToServer()
        end)
        d.opened = false
        if not okc then
            -- close itself failing = broken environment AND a possibly
            -- dangling server session: never fold that into success, and
            -- ALWAYS surface it as close_failed (it outranks any prior
            -- error — the dangling session is the worse condition)
            ok = false
            err = "close_failed"
        end
    end
    d.ok = ok and not d.parse_err
    d.err = err or d.err
    if d.ok then
        -- no session identity = no publish: an unbound cache could leak into
        -- another world. The previous valid cache is kept instead.
        local sid = M.session_id()
        if sid then
            -- change detection feeds made_changes(): an identical harvest
            -- lets the UI skip the visible rescan on routine freshness runs.
            -- The signature covers every PLANNING-VISIBLE field, not just the
            -- id — the same pal redeposited with new level/IVs/passives must
            -- trigger the rescan (codex r12)
            local function sig(list)
                local keys = {}
                for _, r in ipairs(list) do
                    keys[#keys + 1] = table.concat({
                        r.persistent_id or "?", r.cid or "",
                        tostring(r.page), tostring(r.slot),
                        tostring(r.gender), tostring(r.level),
                        tostring(r.rank), tostring(r.iv_hp),
                        tostring(r.iv_melee), tostring(r.iv_shot),
                        tostring(r.iv_defense),
                        table.concat(r.passives or {}, ","),
                        table.concat(r.equipped or {}, ","),
                        table.concat(r.mastered or {}, ","),
                    }, "|")
                end
                table.sort(keys)
                return table.concat(keys, ";")
            end
            -- a session switch counts as change even for an identical id
            -- set: the pre-sync scan ignored the old-session cache, so the
            -- UI still needs its rescan (codex r10)
            M.dps_cache_changed = (not M.dps_cache_ready)
                or (M.dps_cache_session ~= sid)
                or sig(d.temp) ~= sig(M.dps_cache)
            M.dps_cache = d.temp
            M.dps_cache_ready = true
            M.dps_cache_time = os.clock()
            M.dps_cache_session = sid
        else
            d.ok = false
            if d.err == "" then d.err = "no_session" end
        end
    end
    d.stage = "done"
    M._trace(string.format(
        "dps finalize ok=%s err=%s published=%d changed=%s parse_err=%s(%d) dropped=%d",
        tostring(d.ok), tostring(d.err), d.ok and #M.dps_cache or -1,
        tostring(M.dps_cache_changed), tostring(d.parse_err),
        d.parse_err_n or 0, d.dropped or 0))
end

-- ---------------------------------------------------------------------------
-- state machines, driven by a 300ms in-flight-latched ticker (game thread)
-- ---------------------------------------------------------------------------
-- Pacing is field-measured (probes v4+v5, netmode=Client): firing all pages
-- in one burst loses everything but one page (the server keeps a single
-- SyncPageIndex); 100ms/page drops ~1 page in 16 (self-healed by pass 2);
-- 300ms/page drops zero. Pass 1 streams at the 100ms ticker rate — 16 pages
-- landed in 2.8s in the field test — and pass 2 walks any leftovers
-- patiently (send, wait, per-page deadline), which also absorbs the rare
-- 100ms drop.
function M._box_tick()
    local b = M.state.box
    if b.stage == "idle" or b.stage == "done" then return end
    if b.stage == "census" then
        local missing, pages, cok = M._missing_pages()
        b.pages = pages
        if not cok then
            b.residual = -1   -- census unreadable: finish as UNKNOWN, not clean
            b.stage = "done"
            M._trace("box census UNREADABLE -> done")
            return
        end
        M._trace(string.format("box census pass=%d missing=%d/%d",
            b.passes, #missing, pages))
        -- full-refresh pass (see request): every page, via the paced
        -- send/wait walk (300ms/page drops zero in the field probes — the
        -- one-burst stream loses pages, and a lost page here means the
        -- stale slot the heal exists to fix might stay stale). Later
        -- passes converge on the normal filled>param judgement.
        if b.force and pages > 0 then
            b.force = nil
            b.force_settle = true   -- answers land async: settle before recheck
            b.passes = b.passes + 1
            local all = {}
            for pg = 0, pages - 1 do all[#all + 1] = pg end
            b.queue, b.qi = all, 1
            b.stage = "send"
            M._trace("box force-refresh: requesting all " .. pages .. " pages")
            return
        end
        if #missing == 0 or b.passes >= MAX_BOX_PASSES then
            b.residual = #missing
            b.stage = "done"
            M._trace("box done residual=" .. #missing)
            return
        end
        b.passes = b.passes + 1
        b.queue, b.qi = missing, 1
        b.stage = (b.passes == 1) and "stream" or "send"
    elseif b.stage == "stream" then
        local pg = b.queue[b.qi]
        if pg == nil then
            b.deadline = os.clock() + M.SETTLE_S
            b.stage = "settle"
            return
        end
        pcall(function() M._get_ps():RequestPalBoxSyncPage_ToServer(pg) end)
        b.requested = (b.requested or 0) + 1
        M.touched_pages[pg] = true
        M.state.progress = string.format("同步仓库 %d/%d 页…", b.qi, #b.queue)
        b.qi = b.qi + 1
    elseif b.stage == "settle" then
        if os.clock() > b.deadline then
            b.stage = "census"   -- pass finished: re-check, maybe second pass
        end
    elseif b.stage == "send" then
        local pg = b.queue[b.qi]
        if pg == nil then
            -- a force-refresh walk lets the async answers land before the
            -- recheck: a content-stale page reads self-consistent either
            -- way, so an instant census would report clean while the last
            -- answers are still in flight
            if b.force_settle then
                b.force_settle = nil
                b.deadline = os.clock() + M.SETTLE_S
                b.stage = "settle"
                return
            end
            b.stage = "census"
            return
        end
        pcall(function() M._get_ps():RequestPalBoxSyncPage_ToServer(pg) end)
        b.requested = (b.requested or 0) + 1
        M.touched_pages[pg] = true
        b.deadline = os.clock()
            + (b.force_settle and M.FORCE_DWELL_S or M.TIMEOUT_S)
        b.stage = "wait"
        M.state.progress = string.format(
            b.force_settle and "强制刷新仓库 %d/%d 页…" or "补同步 %d/%d 页…",
            b.qi, #b.queue)
    elseif b.stage == "wait" then
        local pg = b.queue[b.qi]
        -- force walk: fixed dwell only. The done_page predicate reads
        -- instantly true on the content-stale pages this walk exists to
        -- rewrite, and releasing on it would pace inside the measured
        -- packet-drop zone (see FORCE_DWELL_S).
        local done_page = false
        if not b.force_settle then
            local storage = M._get_storage()
            if storage then
                local filled, param, pok = M._page_stats(storage, pg)
                done_page = pok and param >= filled
            end
        end
        if done_page or os.clock() > b.deadline then
            b.qi = b.qi + 1
            b.stage = "send"
        end
    end
end

-- next page of the bidirectional early-stop sweep, or nil when done
local DPS_EMPTY_STOP = 4
function M._dps_next_page(d)
    while d.phase_i <= #d.phases do
        local dir = d.phases[d.phase_i]
        local empties = (dir == "fwd") and d.fwd_empties or d.bwd_empties
        if empties >= DPS_EMPTY_STOP then
            d.phase_i = d.phase_i + 1
        else
            local n
            if dir == "fwd" then
                n = d.fwd_next
                if n > d.bwd_next or n >= d.pages or d.visited[n] then
                    return nil   -- pointers met: whole locker swept
                end
                d.fwd_next = n + 1
            else
                n = d.bwd_next
                if n < d.fwd_next or n < 0 or d.visited[n] then
                    return nil
                end
                d.bwd_next = n - 1
            end
            d.cur_dir = dir
            return n
        end
    end
    return nil
end

function M._dps_tick()
    local d = M.state.dps
    if d.stage == "idle" or d.stage == "done" then return end
    -- a dangling (fuse-aborted, unclosed) locker session is a HARD barrier:
    -- opening a new one now would get killed by the pending parameterless
    -- close retry (codex 233 r2 MAJOR). The box machine keeps running; this
    -- one waits for gt_pump's close to land — bounded, so a PC that never
    -- comes back cannot park the job forever.
    if M.state.dps_dangling then
        if not d.dangle_wait_since then d.dangle_wait_since = os.clock() end
        -- 15s, not 10: the close retries at 0/5/10s under the 5s throttle,
        -- and a jittered second failure (~5.9s) pushes the third try to
        -- ~10.9s — the escape must not fire before that third try lands
        -- (codex 233 r3)
        if os.clock() - d.dangle_wait_since > 15.0 then
            M._dps_finalize(false, "dangling_block")
        else
            M.state.progress = "等待上一次仓库会话关闭…"
        end
        return
    end
    if d.stage == "find" then
        M._trace("dps find")
        d.cands, d.open_try, d.temp = {}, 1, {}
        d.parse_err, d.dropped = false, 0
        local models = FindAllOf("PalMapObjectDimensionPalStorageModel") or {}
        -- probe v3: the server accepts GetInstanceId(); ModelInstanceId was
        -- rejected. All InstanceId candidates first, capped total.
        for _, model in ipairs(models) do
            pcall(function()
                local g = model:GetInstanceId()
                if g and #d.cands < MAX_GUID_CANDS then
                    d.cands[#d.cands + 1] = g
                end
            end)
        end
        for _, model in ipairs(models) do
            pcall(function()
                local g = model:GetModelInstanceId()
                if g and #d.cands < MAX_GUID_CANDS then
                    d.cands[#d.cands + 1] = g
                end
            end)
        end
        -- pin the local player's replication object for the whole cycle
        d.pdata = M._resolve_pdata()
        if not d.pdata then
            M._dps_finalize(false, "no_pdata")
            return
        end
        M._trace("dps pdata pinned")
        -- GetDimensionStoragePageNum is a STATIC UFunction with a
        -- WorldContext parameter: the bare no-arg call throws on the live
        -- build (probe v3's "8" was its own fallback constant, a red
        -- herring). Try the explicit-context variants first; an
        -- unverifiable page count must still fail the run, never default
        -- to a guess (codex r5 #3).
        d.pages = 0
        local pd = d.pdata
        local variants = {
            function() return pd:GetDimensionStoragePageNum(pd) end,
            function()
                local UEHelpers = require("UEHelpers")
                return pd:GetDimensionStoragePageNum(UEHelpers.GetWorld())
            end,
            function() return pd:GetDimensionStoragePageNum() end,
        }
        for vi, call in ipairs(variants) do
            local okpg, n = pcall(call)
            M._trace(string.format("dps page_count variant%d ok=%s n=%s",
                vi, tostring(okpg), tostring(n)))
            if okpg and type(n) == "number" and n > 0 and n % 1 == 0 then
                d.pages = n
                break
            end
        end
        if d.pages <= 0 then
            M._dps_finalize(false, "page_count_unknown")
            return
        end
        if #d.cands == 0 then
            M._dps_finalize(false, "no_locker_model")
            return
        end
        d.stage = "open"
    elseif d.stage == "open" then
        local cand = d.cands[d.open_try]
        if cand == nil then
            M._dps_finalize(false, "open_rejected")
            return
        end
        -- a previous candidate may have half-opened a session: close it
        -- before opening with the next GUID; a failing close aborts the run
        -- (same rule as the finalize close, codex r6)
        if d.opened then
            local okc = pcall(function()
                M._get_pc():RequestCloseDimensionStorage_ToServer()
            end)
            d.opened = false
            if not okc then
                M._dps_finalize(false, "close_failed")
                return
            end
        end
        d.temp = {}
        d.parse_err, d.dropped = false, 0
        -- the open RPC failing to SEND is a broken environment: harvesting
        -- must not proceed on the off-chance pages replicate anyway (codex r7)
        local oko = pcall(function()
            M._get_pc():RequestOpenDimensionStorage_ToServer(cand)
        end)
        if not oko then
            M._dps_finalize(false, "open_failed")
            return
        end
        d.opened = true
        -- walk the pages cyclically starting AFTER the currently replicated
        -- one: every arrival is then a page TRANSITION, verifiable even when
        -- the dirty toggle is unreadable on the live build (a client parked
        -- on page 0 deadlocked otherwise: same-page freshness could only be
        -- proven by the toggle). Single-page lockers still need the toggle.
        local parked
        pcall(function()
            local v = M._get_pdata().PageReplicationData.pageIndex
            if type(v) == "number" then parked = v end
        end)
        -- bidirectional early-stop sweep (owner decision 2026-07-16):
        -- players park pals at the START (fill order) or the END (sorting),
        -- almost never mid-locker. Walk 0.. forward and (pages-1)..
        -- backward; a direction retires after 4 consecutive EMPTY pages.
        -- Pals hidden beyond a gap stay reachable: browsing their page once
        -- feeds the transient-handle merge (documented in the tip/README).
        -- Small lockers (pointers meet) get a full sweep, same as before.
        -- The first requested page must differ from the parked one, so a
        -- parked page 0 starts with the backward phase.
        d.phases = (parked == 0) and { "bwd", "fwd" } or { "fwd", "bwd" }
        d.phase_i = 1
        d.fwd_next, d.bwd_next = 0, d.pages - 1
        d.fwd_empties, d.bwd_empties = 0, 0
        d.visited, d.visited_n = {}, 0
        d.page = M._dps_next_page(d)
        if d.page == nil then
            M._dps_finalize(false, "no_pages")
            return
        end
        M._trace(string.format("dps open try=%d parked=%s first_page=%d pages=%d",
            d.open_try, tostring(parked), d.page, d.pages))
        if not M._dps_send_page(d.page) then return end
        d.stage = "page_wait"
    elseif d.stage == "page_wait" then
        M.state.progress = string.format("读取次元仓库 已扫 %d 页…", d.visited_n or 0)
        local before_n = #d.temp + (d.dropped or 0)
        if M._harvest_page(d.page) then
            local got = (#d.temp + (d.dropped or 0)) > before_n
            if d.cur_dir == "bwd" then
                d.bwd_empties = got and 0 or (d.bwd_empties + 1)
            else
                d.fwd_empties = got and 0 or (d.fwd_empties + 1)
            end
            d.visited[d.page] = true
            d.visited_n = (d.visited_n or 0) + 1
            -- trace only pages that yielded records plus sparse breadcrumbs,
            -- not all 320 pages (codex r14 log-volume note)
            if #d.temp > (d.traced_n or 0) or d.page % 64 == 0 then
                M._trace(string.format("dps page %d harvested (%d records so far)",
                    d.page, #d.temp))
                d.traced_n = #d.temp
            end
            local nxt = M._dps_next_page(d)
            if nxt == nil then
                M._trace(string.format("dps sweep done: %d pages visited of %d",
                    d.visited_n, d.pages))
                M._dps_finalize(true)
            else
                d.page = nxt
                if not M._dps_send_page(d.page) then
                    return   -- send failed: finalize already ran
                end
            end
        elseif os.clock() > d.deadline then
            if (d.visited_n or 0) == 0 and d.open_try < #d.cands then
                M._trace("dps first-page timeout -> next GUID candidate")
                d.open_try = d.open_try + 1  -- wrong GUID flavor: retry
                d.stage = "open"
            else
                M._dps_finalize(false, "page_timeout")
            end
        end
    end
end

-- abort without touching UObjects: used when the game-thread scheduler
-- itself is broken and an RPC close cannot be issued safely. An opened
-- locker session is remembered so the next gt_pump (panel heartbeat, safely
-- on the game thread) can close it instead of leaving it dangling on the
-- server for the rest of the play session.
function M._abort_flags_only()
    if M.state.dps.opened then M.state.dps_dangling = true end
    M.state.box.stage = "done"
    M.state.dps.stage = "done"
    M.state.dps.opened = false
    M.state.progress = ""
end

function M._tick()
    -- beat-scoped PC memo window: memoization exists ONLY between these two
    -- lines and the closing pair below — outside a beat every _get_pc call
    -- resolves fresh (fail-closed rule the whole dps test suite pins)
    M._pc_memo, M._pc_memo_open = nil, true
    local ok = pcall(function()
        M._box_tick()
        M._dps_tick()
    end)
    if not ok then
        -- tick crashed: shut both machines down but still close an opened
        -- dps session (finalize is itself pcall-armored)
        M.state.box.stage = "done"
        if M.state.dps.stage ~= "idle" and M.state.dps.stage ~= "done" then
            pcall(function() M._dps_finalize(false, "tick_error") end)
        end
        M.state.progress = ""
    end
    local b, d = M.state.box, M.state.dps
    local busy = (b.stage ~= "idle" and b.stage ~= "done")
        or (d.stage ~= "idle" and d.stage ~= "done")
    if not busy and M.state.running then
        M.state.running = false
        M.state.progress = ""
        M.state.completed_flag = true
    end
    M._pc_memo, M._pc_memo_open = nil, false   -- never outlives the beat
end

function M._arm_ticker()
    if M.state.ticker_armed then return true end
    M.state.ticker_armed = true
    local armed = pcall(function()
        -- 100ms: box stream cadence (v5-measured) and snappier dps polling;
        -- the ticker only runs while a job is active, then parks
        LoopAsync(100, function()
            -- in-flight latch: at most ONE queued game-thread action, EVER.
            -- Overlapping ExecuteInGameThread registrations are a known
            -- UE4SS crash condition (issue #1180), so a stuck action is
            -- never "recovered" by registering a second one — after 5s of
            -- silence the whole manager fails closed for the session and
            -- the UI falls back to 1.1.x behavior (codex r14).
            if M.state.tick_inflight then
                if (os.clock() - M.state.tick_inflight_since) > 5.0 then
                    M.state.tick_gen = M.state.tick_gen + 1
                    M.state.tick_inflight = false
                    M.state.disabled = true
                    M.state.ticker_armed = false
                    if M._gt_fresh() then
                        -- the panel heartbeat is pumping this job on the
                        -- game thread; only the async delivery died (UE4SS
                        -- dropped the shared EngineTick hook, 2026-07-22
                        -- field incident). Retire the ticker, keep the job.
                        M._trace("ticker RETIRED (async callback lost; panel pump carries the job)")
                    else
                        M._abort_flags_only()
                        M.state.running = false
                        M.state.completed_flag = true
                        M._trace("ticker DISABLED (game-thread action stuck >5s)")
                    end
                    return true
                end
            elseif M._gt_fresh() then
                -- panel heartbeat is pumping on the game thread: skip the
                -- post entirely. Per-beat cross-thread ExecuteInGameThread
                -- refs are the registry-corruption vector (one bad ref and
                -- UE4SS removes the shared EngineTick hook, killing every
                -- queued action mod-wide) — while a zero-ref channel is
                -- available the async one stays silent.
            else
                M.state.tick_inflight = true
                M.state.tick_inflight_since = os.clock()
                local mygen = M.state.tick_gen
                local scheduled = pcall(function()
                    ExecuteInGameThread(function()
                        if M.state.tick_gen == mygen then
                            -- a heartbeat takeover makes this stale post
                            -- redundant: drop it outright (codex 233 r2 #4
                            -- — a 50ms shared gate still allowed 50-99ms
                            -- back-to-back pairs breaking the measured
                            -- 100ms page cadence). Without a takeover the
                            -- async channel is single-flight anyway, so no
                            -- gate is needed — original behaviour.
                            if not M._gt_fresh() then
                                M.state.last_gt_tick = os.clock()
                                pcall(M._tick)
                            end
                            M.state.tick_inflight = false
                        end
                    end)
                end)
                if not scheduled then
                    M.state.tick_inflight = false
                    M.state.disabled = true
                    M._abort_flags_only()
                    M.state.running = false
                    M.state.completed_flag = true
                    M.state.ticker_armed = false
                    return true
                end
            end
            -- ExecuteInGameThread is asynchronous: park based on the shared
            -- running flag (one tick late), never on a same-iteration write.
            -- Two-phase park (codex r2 #3): clear the armed flag, then
            -- re-check for a request() that slipped into the gap. Worst case
            -- under true preemption is a short-lived duplicate ticker (the
            -- in-flight latch keeps ticks single-file); never a parked
            -- ticker with a live job.
            if not M.state.running then
                M.state.ticker_armed = false
                if M.state.running then
                    M.state.ticker_armed = true
                    return false
                end
                M._trace("ticker parked")
                return true
            end
            return false
        end)
    end)
    if not armed then
        M.state.ticker_armed = false
        M._trace("ticker ARM FAILED")
        return false
    end
    M._trace("ticker armed")
    return true
end

-- liveness stamp WITHOUT advancing the machines: request() call sites use
-- this — pumping there could finish a parked job on the very beat before
-- request() resets the machine, eating its completion signals
-- (completed_flag/touched_pages/dps_cache_changed; codex 233 MAJOR 1)
function M.mark_gt_alive()
    M.state.last_gt_pump = os.clock()
end

-- direct game-thread pump: called by the panel heartbeat every frame,
-- already ON the game thread, so it moves the state machines with ZERO
-- cross-thread registry refs. While it stamps liveness the async ticker
-- stops posting; if UE4SS drops the shared EngineTick hook (2026-07-22:
-- one corrupted ref removed it and every ExecuteInGameThread died silently
-- for the session) the sync machinery keeps working on this channel alone.
function M.gt_pump()
    local now = os.clock()
    M.state.last_gt_pump = now
    if M.state.dps_dangling and now >= (M.state.dangle_retry_at or 0) then
        -- a fuse abort could not close the server-side locker session from
        -- the async thread; close it here where UObject calls are safe.
        -- Only a SENT close clears the latch — a nil PC or a raised RPC
        -- keeps it armed for a throttled retry (codex 233 MAJOR 2)
        local okc = pcall(function()
            M._get_pc():RequestCloseDimensionStorage_ToServer()
        end)
        if okc then
            M.state.dps_dangling = false
            M._trace("dps dangling session closed (gt)")
        else
            M.state.dangle_retry_at = now + 5.0
            M._trace("dps dangling close failed; retry in 5s")
        end
    end
    if not M.state.running then return end
    if (now - (M.state.last_gt_tick or 0)) < 0.1 then return end
    M.state.last_gt_tick = now
    M._tick()
end

function M._gt_fresh()
    return (os.clock() - (M.state.last_gt_pump or 0)) < 1.0
end

-- kind: "box" | "dps" | "all". Safe to call repeatedly; running jobs are
-- kept. Returns false when the manager cannot run (callers must fall back
-- to 1.1.x behavior instead of waiting on a completion that never comes).
-- A dead ASYNC channel no longer refuses service by itself: with the panel
-- open the heartbeat pumps the job on the game thread (ui stamps liveness
-- via mark_gt_alive right before requesting, so freshness is decidable
-- here without advancing the machines).
function M.request(kind, force_box)
    if M.state.disabled and not M._gt_fresh() then return false end
    local b, d = M.state.box, M.state.dps
    if (kind == "box" or kind == "all")
        and (b.stage == "idle" or b.stage == "done") then
        -- force_box: full-refresh run (stale-mirror heal, dispatch 2026-07-26).
        -- The census judges pages by filled>param, which cannot SEE a
        -- content-stale page: after the player re-sorts the box, the old
        -- mirror data is still self-consistent (filled==param) and a normal
        -- run requests ZERO pages. force makes pass 1 request EVERY page so
        -- the server answers rewrite the mirror wholesale.
        M.state.box = { stage = "census", queue = {}, qi = 1, pages = 0,
                        passes = 0, deadline = 0, residual = -1, requested = 0,
                        force = force_box == true }
        M.touched_pages = {}   -- a fresh run accumulates its own patch set
    elseif (kind == "box" or kind == "all") and force_box == true then
        -- a running box job upgrades in place: its next census loop
        -- consumes the flag (a heal must not silently ride a normal run
        -- that will request zero pages on a content-stale mirror)
        b.force = true
    elseif kind == "dps" and (b.stage == "idle" or b.stage == "done") then
        -- a dps-only cycle must not inherit the previous box run's request
        -- count, or made_changes() would report stale box work
        M.state.box.requested = 0
    end
    if (kind == "dps" or kind == "all")
        and (d.stage == "idle" or d.stage == "done") then
        M.state.dps = { stage = "find", page = 0, pages = 0, cands = {},
                        open_try = 1, deadline = 0, temp = {}, expect = nil,
                        opened = false, parse_err = false, dropped = 0,
                        ok = false, err = "", order = {}, oi = 1 }
        M.dps_cache_changed = false
    end
    M.state.running = true
    M.state.completed_flag = false
    M._trace(string.format("request kind=%s box=%s dps=%s armed=%s inflight=%s",
        tostring(kind), M.state.box.stage, M.state.dps.stage,
        tostring(M.state.ticker_armed), tostring(M.state.tick_inflight)))
    if M.state.disabled then
        -- async channel dead but gt_pump is fresh (checked above): the
        -- heartbeat alone carries this job — never re-arm a dead ticker
        return true
    end
    if not M._arm_ticker() then
        M.state.disabled = true
        if M._gt_fresh() then
            return true   -- heartbeat can still pump it
        end
        M._abort_flags_only()
        M.state.running = false
        return false
    end
    return true
end

function M.is_busy() return M.state.running end
function M.progress_text() return M.state.progress end

-- the box job is the long, visible one; a dps freshness pass runs quietly
function M.box_active()
    local st = M.state.box.stage
    return st ~= "idle" and st ~= "done"
end

-- did the last completed cycle actually change anything the UI shows?
function M.made_changes()
    if (M.state.box.requested or 0) > 0 then return true end
    return M.dps_cache_changed == true
end

-- one-shot completion signal for the UI's poll loop (auto-refresh trigger)
function M.consume_completed()
    if M.state.completed_flag then
        M.state.completed_flag = false
        return true
    end
    return false
end

-- world-load warm-up: box only (invisible pure win; the dps cycle touches a
-- shared server session, so it stays tied to an explicit panel open). The
-- stop condition reads a flag set ON the game thread, never a local written
-- by the asynchronous callback (that write lands after the return).
M._auto = { started = false, kicked = false, ticks = 0,
            inflight = false, inflight_since = 0 }
-- Beat body exported for the offline suite (the LoopAsync shim never fires
-- callbacks). Returning true retires the loop, false keeps it.
M._auto_beat = function()
    local a = M._auto
    if a.kicked or a.ticks > 20 or M.state.disabled then return true end
    -- world-load storm quiet window (crash investigation 2026-07-28):
    -- right after a world loads, BPModLoader replays every blueprint
    -- mod's PostBeginPlay — the exact moment UE4SS's shared hook/ref
    -- machinery is busiest, and the window both access-violation
    -- crashes landed in (stack: two UE4SS trampolines inside the
    -- engine call chain; upstream #1043/#1180 family). Cross-thread
    -- posts are the raw material of that race, so the warm-up goes
    -- SILENT for 30s once the world first reads ready. The panel-open
    -- sync path is untouched — a player already in the panel is past
    -- the storm by definition.
    if a.world_ready_at and (os.clock() - a.world_ready_at) < 30 then
        return false
    end
    -- same single-flight rule as the ticker: never register a second
    -- game-thread action while one may still be queued (codex r14);
    -- a beat with a pending action is simply skipped, and a stuck
    -- action gives the warm-up entirely up
    if a.inflight then
        if (os.clock() - a.inflight_since) > 15.0 then
            -- orphan the late callback: bump the generation so it
            -- no-ops instead of kicking after abandonment (codex r15)
            a.gen = (a.gen or 0) + 1
            M._trace("auto_start ABANDONED (game-thread action stuck)")
            return true
        end
        return false
    end
    a.inflight = true
    a.inflight_since = os.clock()
    local mygen = a.gen or 0
    local scheduled = pcall(function()
        ExecuteInGameThread(function()
            if (a.gen or 0) ~= mygen then return end
            a.inflight = false
            a.ticks = a.ticks + 1
            if not a.kicked and not M.state.disabled and M._get_ps() then
                if not a.world_ready_at then
                    -- first beat that sees a live world IS inside the
                    -- storm window: record the clock and do nothing —
                    -- especially not the full-page census below, the
                    -- heaviest thing this loop ever puts on the game
                    -- thread
                    a.world_ready_at = os.clock()
                    return
                end
                local inc, pages = M.box_incomplete()
                if inc > 0 then
                    a.kicked = true
                    M.request("box")
                elseif inc == 0 and (pages or 0) > 0 then
                    -- box reads complete (single-player always does:
                    -- server data lives locally). Synced pages stay
                    -- synced for the session, so there is nothing to
                    -- warm — stop the loop instead of re-running the
                    -- census every beat for 5 minutes (perf audit
                    -- 2026-07-24: that sweep was the mod's largest
                    -- steady-state frame cost for most players).
                    -- Codex hardening: a client's half-replicated
                    -- box can read as a false zero, so retirement
                    -- takes TWO clean complete reads one beat (15s)
                    -- apart, and pages==0 (storage not populated)
                    -- never counts. The panel-open path re-checks on
                    -- its own.
                    a.zero_streak = (a.zero_streak or 0) + 1
                    if a.zero_streak >= 2 then a.kicked = true end
                else
                    -- -1 (unreadable) or pages==0 (not populated):
                    -- world still coming up — restart the streak
                    a.zero_streak = 0
                end
            end
        end)
    end)
    if not scheduled then
        a.gen = (a.gen or 0) + 1
        return true
    end
    -- one kick total, or give up after ~5 minutes without a world
    -- (20 beats x 15s — the cadence dropped 5s -> 15s with the storm
    -- quiet window: menu-phase cross-thread posts are 3x sparser and
    -- the warm-up remains cosmetic, the panel-open sync is authoritative)
    return a.kicked or a.ticks > 20
end

function M.auto_start()
    if M._auto.started then return end
    M._auto.started = true
    pcall(function()
        LoopAsync(15000, M._auto_beat)
    end)
end

return M

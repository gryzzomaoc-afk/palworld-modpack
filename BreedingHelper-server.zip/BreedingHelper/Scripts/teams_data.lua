-- Built-in team presets for the 帕鲁阵容 tab. DATA-ONLY module: teams evolve
-- with the game meta, so they live here (hot-updatable with a mod minor
-- version) and never get hardcoded into ui logic. Every member and skill
-- number is source-pinned in research/notes/帕鲁阵容内置配置底稿.md
-- (2026-07-19: 巴哈功能队伍精华帖 / 游民 / 游侠 1.0 攻略, cross-checked).
--
-- place = where the partner skill takes effect: "party" (带在队伍),
-- "base" (放在据点), "ride" (骑乘期间). The #1 rookie mistake this tab
-- exists to prevent is the right member standing in the wrong place.
-- alt_of = this member is an upgraded substitute for another member's slot;
-- owning EITHER fills the slot (gap math counts slots, not members).
-- Skill numbers are the ★0~★4 condense range; the UI reminds players that
-- max condensation reaches the top value.
local M = {}

M.version = 1

M.builtin = {
    {
        key = "breeding", name = "育种组",
        desc = "挂机产蛋效率最大化：产蛋加速 + 双蛋 + 头目蛋概率 + 孵化加速",
        members = {
            { id = "Plesiosaur", zh = "梁叶龙", place = "base",
              skill = "在据点：配种牧场产蛋速度加快 20~50%（不可叠加）" },
            { id = "NaughtyCat", zh = "笑魇猫", place = "party",
              skill = "在队伍：捡到帕鲁蛋时 50~75% 概率再捡 1 颗（不可叠加）" },
            { id = "SakuraSaurus", zh = "连理龙", place = "party",
              skill = "在队伍：捡到的帕鲁蛋 35~45% 概率变成头目帕鲁蛋（不可叠加）" },
            { id = "SakuraSaurus_Water", zh = "海誓龙", place = "party",
              alt_of = "SakuraSaurus",
              skill = "在队伍：捡到的帕鲁蛋 45~55% 概率变成头目帕鲁蛋（连理龙上位）" },
            { id = "ThunderFluffyBird", zh = "雷云鹫", place = "base",
              skill = "在据点：帕鲁蛋孵化速度加快 20~40%（不可叠加）" },
        },
    },
    {
        key = "catching", name = "抓怪组",
        desc = "捕获效率最大化：掉落加成 + 背面奖励 + 冻结连锁 + 冻结捕获",
        members = {
            { id = "CatMage", zh = "暗巫猫", place = "party",
              skill = "在队伍：击倒无属性帕鲁掉落 +40~80%；投球 10~50% 概率不消耗帕鲁球（不可叠加）" },
            { id = "GhostBlackCat", zh = "念影喵", place = "party",
              skill = "在队伍：触发背面奖励时捕获概率提升（~特大）（不可叠加）" },
            { id = "GrassMinotaur_Ice", zh = "冰峰陶洛斯", place = "party",
              skill = "在队伍：玩家攻击浸湿状态的敌人时一击冻结" },
            { id = "FluffyBird", zh = "雪绵啾", place = "party",
              skill = "在队伍：对冻结状态帕鲁的捕获概率提升（~特大）（不可叠加）" },
        },
    },
    {
        key = "fishing", name = "钓鱼组",
        desc = "钓鱼收益最大化：渔获加成 + 计量槽保护 + 高潜力鱼",
        members = {
            { id = "JellyfishFairy", zh = "海月仙", place = "party",
              skill = "在队伍：钓鱼获得的道具增加 55~95%（不可叠加）" },
            { id = "OctopusGirl", zh = "墨沫姬", place = "party",
              skill = "在队伍：判定条未重合期间捕获计量槽下降量减少 12~35%（不可叠加）" },
            { id = "IceNarwhal", zh = "凉晶鲸", place = "party",
              skill = "在队伍：计量槽初始位置升高 5~14%、重合期间上升量 +5~14%（不可叠加）" },
            { id = "IceNarwhal_Fire", zh = "桃晶鲸", place = "party",
              alt_of = "IceNarwhal",
              skill = "在队伍：计量槽初始位置升高 7~17%、上升量 +7~17%（凉晶鲸上位）" },
            { id = "KingSunfish", zh = "曼波王", place = "party",
              skill = "在队伍：更容易钓上高潜力帕鲁（不可叠加）" },
            { id = "KingSunfish_Thunder", zh = "曼波皇", place = "party",
              alt_of = "KingSunfish",
              skill = "在队伍：更易钓高潜力帕鲁；骑乘期攻击转雷属性且 +5~20%（曼波王上位）" },
        },
    },
    -- r22 (2026-07-20): the combat team leaves the builtins (owner call);
    -- the base-work team is refit to the 1.0 graduation meta. Sources:
    -- 巴哈 玫玫物語 1.0 打工帕魯詳細推薦 (forum.gamer bsn=71458 snA=4601,
    -- GP175) cross-checked with the datamined base-aura table (snA=4512,
    -- GP112) and 游民星空 2171069; suitability numbers come from OUR OWN
    -- datamine (data.lua), not guide recall.
    {
        key = "work_base", name = "工作 · 据点组",
        desc = "1.0 毕业据点十岗位：手工双神 + 专职生火/发电/采矿/浇水/冷却 + 农业双光环",
        members = {
            { id = "Sekhmet", zh = "塞赫麦特", place = "base",
              skill = "手工6 / 采矿3——在据点时还会提升阿努比斯的工作速度（手工双神组）" },
            { id = "Anubis", zh = "阿努比斯", place = "base",
              skill = "手工6 / 采矿6 / 搬运4——手工与挖矿双毕业主力" },
            { id = "NightLady_Dark", zh = "贝菈露洁", place = "base",
              skill = "手工6 / 制药7 / 搬运4，暗属性通宵——古代文明工作台双适性一只满足" },
            { id = "Umihebi_Fire", zh = "腾炎龙", place = "base",
              skill = "生火7 专职——升三星即可封顶 10，炼锭烧菜首选" },
            { id = "CubeTurtle", zh = "重岩龟", place = "base",
              skill = "采矿4 专职——光环再给据点其他帕鲁采矿 +1（不可叠加）" },
            { id = "ThunderDog", zh = "霹雳犬", place = "base",
              skill = "发电4 专职——满星升 8、职业书封顶 10 的性价比发电位" },
            { id = "LeafPrincess", zh = "春彩娘", place = "base",
              skill = "播种3 / 采集2 / 制药3——光环加快作物生长（农业双光环之一）" },
            { id = "BlueberryFairy", zh = "梅莉姆", place = "base",
              skill = "播种3 / 采集2 / 制药3，暗属性——光环提升收获数量（农业双光环之二）" },
            { id = "GhostAnglerfish", zh = "冥灯鱼", place = "base",
              skill = "浇水5 / 搬运2，暗属性通宵——专职浇水位" },
            { id = "IceFox", zh = "吹雪狐", place = "base",
              skill = "冷却4 / 牧场3——15 级固定头目早期即可入手的冰箱管理员" },
        },
    },
}

return M

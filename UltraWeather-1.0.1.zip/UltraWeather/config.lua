-- 
-- Copyright 2026 Fr4nsson. All rights reserved.
-- Redistribution or derivative works require written permission.
-- Personal use and private modification of this file are permitted.
-- 
-- ============================================================
-- UltraWeather - UE4SS Lua mod for Palworld by Fr4nsson
--  * Rewrites Palworld's time-of-day sky. Three modes, from the lightest
--    touch to the heaviest: CloudsOnly, VanillaPlus and UltraWeather
--  * Creates the volumetric cloud component Palworld ships without
--  * Interpolates height fog tint across time of day, per mode
--  * Overrides the sky creator's post process component, per mode
-- Mostly diff-based: values are written only when they differ, and every
-- value it does write is remembered first so it can be put back.
--
-- Config is applied automatically on world load and teleport. You can also
-- edit this file and press the default F8 key to apply the updated
-- settings immediately in-game.
--
-- AssetPath is the package path WITHOUT the object suffix (the mod appends
-- ".AssetName" automatically). Settings mirrors the property layout of the
-- preset object: nested tables = struct properties, leaf values = fields.
--
-- Two comment labels appear next to values, and they mean different things
-- because the modes start from different places:
--
--   -- Default:    the value inherited from DT_PPSC_Weather_Clear_01, the
--                  InheritFrom base. Used in the UltraWeather section, where
--                  every preset is built on that base.
--   -- Palworld:   the value in Palworld's own preset. Used in the
--                  VanillaPlus and CloudsOnly sections, which have no base
--                  and edit the game's assets directly.
--
-- Presets list deltas, not full property sets. Anything not named is either
-- inherited from the base or left as Palworld has it.
-- ============================================================

local Config = {
    -- 0 = warnings only
    -- 1 = info  (short "Patched X" message when something changed)
    -- 2 = debug (logs every individual value that changed)
    LogLevel = 0,

    -- UE4SS key reference:
    -- https://docs.ue4ss.com/lua-api/table-definitions/key.html#key-code-strings
    -- (changing keybind settings requires a game restart)
    Keys = {
        Sync = {
            Enabled = true,
            Key = "F8", -- re-sync changes made in this config
        },
    },

    Weather = {
        Enabled = true,
        
        -- ========================================================
        -- MODE
        --
        -- Three modes, listed from the lightest touch to the heaviest. None
        -- of them leaves the sky completely alone: for that, disable the mod.
        --
        -- "CloudsOnly"
        --     Clouds, and only clouds. Palworld's sky is otherwise left as it
        --     ships: the schedule, lighting, fog, atmosphere and star map are
        --     all untouched and the fog tint loop stays off. Cloud coverage,
        --     wind and background cloud intensity are still yours to set,
        --     because those live inside the presets and Palworld never tuned
        --     them for clouds being visible.
        --
        -- "VanillaPlus"
        --     Clouds, plus slight edits to the presets the game already uses.
        --     The schedule stays exactly as Palworld shipped it, so the stock
        --     slot times and slot order are kept and only the preset contents
        --     move. Good if you like the stock look and want it tidied rather
        --     than replaced, or if another mod owns the schedule. The pre-mod
        --     value of every property listed under VanillaPlus is remembered,
        --     so switching mode or disabling the section writes the stock
        --     values back without a restart.
        --
        -- "UltraWeather"
        --     This mod's own sky, and the intended look. The time-of-day
        --     schedule is repointed at the Sky Creator plugin's unused sample
        --     assets, which are then rewritten from the settings below. The
        --     game's weather assets are never written to. Gives full control
        --     over all five slots and their times.
        --
        -- Switching mode and pressing F8 is enough; the previous mode's
        -- changes are undone first.
        -- ========================================================
        Mode = "UltraWeather",

        -- ========================================================
        -- MODE: UltraWeather
        --
        -- The original game presets in /Game/Others/nakano_test/nature_test/
        -- WEATHER/ are somewhat of a mess and were difficult to work with.
        -- The horizon colors were the biggest offender. Fortunately for us
        -- they shipped the sample presets that came with the Sky Creator
        -- plugin they use, 31 of them, unused by the game.
        --
        -- One is snapshotted as a shared base and four others are used as
        -- containers for our own values.
        --
        -- The Schedule below is the sky creator's time-of-day array. Five is
        -- the limit for this mod, not the engine: UE4SS can rewrite TArray
        -- entries but not resize one, so a sixth slot would need a pak mod
        -- editing the controller blueprint. Each preset owns its slot
        -- outright and the engine crossfades over the final
        -- InterpolationMinutes before the next one.
        --
        -- Lighting is deliberately left close to stock: the plugin's own
        -- sample presets all leave sun intensity at 10.0 and let sun
        -- elevation supply the brightness curve, varying only clouds, fog
        -- and haze.
        --
        -- "Default:" comments are the inherited value from InheritFrom.
        -- ========================================================
        UltraWeather = {
            -- Search for "WEATHER_REFERENCE" for documentation on available properties and values.
            
            -- Snapshotted once per session and used as the base for every
            -- preset below.
            InheritFrom = "/Game/PPSkyCreator/WeatherPresets/"
                .. "DT_PPSC_Weather_Clear_01",

            -- Crossfade length in GAME minutes. The fade ends on the slot
            -- time, so this must stay below the smallest gap between slots
            -- (66 minutes with the schedule below) or presets never fully
            -- arrive. Sync warns if it is too large.
            InterpolationMinutes = 40,

            -- ---------------------------------------------------------
            -- Applied to the base for every preset, before per-preset
            -- Settings. The stock atmosphere is far from Unreal's physical
            -- values, which tints the sky green at low sun angles.
            -- ---------------------------------------------------------
            BaseOverrides = {
                SkyAtmosphereSettings = {
                    -- Ozone. The stock blue term is ~8x physical, which
                    -- removes blue from the long twilight path and leaves
                    -- red + green.
                    -- Default: R=0.584, G=1.0, B=0.36
                    Absorption = { R = 0.345561, G = 1.0, B = 0.045 },

                    -- Default: 0.006, roughly 7x too weak to pull the
                    -- green-orange band out of that path.
                    AbsorptionScale = 0.040,

                    -- Default: 0.04, about 90x physical. Neutral extinction
                    -- greying the whole sky and flattening saturation.
                    MieAbsorptionScale = 0.00044,

                    -- Default: R=0.118, G=0.280, B=1.0
                    RayleighScattering = {
                        R = 0.175287, G = 0.409607, B = 1.0,
                    },

                    -- Default: 0.04
                    RayleighScatteringScale = 0.0331,
                },
                BackgroundCloudSettings = {
                    BackgroundCloudsIntensity = 30.0,
                    BackgroundCloudsLayerA = 0.0,
                    BackgroundCloudsLayerB = 1.0,
                    BackgroundCloudsLayerC = 0.0,
                },
            },

            Presets = {
                -- -----------------------------------------------------
                -- NIGHT - slots 1 and 5.
                -- -----------------------------------------------------
                Night = {
                    Enabled = true,
                    AssetPath = "/Game/PPSkyCreator/WeatherPresets/"
                        .. "DT_PPSC_Weather_Clear_02",
                    Settings = {
                        SkyAtmosphereSettings = {
                            -- Default: 0.002
                            MieScatteringScale = 0.006, -- Controls night brightness, higher = darker
                                                        -- controls how far you see at night, change to 1.0
                                                        -- or higher to limit how far you can see at night.
                                                        -- Too high values (3+) may make the transitions between
                                                        -- day/night look a little wierd.

                            -- Default: 1.0
                            HeightFogContribution = 0.5,
                        },
                        SkyLightSettings = {
                            -- Default: 1.0
                            Intensity = 1.5, -- Controls night brightness, lower = darker.
                        },
                        SunLightSettings = {
                            -- Default: 10.0
                            Intensity = 0.01,
                        },
                        MoonLightSettings = {
                            -- Default: 0.04
                            Intensity = 0.02, -- Controls night brightness, higher = brighter.

                            -- Default: 8500
                            Temperature = 8500,
                        },
                        StarMapSettings = {
                            -- Default: 1.0
                            StarMapIntensity = 12.0,
                        },
                        VolumetricCloudSettings = {
                            -- Default: 0.0
                            CumulusCoverage = 0.0,
                            StratocumulusCoverage = 0.0,
                            -- Default: R = 0.010725, G = 0.015880, B = 0.025, raise if clouds read as black cutouts.
                            NightEmissive = {
                                R = 0.010725, G = 0.015880, B = 0.025,
                            },
                        },
                        BackgroundCloudSettings = {
                            -- Dim, so the star map stays readable. 0 leaves
                            -- the night sky completely clear.
                            BackgroundCloudsIntensity = 5.0,
                            -- Palworld's night preset is the only one that
                            -- runs all three painted layers at once, which
                            -- gives the night sky more broken-up texture.
                            -- Worth keeping: volumetric coverage is 0 above,
                            -- so these layers are the only clouds at night.
                            BackgroundCloudsLayerA = 0.6,
                            BackgroundCloudsLayerB = 0.8,
                            BackgroundCloudsLayerC = 0.6,
                            BackgroundCloudsColorTint = {
                                R = 1.0, G = 1.0, B = 1.0, A = 1.0,
                            },
                        },
                        WindSettings = {
                            CloudWindSpeed = 3.0,
                            CloudWindDirection = 60.0,
                        },
                        ExponentialHeightFogSettings = {
                            -- Default: 0.002
                            FogDensity = 0.024,

                            -- Default: 0.06
                            FogHeightFalloff = 0.02,

                            -- Default: 0.2
                            VolumetricFogScatteringDistribution = 0.70,

                            -- Default: 1.0
                            VolumetricFogExtinctionScale = 0.35,
                        },
                        PostProcessSettings = {
                            -- Default: 0.675
                            BloomIntensity = 0.7,

                            -- Default: -0.40
                            BloomThreshold = -0.40,

                            -- Default: 1.0
                            ExposureCompensation = 1.0,
                        },
                    },
                },

                -- -----------------------------------------------------
                -- DAWN - slot 2, 03:00, which is sunrise.
                -- -----------------------------------------------------
                Dawn = {
                    Enabled = true,
                    AssetPath = "/Game/PPSkyCreator/WeatherPresets/"
                        .. "DT_PPSC_Weather_Clear_03",
                    Settings = {
                        SkyAtmosphereSettings = {
                            -- Default: 0.002
                            MieScatteringScale = 0.002,

                            -- Default: 1.0
                            HeightFogContribution = 1.0,
                        },
                        SkyLightSettings = {
                            -- Default: 1.0
                            Intensity = 1.5,
                        },
                        SunLightSettings = {
                            -- Default: 10
                            Intensity = 15,

                            -- Default: 5500
                            Temperature = 4000,
                        },
                        StarMapSettings = {
                            -- Default: 1.0
                            StarMapIntensity = 0.4,
                        },
                        VolumetricCloudSettings = {
                            -- Default: 0.0
                            CumulusCoverage = 0.70,
                            StratocumulusCoverage = 0.45,

                            -- Default: 0.6
                            PhaseG = 0.75,

                            -- Default: 0.5
                            MultiScatteringContribution = 0.75,
                        },
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 25.0,
                            
                            -- The painted layers are lit by the sky material,
                            -- so they never pick the low sun up from the
                            -- atmosphere the way the volumetric layer does.
                            -- Palworld solves that with a heavily saturated
                            -- tint on its sunrise/sunset preset; these are
                            -- its values. The engine crossfades the tint
                            -- between slots, so the warm-up is gradual.
                            BackgroundCloudsColorTint = {
                                R = 0.713542, G = 0.241209, B = 0.0, A = 1.0,
                            },
                            BackgroundCloudsLayerA = 0.0,
                            BackgroundCloudsLayerB = 1.0,
                            BackgroundCloudsLayerC = 0.0,
                        },
                        WindSettings = {
                            CloudWindSpeed = 4.0,
                            CloudWindDirection = 60.0,
                        },
                        ExponentialHeightFogSettings = {
                            -- Default: 0.002. Morning mist.
                            FogDensity = 0.005,

                            -- Default: 0.06. Lower so fog sits in valleys.
                            FogHeightFalloff = 0.04,

                            -- Default: 0.2. Forward scatter for godrays.
                            VolumetricFogScatteringDistribution = 0.4,

                            -- Default: 1.0
                            VolumetricFogExtinctionScale = 0.7,
                        },
                    },
                },

                -- -----------------------------------------------------
                -- DAY - slot 3, 05:00 through 22:00
                -- -----------------------------------------------------
                Day = {
                    Enabled = true,
                    AssetPath = "/Game/PPSkyCreator/WeatherPresets/"
                        .. "DT_PPSC_Weather_Clear_04",
                    Settings = {
                        SunLightSettings = {
                            -- Default: 10
                            Intensity = 15,

                            -- Default: 5500
                            Temperature = 6000,
                        },
                        SkyLightSettings = {
                            -- Default: 1.0
                            Intensity = 3.0,
                        },
                        SkyAtmosphereSettings = {
                            -- Default: 0.002
                            MieScatteringScale = 0.003,

                            -- Default: 1.0
                            HeightFogContribution = 1.0,
                        },
                        VolumetricCloudSettings = {
                            -- Default: 0.0.
                            CumulusCoverage = 0.60,
                            StratocumulusCoverage = 0.40,

                            -- Default: 0.5
                            MultiScatteringContribution = 0.70,
                        },
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 20.0,
                            BackgroundCloudsColorTint = {
                                R = 0.95, G = 0.93, B = 0.29, A = 1.0,
                            },
                        },
                        WindSettings = {
                            CloudWindSpeed = 4.0,
                            CloudWindDirection = 60.0,
                        },
                        ExponentialHeightFogSettings = {
                            -- Default: 0.002
                            FogDensity = 0.0018,

                            -- Default: 0.06
                            FogHeightFalloff = 0.06,

                            -- Default: 0.2
                            VolumetricFogScatteringDistribution = 0.45,

                            -- Default: 1.0
                            VolumetricFogExtinctionScale = 0.4,
                        },
                    },
                },

                -- -----------------------------------------------------
                -- DUSK - slot 4, 22:00 to 23:06. Sunset is 23:00
                -- -----------------------------------------------------
                Dusk = {
                    Enabled = true,
                    AssetPath = "/Game/PPSkyCreator/WeatherPresets/"
                        .. "DT_PPSC_Weather_Default",
                    Settings = {
                        SkyAtmosphereSettings = {
                            -- Default: 0.002
                            MieScatteringScale = 0.002,

                            -- Default: 1.0
                            HeightFogContribution = 1.0,
                        },
                        SkyLightSettings = {
                            -- Default: 1.0
                            Intensity = 1.5,
                        },
                        SunLightSettings = {
                            -- Default: 10
                            Intensity = 9,

                            -- Default: 5500
                            Temperature = 3500,
                        },
                        StarMapSettings = {
                            -- Default: 1.0
                            StarMapIntensity = 0.8,
                        },
                        VolumetricCloudSettings = {
                            -- Default: 0.0
                            CumulusCoverage = 0.73,
                            StratocumulusCoverage = 0.50,

                            -- Default: 0.6
                            PhaseG = 0.78,

                            -- Default: 0.5
                            MultiScatteringContribution = 0.75,
                        },
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 35.0,
                            BackgroundCloudsColorTint = {
                                R = 1.21, G = 0.42, B = 0.0, A = 1.0,
                            },
                        },
                        WindSettings = {
                            CloudWindSpeed = 5.0,
                            CloudWindDirection = 60.0,
                        },
                        ExponentialHeightFogSettings = {
                            -- Default: 0.002
                            FogDensity = 0.0025,

                            -- Default: 0.06
                            FogHeightFalloff = 0.06,

                            -- Default: 0.2
                            VolumetricFogScatteringDistribution = 0.45,

                            -- Default: 1.0
                            VolumetricFogExtinctionScale = 0.7,
                        },
                    },
                },
            },

            -- ---------------------------------------------------------
            -- Slot order matches the controller's array. Slots 1 and 5 must
            -- name the same preset or the sky blends across midnight.
            -- Palworld's sun: dawn 01:30, sunrise 03:00, sunset 23:00,
            -- dusk ends 00:30.
            -- ---------------------------------------------------------
            Schedule = {
                { Time = 0.0,  Preset = "Night" },
                { Time = 3.0,  Preset = "Dawn"  },
                { Time = 5.0,  Preset = "Day"   },
                { Time = 22.0, Preset = "Dusk"  },
                { Time = 23.1, Preset = "Night" },
            },
        },

        -- ========================================================
        -- MODE: VanillaPlus
        --
        -- Edits the three presets Palworld already schedules, in place. The
        -- schedule, its slot times and which preset owns which slot are all
        -- left untouched, so the sunrise/sunset preset keeps serving both
        -- ends of the day exactly as the game intends.
        --
        -- Because these are the game's own assets, every property listed
        -- here is read and remembered before the first write. Switching Mode
        -- away from "VanillaPlus", or setting Weather.Enabled = false, and
        -- then pressing F8 writes those stock values back.
        --
        -- The shipped values below only give the volumetric clouds sensible
        -- per-time-of-day coverage, since Palworld tuned these presets with
        -- clouds switched off. Everything else is left as the game has it.
        --
        -- Background cloud intensity is lowered too, because the painted
        -- sky-sphere layers and the new volumetric layer now share the sky.
        -- The layer mix and tint are deliberately left alone here: the three
        -- presets do not agree. Daylight and sunrise/sunset use Layer B on its
        -- own, the night preset runs all three at 0.6/0.8/0.6, and the
        -- sunrise/sunset tint is a deep orange rather than neutral.
        -- ========================================================
        VanillaPlus = {
            -- Search for "WEATHER_REFERENCE" for documentation on available properties and values.
            
            -- Crossfade length in GAME minutes. nil leaves Palworld's own
            -- value alone, which is what you normally want here.
            --InterpolationMinutes = 40,

            -- Merged into every preset below, before that preset's own
            -- Settings. The physically corrected atmosphere from the
            -- UltraWeather section is a large change to the stock look, so it
            -- is left commented out here.
            SharedOverrides = {
                --SkyAtmosphereSettings = {
                --    Absorption = { R = 0.345561, G = 1.0, B = 0.045 },
                --    AbsorptionScale = 0.040,
                --    MieAbsorptionScale = 0.00044,
                --    RayleighScattering = {
                --        R = 0.175287, G = 0.409607, B = 1.0,
                --    },
                --    RayleighScatteringScale = 0.0331,
                --},
            },

            Presets = {
                PalDaylight = {
                    Enabled = true,
                    AssetPath =
                        "/Game/Others/nakano_test/nature_test/WEATHER/"
                        .. "PPSC_pal_daylight_2_remake_work_1",

                    Settings = {
                        SunLightSettings = {
                            -- Palworld: 30
                            Intensity = 25.0, -- Direct sunlight.
                                              
                            -- Palworld: 7000
                            Temperature = 8000, -- bit more blue

                            -- Palworld: 1
                            VolumetricScatteringIntensity = 0.75 -- less foggy haze
                        },

                        SkyLightSettings = {
                            -- Palworld: 7
                            Intensity = 6.0, -- lower ambient light
                        },

                        SkyAtmosphereSettings = {
                            -- Palworld: 1.20
                            HeightFogContribution = 1.40
                        },
                        
                        VolumetricCloudSettings = {
                            CumulusCoverage = 0.55,
                            StratocumulusCoverage = 0.35,
                            MultiScatteringContribution = 0.70,
                        },
                        
                        BackgroundCloudSettings = {
                            -- Palworld: 50
                            BackgroundCloudsIntensity = 25.0,
                        },
                        
                        WindSettings = {
                            CloudWindSpeed = 4.0,
                            CloudWindDirection = 60.0,
                        },
                        
                        ExponentialHeightFogSettings = {
                            -- Palworld: 0.01
                            FogDensity = 0.03,

                            -- Palworld: 0.35
                            FogHeightFalloff = 0.35,
                            
                            -- Palworld: 10000.0
                            FogStartDistance = 10000.0,
                            
                            -- Palworld: 0.4
                            VolumetricFogExtinctionScale = 0.1, -- gives clarity to day time
                                                                -- gets rid of haze
                        }
                    }
                },
                PalSunriseSunsetLight = {
                    Enabled = true,
                    AssetPath =
                        "/Game/Others/nakano_test/nature_test/WEATHER/"
                        .. "PPSC_pal_sunrise_sunset_light_remake",

                    Settings = {
                        BackgroundCloudSettings = {
                            -- Palworld: 50
                            BackgroundCloudsIntensity = 25.0,
                        },
                    
                        SunLightSettings = {
                            -- Palworld: 30
                            Intensity = 20.0, 
                            
                            -- Palworld: { R = 1.0, G = 1.0, B = 0.9, A = 1.0 },
                            LightColor = { R = 1.0, G = 0.6, B = 0.9, A = 1.0 },
                        },
                        
                        SkyLightSettings = {
                            -- Palworld: 6.0
                            Intensity = 4.0,
                            
                            -- Palworld: 35
                            -- INERT. Writes land on the asset and change
                            -- nothing on screen, tested down to 0.0. Left
                            -- here only to document Palworld's own value.
                            --NightIntensity = 20,
                        },
                        
                        SkyAtmosphereSettings = {
                            -- Palworld: 1.0
                            HeightFogContribution = 1.0
                        },
                        
                        VolumetricCloudSettings = {
                            CumulusCoverage = 0.65,
                            StratocumulusCoverage = 0.45,
                            PhaseG = 0.76,
                            MultiScatteringContribution = 0.75,
                        },
                        
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 25.0,
                        },
                        
                        WindSettings = {
                            CloudWindSpeed = 4.5,
                            CloudWindDirection = 60.0,
                        },
                        
                        ExponentialHeightFogSettings = {
                            -- Palworld: 0.08
                            FogDensity = 0.08,

                            -- Palworld: 1.085636
                            FogHeightFalloff = 0.35, -- 0.5
                            
                            -- Palworld: 2960.0
                            FogStartDistance = 5000.0,
          
                            -- Palworld: 
                            VolumetricFogExtinctionScale = 0.15,
                        }
                    }
                },
                PalNightlight = {
                    Enabled = true,
                    AssetPath =
                        "/Game/Others/nakano_test/nature_test/WEATHER/"
                        .. "PPSC_pal_nightlight_2_remake",

                    Settings = {
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 20.0,
                            BackgroundCloudsLayerA = 0.0,
                            BackgroundCloudsLayerB = 0.2,
                            BackgroundCloudsLayerC = 0.0,
                        },
                    
                        SkyLightSettings = {
                            -- Palworld: 7.5
                            Intensity = 5, -- controls night brightness
                            -- Too many objects in the world are emissive (e.g. pals, beaches, or the shield dome),
                            -- and they become very obvious when this value is set to 0.
                            -- This is the darkest result I could achieve without modifying every self-lit object.
                            -- I may revisit this in a future version.
                        },
                        
                        SunLightSettings = {
                            -- Palworld: 0
                            Intensity = 20.0, -- gives smoother transition from night to daytime
                            
                            -- Palworld: 7000
                            Temperature = 8000,
                        },
                        
                        MoonLightSettings = {
                            -- Palworld: 0.04
                            Intensity = 0.00, -- controls night brightness
                        },
                        
                        VolumetricCloudSettings = {
                            CumulusCoverage = 0.25,
                            StratocumulusCoverage = 0.15,

                            -- Cloud self-glow; raise if clouds read as black
                            -- cutouts against the star map.
                            NightEmissive = {
                                R = 0.010725, G = 0.015880, B = 0.025,
                            },
                        },
                        
                        BackgroundCloudSettings = {
                            -- Low so the star map stays readable.
                            BackgroundCloudsIntensity = 10.0,
                        },
                        
                        WindSettings = {
                            CloudWindSpeed = 3.0,
                            CloudWindDirection = 60.0,
                        },
                        
                        ExponentialHeightFogSettings = {
                            -- Palworld: 0.01
                            FogDensity = 0.02,

                            -- Palworld: 0.03
                            FogHeightFalloff = 0.07,
                            
                            -- Palworld: 5000
                            FogStartDistance = 5000.0,
                            
                            -- Palworld: 0.71
                            VolumetricFogScatteringDistribution = 0.78,
                        },
                        
                        SkyAtmosphereSettings = {
                            -- Palworld: 8
                            RayleighExponentialDistribution = 8.0,
                            
                            -- Palworld: 1.0
                            HeightFogContribution = 1.0
                        }
                    }
                },
            },
        },
        
        -- ========================================================
        -- MODE: CloudsOnly
        --
        -- The same three presets as VanillaPlus, but only their cloud
        -- properties are set and nothing else.
        --
        -- This section exists because cloud coverage is stored inside the
        -- weather presets, not on the sky actor, so there is no way to turn
        -- the clouds down without writing to a preset. Palworld shipped with
        -- clouds switched off, which means the coverage values sitting in
        -- those presets were never tuned for anyone actually seeing them, and
        -- straight out of the box they are heavy. The values below thin them
        -- to something reasonable.
        --
        -- Every property here is read and remembered before the first write,
        -- exactly as in VanillaPlus, so switching mode or disabling the mod
        -- puts the stock values back without a restart.
        --
        -- Keep this section to cloud properties. Anything else belongs in
        -- VanillaPlus, which is the same three presets with a wider remit.
        -- ========================================================
        CloudsOnly = {
            -- Merged into every preset below, before its own Settings.
            SharedOverrides = {
                VolumetricCloudSettings = {
                    MultiScatteringContribution = 0.70,
                },
                WindSettings = {
                    CloudWindSpeed = 4.0,
                    CloudWindDirection = 60.0,
                },
            },
            
            Presets = {
                PalDaylight = {
                    Enabled = true,
                    AssetPath =
                        "/Game/Others/nakano_test/nature_test/WEATHER/"
                        .. "PPSC_pal_daylight_2_remake_work_1",
                    Settings = {
                        -- Lower both for a clearer sky, raise for overcast.
                        VolumetricCloudSettings = {
                            CumulusCoverage = 0.55,
                            StratocumulusCoverage = 0.35,
                        },
                        -- The painted sky-sphere layers. This preset ships 50,
                        -- halved because the volumetric layer now shares the
                        -- same sky. Put it back to 50 for the stock backdrop.
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 50.0,
                        },
                    },
                },
                
                PalSunriseSunsetLight = {
                    Enabled = true,
                    AssetPath =
                        "/Game/Others/nakano_test/nature_test/WEATHER/"
                        .. "PPSC_pal_sunrise_sunset_light_remake",
                    Settings = {
                        VolumetricCloudSettings = {
                            CumulusCoverage = 0.65,
                            StratocumulusCoverage = 0.45,
                            PhaseG = 0.76,
                        },
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 50.0,
                        },
                    },
                },
                
                PalNightlight = {
                    Enabled = true,
                    AssetPath =
                        "/Game/Others/nakano_test/nature_test/WEATHER/"
                        .. "PPSC_pal_nightlight_2_remake",
                    Settings = {
                        VolumetricCloudSettings = {
                            -- Light cover so the star map stays readable.
                            CumulusCoverage = 0.25,
                            StratocumulusCoverage = 0.15,

                            -- Cloud self-glow; raise if clouds read as black
                            -- cutouts against the stars.
                            NightEmissive = {
                                R = 0.010725, G = 0.015880, B = 0.025,
                            },
                        },
                        BackgroundCloudSettings = {
                            BackgroundCloudsIntensity = 10.0,
                        },
                    },
                },
            },
        },

        -- ========================================================
        -- VOLUMETRIC CLOUDS
        --
        -- Palworld ships the cloud component missing, so it is created and
        -- handed to the plugin on sync. Stock sample scales are Palworld's
        -- own, left low because clouds were off. Applies in every mode.
        --
        -- These are quality and extent settings on the sky actor. Cloud
        -- coverage is not here: it lives inside the weather presets.
        -- ========================================================
        VolumetricClouds = {
            Enabled = true,

            ViewSampleCountScale = 4.0,             -- stock 1.5
            ShadowViewSampleCountScale = 2.0,       -- stock 0.5
            ReflectionSampleCountScale = 1.0,       -- stock 0.5
            ShadowReflectionSampleCountScale = 0.5, -- stock 0.25
            ShadowTracingDistance = 8.0,            -- stock 2.0 km

            -- Where the cloud layer visibly ends at the horizon.
            -- The most expensive value here.
            TracingMaxDistance = 15.0,              -- stock 5.0 km
            TracingStartMaxDistance = 50.0,

            -- Clouds darken ambient light beneath them.
            AmbientOcclusion = true,

            -- false leaves wind on the actor's own values instead of the
            -- WindSettings in each preset.
            PresetWind = true,

            -- Clouds render nothing while r.VolumetricCloud is 0, which
            -- another mod or a custom Engine.ini can leave disabled. Set to
            -- false if you want to control that CVar yourself.
            ForceCVar = true,
        },

        -- ========================================================
        -- BACKGROUND CLOUDS
        --
        -- Background clouds are the painted layers on the sky sphere, drawn
        -- behind the volumetric clouds. The two systems are independent and
        -- are meant to be used together: the painted layers cover the horizon
        -- past VolumetricClouds.TracingMaxDistance, where volumetric tracing
        -- stops. They cast no cloud shadows and are not lit by the atmosphere,
        -- so keep them as a backdrop rather than the main cloud layer.
        --
        -- Intensity, tint and the layer mix are preset fields, set per time of
        -- day in BackgroundCloudSettings on each preset above. The three
        -- values here are sky-actor properties and therefore apply to every
        -- time of day at once. nil leaves the property untouched, which is the
        -- default. Ignored in "CloudsOnly" mode.
        --
        -- Unlike the preset fields, these names come from the plugin's
        -- documentation rather than a verified dump of Palworld's sky actor.
        -- A warning in UE4SS.log means the name is wrong on this build.
        -- ========================================================
        BackgroundClouds = {
            Enabled = true,

            -- Contrast of the painted layers.
            --BackgroundCloudsContrast = 1.0,

            -- How strongly the painted layers light the world through the sky
            -- light. 0 stops them contributing at all, which is worth trying
            -- if ambient light looks washed out now that the volumetric clouds
            -- feed the same sky light capture.
            --BackgroundCloudsReflectionScale = 1.0,

            -- Extra yaw on the painted layers, in degrees. Useful for lining
            -- their drift up with CloudWindDirection in the presets.
            --BackgroundCloudsRotation = 60.0,
        },

        -- ========================================================
        -- FOG TINT
        --
        -- Palworld's fog runs in cubemap mode, so its colour is the cubemap
        -- times InscatteringTextureTint and the colour fields in
        -- ExponentialHeightFogSettings do nothing. The tint is a component
        -- property, so it is interpolated here against time of day using the
        -- same model as the engine crossfade.
        --
        -- Values sit near stock luminance, so only the hue moves. Each entry
        -- in Schedule names a key in Colors; keep BlendMinutes equal to the
        -- active mode's InterpolationMinutes or the fog leads or lags the sky
        -- through every transition.
        --
        -- The values here are the shared base. Modes below is merged over
        -- them and is keyed by Weather.Mode, so each mode can have its own
        -- colours, its own schedule, or no tint at all. The base colours are
        -- tuned for "UltraWeather"; Palworld's stock tint already matches its
        -- own presets, so VanillaPlus and CloudsOnly ship with the tint off.
        --
        -- Turning the tint off restores the fog's original tint on the next
        -- sync, so switching it off mid-session is safe.
                                                                        
        -- ========================================================
        FogTint = {
            Enabled = true,
            UpdateMs = 500,
            BlendMinutes = 40,

            Schedule = {
                { Time = 0.0,  Color = "Night" },
                { Time = 3.0,  Color = "Dawn"  },
                { Time = 5.0,  Color = "Day"   },
                { Time = 22.0, Color = "Dusk"  },
                { Time = 23.1, Color = "Night" },
            },

            Colors = {
                --Night = { R = 0.000, G = 0.000, B = 0.000 }, -- pure black night fog -- controls night brightness
                Night = { R = 0.030, G = 0.030, B = 0.060 }, -- classic night fog
                Dawn  = { R = 0.010, G = 0.010, B = 0.140 },
                Day   = { R = 0.110, G = 0.150, B = 0.210 },
                Dusk  = { R = 0.010, G = 0.010, B = 0.250 },
            },

            -- ----------------------------------------------------
            -- Per-mode overrides, merged over everything above.
            --
            -- Colors merges key by key, so naming just one time of day
            -- leaves the rest of the base colours alone. Schedule is the
            -- exception: it is an ordered list, so overriding it replaces
            -- the whole thing and you must give all the entries.
            -- ----------------------------------------------------
            Modes = {
                UltraWeather = {
                    -- Uses the base values above.
                },

                VanillaPlus = {
                    -- Off by default: Palworld's own presets were authored
                    -- against its own fog tint, and the base colours above
                    -- were picked for the UltraWeather sky. Set this true
                    -- and fill in Colors below to tint the stock sky.
                    Enabled = false,

                    --Colors = {
                    --    Night = { R = 0.000, G = 0.000, B = 0.000 },
                    --    Dawn  = { R = 0.010, G = 0.010, B = 0.140 },
                    --    Day   = { R = 0.110, G = 0.150, B = 0.210 },
                    --    Dusk  = { R = 0.010, G = 0.010, B = 0.250 },
                    --},
                },

                CloudsOnly = {
                    -- Fog is not a cloud property, so this mode leaves it
                    -- alone. Enabling it here would step outside what the
                    -- mode is meant to change.
                    Enabled = false,
                },
            },
        },
    },

    -- ============================================================
    -- POST PROCESS
    --
    -- Overrides settings on the sky creator's own post process component, the
    -- one that sits over the whole scene.
    --
    -- Settings applies in every mode. Modes is merged over it and is keyed by
    -- Weather.Mode above, because the modes do not need the same treatment:
    -- the UltraWeather presets are deliberately darker than stock, so without
    -- lowering the auto exposure floor you can barely see anything in caves,
    -- interiors and night-time shade. VanillaPlus keeps Palworld's own
    -- brightness and needs no compensation, so its block is left empty.
    --
    -- Anything this section writes is read and remembered first, so switching
    -- mode or setting Enabled = false puts the original values back on the
    -- next sync.
    --
    -- ------------------------------------------------------------
    -- RUNNING ULTRAGRAPHICS AS WELL? READ THIS
    -- ------------------------------------------------------------
    -- UltraGraphics patches this same component, but the two mods set
    -- different properties, so out of the box they do not collide.
    --
    --   UltraGraphics   LumenSkylightLeaking
    --                   LumenDiffuseColorBoost
    --                   LumenFullSkylightLeakingDistance
    --
    --   UltraWeather    AutoExposureMinBrightness            (UltraWeather)
    --                   AutoExposureMaxBrightness            (UltraWeather)
    --                   LocalExposureHighlightContrastScale  (VanillaPlus)
    --                   nothing at all                       (CloudsOnly)
    --
    -- Leave both enabled. Turning either off only costs you what that mod
    -- was doing; there is no duplicated work to resolve.
    --
    -- Only the properties named in this section are ever read or written,
    -- so the Lumen values are genuinely untouched rather than rewritten
    -- with the same number. Adding a Lumen property below stops that being
    -- true, which is why they are deliberately absent from Settings above.
    --
    -- The one way to create a conflict is to set the same property in both
    -- config.lua files to different values. Whichever mod syncs last wins,
    -- so the value looks like it is being ignored, or like it changes after
    -- a fast travel. If you customise, keep each property in one file only.
    --
    -- Separately, and nothing to do with this section: UltraGraphics'
    -- weather section still has to be disabled while running both mods.
    -- That goes away in UltraGraphics 1.2.0, which drops weather entirely.
    -- ============================================================
    PostProcess = {
        Enabled = true,

        SkyCreator = {
            Enabled = true,
            ComponentClass = "PostProcessComponent",
            NameContains = {
                "PPSkyCreator_",
                ".Post Process Component",
            },

            -- Applied in every mode, before the Modes block below.
            Settings = {
                -- The Lumen and reflection properties on this component are
                -- UltraGraphics' territory. Setting them here as well is the
                -- easiest way to end up with the two mods disagreeing, so
                -- they are left out rather than duplicated.
            },

            -- Merged over Settings when Weather.Mode matches the key. A mode
            -- with no entry, or an empty one, just gets Settings.
            Modes = {
                UltraWeather = {
                    Settings = {
                        -- The presets in this mode run darker than Palworld's,
                        -- so the exposure floor has to come down with them or
                        -- dark interiors and caves end up near-black. If it is
                        -- still too dark, lower AutoExposureMinBrightness
                        bOverride_AutoExposureMinBrightness = true,
                        bOverride_AutoExposureMaxBrightness = true,
                        AutoExposureMinBrightness = 0.30, -- Vanilla: 0.50 -- controls how dark it is 
                                                                           -- controls night brightness
                                                                           -- lower = brighter
                                                                           
                        AutoExposureMaxBrightness = 3.40, -- Vanilla: 3.40
                        
                        -- bOverride_LumenSkylightLeaking = true,             -- DO NOT SET HERE IF YOU ARE USING ULTRA GRAPHICS MOD, SET IT THERE INSTEAD
                        -- LumenSkylightLeaking = 0.10, -- Vanilla: 0.00      -- DO NOT SET HERE IF YOU ARE USING ULTRA GRAPHICS MOD, SET IT THERE INSTEAD
                        -- 
                        -- bOverride_LumenDiffuseColorBoost = true,           -- DO NOT SET HERE IF YOU ARE USING ULTRA GRAPHICS MOD, SET IT THERE INSTEAD
                        -- LumenDiffuseColorBoost = 1.50, -- Vanilla: 1.00    -- DO NOT SET HERE IF YOU ARE USING ULTRA GRAPHICS MOD, SET IT THERE INSTEAD
                        -- 
                        -- bOverride_LumenFullSkylightLeakingDistance = true, -- DO NOT SET HERE IF YOU ARE USING ULTRA GRAPHICS MOD, SET IT THERE INSTEAD
                        -- LumenFullSkylightLeakingDistance = 10000.0,        -- DO NOT SET HERE IF YOU ARE USING ULTRA GRAPHICS MOD, SET IT THERE INSTEAD
                    },
                },

                VanillaPlus = {
                    Settings = {
                        -- Palworld's own presets
                        bOverride_LocalExposureHighlightContrastScale = true,
                        LocalExposureHighlightContrastScale = 0.75, -- Vanilla: 1.00, lowered to reduce harsh midday glare and prevent near-white clipping.
                    },
                },

                CloudsOnly = {
                    Settings = {
                        -- If you want to add some post process changes to the clouds only mode, do it here.
                    },
                },
            },
        },
    },
}

-- ============================================================
-- WEATHER_REFERENCE: cloud brightness / opacity, every value at stock
--
-- This is a lookup sheet, NOT a drop-in.
--
-- Every value below is the stock value from DT_PPSC_Weather_Clear_01,
-- which is the InheritFrom base for UltraWeather: it gets snapshotted 
-- once per session and every UltraWeather preset is built on top of it.
-- So these are the values a preset starts from before BaseOverrides and 
-- its own Settings are layered over them, and they are what the "Default:"
-- comments elsewhere in this file are quoting.
--
-- Presets are meant to list deltas, not full property sets. Anything a
-- preset does not name is inherited from the base already, so writing a
-- value that matches what you would inherit adds a line that can only
-- drift out of sync later. Pasting this whole block into a real preset
-- would do exactly that, and pin the tuned coverage we ship back to
-- base while it was at it. Copy the two or three lines you actually
-- want to change.
--
-- All names verified against the Live View dump. Fields absent from that
-- dump do not exist on Palworld's plugin build, which predates 1.40.2 --
-- no IntensityScale, no Solar Eclipse, no VolumetricFogStartDistance.
-- ============================================================
-- Day = {
--     Enabled = true,
--     AssetPath = "/Game/PPSkyCreator/WeatherPresets/DT_PPSC_Weather_Clear_04",
--     Settings = {
-- 
--         VolumetricCloudSettings = {
--             -- --- BRIGHTNESS AND TINT ---------------------------------
-- 
--             -- Cloud tint and brightness in one: how much light the cloud
--             -- reflects. Lower it to ~0.85 grey to take the glare off
--             -- without touching anything else in the scene.
--             -- NOTE THE LOWERCASE 'a'. Every other field in this struct is
--             -- PascalCase; this one is not. "Albedo" silently does nothing
--             -- and logs a property-not-found warning.
--             albedo = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 },
-- 
--             -- Ground bounce colour lighting the cloud from below. Only
--             -- used when Ground Contribution is on in the actor's quality
--             -- settings.
--             GroundAlbedo = { R = 0.25, G = 0.25, B = 0.25, A = 1.0 },
-- 
--             -- Self-illumination. Independent of any light source, which
--             -- is why it works at night. Keep it low or clouds go flat.
--             NightEmissive = { R = 0.010725, G = 0.015880, B = 0.025, A = 1.0 },
-- 
--             -- --- OPACITY ---------------------------------------------
-- 
--             -- Density per altitude band. Lower = wispier, higher = solid.
--             -- Note how thin the bottom is by default; raising DensityBottom
--             -- is what gives clouds a heavy, flat base.
--             DensityBottom = 0.001,
--             DensityMiddle = 0.050,
--             DensityTop = 0.100,
-- 
--             -- --- SHAPE AND SHADING -----------------------------------
-- 
--             -- Darkens cloud undersides. The storm-cloud lever. Affects
--             -- only the Cumulus and Cumulonimbus layers.
--             BottomOcclusion = 0.0,
--             BottomOcclusionHeight = 0.25,
-- 
--             -- Beer's powder effect: how edges respond to backlighting.
--             BeersPowderIntensity = 0.25,
--             BeersPowderDepth = 100.0,
-- 
--             -- Scattering direction. G < 0 forward, G > 0 backward. Two
--             -- phase functions blended by PhaseBlend, so the pair set the
--             -- rim glow when the sun is behind a cloud.
--             PhaseG = 0.60,
--             PhaseG2 = -0.40,
--             PhaseBlend = 0.50,
-- 
--             -- Multi-scattering approximation. Contribution is the main
--             -- one: raise it to brighten cloud interiors and shadowed
--             -- sides, lower it for darker and more contrasty.
--             MultiScatteringContribution = 0.50,
--             MultiScatteringOcclusion = 0.10,
--             MultiScatteringEccentricity = 0.50,
-- 
--             -- --- COVERAGE: FOUR LAYERS, NOT TWO ----------------------
--             -- The config currently sets only Cumulus and Stratocumulus.
--             -- If a preset has Stratus or Cumulonimbus above zero, turning
--             -- the other two down only thins half the sky.
-- 
--             StratusCoverage = 0.0,
--             StratusCoverageVariation = 0.50,
--             StratusHeightVariation = 0.50,
-- 
--             StratocumulusCoverage = 0.0,
--             StratocumulusCoverageVariation = 0.50,
--             StratocumulusHeightVariation = 0.50,
-- 
--             CumulusCoverage = 0.0,
--             CumulusCoverageVariation = 0.50,
--             CumulusHeightVariation = 0.50,
-- 
--             CumulonimbusCoverage = 0.0,
--             CumulonimbusAnvil = 0.0,
--             CumulonimbusHeightVariation = 0.50,
-- 
--             -- --- DETAIL ----------------------------------------------
--             NoiseShapeIntensityA = 0.500,
--             NoiseShapeIntensityB = 0.625,
--             NoiseShapeIntensityC = 0.250,
--             NoiseShapeIntensityD = 0.125,
--             TurbulenceIntensity = 0.250,
--         },
-- 
--         SunLightSettings = {
--             -- The cleanest brightness dial there is. Scales the sun's
--             -- contribution *only where it scatters inside cloud media*,
--             -- so clouds get brighter or dimmer while the rest of the
--             -- scene is untouched. It is an RGBA colour, not a scalar, so
--             -- it tints as well as scales.
--             CloudScatteredLuminanceScale = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 },
-- 
--             -- How hard clouds block light, split by receiver.
--             CloudShadowStrength = 1.0,
--             CloudShadowOnAtmosphereStrength = 0.50, -- god rays
--             CloudShadowOnSurfaceStrength = 0.90,    -- terrain and meshes
-- 
--             Intensity = 10.0,
--             Temperature = 5500.0,
--             LightColor = { R = 1.0, G = 1.0, B = 0.9, A = 1.0 },
--             VolumetricScatteringIntensity = 1.0,
--             AtmosphereDiskColorScale = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 },
--         },
-- 
--         MoonLightSettings = {
--             -- Same dial for the night side.
--             CloudScatteredLuminanceScale = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 },
--             CloudShadowStrength = 1.0,
--             CloudShadowOnAtmosphereStrength = 0.50,
--             CloudShadowOnSurfaceStrength = 0.90,
-- 
--             Intensity = 0.04,
--             Temperature = 8500.0,
--             LightColor = { R = 0.48, G = 0.74, B = 1.0, A = 1.0 },
--             AtmosphereDiskColorScale = { R = 1.0, G = 0.88, B = 0.4, A = 1.0 },
--         },
-- 
--         SkyLightSettings = {
--             Intensity = 1.0,
-- 
--             -- Seems to be inert on Palworld's build
--             NightIntensity = 4.0,
-- 
--             -- How much clouds darken the ambient beneath them.
--             CloudAmbientOcclusionStrength = 0.25,
-- 
--             LightColor = { R = 1.0, G = 1.0, B = 1.0, A = 1.0 },
--             LowerHemisphereColor = { R = 0.0006, G = 0.0007, B = 0.001, A = 1.0 },
--         },
-- 
--         WindSettings = {
--             -- Moves the cloud map as a rigid pattern.
--             CloudWindDirection = 0.0,
--             CloudWindSpeed = 0.0,
-- 
--             -- Animates the shape noise itself. Stock is 0, and we never
--             -- set it, so our clouds currently slide across the sky without
--             -- evolving. Raise this to make them churn and reform.
--             CloudNoiseShapeWindDirection = 0.0,
--             CloudNoiseShapeWindSpeedHorizontal = 0.0,
-- 
--             -- Already non-zero at stock, giving some vertical detail life.
--             CloudNoiseDetailWindSpeedVertical = 2.0,
-- 
--             PrecipitationWindDirection = 0.0,
--             PrecipitationWindSpeed = 0.0,
--         },
-- 
--         PostProcessSettings = {
--             BloomIntensity = 0.675,
-- 
--             -- -1 means every pixel blooms equally; higher means only
--             -- brighter pixels above the threshold do. Raising this is a
--             -- real cut to bloom, so it is worth being deliberate about.
--             BloomThreshold = -0.40,
-- 
--             ExposureCompensation = 1.0,
--         },
--     },
-- },

-- ============================================================
-- INTERNAL CONFIGURATION
-- Advanced users may edit below. Normal users can stop here.
-- ============================================================

-- Sky clock scrubbing, for tuning presets without waiting out the game clock.
--
-- Enabling this detaches the sky creator's clock driver the first time you
-- step the clock, so the sky stops following the world's time of day until
-- the restore key is pressed or the world is reloaded. Only the sky is
-- affected; quests, spawns and everything else keep running on the game's own
-- clock. Leave this off during normal play.
--
--   Left / Right arrow   step 15 game minutes
--   Up / Down arrow      step 1 game hour
--   RestoreKey           hand the clock back, sky jumps to the real time
--
-- Key names use the same UE4SS reference as Keys above, and like Keys this is
-- only read at startup, so changing it requires a game restart.
Config.TimeScrub = {
    Enabled = false,
    RestoreKey = "PAGE_DOWN",
}

return Config

-- 
-- Copyright 2026 Fr4nsson. All rights reserved.
-- Redistribution or derivative works require written permission.
-- Personal use and private modification of this file are permitted.
-- 
-- ============================================================
-- UltraWeather - UE4SS Lua mod for Palworld by Fr4nsson
--  * Patches PPSC weather preset assets from config.lua, either the unused
--    Sky Creator sample presets or the presets Palworld already uses
--  * Repoints the sky creator's time-of-day schedule and sets its crossfade
--    length, restores the stock array when disabled
--  * Creates the volumetric cloud component Palworld ships without
--  * Interpolates height fog tint across time of day
--  * Overrides the sky creator's post process component, per weather mode
-- Diff-based: only writes values that differ from config.
-- ============================================================

local UEHelpers = require("UEHelpers")

local MOD_NAME = "UltraWeather"
local MOD_VERSION = "1.0.0"
local LOG_PREFIX = "[" .. MOD_NAME .. "] "

local function Log(msg)
    print(LOG_PREFIX .. msg .. "\n")
end

local Cfg = nil
-- Keybinds are read once at startup, so a later config reload must not report
-- a key that was never registered.
local DEFAULT_SYNC_KEY = "F8"
local registeredSyncKey = DEFAULT_SYNC_KEY

local cachedPalUtility = nil
local cachedPlayerController = nil
local cachedInGamePlayerController = nil

-- Never trust a cached/wrapped Unreal object during world streaming or
-- teardown. Even IsValid itself can throw if UE4SS is handed a stale wrapper.
local function IsValidObject(obj)
    if obj == nil then return false end
    local ok, valid = pcall(function() return obj:IsValid() end)
    return ok and valid == true
end

local function SameObject(a, b)
    if not IsValidObject(a) or not IsValidObject(b) then return false end
    local okA, addressA = pcall(function() return a:GetAddress() end)
    local okB, addressB = pcall(function() return b:GetAddress() end)
    return okA and okB and addressA == addressB
end

local function IsLocalPlayerController(pc)
    if not IsValidObject(pc) then return false end

    local ok, isLocal = pcall(function()
        return pc:IsLocalPlayerController()
    end)
    if ok then return isLocal == true end

    -- Compatibility fallback for builds where only the base Controller helper
    -- is reflected.
    ok, isLocal = pcall(function() return pc:IsLocalController() end)
    return ok and isLocal == true
end

-- A controller can remain valid for a short time after map travel. Comparing
-- its world with the viewport world prevents a menu/previous-world controller
-- from being reused just because the UObject wrapper is still valid.
local function IsInCurrentViewportWorld(obj)
    if not IsValidObject(obj) then return false end

    local okViewport, viewport = pcall(UEHelpers.GetGameViewportClient)
    if not okViewport or not IsValidObject(viewport) then
        return true -- no viewport means there is no reliable client-world check
    end

    local okCurrent, currentWorld = pcall(function()
        return viewport:GetWorld()
    end)
    if not okCurrent or not IsValidObject(currentWorld) then return true end

    local okObject, objectWorld = pcall(function() return obj:GetWorld() end)
    if not okObject or not IsValidObject(objectWorld) then return false end

    return SameObject(objectWorld, currentWorld)
end

local function IsUsableLocalPlayerController(pc)
    return IsLocalPlayerController(pc) and IsInCurrentViewportWorld(pc)
end

-- Never use FindFirstOf for controller work: on a listen server it can select
-- another player's controller.
local function GetLocalPlayerController()
    if IsUsableLocalPlayerController(cachedPlayerController) then
        return cachedPlayerController
    end

    cachedPlayerController = nil

    local ok, pc = pcall(UEHelpers.GetPlayerController)
    if ok and IsUsableLocalPlayerController(pc) then
        cachedPlayerController = pc
        return pc
    end

    -- Older UEHelpers versions can return the first PlayerController instead
    -- of the local one, so explicitly scan all controllers as a fallback.
    local okAll, controllers = pcall(FindAllOf, "PlayerController")
    if okAll and type(controllers) == "table" then
        for _, candidate in ipairs(controllers) do
            if IsUsableLocalPlayerController(candidate) then
                cachedPlayerController = candidate
                return candidate
            end
        end
    end

    return nil
end

local function GetObjectFullName(obj)
    if not IsValidObject(obj) then return nil end
    local okName, fullName = pcall(function() return obj:GetFullName() end)
    if not okName then return nil end
    return tostring(fullName)
end

local function IsPalInGamePlayerController(pc)
    if not IsUsableLocalPlayerController(pc) then return false end
    local fullName = GetObjectFullName(pc)
    return fullName ~= nil
        and fullName:find("BP_PalPlayerController_C /Game/Pal/Maps", 1, true)
            ~= nil
end

local function IsPalTitlePlayerController(pc)
    if not IsUsableLocalPlayerController(pc) then return false end
    local fullName = GetObjectFullName(pc)
    return fullName ~= nil
        and fullName:find(
            "BP_PalPlayerController_Title_C /Game/Pal/Maps", 1, true)
            ~= nil
end

-- Gameplay-only local controller accessor. The class does not exist in the
-- main menu, and IsLocalPlayerController keeps this safe for clients and
-- listen-server hosts in multiplayer.
local function GetLocalInGamePlayerController()
    if IsPalInGamePlayerController(cachedInGamePlayerController) then
        return cachedInGamePlayerController
    end

    cachedInGamePlayerController = nil

    local pc = GetLocalPlayerController()
    if IsPalInGamePlayerController(pc) then
        cachedInGamePlayerController = pc
        return pc
    end

    -- The generic local controller is authoritative on the title screen. Do
    -- not scan for an absent gameplay-controller class every pump tick.
    if IsPalTitlePlayerController(pc) then return nil end

    local okAll, controllers = pcall(FindAllOf, "BP_PalPlayerController_C")
    if okAll and type(controllers) == "table" then
        for _, candidate in ipairs(controllers) do
            if IsPalInGamePlayerController(candidate) then
                cachedPlayerController = candidate
                cachedInGamePlayerController = candidate
                return candidate
            end
        end
    end

    return nil
end

-- --------------------------------------------------------------------------
-- Config error popup
--
-- PalUtility.Alert works in UE4SS Live View because Live View temporarily
-- marks the UFunction as FUNC_Exec and invokes it through ProcessConsoleExec.
-- Calling Alert directly from Lua uses UE4SS's reflected parameter marshaller,
-- which can crash on native string parameters in some UE4SS builds. Reproduce
-- Live View's console-exec path instead of directly invoking palUtility:Alert.
-- --------------------------------------------------------------------------
local FUNC_EXEC = 0x00000200

local function GetPalUtility()
    if IsValidObject(cachedPalUtility) then return cachedPalUtility end
    cachedPalUtility = StaticFindObject("/Script/Pal.Default__PalUtility")
    if IsValidObject(cachedPalUtility) then return cachedPalUtility end
    cachedPalUtility = nil
    return nil
end

local function PrepareAlertConsoleMessage(message)
    message = tostring(message or ""):gsub("%z", "")
    message = message:gsub("\r\n", "\n"):gsub("\r", "\n")

    -- Keep real LF characters inside the quoted FString argument. Unreal's
    -- exec parser reads the complete quoted token, so the Alert widget
    -- receives the line breaks.
    message = message:gsub("\t", "    ")
    message = message:gsub('"', "'")
    message = message:gsub("[ ]+\n", "\n")
    if #message > 2048 then
        message = message:sub(1, 2045) .. "..."
    end
    return message
end

local function ShowPalAlertViaConsole(worldContextObject, message)
    if not IsUsableLocalPlayerController(worldContextObject) then
        return false, "world context controller unavailable"
    end

    local palUtility = GetPalUtility()
    if not IsValidObject(palUtility) then
        return false, "PalUtility CDO unavailable"
    end

    local fullName = GetObjectFullName(worldContextObject)
    local contextName = fullName and fullName:match("^%S+%s+(.+)$")
    if contextName == nil or contextName == "" then
        return false, "could not resolve controller object name"
    end

    local okFunction, alertFunction = pcall(function()
        return palUtility.Alert
    end)
    if not okFunction or alertFunction == nil then
        return false, "PalUtility.Alert UFunction unavailable"
    end

    local okFlags, oldFlags = pcall(function()
        return alertFunction:GetFunctionFlags()
    end)
    if not okFlags or type(oldFlags) ~= "number" then
        return false, "could not read Alert function flags"
    end

    local command = 'Alert ' .. contextName .. ' "'
        .. PrepareAlertConsoleMessage(message) .. '"'

    -- FUNC_Exec is a power-of-two flag. Use arithmetic rather than Lua's
    -- bitwise syntax so this remains parseable on older UE4SS Lua builds.
    local execFlags = oldFlags
    if math.floor(oldFlags / FUNC_EXEC) % 2 == 0 then
        execFlags = oldFlags + FUNC_EXEC
    end

    local setOk, setErr = pcall(function()
        alertFunction:SetFunctionFlags(execFlags)
    end)
    if not setOk then
        return false, "could not enable FUNC_Exec: " .. tostring(setErr)
    end

    -- Live View's "WorldContextObject" mode passes nullptr as the console
    -- executor. UE4SS's Lua overload requires an UObject value and rejects
    -- literal nil, so CreateInvalidObject() is used as the Lua representation
    -- of a null UObject pointer. Do not pass worldContextObject here: that
    -- would reproduce Live View's crashing "Implicit" mode instead.
    if type(CreateInvalidObject) ~= "function" then
        pcall(function() alertFunction:SetFunctionFlags(oldFlags) end)
        return false, "CreateInvalidObject is unavailable in this UE4SS build"
    end

    local nullExecutor = CreateInvalidObject()
    if nullExecutor == nil then
        pcall(function() alertFunction:SetFunctionFlags(oldFlags) end)
        return false, "could not create null UObject executor"
    end

    local callOk, callResult = pcall(function()
        return palUtility:ProcessConsoleExec(command, nil, nullExecutor)
    end)

    local restoreOk, restoreErr = pcall(function()
        alertFunction:SetFunctionFlags(oldFlags)
    end)
    if not restoreOk then
        Log("WARN: failed restoring Alert flags: " .. tostring(restoreErr))
    end

    if not callOk then return false, tostring(callResult) end
    if callResult ~= true then
        return false, "ProcessConsoleExec returned false"
    end
    return true
end

local function GetConfigErrorAlertMessage()
    local prefix = "<Warning>" .. MOD_NAME
        .. " failed to load config.lua.</>\n\n"
        .. "Check UE4SS.log for the error, then fix config.lua. "

    local displayed = registeredSyncKey == "INS" and "INSERT" or registeredSyncKey
    if type(displayed) == "string" and displayed ~= "" then
        return prefix .. "After saving your changes, press <Blue_16>"
            .. displayed .. "</> to reload the configuration."
    end

    return prefix .. "The sync key is disabled, so restart the game "
        .. "after fixing the file."
end

local function ShowConfigErrorAlert()
    local pc = GetLocalInGamePlayerController()
    if not IsPalInGamePlayerController(pc) then
        return false, "gameplay controller unavailable"
    end
    return ShowPalAlertViaConsole(pc, GetConfigErrorAlertMessage())
end

-- --------------------------------------------------------------------------
-- Config
-- --------------------------------------------------------------------------

-- config.lua lives next to the Scripts folder, resolve it relative to this
-- file so every install layout works (Win64/Mods, ue4ss/Mods, Steam Workshop
-- NativeMods, symlinked Linux/Proton setups, renamed mod folders). NOTE: keep
-- exact file casing, native-Linux UE4SS runs on case-sensitive filesystems.
local ConfigPath = debug.getinfo(1, "S").source
    :match("@?(.*[/\\])") .. "../config.lua"

local function LoadConfig()
    local chunk, err = loadfile(ConfigPath)
    if not chunk then
        local message = "cannot open or compile config.lua ("
            .. tostring(err) .. ")"
        Log("ERROR: " .. message)
        return nil, message
    end

    local ok, cfg = pcall(chunk)
    if not ok then
        local message = "runtime error in config.lua (" .. tostring(cfg) .. ")"
        Log("ERROR: " .. message)
        return nil, message
    end
    if type(cfg) ~= "table" then
        local message = "config.lua must return a table, got " .. type(cfg)
        Log("ERROR: " .. message)
        return nil, message
    end
    return cfg, nil
end

-- 0 = warnings only, 1 = info, 2 = debug
local function Lvl()
    return tonumber((Cfg or {}).LogLevel) or 0
end

-- --------------------------------------------------------------------------
-- Shared helpers
-- --------------------------------------------------------------------------

-- Runs callback on the game thread after delayMs. Used by the fog tint pump,
-- which touches UObjects and therefore cannot run on a LoopAsync worker.
local function ScheduleOnGameThread(delayMs, callback)
    if type(ExecuteInGameThreadWithDelay) == "function" then
        local ok = pcall(function()
            ExecuteInGameThreadWithDelay(delayMs, callback)
        end)
        if ok then return true end
    end

    if type(ExecuteWithDelay) == "function" then
        local ok = pcall(function()
            ExecuteWithDelay(delayMs, function()
                local queued = pcall(function()
                    ExecuteInGameThread(callback)
                end)
                if not queued then callback() end
            end)
        end)
        if ok then return true end
    end

    return false
end

local function FindOrLoadAsset(assetPath)
    if not assetPath:find("%.") then
        assetPath = assetPath .. "." .. assetPath:match("([^/]+)$")
    end
    local obj = StaticFindObject(assetPath)
    if IsValidObject(obj) then return obj end
    local ok, loaded = pcall(LoadAsset, assetPath)
    if ok and IsValidObject(loaded) then return loaded end
    return nil
end

local function IsEnabled(section)
    return type(section) == "table" and section.Enabled ~= false
end

-- ===========================================================================
-- SKY AND WEATHER
-- ===========================================================================
local W = {
    -- Set from Config.TimeScrub at startup. Detaches the sky creator's clock
    -- driver, so this stays false until the config explicitly enables it.
    TimeScrub = false,

    Snapshot = nil,        -- base captured from UltraWeather.InheritFrom
    Original = nil,        -- stock schedule contents, per controller
    Restored = nil,        -- latch so a disabled sync restores only once
    StockSnapshot = nil,   -- stock values of every preset VanillaPlus edits
    StockRestored = nil,
    Sky = nil,             -- cached sky actor
    FogLoop = false,
    FogGen = 0,

    -- Blueprint property names, GUID suffixes and spaces included.
    PRESET_FIELD = "WeatherPreset_7_B173F3074E77F47BFAED839E1A55A226",
    TIME_FIELD = "Time_2_42BBD1624B3A7C0FC962D685060B487F",
    ARRAY_FIELD = "Weather Presets",
    INTERP_FIELD = "Interpolation Duration",
    CLOCK_FIELD = "SkyCreatorTarget",
    FOG_FIELD = "ExponentialHeightFog",
    TINT_FIELD = "InscatteringTextureTint",

    CONTROLLER = "BP_PPSkyCreatorWeatherPresetController_C",
    CLOCK_CLASS = "BP_PPSkyCreator_Controller_C",
    SKY_CLASS = "BP_PalSkyCreator_C",
    CLOUD_CLASS = "/Script/Engine.VolumetricCloudComponent",

    -- Property types worth copying out of the base asset. Containers are
    -- excluded: UE4SS cannot resize a TArray and a partial copy is worse
    -- than none.
    LEAF = {
        FloatProperty = true, DoubleProperty = true, IntProperty = true,
        Int8Property = true, Int16Property = true, Int64Property = true,
        UInt16Property = true, UInt32Property = true, UInt64Property = true,
        ByteProperty = true, BoolProperty = true, EnumProperty = true,
        StrProperty = true, NameProperty = true,
    },
    REF = {
        ObjectProperty = true, ObjectPtrProperty = true,
        SoftObjectProperty = true, ClassProperty = true,
        SoftClassProperty = true, WeakObjectProperty = true,
        LazyObjectProperty = true, InterfaceProperty = true,
    },

    CLOUD_QUALITY = {
        "ViewSampleCountScale", "ShadowViewSampleCountScale",
        "ReflectionSampleCountScale", "ShadowReflectionSampleCountScale",
        "ShadowTracingDistance", "TracingMaxDistance",
        "TracingStartMaxDistance",
    },
}

-- --------------------------------------------------------------------------
-- Object helpers
-- --------------------------------------------------------------------------

function W.Get(obj, key)
    local ok, v = pcall(function() return obj[key] end)
    if not ok then return nil end
    return v
end

function W.Set(obj, key, value)
    return (pcall(function() obj[key] = value end))
end

-- Never type-check before calling: real UFunctions are userdata with a call
-- metamethod, so type(fn) == "function" is false for them. Unresolvable names
-- return a placeholder that errors when called.
function W.TryCall(obj, name, ...)
    local args = table.pack(...)
    local ok = pcall(function()
        return obj[name](obj, table.unpack(args, 1, args.n))
    end)
    return ok
end

function W.RefName(v)
    if type(v) ~= "userdata" then return tostring(v) end
    local ok, name = pcall(function() return v:GetFullName() end)
    return ok and name or tostring(v)
end

function W.KeyOf(actor)
    local ok, full = pcall(function() return actor:GetFullName() end)
    if ok and type(full) == "string" and full ~= "" then return full end
    return "__controller"
end

function W.PathOf(obj)
    if obj == nil then return nil end
    local ok, full = pcall(function() return obj:GetFullName() end)
    if not ok or type(full) ~= "string" then return nil end
    return full:match("^%S+%s+(.+)$")
end

-- FindAllOf can return the class default object; writing to it does nothing
-- in the live world.
function W.LiveInstances(className)
    local ok, list = pcall(FindAllOf, className)
    if not ok or type(list) ~= "table" then return {} end
    local out = {}
    for _, obj in ipairs(list) do
        if IsValidObject(obj)
                and not tostring(W.RefName(obj)):find("Default__") then
            out[#out + 1] = obj
        end
    end
    return out
end

function W.Controllers()
    return W.LiveInstances(W.CONTROLLER)
end

-- Re-verify rather than trusting the cache: a level load leaves a stale
-- wrapper behind and writing through one crashes the process.
function W.SkyActor()
    if W.Sky ~= nil then
        local ok, full = pcall(function() return W.Sky:GetFullName() end)
        if ok and type(full) == "string" and IsValidObject(W.Sky) then
            return W.Sky
        end
        W.Sky = nil
    end
    W.Sky = W.LiveInstances(W.SKY_CLASS)[1]
    return W.Sky
end

-- --------------------------------------------------------------------------
-- Diffing
-- --------------------------------------------------------------------------

local function ValuesEqual(current, desired)
    if type(desired) == "number" and type(current) == "number" then
        local scale = math.max(math.abs(desired), 1.0)
        return math.abs(current - desired) <= 0.0001 * scale
    end
    if type(desired) == "boolean" then
        -- UE returns bitfield bools as 0/1 in some paths
        if type(current) == "number" then current = current ~= 0 end
        return current == desired
    end
    -- Object refs (curves, materials) arrive as userdata whose tostring is not
    -- stable between reads, so compare by path instead.
    if type(desired) == "userdata" or type(current) == "userdata" then
        return W.RefName(current) == W.RefName(desired)
    end
    return tostring(current) == tostring(desired)
end

-- Walks settings, nested tables descend into structs, leaves are compared and
-- only written when they differ. Returns change count.
local function ApplyDiff(target, settings, path, debug, allowSetter)
    local changed = 0
    for key, desired in pairs(settings) do
        local propPath = path .. "." .. key
        if type(desired) == "table" then
            local ok, child = pcall(function() return target[key] end)
            if ok and child ~= nil then
                -- Nested values are UScriptStructs. Never try Set<Name> on
                -- them: UE4SS UFunctions require a UObject context.
                changed = changed
                    + ApplyDiff(child, desired, propPath, debug, false)
            else
                Log(("WARN: failed to set %s (property not found)")
                    :format(propPath))
            end
        else
            local ok, current = pcall(function() return target[key] end)
            if ok and not ValuesEqual(current, desired) then
                local okSet, err = pcall(function() target[key] = desired end)
                if okSet then
                    -- bitfield bools can "succeed" without sticking, verify by
                    -- reading the value back
                    local okR, now = pcall(function() return target[key] end)
                    if okR and not ValuesEqual(now, desired) then
                        okSet = false
                        err = "direct write did not stick"
                    end
                end
                if not okSet and allowSetter and IsValidObject(target) then
                    local okFn, setter = pcall(function()
                        return target["Set" .. key]
                    end)
                    if okFn and setter ~= nil then
                        local okCall, callErr = pcall(function()
                            setter(target, desired)
                        end)
                        okSet = okCall
                        if not okCall then err = callErr end
                    end
                end
                if okSet then
                    changed = changed + 1
                    if debug then
                        Log(("set %s: %s -> %s"):format(
                            propPath, tostring(current), tostring(desired)))
                    end
                else
                    Log(("WARN: failed to set %s (%s)")
                        :format(propPath, tostring(err)))
                end
            elseif not ok then
                Log(("WARN: failed to set %s (property not readable)")
                    :format(propPath))
            end
        end
    end
    return changed
end

-- Deltas win over the base. Tables merge, everything else replaces.
function W.Merge(base, over)
    local out = {}
    for k, v in pairs(base or {}) do
        out[k] = (type(v) == "table") and W.Merge(v, nil) or v
    end
    for k, v in pairs(over or {}) do
        if type(v) == "table" and type(out[k]) == "table" then
            out[k] = W.Merge(out[k], v)
        else
            out[k] = v
        end
    end
    return out
end

-- --------------------------------------------------------------------------
-- Base snapshot
--
-- Preset assets are patched in place, so a pristine copy of the base is taken
-- once per session before anything is written. Capturing later would read a
-- base that earlier syncs had already edited.
-- --------------------------------------------------------------------------

function W.PropType(prop)
    local ok, cls = pcall(function() return prop:GetClass() end)
    if ok and cls then
        local okName, name = pcall(function()
            return cls:GetFName():ToString()
        end)
        if okName and name and name ~= "" then return name end
    end
    local okFull, full = pcall(function() return prop:GetFullName() end)
    return okFull and full and full:match("^(%a+Property)") or nil
end

function W.StructOf(prop, value)
    local ok, s = pcall(function() return prop:GetStruct() end)
    if ok and s then return s end
    local okC, c = pcall(function() return value:GetClass() end)
    return okC and c or nil
end

function W.Capture(container, struct, depth)
    depth = depth or 0
    if depth > 4 then return nil end
    local out, count = {}, 0
    local walked = pcall(function()
        struct:ForEachProperty(function(prop)
            local okName, name = pcall(function()
                return prop:GetFName():ToString()
            end)
            if not okName or not name then return end
            local ptype = W.PropType(prop)
            if not ptype then return end
            local okRead, value = pcall(function() return container[name] end)
            if not okRead or value == nil then return end

            if W.LEAF[ptype] then
                local vt = type(value)
                if vt == "number" or vt == "boolean" or vt == "string" then
                    out[name] = value
                    count = count + 1
                else
                    local okStr, str = pcall(function()
                        return value:ToString()
                    end)
                    if okStr and str then out[name] = str count = count + 1 end
                end
            elseif W.REF[ptype] then
                out[name] = value
                count = count + 1
            elseif ptype == "StructProperty" then
                local inner = W.StructOf(prop, value)
                local child = inner and W.Capture(value, inner, depth + 1)
                if child and next(child) then
                    out[name] = child
                    count = count + 1
                end
            end
        end)
    end)
    if not walked or count == 0 then return nil end
    return out
end

function W.CaptureBase(assetPath, lvl)
    local base = FindOrLoadAsset(assetPath)
    if not base then
        Log("WARN: weather base not found: " .. tostring(assetPath))
        return nil
    end
    local okCls, cls = pcall(function() return base:GetClass() end)
    if not okCls or not cls then
        Log("WARN: weather base has no reflected class")
        return nil
    end
    local snap = W.Capture(base, cls, 0)
    if not snap then
        Log("WARN: weather base snapshot failed; presets will use their own "
            .. "Settings only")
        return nil
    end
    if lvl >= 1 then
        local n = 0
        for _ in pairs(snap) do n = n + 1 end
        Log(("Captured weather base from %s (%d property groups)")
            :format(tostring(assetPath), n))
    end
    return snap
end

-- --------------------------------------------------------------------------
-- Stock preset snapshot
--
-- VanillaPlus edits assets the game itself uses, so the pre-mod value of
-- every property the config touches is kept and can be written back when the
-- mode changes or the feature is switched off. Values already recorded are
-- never overwritten, because by then they hold this mod's own output.
-- --------------------------------------------------------------------------

function W.CaptureShape(target, settings, depth)
    depth = depth or 0
    if depth > 4 then return nil end
    local out = nil
    for key, desired in pairs(settings) do
        local ok, current = pcall(function() return target[key] end)
        if ok and current ~= nil then
            if type(desired) == "table" then
                local child = W.CaptureShape(current, desired, depth + 1)
                if child then
                    out = out or {}
                    out[key] = child
                end
            else
                local vt = type(current)
                if vt == "number" or vt == "boolean" or vt == "string" then
                    out = out or {}
                    out[key] = current
                end
            end
        end
    end
    return out
end

function W.RememberStock(assetPath, asset, settings)
    local snap = W.CaptureShape(asset, settings)
    if not snap then return end
    W.StockSnapshot = W.StockSnapshot or {}
    local prior = W.StockSnapshot[assetPath]
    -- prior wins, so only newly configured properties are added
    W.StockSnapshot[assetPath] = prior and W.Merge(snap, prior) or snap
end

function W.RestoreStock(lvl)
    if not W.StockSnapshot or W.StockRestored then return false end
    local total = 0
    for assetPath, snap in pairs(W.StockSnapshot) do
        local asset = FindOrLoadAsset(assetPath)
        if asset then
            total = total
                + ApplyDiff(asset, snap, "restore", lvl >= 2, true)
        end
    end
    W.StockRestored = true
    if total > 0 and lvl >= 1 then
        Log(("Restored %d value(s) on Palworld's own weather presets")
            :format(total))
    end
    return total > 0
end

-- --------------------------------------------------------------------------
-- Schedule
--
-- The controller holds a five-entry array of {Time, WeatherPreset}. Entries
-- are repointed at the configured assets.
--
-- Five is this mod's limit, not the engine's: UE4SS can rewrite TArray entries
-- but not resize one. More slots would need a pak mod editing the controller
-- blueprint.
-- --------------------------------------------------------------------------

-- Record a slot's stock contents the first time it is touched, so switching
-- mode or disabling the feature can put the vanilla sky back without a
-- restart.
function W.RememberSlot(key, index, entry)
    W.Original = W.Original or {}
    local store = W.Original[key]
    if not store then
        store = {}
        W.Original[key] = store
    end
    if store[index] ~= nil then return end
    local ok, time, preset = pcall(function()
        return entry[W.TIME_FIELD], entry[W.PRESET_FIELD]
    end)
    if not ok then return end
    store[index] = {
        Time = time,
        Preset = preset,
        Path = W.PathOf(preset),
    }
end

function W.ApplySchedule(schedule, resolved, lvl)
    local controllers = W.Controllers()
    if #controllers == 0 then
        Log("WARN: no live " .. W.CONTROLLER .. ", schedule skipped")
        return
    end
    W.Restored = nil

    for _, actor in ipairs(controllers) do
        local okArr, arr = pcall(function() return actor[W.ARRAY_FIELD] end)
        if not okArr or not arr then
            Log("WARN: could not read '" .. W.ARRAY_FIELD .. "'")
        else
            local key = W.KeyOf(actor)
            local slots = 0
            local okNum, num = pcall(function() return arr:GetArrayNum() end)
            if okNum and type(num) == "number" then slots = num end

            local function WriteSlot(index, entry)
                W.RememberSlot(key, index, entry)
                local slot = schedule[index]
                if not slot then return end
                local target = resolved[slot.Preset]
                if not target then
                    Log(("WARN: schedule slot %d names unknown preset '%s'")
                        :format(index, tostring(slot.Preset)))
                    return
                end
                local okWrite, err = pcall(function()
                    if slot.Time ~= nil then
                        entry[W.TIME_FIELD] = slot.Time
                    end
                    entry[W.PRESET_FIELD] = target
                end)
                if not okWrite then
                    Log(("WARN: slot %d write failed: %s")
                        :format(index, tostring(err)))
                elseif lvl >= 2 then
                    Log(("slot %d -> %s @ %s"):format(
                        index, slot.Preset, tostring(slot.Time)))
                end
            end

            local okEach = pcall(function()
                arr:ForEach(function(index, elem)
                    WriteSlot(index, elem:get())
                end)
            end)
            if not okEach and slots > 0 then
                for index = 1, slots do
                    local okGet, entry = pcall(function() return arr[index] end)
                    if okGet and entry then WriteSlot(index, entry) end
                end
            end

            if #schedule > slots and slots > 0 then
                Log(("WARN: schedule has %d entries but the array holds %d; "
                    .. "extras ignored. UE4SS cannot resize a TArray, so more "
                    .. "slots need a pak mod editing the controller.")
                    :format(#schedule, slots))
            end
            if lvl >= 1 then
                Log(("Repointed %d weather slot(s)")
                    :format(math.min(#schedule, math.max(slots, 0))))
            end
        end
    end
end

-- Leaving UltraWeather mode stops further writes but leaves the array pointing
-- at the sample assets, so stock skies need an explicit repoint back.
function W.RestoreSchedule(lvl)
    if not W.Original or W.Restored then return false end
    local total = 0
    for _, actor in ipairs(W.Controllers()) do
        local store = W.Original[W.KeyOf(actor)]
        local okArr, arr = pcall(function() return actor[W.ARRAY_FIELD] end)
        if store and okArr and arr then
            local function Put(index, entry)
                local saved = store[index]
                if not saved then return end
                -- Prefer re-resolving by path: nothing has referenced the
                -- stock presets since the repoint, so they may have been
                -- unloaded and the saved wrapper gone stale.
                local target = saved.Path and FindOrLoadAsset(saved.Path)
                    or saved.Preset
                if not target then return end
                if pcall(function()
                    if saved.Time ~= nil then
                        entry[W.TIME_FIELD] = saved.Time
                    end
                    entry[W.PRESET_FIELD] = target
                end) then
                    total = total + 1
                end
            end

            local okEach = pcall(function()
                arr:ForEach(function(index, elem) Put(index, elem:get()) end)
            end)
            if not okEach then
                local okNum, num = pcall(function()
                    return arr:GetArrayNum()
                end)
                for index = 1, (okNum and num or 0) do
                    local okGet, entry = pcall(function() return arr[index] end)
                    if okGet and entry then Put(index, entry) end
                end
            end
        end
    end
    if total > 0 then
        W.Restored = true
        if lvl >= 1 then
            Log(("Restored %d weather slot(s) to stock assets"):format(total))
        end
    end
    return total > 0
end

-- --------------------------------------------------------------------------
-- Crossfade
--
-- Interpolation Duration is in GAME MINUTES and the fade ENDS at the slot
-- time, so 120 starts the fade into a 23:06 slot at 21:06. It must be smaller
-- than the gap before each slot or fades overlap and a preset never fully
-- arrives.
-- --------------------------------------------------------------------------

function W.SmallestGap(schedule)
    if type(schedule) ~= "table" or #schedule < 2 then return nil end
    local worst
    for i = 2, #schedule do
        -- Same preset either side means an overlap is invisible.
        if schedule[i].Preset ~= schedule[i - 1].Preset then
            local gap = (schedule[i].Time or 0) - (schedule[i - 1].Time or 0)
            if gap > 0 and (not worst or gap < worst) then worst = gap end
        end
    end
    return worst
end

function W.ApplyInterpolation(minutes, schedule, lvl)
    local mins = tonumber(minutes)
    if not mins then return end

    local gap = W.SmallestGap(schedule)
    if gap and mins >= gap * 60 then
        Log(("WARN: InterpolationMinutes %d is at or above the smallest slot "
            .. "gap of %d minutes. Fades will overlap and presets will not "
            .. "fully arrive."):format(mins, math.floor(gap * 60)))
    end

    for _, actor in ipairs(W.Controllers()) do
        local okRead, prev = pcall(function() return actor[W.INTERP_FIELD] end)
        if not W.Set(actor, W.INTERP_FIELD, mins) then
            Log("WARN: could not set " .. W.INTERP_FIELD)
        elseif lvl >= 1 then
            Log(("Preset crossfade %s -> %d game minutes%s")
                :format(okRead and tostring(prev) or "?", mins,
                    gap and (" (max %d)"):format(math.floor(gap * 60) - 1)
                        or ""))
        end
    end
end

-- --------------------------------------------------------------------------
-- Volumetric clouds
--
-- Palworld ships bUseVolumetricCloud = false with no VolumetricCloud
-- component, so the plugin never creates one and the cloud path stays dormant.
-- Everything else is already built at BeginPlay: the material variant, its
-- dynamic instance, the density render target and the parameter collection.
-- Adding the component and handing it to the plugin activates the rest,
-- including sun cloud shadows driven from the active preset.
-- --------------------------------------------------------------------------

function W.EnableClouds(weather, lvl)
    local opts = weather and weather.VolumetricClouds
    if not IsEnabled(opts) then return false end

    local actor = W.SkyActor()
    if not IsValidObject(actor) then return false end

    -- The component renders nothing while r.VolumetricCloud is 0, which other
    -- mods or a user Engine.ini can leave disabled.
    if opts.ForceCVar ~= false then
        local pc = GetLocalInGamePlayerController()
        if IsValidObject(pc) then
            pcall(function() pc:SendToConsole("r.VolumetricCloud 1") end)
        end
    end

    local comp = W.Get(actor, "VolumetricCloud")
    if not IsValidObject(comp) then
        local cls = StaticFindObject(W.CLOUD_CLASS)
        if not IsValidObject(cls) then
            Log("WARN: " .. W.CLOUD_CLASS .. " not reflected")
            return false
        end

        -- bDeferredFinish = false, so this registers the component too.
        -- RegisterComponent itself is not callable in UE4SS 3.0.1.
        local okAdd
        okAdd, comp = pcall(function()
            return actor:AddComponentByClass(cls, false, {
                Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 },
                Translation = { X = 0.0, Y = 0.0, Z = 0.0 },
                Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
            }, false)
        end)
        if type(comp) == "userdata" then
            local okInner, inner = pcall(function() return comp:get() end)
            if okInner and inner ~= nil then comp = inner end
        end
        if not okAdd or not IsValidObject(comp) then
            Log("WARN: could not create VolumetricCloudComponent")
            return false
        end

        -- The plugin already selected a material variant matching its own bool
        -- state and built a dynamic instance from it.
        local mat = W.Get(actor, "VolumetricCloudMID")
        if not IsValidObject(mat) then
            mat = W.Get(actor, "CurrentVolumetricCloudMaterial")
        end
        if IsValidObject(mat) then
            W.Set(comp, "Material", mat)
        else
            Log("WARN: no cloud material on the sky actor")
        end

        for _, k in ipairs({ "LayerBottomAltitude", "LayerHeight" }) do
            local v = W.Get(actor, k)
            if type(v) == "number" then W.Set(comp, k, v) end
        end

        if lvl >= 1 then Log("Created VolumetricCloudComponent") end
    end

    -- Palworld ships low cloud sampling because clouds were disabled. The
    -- plugin pushes these from the actor onto the component every frame, so
    -- the actor is the authoritative place to set them.
    for _, k in ipairs(W.CLOUD_QUALITY) do
        local want = tonumber(opts[k])
        if want then
            W.Set(actor, k, want)
            W.Set(comp, k, want)
        end
    end

    if opts.AmbientOcclusion ~= nil then
        W.Set(actor, "bCloudAmbientOcclusion",
            opts.AmbientOcclusion and true or false)
    end

    -- While bIndependentWindControl is true the actor overrides the preset's
    -- WindSettings with its own editor values.
    if opts.PresetWind ~= false then
        W.Set(actor, "bIndependentWindControl", false)
    end

    if not W.TryCall(comp, "SetVisibility", true, false) then
        W.Set(comp, "bVisible", true)
    end
    W.Set(actor, "VolumetricCloud", comp)
    W.Set(actor, "bUseVolumetricCloud", true)
    W.CloudsOn = true
    return true
end

-- Only meaningful once this mod has switched clouds on: Palworld never
-- creates the component itself, so there is nothing to hide otherwise.
function W.DisableClouds()
    if not W.CloudsOn then return false end
    W.CloudsOn = false

    local actor = W.SkyActor()
    if not IsValidObject(actor) then return false end

    local comp = W.Get(actor, "VolumetricCloud")
    if IsValidObject(comp) then
        if not W.TryCall(comp, "SetVisibility", false, false) then
            W.Set(comp, "bVisible", false)
        end
    end
    W.Set(actor, "bUseVolumetricCloud", false)
    return true
end

-- --------------------------------------------------------------------------
-- Background clouds
--
-- The painted layers drawn on the sky sphere, behind the volumetric clouds.
-- Intensity, tint and the layer mix are preset fields and live in each
-- preset's BackgroundCloudSettings. The three values below are sky-actor
-- properties instead, so they cannot vary per time of day.
-- --------------------------------------------------------------------------

W.BACKGROUND_CLOUD_KEYS = {
    "BackgroundCloudsContrast",
    "BackgroundCloudsReflectionScale",
    "BackgroundCloudsRotation",
}

function W.ApplyBackgroundClouds(weather, lvl)
    local opts = weather and weather.BackgroundClouds
    if not IsEnabled(opts) then return false end

    local actor = W.SkyActor()
    if not IsValidObject(actor) then return false end

    local changed = 0
    for _, key in ipairs(W.BACKGROUND_CLOUD_KEYS) do
        local want = tonumber(opts[key])
        if want then
            local current = W.Get(actor, key)
            if type(current) ~= "number" then
                -- Warn rather than fail silently: unlike the preset struct,
                -- these names are taken from the plugin's documented display
                -- names and may differ on Palworld's build.
                W.BackgroundWarned = W.BackgroundWarned or {}
                if not W.BackgroundWarned[key] then
                    W.BackgroundWarned[key] = true
                    Log(("WARN: %s is not a readable number on %s")
                        :format(key, W.SKY_CLASS))
                end
            elseif not ValuesEqual(current, want)
                    and W.Set(actor, key, want) then
                changed = changed + 1
                if lvl >= 2 then
                    Log(("set %s: %s -> %s")
                        :format(key, tostring(current), tostring(want)))
                end
            end
        end
    end

    if changed > 0 and lvl >= 1 then
        Log(("Patched %d background cloud setting(s)"):format(changed))
    end
    return changed > 0
end

-- --------------------------------------------------------------------------
-- Fog tint
--
-- Palworld's fog component runs in cubemap mode: colour is
-- InscatteringColorCubemap x InscatteringTextureTint, and the colour fields
-- inside ExponentialHeightFogSettings are ignored. The tint is a component
-- property rather than a preset field, so the plugin's blend cannot carry it
-- and it is interpolated here using the same model as the engine crossfade.
--
-- No render-state call is needed: the plugin rewrites fog density every frame
-- and Unreal rebuilds the fog scene info as a unit.
-- --------------------------------------------------------------------------

function W.ValidTint(colors, name)
    local t = name and colors[name]
    if type(t) == "table" and type(t.R) == "number"
            and type(t.G) == "number" and type(t.B) == "number" then
        return t
    end
    W.TintWarned = W.TintWarned or {}
    if name and not W.TintWarned[name] then
        W.TintWarned[name] = true
        Log(("WARN: FogTint.Colors.%s is %s - needs numeric R, G and B")
            :format(tostring(name), t == nil and "missing" or "malformed"))
    end
    return nil
end

-- Hold the current slot's tint, then crossfade over the final `dur` game-hours
-- so the new tint lands exactly on the slot time.
function W.TintAt(schedule, colors, tod, dur)
    local n = #schedule
    if n == 0 then return nil end

    local nextIdx, nextT
    for i = 1, n do
        local t = schedule[i].Time or 0
        if t > tod then nextIdx, nextT = i, t break end
    end
    if not nextIdx then
        nextIdx, nextT = 1, (schedule[1].Time or 0) + 24.0
    end
    local curIdx = nextIdx - 1
    if curIdx < 1 then curIdx = n end

    local from = W.ValidTint(colors, schedule[curIdx].Color)
    local to = W.ValidTint(colors, schedule[nextIdx].Color)
    if not from and not to then return nil end
    from = from or to
    to = to or from

    local a = 0.0
    if dur and dur > 0 then
        a = math.max(0.0, math.min(1.0, (tod - (nextT - dur)) / dur))
    end
    return from.R + (to.R - from.R) * a,
        from.G + (to.G - from.G) * a,
        from.B + (to.B - from.B) * a
end

-- Merges FogTint.Modes[mode] over the shared FogTint values, so each weather
-- mode can have its own tint or none at all.
function W.ResolveFogTint(weather, mode)
    local base = weather and weather.FogTint
    if type(base) ~= "table" then return nil end

    local modeEntry = mode and (base.Modes or {})[mode]
    if type(modeEntry) ~= "table" then return base end

    local out = W.Merge(base, modeEntry)
    out.Modes = nil
    -- A schedule is an ordered list, so an override replaces it outright
    -- instead of merging entry by entry.
    if modeEntry.Schedule then out.Schedule = modeEntry.Schedule end
    return out
end

-- The tint is a component property this mod overwrites, so switching the
-- feature off has to put the original back. Without this, disabling fog tint
-- only stops further writes and the last colour written stays on the fog for
-- the rest of the session.
function W.RestoreFogTint(lvl)
    local stock = W.FogTintStock
    if stock == nil then return false end

    local actor = W.SkyActor()
    if not IsValidObject(actor) then return false end
    local fog = W.Get(actor, W.FOG_FIELD)
    if not IsValidObject(fog) then return false end
    if not W.Set(fog, W.TINT_FIELD, stock) then return false end

    W.FogTintStock = nil
    if lvl and lvl >= 1 then Log("Restored the stock height fog tint") end
    return true
end

function W.ApplyFogTint(tints)
    if not IsEnabled(tints) then return false end

    local sched = tints.Schedule
    if type(sched) ~= "table" or #sched == 0 then return false end
    if type(tints.Colors) ~= "table" then return false end

    local actor = W.SkyActor()
    if not IsValidObject(actor) then return false end

    local tod = W.Get(actor, "TimeOfDay")
    if type(tod) ~= "number" then return false end

    local dur = (tonumber(tints.BlendMinutes) or 20) / 60.0
    local r, g, b = W.TintAt(sched, tints.Colors, tod, dur)
    if not r then return false end

    local fog = W.Get(actor, W.FOG_FIELD)
    if not IsValidObject(fog) then return false end
    local tint = W.Get(fog, W.TINT_FIELD)
    if tint == nil then return false end

    local cr = W.Get(tint, "R")
    local cg = W.Get(tint, "G")
    local cb = W.Get(tint, "B")

    -- Remember the untouched tint before the first write in this world.
    if W.FogTintStock == nil and type(cr) == "number"
            and type(cg) == "number" and type(cb) == "number" then
        W.FogTintStock = {
            R = cr, G = cg, B = cb, A = W.Get(tint, "A") or 1.0,
        }
    end

    -- Skip imperceptible changes; this runs on a timer.
    if type(cr) == "number" and type(cg) == "number" and type(cb) == "number"
            and math.abs(cr - r) < 0.002 and math.abs(cg - g) < 0.002
            and math.abs(cb - b) < 0.002 then
        return true
    end

    return W.Set(fog, W.TINT_FIELD, { R = r, G = g, B = b, A = 1.0 })
end

-- Self-rescheduling on the game thread. Not LoopAsync: that runs on a worker
-- thread and this touches UObjects. The generation check retires the previous
-- chain if the loop is restarted while a tick is still pending.
function W.PumpFogTint(generation)
    if not W.FogLoop or generation ~= W.FogGen then return end

    local weather = (Cfg or {}).Weather
    local tints = IsEnabled(weather)
        and W.ResolveFogTint(weather, W.Mode) or nil
    if not IsEnabled(tints) then
        W.FogLoop = false
        W.RestoreFogTint(Lvl())
        return
    end

    pcall(W.ApplyFogTint, tints)

    local delay = tonumber(tints.UpdateMs) or 500
    if not ScheduleOnGameThread(delay, function()
        W.PumpFogTint(generation)
    end) then
        W.FogLoop = false
        Log("WARN: no game-thread scheduler, fog tint pump stopped")
    end
end

function W.StartFogLoop(tints)
    if W.FogLoop then return end
    if not IsEnabled(tints) then return end

    W.FogGen = W.FogGen + 1
    local generation = W.FogGen
    W.FogLoop = true
    if not ScheduleOnGameThread(tonumber(tints.UpdateMs) or 500, function()
        W.PumpFogTint(generation)
    end) then
        W.FogLoop = false
        Log("WARN: no game-thread scheduler, fog tint disabled")
    end
end

-- --------------------------------------------------------------------------
-- TIME SCRUB (debug)
--
-- Active only when Config.TimeScrub is enabled. TimeOfDay is rewritten every
-- frame by BP_PPSkyCreator_Controller_C through its SkyCreatorTarget, so the
-- clock must be detached before a written time will hold. Only the sky is
-- affected; game logic keeps its own clock. The configured restore key hands
-- the clock back without a restart.
-- --------------------------------------------------------------------------

function W.DetachClock()
    if W.ClockDetached then return true end
    if type(CreateInvalidObject) ~= "function" then
        Log("WARN: CreateInvalidObject unavailable, cannot detach the clock")
        return false
    end
    local ctl = W.LiveInstances(W.CLOCK_CLASS)[1]
    if not IsValidObject(ctl) then
        Log("WARN: no " .. W.CLOCK_CLASS .. " in the loaded world")
        return false
    end
    local okNull, nullObj = pcall(CreateInvalidObject)
    if not okNull or nullObj == nil then return false end

    W.Set(ctl, W.CLOCK_FIELD, nullObj)
    if IsValidObject(W.Get(ctl, W.CLOCK_FIELD)) then
        Log("WARN: could not detach the sky clock")
        return false
    end
    W.ClockDetached = true
    Log("Sky clock detached for time scrubbing")
    return true
end

-- Hands the clock back so time passes normally again. The sky jumps to the
-- game's real time of day on the next tick.
function W.ReattachClock()
    if not W.ClockDetached then
        Log("Sky clock is already running")
        return true
    end
    local ctl = W.LiveInstances(W.CLOCK_CLASS)[1]
    local actor = W.SkyActor()
    if not IsValidObject(ctl) or not IsValidObject(actor) then
        Log("WARN: could not reattach the sky clock")
        return false
    end
    W.Set(ctl, W.CLOCK_FIELD, actor)
    if not IsValidObject(W.Get(ctl, W.CLOCK_FIELD)) then
        Log("WARN: sky clock reattach rejected")
        return false
    end
    W.ClockDetached = nil
    Log("Sky clock reattached, time passing normally")
    return true
end

-- Called from the hotkey thread, so it only appends. Steps are queued rather
-- than replaced, otherwise presses made inside one pump interval would
-- collapse into a single step. The cap bounds a stuck key.
W.MAX_PENDING_STEPS = 32

function W.QueueStep(delta)
    local steps = W.PendingSteps
    if not steps then
        steps = {}
        W.PendingSteps = steps
    end
    if #steps < W.MAX_PENDING_STEPS then
        steps[#steps + 1] = delta
    end
end

function W.StepTime(delta)
    if not W.TimeScrub then return end
    local actor = W.SkyActor()
    if not IsValidObject(actor) then return end
    if not W.DetachClock() then return end

    local now = W.Get(actor, "TimeOfDay")
    if type(now) ~= "number" then return end

    -- Snap to the step grid rather than adding an offset, so stepping from
    -- 14.36 gives 14.50 / 14.75 / 15.00 instead of carrying the .36 forward.
    -- The epsilon keeps a step from a value already on the grid moving a full
    -- step instead of rounding back to itself.
    local step = math.abs(delta)
    if step <= 0 then return end
    local want
    if delta > 0 then
        want = (math.floor(now / step + 1e-6) + 1) * step
    else
        want = (math.ceil(now / step - 1e-6) - 1) * step
    end
    want = want % 24.0

    -- SetTime also recomputes sun position; writing the property does not.
    if not W.TryCall(actor, "SetTime", want) then
        W.Set(actor, "TimeOfDay", want)
    end
    Log(("TimeOfDay %.2f -> %.2f")
        :format(now, W.Get(actor, "TimeOfDay") or want))
end

-- --------------------------------------------------------------------------
-- Modes
-- --------------------------------------------------------------------------

local MODES = {
    ultraweather = "UltraWeather",
    vanillaplus = "VanillaPlus",
    cloudsonly = "CloudsOnly",
}

local function ResolveMode(weather)
    if not IsEnabled(weather) then return nil end
    local raw = tostring(weather.Mode or "UltraWeather"):gsub("%s+", ""):lower()
    local mode = MODES[raw]
    if mode then return mode end
    Log(("WARN: unknown Mode '%s', falling back to UltraWeather")
        :format(tostring(weather.Mode)))
    return "UltraWeather"
end

-- Repoints the schedule at this mod's own presets, which are the Sky Creator
-- plugin's unused sample assets rewritten from config. Palworld's own weather
-- assets are never touched.
function W.SyncUltraWeather(weather, lvl)
    local sc = weather.UltraWeather
    if type(sc) ~= "table" then
        Log("WARN: Weather.UltraWeather section is missing")
        return
    end

    if not W.Snapshot and sc.InheritFrom then
        W.Snapshot = W.CaptureBase(sc.InheritFrom, lvl)
    end

    -- Corrections merged into the inherited base so every preset gets them,
    -- before each preset's own Settings are layered on top.
    local base = W.Snapshot
    if sc.BaseOverrides then base = W.Merge(base, sc.BaseOverrides) end

    local resolved, donors = {}, {}
    for name, preset in pairs(sc.Presets or {}) do
        if IsEnabled(preset) then
            local asset = preset.AssetPath and FindOrLoadAsset(preset.AssetPath)
            if asset then
                -- pairs() order is undefined, so two presets sharing a donor
                -- asset would let an arbitrary one win each sync.
                local key = W.RefName(asset)
                if donors[key] then
                    Log(("WARN: '%s' and '%s' share asset %s; give each preset "
                        .. "its own AssetPath")
                        :format(donors[key], name, tostring(preset.AssetPath)))
                end
                donors[key] = name
                resolved[name] = asset

                local settings = (sc.InheritFrom or sc.BaseOverrides)
                    and W.Merge(base, preset.Settings)
                    or (preset.Settings or {})
                local changed = ApplyDiff(asset, settings, name, lvl >= 2, true)
                if changed > 0 and lvl >= 1 then
                    Log("Patched weather preset '" .. name .. "'")
                end
            else
                Log(("WARN: asset not found for '%s': %s")
                    :format(name, tostring(preset.AssetPath)))
            end
        end
    end

    if type(sc.Schedule) == "table" and #sc.Schedule > 0 then
        W.ApplySchedule(sc.Schedule, resolved, lvl)
    end
    W.ApplyInterpolation(sc.InterpolationMinutes, sc.Schedule, lvl)
end

-- Edits the presets the game already schedules, so the stock slot times and
-- slot order are kept exactly as Palworld shipped them. Shared by VanillaPlus
-- and CloudsOnly: the two modes differ only in what their section is allowed
-- to contain, not in how it is applied.
function W.SyncStockPresets(section, sectionName, lvl)
    if type(section) ~= "table" then
        Log("WARN: Weather." .. sectionName .. " section is missing")
        return
    end
    W.StockRestored = nil

    for name, preset in pairs(section.Presets or {}) do
        if IsEnabled(preset) and preset.AssetPath then
            local asset = FindOrLoadAsset(preset.AssetPath)
            if asset then
                local settings = section.SharedOverrides
                    and W.Merge(section.SharedOverrides, preset.Settings)
                    or (preset.Settings or {})
                W.RememberStock(preset.AssetPath, asset, settings)
                local changed = ApplyDiff(asset, settings, name, lvl >= 2, true)
                if changed > 0 and lvl >= 1 then
                    Log("Patched weather preset '" .. name .. "'")
                end
            else
                Log(("WARN: asset not found for '%s': %s")
                    :format(name, tostring(preset.AssetPath)))
            end
        end
    end

    W.ApplyInterpolation(section.InterpolationMinutes, nil, lvl)
end

local function SyncWeather(config)
    local weather = config.Weather
    local lvl = Lvl()
    local mode = ResolveMode(weather)
    -- The fog pump reruns between syncs and needs to know the active mode.
    W.Mode = mode

    -- Undo whatever the other mode wrote before applying this one, so the
    -- mode can be changed without restarting the game.
    if mode ~= "UltraWeather" then W.RestoreSchedule(lvl) end

    -- VanillaPlus and CloudsOnly both write to Palworld's own presets, so put
    -- the stock values back before the active mode reapplies. Diff-based, so
    -- this writes nothing once the two agree.
    W.RestoreStock(lvl)

    if mode == nil then
        W.DisableClouds()
        W.FogLoop = false
        W.RestoreFogTint(lvl)
        return
    end

    if mode == "UltraWeather" then
        W.SyncUltraWeather(weather, lvl)
    elseif mode == "VanillaPlus" then
        W.SyncStockPresets(weather.VanillaPlus, "VanillaPlus", lvl)
    elseif mode == "CloudsOnly" then
        W.SyncStockPresets(weather.CloudsOnly, "CloudsOnly", lvl)
    end

    if IsEnabled(weather.VolumetricClouds) then
        W.EnableClouds(weather, lvl)
    else
        W.DisableClouds()
    end

    -- Cloud properties, so they belong in CloudsOnly too.
    W.ApplyBackgroundClouds(weather, lvl)

    -- Driven entirely by config now: each mode's FogTint.Modes entry decides
    -- whether the tint runs, rather than the mode being special-cased here.
    local tints = W.ResolveFogTint(weather, mode)
    if IsEnabled(tints) then
        W.StartFogLoop(tints)
        W.ApplyFogTint(tints)
    else
        W.FogLoop = false
        W.RestoreFogTint(lvl)
    end
end

-- ===========================================================================
-- POST PROCESS
--
-- Overrides FPostProcessSettings on live components matched by class plus name
-- substrings; every NameContains entry must match.
--
-- Each entry may carry a Modes table keyed by Weather.Mode, merged over the
-- entry's shared Settings. A darker preset set needs different exposure
-- compensation than the stock one, so the two cannot share fixed values.
--
-- The pre-mod value of every property that any mode could write is captured
-- before the first write and used as the base on every sync. Switching mode
-- therefore restores values the incoming mode does not set, rather than
-- leaving the outgoing mode's numbers behind.
-- ===========================================================================

local postSnapshots = {}

-- The union of every property any mode could write, used as a capture shape.
-- Only the key layout matters here, not the values.
local function PostProcessShape(entry)
    local shape = W.Merge(entry.Settings, nil)
    for _, modeEntry in pairs(entry.Modes or {}) do
        if type(modeEntry) == "table" then
            shape = W.Merge(shape, modeEntry.Settings)
        end
    end
    return shape
end

local function SyncPostProcess(config, mode)
    local postProcess = config.PostProcess
    if type(postProcess) ~= "table" then return end

    local lvl = Lvl()
    local sectionEnabled = IsEnabled(postProcess)

    for name, entry in pairs(postProcess) do
        if name ~= "Enabled" and type(entry) == "table" then
            local shape = PostProcessShape(entry)

            -- nil means restore only, so a disabled entry undoes its writes.
            local wanted = nil
            if sectionEnabled and IsEnabled(entry) then
                wanted = W.Merge(entry.Settings, nil)
                local modeEntry = mode and (entry.Modes or {})[mode]
                if type(modeEntry) == "table" then
                    wanted = W.Merge(wanted, modeEntry.Settings)
                end
            end

            local okAll, comps = pcall(FindAllOf,
                entry.ComponentClass or "PostProcessComponent")
            local matched, changed = false, 0

            for _, comp in ipairs(okAll and comps or {}) do
                if IsValidObject(comp) then
                    local full = GetObjectFullName(comp)
                    local hit = full ~= nil
                    for _, needle in ipairs(entry.NameContains or {}) do
                        if not full:find(needle, 1, true) then
                            hit = false
                            break
                        end
                    end

                    if hit then
                        matched = true
                        local settings = W.Get(comp, "Settings")
                        if settings ~= nil then
                            -- Values already recorded win, because by now they
                            -- hold this mod's own output rather than stock.
                            local stock = postSnapshots[full]
                            local fresh = W.CaptureShape(settings, shape)
                            if fresh then
                                stock = stock and W.Merge(fresh, stock) or fresh
                                postSnapshots[full] = stock
                            end
                            stock = stock or {}

                            changed = changed + ApplyDiff(settings,
                                wanted and W.Merge(stock, wanted) or stock,
                                name, lvl >= 2, false)
                        end
                    end
                end
            end

            if not matched then
                Log("WARN: no component matched for PostProcess '"
                    .. name .. "'")
            elseif changed > 0 and lvl >= 1 then
                Log("Patched post process '" .. name .. "'")
            end
        end
    end
end

-- ===========================================================================
-- SYNC DRIVER
-- ===========================================================================

local pendingConfigErrorAlert = false
local gameThreadJobQueued = false
local wantNotifySync = false
local wantWorldCleanup = false
local gameplayStableTicks = 0

local PUMP_MS = 250
local INITIAL_SYNC_COALESCE_MS = 1500
local ALERT_SETTLE_TICKS = 8 -- 2 seconds

local function InGame()
    return GetLocalInGamePlayerController() ~= nil
end

local function ProcessPendingConfigErrorAlert()
    if not pendingConfigErrorAlert then return false end

    local shown, showErr = ShowConfigErrorAlert()
    if shown then
        pendingConfigErrorAlert = false
        return true
    end

    if showErr ~= "gameplay controller unavailable" then
        Log("WARN: config error alert failed: " .. tostring(showErr))
        -- Avoid repeatedly invoking a failing native function every 250 ms.
        pendingConfigErrorAlert = false
    end
    return false
end

local function Notify(title, message)
    local pc = GetLocalInGamePlayerController()
    if not IsValidObject(pc) then return false end
    local ok, err = pcall(function()
        pc:AddKillLog_Client({
            LogType = 2,
            AttackerName = tostring(title),
            KilledCharacterName = tostring(message),
        })
    end)
    if not ok then
        Log("WARN: failed to show notification: " .. tostring(err))
    end
    return ok
end

local function SyncNow(showNotification)
    if not InGame() then
        Log("Not in game, sync skipped")
        return
    end

    local loaded, loadErr = LoadConfig()
    if not loaded then
        -- Keep the exact parser/runtime error in UE4SS.log, but show the short
        -- user-facing message immediately in the loaded gameplay world.
        pendingConfigErrorAlert = true
        ProcessPendingConfigErrorAlert()
        Log("Config error alert requested in game: " .. tostring(loadErr))
        return
    end
    Cfg = loaded
    pendingConfigErrorAlert = false

    local ok, err = pcall(function()
        SyncWeather(Cfg)
        SyncPostProcess(Cfg, ResolveMode(Cfg.Weather))
    end)
    if not ok then
        Log("ERROR during sync: " .. tostring(err))
    elseif showNotification then
        Notify(MOD_NAME, "Config Refreshed")
    end
end

-- One table, not three locals, to keep the shared state together.
local worldSync = {
    cooldownTicks = 0,   -- coalescing window after a sync
    pending = false,     -- sync requested but not yet runnable
    watchdogTicks = 0,   -- 0 = disarmed
    -- Must stay well above the longest loading screen (23 s observed on a busy
    -- server) or it fires a sync before the region has streamed in.
    WATCHDOG_LIMIT = 240, -- 60 seconds of pump ticks
}

local function RunWorldSync()
    worldSync.cooldownTicks = math.max(1,
        math.ceil(INITIAL_SYNC_COALESCE_MS / PUMP_MS))
    worldSync.pending = false
    worldSync.watchdogTicks = 0
    SyncNow(false)
end

-- Deferred rather than dropped: the pump loses ticks while a loading screen is
-- up, which is exactly when world-partition events arrive.
local function QueueSyncs()
    if worldSync.cooldownTicks > 0 or not InGame() then
        worldSync.pending = true
        return
    end
    RunWorldSync()
end

local function ClearDeferredWorldWork()
    cachedPlayerController = nil
    cachedInGamePlayerController = nil
    worldSync.cooldownTicks = 0
    worldSync.pending = false
    worldSync.watchdogTicks = 0
    -- Every cached UObject belongs to the world that is going away.
    W.Sky = nil
    W.Original = nil
    W.Restored = nil
    W.StockRestored = nil
    W.ClockDetached = nil
    W.CloudsOn = nil
    W.FogLoop = false
    -- The fog component died with the world; the next one starts at stock.
    W.FogTintStock = nil
    W.Mode = nil
    postSnapshots = {}
    W.PendingSteps = nil
    W.PendingReattach = nil
end

do
-- Synchronization is driven by the local player's WaitLoadingWorldPartition
-- action, the only loading-screen signal that fires on a host and a client
-- alike.
--
-- The Blueprint class is not loaded at the main menu, so wait for its first
-- constructed instance before registering. Hooks bind to the class UFunction,
-- not an instance, so one registration serves every later character.
local WAIT_LOADING_CLASS_PATH =
    "/Game/Pal/Blueprint/Action/Common/BP_Action_WaitLoadingWorldPartition." ..
    "BP_Action_WaitLoadingWorldPartition_C"
local WAIT_LOADING_BEGIN_PATH = WAIT_LOADING_CLASS_PATH .. ":OnBeginAction"
local WAIT_LOADING_END_PATH = WAIT_LOADING_CLASS_PATH .. ":OnEndAction"

local hooks = { beginFn = nil, endFn = nil, busy = false }

local function GetLocalPawn()
    local pc = GetLocalInGamePlayerController()
    if not IsValidObject(pc) then return nil end
    local ok, pawn = pcall(function() return pc.Pawn end)
    if ok and IsValidObject(pawn) then return pawn end
    ok, pawn = pcall(function() return pc:K2_GetPawn() end)
    if ok and IsValidObject(pawn) then return pawn end
    return nil
end

-- Remote players' action components run in this process too, and on a proxy
-- PlayerCharacter and Controller are usually unset, so neither is a usable
-- ownership test. Compare identity against the local pawn instead, via the
-- outer chain: action -> ActionComponent -> character. Fails closed; the
-- watchdog recovers a missed local sync, whereas a false accept would resync
-- on every other player's fast travel.
local function IsLocalWaitLoadingAction(action)
    local pawn = GetLocalPawn()
    if not IsValidObject(pawn) then return false end

    local ok, owner = pcall(function()
        local component = action:GetOuter()
        if not IsValidObject(component) then return nil end
        return component:GetOuter()
    end)
    if ok and IsValidObject(owner) and SameObject(owner, pawn) then
        return true
    end

    local okCharacter, character =
        pcall(function() return action.PlayerCharacter end)
    return okCharacter and IsValidObject(character)
        and SameObject(character, pawn)
end

local function IsLocalWaitLoadingContext(Context)
    local ok, action = pcall(function() return Context:get() end)
    if not ok or not IsValidObject(action) then return false end
    return IsLocalWaitLoadingAction(action)
end

-- Loading screen up, outgoing region tearing down.
local function OnWaitLoadingBegin(Context)
    if not IsLocalWaitLoadingContext(Context) then return end

    W.Sky = nil
    -- Restart the countdown so a long loading screen cannot trip it, and so a
    -- Begin whose End never arrives still recovers.
    worldSync.watchdogTicks = 1

    if Lvl() >= 2 then Log("World partition streaming started") end
end

-- Loading screen about to close, incoming region streamed in.
local function OnWaitLoadingEnd(Context)
    if not IsLocalWaitLoadingContext(Context) then return end

    if Lvl() >= 2 then
        Log("World partition streaming finished, synchronizing")
    end
    QueueSyncs()
end

-- Returns the hooked UFunction so a later class reload can be detected, or nil
-- if the hook could not be installed.
local function RegisterWaitLoadingHook(path, label, callback)
    local findOk, fn = pcall(StaticFindObject, path)
    if not findOk or not IsValidObject(fn) then
        local detail = findOk and "not currently in memory"
            or ("StaticFindObject error: " .. tostring(fn))
        Log(("WARN: world partition hook %s unavailable (%s)")
            :format(label, detail))
        return nil
    end

    local registerOk, preId, postId = pcall(RegisterHook, path, callback)
    if not registerOk then
        Log(("WARN: world partition hook %s registration failed: %s")
            :format(label, tostring(preId)))
        return nil
    end

    if preId == nil and postId == nil then
        Log(("WARN: world partition hook %s returned no hook IDs")
            :format(label))
        return nil
    end
    return fn
end

-- Re-registers only when the UFunction differs, i.e. the class was unloaded
-- and reloaded. The old hook IDs then refer to freed memory; unregistering
-- those is not safe, so the stale registration is abandoned.
local function TryRegisterWaitLoadingHooks()
    if hooks.busy then return end
    hooks.busy = true

    local beginOk, currentBegin =
        pcall(StaticFindObject, WAIT_LOADING_BEGIN_PATH)
    if not beginOk or not SameObject(hooks.beginFn, currentBegin) then
        hooks.beginFn = RegisterWaitLoadingHook(
            WAIT_LOADING_BEGIN_PATH, "OnBeginAction", OnWaitLoadingBegin)
    end

    local endOk, currentEnd = pcall(StaticFindObject, WAIT_LOADING_END_PATH)
    if not endOk or not SameObject(hooks.endFn, currentEnd) then
        hooks.endFn = RegisterWaitLoadingHook(
            WAIT_LOADING_END_PATH, "OnEndAction", OnWaitLoadingEnd)
    end

    hooks.busy = false
end

local notifyOk, notifyErr = pcall(function()
    NotifyOnNewObject(WAIT_LOADING_CLASS_PATH, function()
        -- Never returns true: removing the notifier would leave no way to
        -- reinstall the hooks if the class is unloaded. The UFunction
        -- comparison already prevents duplicate registrations.
        TryRegisterWaitLoadingHooks()
        return false
    end)
end)

if not notifyOk then
    Log("WARN: failed to arm world partition watcher: " .. tostring(notifyErr))
end
end

RegisterHook("/Script/Engine.PlayerController:ClientRestart", function(Context)
    local ok, pc = pcall(function() return Context:get() end)
    if not ok or not IsLocalPlayerController(pc) then
        return -- never let a remote multiplayer controller replace local state
    end

    -- Cache priming only. Do not sync here: the pump calls InGame() every
    -- 250 ms and populates the same cache, so any "has the controller changed"
    -- test races it and loses on a multiplayer join.
    cachedPlayerController = pc
    cachedInGamePlayerController =
        IsPalInGamePlayerController(pc) and pc or nil
end)

-- ===========================================================================
-- PUMP
-- ===========================================================================

local wasInGame = false
local function RunGameThreadJobs()
    local ok, err = pcall(function()
        local inGame = InGame()
        gameplayStableTicks = inGame and (gameplayStableTicks + 1) or 0

        if wasInGame and not inGame then wantWorldCleanup = true end
        if inGame and not wasInGame then worldSync.watchdogTicks = 1 end
        wasInGame = inGame

        if inGame then
            if worldSync.cooldownTicks > 0 then
                worldSync.cooldownTicks = worldSync.cooldownTicks - 1
            end
            if worldSync.pending and worldSync.cooldownTicks == 0 then
                RunWorldSync()
            end
            if worldSync.watchdogTicks > 0 then
                worldSync.watchdogTicks = worldSync.watchdogTicks + 1
                if worldSync.watchdogTicks >= worldSync.WATCHDOG_LIMIT then
                    worldSync.watchdogTicks = 0
                    Log("WARN: no world partition streaming event seen after "
                        .. "entering the world, running fallback sync")
                    QueueSyncs()
                end
            end
        end

        if wantWorldCleanup then
            wantWorldCleanup = false
            ClearDeferredWorldWork()
        end

        if not inGame then
            if wantNotifySync then
                wantNotifySync = false
                local loaded, loadErr = LoadConfig()
                if loaded then
                    Cfg = loaded
                    Log("Config reloaded at title screen")
                else
                    -- Config errors are intentionally displayed only in a
                    -- loaded gameplay world, never on the title screen.
                    pendingConfigErrorAlert = true
                    Log("Config reload failed at title screen, gameplay error "
                        .. "alert queued: " .. tostring(loadErr))
                end
            end
            return
        end

        if pendingConfigErrorAlert
                and gameplayStableTicks >= ALERT_SETTLE_TICKS then
            ProcessPendingConfigErrorAlert()
        end
        if wantNotifySync then
            wantNotifySync = false
            SyncNow(true)
        end
        if W.PendingSteps then
            local steps = W.PendingSteps
            W.PendingSteps = nil
            for _, step in ipairs(steps) do W.StepTime(step) end
        end
        if W.PendingReattach then
            W.PendingReattach = nil
            W.ReattachClock()
        end
    end)

    gameThreadJobQueued = false
    if not ok then
        Log("ERROR in game-thread dispatcher: " .. tostring(err))
    end
end

-- The pump runs unconditionally because entering and leaving a world is
-- detected by polling the local controller, which is only safe to read on the
-- game thread. An idle tick is a single cached-validity check.
--
-- This is the only place that dispatches to the game thread. Hotkey callbacks
-- fire on their own thread and merely set a flag for the next tick: handing
-- UE4SS the same function object from two threads at once can leave one of its
-- queued registry references dangling, and it responds by removing the engine
-- tick hook, which would take the whole pump down with it. The fallback below
-- passes a fresh closure each time for the same reason.
if type(LoopInGameThreadWithDelay) == "function" then
    LoopInGameThreadWithDelay(PUMP_MS, function()
        if gameThreadJobQueued then return end
        gameThreadJobQueued = true
        RunGameThreadJobs()
    end)
else
    LoopAsync(PUMP_MS, function()
        if not gameThreadJobQueued then
            gameThreadJobQueued = true
            ExecuteInGameThread(function() RunGameThreadJobs() end)
        end
        return false
    end)
end

-- ===========================================================================
-- STARTUP
-- ===========================================================================

do
    local loaded, loadErr = LoadConfig()
    if loaded then
        Cfg = loaded
    else
        Cfg = {}
        pendingConfigErrorAlert = true
        Log("Initial config error alert queued for gameplay: "
            .. tostring(loadErr))
    end
end

do
    local binding = (Cfg.Keys or {}).Sync
    local enabled, name = true, nil
    if type(binding) == "table" then
        enabled = binding.Enabled ~= false
        name = type(binding.Key) == "string" and binding.Key or nil
    elseif type(binding) == "string" then
        name = binding
    end

    local code = enabled and name and Key[name] or nil
    if enabled and name and not code then
        Log(("WARN: unknown Keys.Sync key '%s', using %s")
            :format(name, DEFAULT_SYNC_KEY))
    end
    if enabled and not code then
        code = Key[DEFAULT_SYNC_KEY]
        name = DEFAULT_SYNC_KEY
    end

    if code then
        RegisterKeyBind(code, function()
            wantNotifySync = true
        end)
        registeredSyncKey = name
    else
        registeredSyncKey = nil
    end
end

-- Debug time scrubbing, configured at the bottom of config.lua.
W.TimeScrub = IsEnabled(Cfg.TimeScrub)
if W.TimeScrub then
    for _, bind in ipairs({
        { "RIGHT_ARROW", "RIGHT", 0.25 },
        { "LEFT_ARROW", "LEFT", -0.25 },
        { "UP_ARROW", "UP", 1.0 },
        { "DOWN_ARROW", "DOWN", -1.0 },
    }) do
        local code = Key[bind[1]] or Key[bind[2]]
        if code then
            RegisterKeyBind(code, function()
                W.QueueStep(bind[3])
            end)
        end
    end

    local restoreName = type(Cfg.TimeScrub.RestoreKey) == "string"
        and Cfg.TimeScrub.RestoreKey or "RIGHT_WIN"
    local restoreCode = Key[restoreName]
    if restoreCode then
        RegisterKeyBind(restoreCode, function()
            W.PendingReattach = true
        end)
    else
        Log(("WARN: unknown TimeScrub.RestoreKey '%s', reload the world to "
            .. "restore the sky clock"):format(restoreName))
        restoreName = nil
    end

    Log("Time scrub enabled: arrow keys step the sky clock"
        .. (restoreName and (", " .. restoreName .. " restores normal time")
            or ""))
end

Log("Version " .. MOD_VERSION .. " initialized.")

-- PlayerRadar-Server v1.0.0
-- 2026-08-02 CrazyChips.
--
-- Server-side player position broadcaster. Runs on the dedicated server,
-- tracks every PalPlayerCharacter, writes a JSON snapshot every
-- CONFIG.write_interval_seconds to CONFIG.output_path. The client-side
-- mod reads the same file and renders the positions on the in-game map.
--
-- Why this exists: clients can only see player pawns that are
-- currently replicated to them. On a 32-slot server with players spread
-- across the world, a client can miss most of them. The server is the
-- authoritative owner of every pawn, so it can see all of them and
-- broadcast the snapshot via a plain file.
--
-- File format (UTF-8 JSON):
--   {
--     "ts":       <unix-ish timestamp>,
--     "server":   "CrazyChips's server",
--     "players":  [
--       { "name": "Alice", "x": 1234.5, "y": 5678.9, "z": 120.0 },
--       ...
--     ]
--   }

local CONFIG = require("config")

local PREFIX = "[PlayerRadar-Server]"

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
local function log(msg)
    print(string.format("%s %s\n", PREFIX, tostring(msg)))
end

local function is_valid(obj)
    if obj == nil then return false end
    local ok, v = pcall(function() return obj:IsValid() end)
    return ok and v == true
end

-- JSON-ish string escape.  We don't need full JSON conformance for
-- player names; ASCII printable + escape backslash/quote/newline is
-- enough to keep UE4SS.log happy and the client parser reliable.
local function json_escape(s)
    s = tostring(s or "")
    s = s:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "")
    return s
end

-- ---------------------------------------------------------------------------
-- Player collection
-- ---------------------------------------------------------------------------
local function collect_players()
    local out = {}
    local ok, list = pcall(function() return FindAllOf("PalPlayerCharacter") end)
    if not ok or type(list) ~= "table" then return out end

    for _, p in ipairs(list) do
        if is_valid(p) then
            local name = "?"
            pcall(function()
                local ps = p:GetPlayerState()
                if is_valid(ps) then
                    local n = ps:GetPlayerName()
                    if n and n ~= "" then name = tostring(n) end
                end
            end)
            local x, y, z = 0, 0, 0
            pcall(function()
                local v = p:K2_GetActorLocation()
                if type(v) == "table" then
                    x = tonumber(v.X) or 0
                    y = tonumber(v.Y) or 0
                    z = tonumber(v.Z) or 0
                end
            end)
            out[#out + 1] = {
                name = name,
                x = x, y = y, z = z,
            }
        end
    end
    return out
end

-- ---------------------------------------------------------------------------
-- File output
-- ---------------------------------------------------------------------------
local function build_json(players)
    local now = os.time()
    local lines = { string.format('{"ts":%d,"server":"%s","players":[',
                                  now, json_escape(CONFIG.server_label or "")) }
    for i, p in ipairs(players) do
        local sep = (i == 1) and "" or ","
        lines[#lines + 1] = string.format(
            '%s{"name":"%s","x":%.2f,"y":%.2f,"z":%.2f}',
            sep, json_escape(p.name), p.x, p.y, p.z
        )
    end
    lines[#lines + 1] = "]}"
    return table.concat(lines, "")
end

local function write_json_file(players)
    local path = CONFIG.output_path
    if not path or path == "" then
        log("write: no output_path configured (set it in config.lua)")
        return false
    end
    -- Make sure the directory exists.
    local dir = path:match("^(.*)[/\\][^/\\]+$")
    if dir and dir ~= "" then
        pcall(function()
            -- Minimal mkdir -p via cmd.  UE4SS Lua doesn't have a portable
            -- directory creation API; 'mkdir' is fine on Windows.
            os.execute('mkdir "' .. dir .. '" 2>NUL')
        end)
    end
    local ok, err = pcall(function()
        local f = assert(io.open(path, "w"))
        f:write(build_json(players))
        f:close()
    end)
    if not ok then
        log(string.format("write FAILED (%s): %s", path, tostring(err)))
        return false
    end
    return true
end

-- ---------------------------------------------------------------------------
-- Periodic write loop
-- ---------------------------------------------------------------------------
local write_handle = nil
local function start_write_loop()
    local interval = CONFIG.write_interval_seconds or 1.0
    if interval <= 0 then interval = 1.0 end
    local ms = math.floor(interval * 1000)

    local function tick()
        local players = collect_players()
        local ok = write_json_file(players)
        if ok then
            log(string.format("wrote %d player(s) -> %s", #players, CONFIG.output_path))
        end
        pcall(function()
            write_handle = LoopInGameThreadWithDelay(ms, tick)
        end)
    end
    pcall(function()
        write_handle = LoopInGameThreadWithDelay(ms, tick)
    end)
    log(string.format("write loop started (every %ss)", tostring(interval)))
end

-- ---------------------------------------------------------------------------
-- Console commands (server admin, types into PalServer stdout)
-- ---------------------------------------------------------------------------
local function tokenize(line)
    local tokens = {}
    for tok in string.gmatch(tostring(line or ""), "%S+") do
        tokens[#tokens + 1] = tok
    end
    return tokens
end

local function handle_console_command(line)
    local tokens = tokenize(line)
    local cmd = table.remove(tokens, 1) or ""
    if cmd == "" or cmd == "help" or cmd == "?" then
        log("commands:")
        log("  list              -- list all players with positions")
        log("  flush             -- write the JSON snapshot now")
        log("  help              -- show this text")
    elseif cmd == "list" then
        local players = collect_players()
        if #players == 0 then
            log("list: no players")
            return
        end
        log(string.format("list: %d player(s)", #players))
        for i, p in ipairs(players) do
            log(string.format("  [%d] %-24s (%.0f, %.0f, %.0f)", i, p.name, p.x, p.y, p.z))
        end
    elseif cmd == "flush" then
        local players = collect_players()
        local ok = write_json_file(players)
        log(ok and ("flushed %d player(s)"):format(#players) or "flush failed (see log)")
    else
        log(string.format("unknown subcommand: %s (try 'help')", tostring(cmd)))
    end
end

local console_registered = false
local function try_register_console()
    if console_registered then return end
    local ok = pcall(function()
        RegisterConsoleCommandHandler(CONFIG.console_command, function(cmd_line)
            handle_console_command(cmd_line)
        end)
    end)
    if ok then
        console_registered = true
        log(string.format("console: registered (try '%s help' in the PalServer window)",
                          CONFIG.console_command))
    else
        log("console: RegisterConsoleCommandHandler not available (write loop still works)")
    end
end

-- ---------------------------------------------------------------------------
-- Bootstrap
-- ---------------------------------------------------------------------------
log("v1.0.0 loaded")
log(string.format("output -> %s", tostring(CONFIG.output_path)))
try_register_console()
start_write_loop()

-- PlayerRadar-Server config
-- Installed on the dedicated server (192.168.1.112). Tracks every
-- PalPlayerCharacter and writes their state to a shared JSON file that
-- the client-side mod reads.
return {
    -- JSON output path. Set this to a Windows file share that the
    -- client's UE4SS mod can also read. Example for a share named
    -- 'palradar$' on the dedicated server:
    --     "\\\\192.168.1.112\\palradar$\\positions.json"
    -- If the client is on the same machine, a local path also works:
    --     "C:\\palradar\\positions.json"
    output_path = "C:\\palradar\\positions.json",

    -- How often to write the JSON (seconds). 1s is plenty.
    write_interval_seconds = 1.0,

    -- Optional server name to embed in the JSON (shown in the client's
    -- UE4SS.log so the user can confirm which server sent the data).
    server_label = "CrazyChips's server",

    -- Console command name (server admin types this in the PalServer window).
    console_command = "pradar",
}

-- Deterministic schema-driven binary representation for blueprint clipboard data.
--
-- Field names are implied by the schema below and are never written to the
-- payload.  Repeated strings live in one sorted pool, while connection records
-- live in one deduplicated pool and are referenced by index.  IEEE-754 doubles
-- preserve every Lua numeric value, including negative zero.

local Compact = {}

Compact.MAGIC = "PBC"
Compact.VERSION = 1
Compact.MAX_STRINGS = 262144
Compact.MAX_COLLECTION_ITEMS = 1048576
Compact.MAX_STRING_BYTES = 8 * 1024 * 1024

local function field(name, value_type)
    return { name = name, value_type = value_type }
end

local CONNECTION_FIELDS = {
    field("target_source_instance_id", "string"),
    field("source_property", "string"),
    field("source_connect_index", "string"),
    field("target_connect_index", "string"),
    field("target_build_object_id", "string"),
    field("target_connector_class", "string"),
    field("target_relative_to_anchor", "transform"),
    field("source_selection_index", "uint"),
    field("target_selection_index", "uint"),
}

local PREVIEW_MESH_FIELDS = {
    field("static_mesh_path", "string"),
    field("relative_transform", "transform"),
    field("material_slot_count", "uint"),
}

local OVERLAP_FIELDS = {
    field("relative_transform", "transform"),
    field("allowed_collision_profiles", "strings"),
    field("shape_type", "string"),
    field("box_extent", "vector"),
    field("radius", "number"),
    field("half_height", "number"),
}

local BUILDING_FIELDS = {
    field("source", "string"),
    field("build_object_id", "string"),
    field("map_object_master_data_id", "string"),
    field("source_instance_id", "string"),
    field("world_transform", "transform"),
    field("build_object_class_path", "string"),
    field("relative_transform", "transform"),
    field("actor_relative_to_model", "transform"),
    field("preview_meshes", "preview_meshes"),
    field("overlap_descriptor", "overlap"),
    field("install_strategy", "string"),
    field("install_capacity_sink_rate_by_height", "number"),
    field("install_capacity_slope_angle", "number"),
    field("install_location_offset", "vector"),
    field("spawn_location_offset", "vector"),
    field("connector_class", "string"),
    field("connector_supported_level", "number"),
    field("selection_index", "uint"),
    field("is_anchor", "bool"),
    field("connections", "connections"),
    field("external_connections", "connections"),
}

local TOP_FIELDS = {
    field("schema_version", "uint"),
    field("connection_schema_version", "uint"),
    field("anchor_was_user_selected", "bool"),
    field("anchor_instance_id", "string"),
    field("anchor_build_object_id", "string"),
    field("anchor_world_transform", "transform"),
    field("saved_connections", "connections"),
    field("buildings", "buildings"),
}

local function is_finite_number(value)
    return type(value) == "number" and value == value
        and value ~= math.huge and value ~= -math.huge
end

local function is_uint(value)
    return is_finite_number(value) and value >= 0
        and value <= 9007199254740991 and value == math.floor(value)
end

local function validate_sequence(value, path)
    if type(value) ~= "table" then
        return false, path .. " is not an array"
    end
    local count = #value
    if count > Compact.MAX_COLLECTION_ITEMS then
        return false, path .. " exceeds the collection limit"
    end
    for key in pairs(value) do
        if type(key) ~= "number" or key < 1 or key > count
            or key ~= math.floor(key) then
            return false, path .. " is not a dense array"
        end
    end
    return true, nil
end

local function validate_plain_object(value, allowed_fields, path, allowed_extras)
    if type(value) ~= "table" then return false, path .. " is not an object" end
    local allowed = {}
    for _, descriptor in ipairs(allowed_fields) do
        allowed[descriptor.name] = true
    end
    for key in pairs(value) do
        if type(key) ~= "string" then
            return false, path .. " contains a non-string field"
        end
        if not allowed[key] and not (allowed_extras and allowed_extras[key]) then
            return false, path .. " contains unsupported field=" .. tostring(key)
        end
    end
    return true, nil
end

local function validate_vector(value, path)
    local ok, err = validate_plain_object(value, {
        field("x", "number"), field("y", "number"), field("z", "number"),
    }, path)
    if not ok then return false, err end
    for _, name in ipairs({ "x", "y", "z" }) do
        if not is_finite_number(value[name]) then
            return false, path .. "." .. name .. " is not a finite number"
        end
    end
    return true, nil
end

local function validate_quaternion(value, path)
    local ok, err = validate_plain_object(value, {
        field("x", "number"), field("y", "number"), field("z", "number"),
        field("w", "number"),
    }, path)
    if not ok then return false, err end
    for _, name in ipairs({ "x", "y", "z", "w" }) do
        if not is_finite_number(value[name]) then
            return false, path .. "." .. name .. " is not a finite number"
        end
    end
    return true, nil
end

local function validate_transform(value, path)
    local ok, err = validate_plain_object(value, {
        field("translation", "vector"), field("rotation", "quaternion"),
        field("scale", "vector"),
    }, path)
    if not ok then return false, err end
    ok, err = validate_vector(value.translation, path .. ".translation")
    if not ok then return false, err end
    ok, err = validate_quaternion(value.rotation, path .. ".rotation")
    if not ok then return false, err end
    return validate_vector(value.scale, path .. ".scale")
end

local validate_typed
local validate_object

validate_object = function(value, fields, path, allowed_extras)
    local ok, err = validate_plain_object(value, fields, path, allowed_extras)
    if not ok then return false, err end
    for _, descriptor in ipairs(fields) do
        local item = value[descriptor.name]
        if item ~= nil then
            ok, err = validate_typed(
                item, descriptor.value_type, path .. "." .. descriptor.name
            )
            if not ok then return false, err end
        end
    end
    return true, nil
end

validate_typed = function(value, value_type, path)
    if value_type == "string" then
        if type(value) ~= "string" then return false, path .. " is not a string" end
        return true, nil
    elseif value_type == "number" then
        if not is_finite_number(value) then
            return false, path .. " is not a finite number"
        end
        return true, nil
    elseif value_type == "uint" then
        if not is_uint(value) then return false, path .. " is not an unsigned integer" end
        return true, nil
    elseif value_type == "bool" then
        if type(value) ~= "boolean" then return false, path .. " is not a boolean" end
        return true, nil
    elseif value_type == "vector" then
        return validate_vector(value, path)
    elseif value_type == "transform" then
        return validate_transform(value, path)
    elseif value_type == "strings" then
        local ok, err = validate_sequence(value, path)
        if not ok then return false, err end
        for index, item in ipairs(value) do
            if type(item) ~= "string" then
                return false, path .. "[" .. index .. "] is not a string"
            end
        end
        return true, nil
    elseif value_type == "preview_meshes" then
        local ok, err = validate_sequence(value, path)
        if not ok then return false, err end
        for index, item in ipairs(value) do
            ok, err = validate_object(
                item, PREVIEW_MESH_FIELDS, path .. "[" .. index .. "]"
            )
            if not ok then return false, err end
        end
        return true, nil
    elseif value_type == "overlap" then
        return validate_object(value, OVERLAP_FIELDS, path)
    elseif value_type == "connections" then
        local ok, err = validate_sequence(value, path)
        if not ok then return false, err end
        for index, item in ipairs(value) do
            ok, err = validate_object(
                item, CONNECTION_FIELDS, path .. "[" .. index .. "]"
            )
            if not ok then return false, err end
        end
        return true, nil
    elseif value_type == "buildings" then
        local ok, err = validate_sequence(value, path)
        if not ok then return false, err end
        for index, item in ipairs(value) do
            ok, err = validate_object(item, BUILDING_FIELDS,
                path .. "[" .. index .. "]", { runtime_overlap_component = true })
            if not ok then return false, err end
        end
        return true, nil
    end
    return false, path .. " uses unknown compact field type=" .. tostring(value_type)
end

local function new_writer()
    return { parts = {}, size = 0 }
end

local function write_bytes(writer, bytes)
    writer.parts[#writer.parts + 1] = bytes
    writer.size = writer.size + #bytes
end

local function write_u8(writer, value)
    write_bytes(writer, string.char(value))
end

local function write_u32(writer, value)
    write_bytes(writer, string.char(
        value & 0xFF,
        (value >> 8) & 0xFF,
        (value >> 16) & 0xFF,
        (value >> 24) & 0xFF
    ))
end

local function write_varuint(writer, value)
    value = math.tointeger(value)
    if value == nil or value < 0 then error("invalid compact unsigned integer") end
    repeat
        local byte = value & 0x7F
        value = value >> 7
        if value ~= 0 then byte = byte | 0x80 end
        write_u8(writer, byte)
    until value == 0
end

local function write_double(writer, value)
    write_bytes(writer, string.pack("<d", value))
end

local function writer_result(writer)
    return table.concat(writer.parts)
end

local function new_reader(data)
    return { data = data, position = 1, length = #data }
end

local function read_bytes(reader, count)
    if count < 0 or reader.position + count - 1 > reader.length then
        error("compact payload is truncated")
    end
    local result = string.sub(
        reader.data, reader.position, reader.position + count - 1
    )
    reader.position = reader.position + count
    return result
end

local function read_u8(reader)
    local value = string.byte(reader.data, reader.position)
    if value == nil then error("compact payload is truncated") end
    reader.position = reader.position + 1
    return value
end

local function read_u32(reader)
    local a, b, c, d = string.byte(reader.data, reader.position, reader.position + 3)
    if d == nil then error("compact payload is truncated") end
    reader.position = reader.position + 4
    return a + b * 256 + c * 65536 + d * 16777216
end

local function read_varuint(reader)
    local result = 0
    local factor = 1
    for _ = 1, 8 do
        local byte = read_u8(reader)
        result = result + (byte & 0x7F) * factor
        if (byte & 0x80) == 0 then
            if result > 9007199254740991 then
                error("compact unsigned integer exceeds the exact range")
            end
            return result
        end
        factor = factor * 128
    end
    error("compact unsigned integer is too long")
end

local function read_double(reader)
    if reader.position + 7 > reader.length then
        error("compact payload is truncated")
    end
    local value, next_position = string.unpack("<d", reader.data, reader.position)
    reader.position = next_position
    if not is_finite_number(value) then error("compact number is not finite") end
    return value
end

local function collect_string(strings, value)
    strings[value] = true
end

local collect_typed_strings
local collect_object_strings

collect_object_strings = function(strings, value, fields)
    for _, descriptor in ipairs(fields) do
        local item = value[descriptor.name]
        if item ~= nil then
            collect_typed_strings(strings, item, descriptor.value_type)
        end
    end
end

collect_typed_strings = function(strings, value, value_type)
    if value_type == "string" then
        collect_string(strings, value)
    elseif value_type == "strings" then
        for _, item in ipairs(value) do collect_string(strings, item) end
    elseif value_type == "preview_meshes" then
        for _, item in ipairs(value) do
            collect_object_strings(strings, item, PREVIEW_MESH_FIELDS)
        end
    elseif value_type == "overlap" then
        collect_object_strings(strings, value, OVERLAP_FIELDS)
    elseif value_type == "connections" then
        for _, item in ipairs(value) do
            collect_object_strings(strings, item, CONNECTION_FIELDS)
        end
    elseif value_type == "buildings" then
        for _, item in ipairs(value) do
            collect_object_strings(strings, item, BUILDING_FIELDS)
        end
    end
end

local write_typed
local write_object

write_object = function(writer, value, fields, context)
    local mask = 0
    for index, descriptor in ipairs(fields) do
        if value[descriptor.name] ~= nil then
            mask = mask | (1 << (index - 1))
        end
    end
    write_u32(writer, mask)
    for _, descriptor in ipairs(fields) do
        local item = value[descriptor.name]
        if item ~= nil then
            write_typed(writer, item, descriptor.value_type, context)
        end
    end
end

local function write_string_ref(writer, value, context)
    local string_id = context.string_ids[value]
    if string_id == nil then error("compact string is absent from the pool") end
    write_varuint(writer, string_id)
end

local function write_vector(writer, value)
    write_double(writer, value.x)
    write_double(writer, value.y)
    write_double(writer, value.z)
end

local function write_transform(writer, value)
    write_vector(writer, value.translation)
    write_double(writer, value.rotation.x)
    write_double(writer, value.rotation.y)
    write_double(writer, value.rotation.z)
    write_double(writer, value.rotation.w)
    write_vector(writer, value.scale)
end

write_typed = function(writer, value, value_type, context)
    if value_type == "string" then
        write_string_ref(writer, value, context)
    elseif value_type == "number" then
        write_double(writer, value)
    elseif value_type == "uint" then
        write_varuint(writer, value)
    elseif value_type == "bool" then
        write_u8(writer, value and 1 or 0)
    elseif value_type == "vector" then
        write_vector(writer, value)
    elseif value_type == "transform" then
        write_transform(writer, value)
    elseif value_type == "strings" then
        write_varuint(writer, #value)
        for _, item in ipairs(value) do write_string_ref(writer, item, context) end
    elseif value_type == "preview_meshes" then
        write_varuint(writer, #value)
        for _, item in ipairs(value) do
            write_object(writer, item, PREVIEW_MESH_FIELDS, context)
        end
    elseif value_type == "overlap" then
        write_object(writer, value, OVERLAP_FIELDS, context)
    elseif value_type == "connections" then
        write_varuint(writer, #value)
        for _, connection in ipairs(value) do
            local connection_id = context.connection_id(connection)
            if connection_id == nil then
                error("compact connection is absent from the pool")
            end
            write_varuint(writer, connection_id)
        end
    elseif value_type == "buildings" then
        write_varuint(writer, #value)
        for _, item in ipairs(value) do
            write_object(writer, item, BUILDING_FIELDS, context)
        end
    else
        error("unknown compact write type=" .. tostring(value_type))
    end
end

local function deep_clone(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, item in pairs(value) do result[key] = deep_clone(item) end
    return result
end

local read_typed
local read_object

read_object = function(reader, fields, context)
    local mask = read_u32(reader)
    local valid_mask = (1 << #fields) - 1
    if (mask & (~valid_mask)) ~= 0 then
        error("compact object presence mask contains unknown fields")
    end
    local result = {}
    for index, descriptor in ipairs(fields) do
        if (mask & (1 << (index - 1))) ~= 0 then
            result[descriptor.name] = read_typed(
                reader, descriptor.value_type, context
            )
        end
    end
    return result
end

local function read_count(reader, label)
    local count = read_varuint(reader)
    if count > Compact.MAX_COLLECTION_ITEMS then
        error(label .. " exceeds the compact collection limit")
    end
    return count
end

local function read_string_ref(reader, context)
    local string_id = read_varuint(reader)
    local value = context.strings[string_id + 1]
    if value == nil then error("compact string reference is out of range") end
    return value
end

local function read_vector(reader)
    return { x = read_double(reader), y = read_double(reader), z = read_double(reader) }
end

local function read_transform(reader)
    return {
        translation = read_vector(reader),
        rotation = {
            x = read_double(reader), y = read_double(reader),
            z = read_double(reader), w = read_double(reader),
        },
        scale = read_vector(reader),
    }
end

read_typed = function(reader, value_type, context)
    if value_type == "string" then
        return read_string_ref(reader, context)
    elseif value_type == "number" then
        return read_double(reader)
    elseif value_type == "uint" then
        return read_varuint(reader)
    elseif value_type == "bool" then
        local value = read_u8(reader)
        if value ~= 0 and value ~= 1 then error("compact boolean is invalid") end
        return value == 1
    elseif value_type == "vector" then
        return read_vector(reader)
    elseif value_type == "transform" then
        return read_transform(reader)
    elseif value_type == "strings" then
        local result = {}
        for index = 1, read_count(reader, "string array") do
            result[index] = read_string_ref(reader, context)
        end
        return result
    elseif value_type == "preview_meshes" then
        local result = {}
        for index = 1, read_count(reader, "preview mesh array") do
            result[index] = read_object(reader, PREVIEW_MESH_FIELDS, context)
        end
        return result
    elseif value_type == "overlap" then
        return read_object(reader, OVERLAP_FIELDS, context)
    elseif value_type == "connections" then
        local result = {}
        for index = 1, read_count(reader, "connection reference array") do
            local connection_id = read_varuint(reader)
            local connection = context.connections[connection_id + 1]
            if connection == nil then
                error("compact connection reference is out of range")
            end
            result[index] = deep_clone(connection)
        end
        return result
    elseif value_type == "buildings" then
        local result = {}
        for index = 1, read_count(reader, "building array") do
            result[index] = read_object(reader, BUILDING_FIELDS, context)
        end
        return result
    end
    error("unknown compact read type=" .. tostring(value_type))
end

local function enumerate_connections(blueprint, callback)
    for _, connection in ipairs(blueprint.saved_connections or {}) do
        callback(connection)
    end
    for _, building in ipairs(blueprint.buildings or {}) do
        for _, connection in ipairs(building.connections or {}) do
            callback(connection)
        end
        for _, connection in ipairs(building.external_connections or {}) do
            callback(connection)
        end
    end
end

function Compact.encode(blueprint)
    if string.pack == nil then return nil, "Lua string.pack is unavailable" end
    local valid, validation_error = validate_object(blueprint, TOP_FIELDS, "$blueprint")
    if not valid then return nil, validation_error end

    local string_set = {}
    collect_object_strings(string_set, blueprint, TOP_FIELDS)
    local strings = {}
    for value in pairs(string_set) do strings[#strings + 1] = value end
    table.sort(strings)
    if #strings > Compact.MAX_STRINGS then
        return nil, "compact string pool limit exceeded"
    end
    local total_string_bytes = 0
    local string_ids = {}
    for index, value in ipairs(strings) do
        total_string_bytes = total_string_bytes + #value
        string_ids[value] = index - 1
    end
    if total_string_bytes > Compact.MAX_STRING_BYTES then
        return nil, "compact string byte limit exceeded"
    end

    local base_context = { string_ids = string_ids }
    local connection_pool = {}
    local connection_ids = {}
    local function connection_signature(connection)
        local writer = new_writer()
        write_object(writer, connection, CONNECTION_FIELDS, base_context)
        return writer_result(writer)
    end
    local function intern_connection(connection)
        local signature = connection_signature(connection)
        local connection_id = connection_ids[signature]
        if connection_id == nil then
            connection_id = #connection_pool
            connection_ids[signature] = connection_id
            connection_pool[#connection_pool + 1] = connection
        end
        return connection_id
    end
    enumerate_connections(blueprint, intern_connection)

    local writer = new_writer()
    write_bytes(writer, Compact.MAGIC)
    write_u8(writer, Compact.VERSION)
    write_varuint(writer, #strings)
    for _, value in ipairs(strings) do
        write_varuint(writer, #value)
        write_bytes(writer, value)
    end
    write_varuint(writer, #connection_pool)
    for _, connection in ipairs(connection_pool) do
        write_object(writer, connection, CONNECTION_FIELDS, base_context)
    end
    local context = {
        string_ids = string_ids,
        connection_id = intern_connection,
    }
    write_object(writer, blueprint, TOP_FIELDS, context)
    return writer_result(writer), {
        strings = #strings,
        connections = #connection_pool,
        binary_bytes = writer.size,
    }
end

function Compact.decode(binary)
    if type(binary) ~= "string" then return nil, "compact payload is unavailable" end
    if string.unpack == nil then return nil, "Lua string.unpack is unavailable" end
    local ok, result_or_error, stats = pcall(function()
        local reader = new_reader(binary)
        if read_bytes(reader, #Compact.MAGIC) ~= Compact.MAGIC then
            error("compact payload magic is invalid")
        end
        local version = read_u8(reader)
        if version ~= Compact.VERSION then
            error("unsupported compact schema version=" .. tostring(version))
        end
        local string_count = read_count(reader, "string pool")
        if string_count > Compact.MAX_STRINGS then
            error("compact string pool limit exceeded")
        end
        local strings = {}
        local total_string_bytes = 0
        for index = 1, string_count do
            local byte_count = read_count(reader, "string byte sequence")
            total_string_bytes = total_string_bytes + byte_count
            if total_string_bytes > Compact.MAX_STRING_BYTES then
                error("compact string byte limit exceeded")
            end
            strings[index] = read_bytes(reader, byte_count)
        end
        local context = { strings = strings, connections = {} }
        local connection_count = read_count(reader, "connection pool")
        for index = 1, connection_count do
            context.connections[index] = read_object(
                reader, CONNECTION_FIELDS, context
            )
        end
        local blueprint = read_object(reader, TOP_FIELDS, context)
        if reader.position ~= reader.length + 1 then
            error("trailing bytes after compact blueprint")
        end
        return blueprint, {
            strings = string_count,
            connections = connection_count,
            binary_bytes = #binary,
        }
    end)
    if not ok then return nil, tostring(result_or_error) end
    return result_or_error, stats
end

return Compact

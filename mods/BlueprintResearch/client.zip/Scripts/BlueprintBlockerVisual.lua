local BlueprintBlockerVisual = {}

local MAX_MATERIAL_SLOTS = 32

function BlueprintBlockerVisual.install(deps)
    assert(type(deps) == "table",
        "BlueprintBlockerVisual.install requires deps")

    local log = assert(
        deps.log, "BlueprintBlockerVisual requires log"
    )
    local unwrap = assert(
        deps.unwrap, "BlueprintBlockerVisual requires unwrap"
    )
    local is_valid_object = assert(
        deps.is_valid_object,
        "BlueprintBlockerVisual requires is_valid_object"
    )
    local safe_property = assert(
        deps.safe_property,
        "BlueprintBlockerVisual requires safe_property"
    )
    local safe_object_address = assert(
        deps.safe_object_address,
        "BlueprintBlockerVisual requires safe_object_address"
    )
    local object_name = assert(
        deps.object_name, "BlueprintBlockerVisual requires object_name"
    )
    local find_valid_instance = assert(
        deps.find_valid_instance,
        "BlueprintBlockerVisual requires find_valid_instance"
    )
    local collect_build_object_meshes = assert(
        deps.collect_build_object_meshes,
        "BlueprintBlockerVisual requires collect_build_object_meshes"
    )
    local component_store = assert(
        deps.component_store,
        "BlueprintBlockerVisual requires component_store"
    )

    local function get_highlight_material(session)
        local cached = component_store.get_reference(
            session, "blocker_highlight_material"
        )
        if is_valid_object(cached) then return cached end
        local manager = find_valid_instance(
            "PalMapObjectManager", "/Game/Pal/Maps/"
        )
        local material_set =
            safe_property(manager, "BuildingSurfaceMaterialSet")
        local material =
            unwrap(safe_property(material_set, "Highlight"))
        if not is_valid_object(material) then
            material = unwrap(StaticFindObject(
                "/Game/Pal/Material/MapObject/BuildObject/"
                    .. "BuildingProcess/MI_LooksPredicatorNormal."
                    .. "MI_LooksPredicatorNormal"
            ))
        end
        if is_valid_object(material) then
            component_store.set_reference(
                session, "blocker_highlight_material", material
            )
            return material
        end
        return nil
    end

    local function unsafe_visual_label(value)
        local label = string.lower(tostring(object_name(value)))
        return string.find(label, "landscape", 1, true) ~= nil
            or string.find(label, "water", 1, true) ~= nil
            or string.find(label, "ocean", 1, true) ~= nil
            or string.find(label, "river", 1, true) ~= nil
            or string.find(label, "lake", 1, true) ~= nil
            or string.find(label, "volume", 1, true) ~= nil
            or string.find(
                label, "instancedstaticmesh", 1, true
            ) ~= nil
            or string.find(
                label, "hierarchicalinstanced", 1, true
            ) ~= nil
    end

    local function restore(session)
        if not is_valid_object(session) then return 0 end
        local mesh_count =
            component_store.array_count(session, "blocker_meshes")
        local material_count =
            component_store.array_count(session, "blocker_materials")
        local slot_count =
            component_store.array_count(session, "blocker_slots")
        local count = math.min(
            mesh_count, material_count, slot_count
        )
        local restored = 0
        for index = 1, count do
            local mesh = component_store.get_array_item(
                session, "blocker_meshes", index
            )
            local original_material =
                component_store.get_array_item(
                    session, "blocker_materials", index
                )
            local slots = component_store.get_array(
                session, "blocker_slots"
            )
            local slot_index = nil
            pcall(function()
                slot_index = tonumber(slots[index])
            end)
            if is_valid_object(mesh)
                and is_valid_object(original_material)
                and slot_index ~= nil then
                local ok = pcall(function()
                    mesh:SetMaterial(slot_index, original_material)
                end)
                if ok then restored = restored + 1 end
            end
        end
        component_store.reset_blocker(session)
        return restored
    end

    local function add_unique_mesh(result, seen, mesh)
        mesh = unwrap(mesh)
        if not is_valid_object(mesh)
            or unsafe_visual_label(mesh) then
            return
        end
        local address = safe_object_address(mesh)
        if address == nil or seen[address] then return end
        seen[address] = true
        result[#result + 1] = mesh
    end

    local function collect_meshes(actor)
        local result = {}
        local seen = {}
        local build_meshes = nil
        pcall(function()
            build_meshes = collect_build_object_meshes(actor)
        end)
        for _, mesh in ipairs(build_meshes or {}) do
            add_unique_mesh(result, seen, mesh)
        end
        return result
    end

    local function apply(session, actor, blocker_component)
        actor = unwrap(actor)
        blocker_component = unwrap(blocker_component)
        if not is_valid_object(session) then
            return false, "placement Session is unavailable"
        end
        if not is_valid_object(actor) then
            restore(session)
            return false, "blocker actor is unavailable"
        end
        if unsafe_visual_label(actor) then
            restore(session)
            return false, "blocker actor is unsafe to recolor"
        end
        local build_object_id = tostring(
            safe_property(actor, "BuildObjectId") or ""
        )
        if build_object_id == "" or build_object_id == "None"
            or build_object_id == "<nil>" then
            restore(session)
            return false, "dynamic blocker actors are message-only"
        end

        local current_actor = component_store.get_reference(
            session, "blocker_actor"
        )
        if safe_property(session, "SBB_BlockerVisualActive") == true
            and safe_object_address(current_actor)
                == safe_object_address(actor)
            and component_store.array_count(
                session, "blocker_meshes"
            ) > 0 then
            return true, nil
        end

        restore(session)
        local highlight_material = get_highlight_material(session)
        if not is_valid_object(highlight_material) then
            return false, "highlight material is unavailable"
        end

        local highlighted_slots = 0
        for _, mesh in ipairs(collect_meshes(actor)) do
            if highlighted_slots >= MAX_MATERIAL_SLOTS then break end
            local materials = nil
            pcall(function() materials = mesh:GetMaterials() end)
            local material_count = 0
            pcall(function() material_count = #materials end)
            for index = 1, material_count do
                if highlighted_slots >= MAX_MATERIAL_SLOTS then break end
                local slot_index = index - 1
                local original_material = nil
                pcall(function()
                    original_material =
                        unwrap(mesh:GetMaterial(slot_index))
                end)
                if is_valid_object(original_material) then
                    local dynamic_material = nil
                    local applied = pcall(function()
                        dynamic_material = unwrap(
                            mesh:
                                CreateAndSetMaterialInstanceDynamicFromMaterial(
                                    slot_index, highlight_material
                                )
                        )
                        if is_valid_object(dynamic_material) then
                            local red = {
                                R = 1.0,
                                G = 0.02,
                                B = 0.0,
                                A = 1.0,
                            }
                            dynamic_material:SetScalarParameterValue(
                                FName("Progress"), 0.0
                            )
                            dynamic_material:SetVectorParameterValue(
                                FName("RimInitialColor"), red
                            )
                            dynamic_material:SetVectorParameterValue(
                                FName("RimCompleteColor"), red
                            )
                            dynamic_material:SetVectorParameterValue(
                                FName("RimBorderColor"), red
                            )
                        end
                    end)
                    if applied and is_valid_object(dynamic_material) then
                        local state_index = highlighted_slots + 1
                        local mesh_stored =
                            component_store.set_array_item(
                                session, "blocker_meshes",
                                state_index, mesh
                            )
                        local material_stored =
                            component_store.set_array_item(
                                session, "blocker_materials",
                                state_index, original_material
                            )
                        local slot_stored =
                            component_store.set_array_item(
                                session, "blocker_slots",
                                state_index, slot_index
                            )
                        if mesh_stored and material_stored
                            and slot_stored then
                            highlighted_slots = state_index
                        else
                            pcall(function()
                                mesh:SetMaterial(
                                    slot_index, original_material
                                )
                            end)
                        end
                    end
                end
            end
        end

        if highlighted_slots == 0 then
            restore(session)
            return false, "blocker has no safe visible mesh slots"
        end
        local actor_stored = component_store.set_reference(
            session, "blocker_actor", actor
        )
        if not actor_stored then
            restore(session)
            return false, "blocker Actor ownership write failed"
        end
        pcall(function() session.SBB_BlockerVisualActive = true end)
        log("blueprint blocker visual active ownership=session actor="
            .. object_name(actor) .. " component="
            .. object_name(blocker_component) .. " materialSlots="
            .. tostring(highlighted_slots))
        return true, nil
    end

    local function abandon_world()
        -- Unreal destroys the old Session and its state. Never reacquire or
        -- restore external components while that World is tearing down.
        return true
    end

    return {
        apply = apply,
        clear = restore,
        abandon_world = abandon_world,
    }
end

return BlueprintBlockerVisual

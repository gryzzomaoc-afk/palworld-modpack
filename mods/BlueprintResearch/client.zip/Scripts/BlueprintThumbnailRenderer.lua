local BlueprintThumbnailRenderer = {}
local BlueprintPreviewMesh = require("BlueprintPreviewMesh")
local BlueprintLibraryFileSystem = require("BlueprintLibraryFileSystem")

local CAPTURE_WIDTH = 320.0
local CAPTURE_HEIGHT = 180.0
local CAPTURE_HORIZONTAL_FOV_DEGREES = 40.0
local FRAME_FILL = 0.86
local MIN_CAMERA_DISTANCE = 100.0
local MIN_CAMERA_DEPTH = 10.0
local PLACEHOLDER_MATERIAL_PATH =
    "/Game/Pal/Material/MapObject/BuildObject/BuildingProcess/"
        .. "MI_LooksPredicatorDismantle.MI_LooksPredicatorDismantle"
local THUMBNAIL_LIGHT_SPECS = {
    {
        intensity = 48.0,
        color = { R = 1.0, G = 0.94, B = 0.86, A = 1.0 },
        pitch_offset = 0.0,
        yaw_offset = 0.0,
    },
    {
        intensity = 16.0,
        color = { R = 0.68, G = 0.78, B = 1.0, A = 1.0 },
        pitch_offset = -12.0,
        yaw_offset = 115.0,
    },
}

local function dot(left, right)
    return left.X * right.X + left.Y * right.Y + left.Z * right.Z
end

local function normalized(vector)
    local length = math.sqrt(dot(vector, vector))
    assert(length > 0.0, "thumbnail camera vector is empty")
    return {
        X = vector.X / length,
        Y = vector.Y / length,
        Z = vector.Z / length,
    }
end

-- Preserve the established three-quarter view while calculating its distance
-- from the actual projected bounds instead of multiplying a bounding sphere.
local CAMERA_FORWARD = normalized({ X = 4.2, Y = 4.2, Z = -3.0 })
local CAMERA_RIGHT = normalized({
    X = -CAMERA_FORWARD.Y,
    Y = CAMERA_FORWARD.X,
    Z = 0.0,
})
local CAMERA_UP = normalized({
    X = CAMERA_FORWARD.Y * CAMERA_RIGHT.Z
        - CAMERA_FORWARD.Z * CAMERA_RIGHT.Y,
    Y = CAMERA_FORWARD.Z * CAMERA_RIGHT.X
        - CAMERA_FORWARD.X * CAMERA_RIGHT.Z,
    Z = CAMERA_FORWARD.X * CAMERA_RIGHT.Y
        - CAMERA_FORWARD.Y * CAMERA_RIGHT.X,
})

local function compute_camera_frame(bounds_min, bounds_max)
    local center = {
        X = (bounds_min.X + bounds_max.X) * 0.5,
        Y = (bounds_min.Y + bounds_max.Y) * 0.5,
        Z = (bounds_min.Z + bounds_max.Z) * 0.5,
    }
    local horizontal_tangent = math.tan(math.rad(
        CAPTURE_HORIZONTAL_FOV_DEGREES * 0.5
    )) * FRAME_FILL
    local vertical_tangent = horizontal_tangent
        / (CAPTURE_WIDTH / CAPTURE_HEIGHT)
    local distance = MIN_CAMERA_DISTANCE

    for _, x in ipairs({ bounds_min.X, bounds_max.X }) do
        for _, y in ipairs({ bounds_min.Y, bounds_max.Y }) do
            for _, z in ipairs({ bounds_min.Z, bounds_max.Z }) do
                local relative = {
                    X = x - center.X,
                    Y = y - center.Y,
                    Z = z - center.Z,
                }
                local depth = dot(relative, CAMERA_FORWARD)
                local horizontal = math.abs(dot(relative, CAMERA_RIGHT))
                local vertical = math.abs(dot(relative, CAMERA_UP))
                distance = math.max(
                    distance,
                    horizontal / horizontal_tangent - depth,
                    vertical / vertical_tangent - depth,
                    MIN_CAMERA_DEPTH - depth
                )
            end
        end
    end

    return {
        center = center,
        distance = distance,
        location = {
            X = center.X - CAMERA_FORWARD.X * distance,
            Y = center.Y - CAMERA_FORWARD.Y * distance,
            Z = center.Z - CAMERA_FORWARD.Z * distance,
        },
        forward = CAMERA_FORWARD,
        right = CAMERA_RIGHT,
        up = CAMERA_UP,
        horizontal_tangent = horizontal_tangent,
        vertical_tangent = vertical_tangent,
    }
end

BlueprintThumbnailRenderer.compute_camera_frame = compute_camera_frame

function BlueprintThumbnailRenderer.install(deps)
    assert(type(deps) == "table",
        "BlueprintThumbnailRenderer dependencies are required")
    local UEHelpers = assert(
        deps.UEHelpers, "BlueprintThumbnailRenderer UEHelpers is required"
    )
    local log = assert(deps.log, "BlueprintThumbnailRenderer log is required")
    local unwrap = assert(
        deps.unwrap, "BlueprintThumbnailRenderer unwrap is required"
    )
    local is_valid_object = assert(
        deps.is_valid_object,
        "BlueprintThumbnailRenderer is_valid_object is required"
    )
    local object_name = assert(
        deps.object_name, "BlueprintThumbnailRenderer object_name is required"
    )
    local restore_transform = assert(
        deps.restore_transform,
        "BlueprintThumbnailRenderer restore_transform is required"
    )

    local renderer = {
        probe_attempted = false,
        probe_succeeded = false,
        probe_path = nil,
        max_instances = tonumber(deps.max_instances) or 25000,
    }

    local function identity_transform()
        return {
            Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 },
            Translation = { X = 0.0, Y = 0.0, Z = 0.0 },
            Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
        }
    end

    local function destroy_component(component)
        component = unwrap(component)
        if not is_valid_object(component) then return end
        pcall(function()
            component:ClearShowOnlyComponents()
        end)
        pcall(function()
            component:K2_DestroyComponent(component)
        end)
    end

    local function split_png_path(path)
        if type(path) ~= "string" or path == "" then
            return nil, nil, "thumbnail output path is unavailable"
        end
        local directory, file_name = path:match("^(.*)[\\/]+([^\\/]+)$")
        if directory == nil or directory == "" or file_name == nil
            or file_name == "" then
            return nil, nil, "thumbnail output path is invalid"
        end
        if string.lower(string.sub(file_name, -4)) ~= ".png" then
            return nil, nil, "thumbnail output must use the PNG extension"
        end
        return directory, file_name, nil
    end

    local function read_png_signature(path)
        local content, read_error =
            BlueprintLibraryFileSystem.read_file(path)
        if content == nil then return false, tostring(read_error) end
        local signature = content:sub(1, 8)
        if signature ~= "\137PNG\13\10\26\10" then
            return false, "render target output is not a PNG"
        end
        return true, nil
    end

    local function resolve_mesh_asset(path, kind)
        local mesh = nil
        local find_ok, found = pcall(StaticFindObject, path)
        mesh = find_ok and unwrap(found) or nil
        if not is_valid_object(mesh) then
            pcall(LoadAsset, path)
            find_ok, found = pcall(StaticFindObject, path)
            mesh = find_ok and unwrap(found) or nil
        end
        if not is_valid_object(mesh) then
            return nil, tostring(kind) .. " mesh unavailable path="
                .. tostring(path)
        end
        return mesh, nil
    end

    local function resolve_material_asset(path)
        local material = nil
        local find_ok, found = pcall(StaticFindObject, path)
        material = find_ok and unwrap(found) or nil
        if not is_valid_object(material) then
            pcall(LoadAsset, path)
            find_ok, found = pcall(StaticFindObject, path)
            material = find_ok and unwrap(found) or nil
        end
        if not is_valid_object(material) then
            return nil, "thumbnail material unavailable path="
                .. tostring(path)
        end
        return material, nil
    end

    function renderer.render(blueprint, output_path)
        if type(blueprint) ~= "table"
            or type(blueprint.buildings) ~= "table"
            or #blueprint.buildings == 0 then
            return false, "thumbnail blueprint is empty"
        end
        local output_directory, file_name, path_error =
            split_png_path(output_path)
        if output_directory == nil then return false, path_error end

        local owner = unwrap(UEHelpers.GetPlayer())
        local math_library = unwrap(UEHelpers.GetKismetMathLibrary())
        local rendering_library = unwrap(StaticFindObject(
            "/Script/Engine.Default__KismetRenderingLibrary"
        ))
        local capture_class = unwrap(StaticFindObject(
            "/Script/Engine.SceneCaptureComponent2D"
        ))
        local instanced_mesh_class = unwrap(StaticFindObject(
            "/Script/Engine.InstancedStaticMeshComponent"
        ))
        local skeletal_mesh_class = unwrap(StaticFindObject(
            "/Script/Engine.SkeletalMeshComponent"
        ))
        local directional_light_class = unwrap(StaticFindObject(
            "/Script/Engine.DirectionalLightComponent"
        ))
        if not is_valid_object(owner)
            or not is_valid_object(math_library)
            or not is_valid_object(rendering_library)
            or not is_valid_object(capture_class)
            or not is_valid_object(instanced_mesh_class)
            or not is_valid_object(skeletal_mesh_class)
            or not is_valid_object(directional_light_class) then
            return false, "thumbnail renderer dependencies are unavailable"
        end

        local groups = {}
        local group_order = {}
        local skeletal_entries = {}
        local resolved_assets = {}
        local instance_count = 0
        local placeholder_instance_count = 0
        local bounds_min = { X = math.huge, Y = math.huge, Z = math.huge }
        local bounds_max = { X = -math.huge, Y = -math.huge, Z = -math.huge }

        local function include_asset_bounds(asset_bounds, world_transform)
            local local_origin = asset_bounds ~= nil
                and asset_bounds.Origin
                or { X = 0.0, Y = 0.0, Z = 0.0 }
            local box_extent = asset_bounds ~= nil
                and asset_bounds.BoxExtent or nil
            local extent_x = math.abs(tonumber(
                box_extent ~= nil and box_extent.X
            ) or 0.0)
            local extent_y = math.abs(tonumber(
                box_extent ~= nil and box_extent.Y
            ) or 0.0)
            local extent_z = math.abs(tonumber(
                box_extent ~= nil and box_extent.Z
            ) or 0.0)

            if extent_x > 0.0 or extent_y > 0.0 or extent_z > 0.0 then
                for _, sign_x in ipairs({ -1.0, 1.0 }) do
                    for _, sign_y in ipairs({ -1.0, 1.0 }) do
                        for _, sign_z in ipairs({ -1.0, 1.0 }) do
                            local corner = math_library:TransformLocation(
                                world_transform,
                                {
                                    X = (tonumber(local_origin.X) or 0.0)
                                        + extent_x * sign_x,
                                    Y = (tonumber(local_origin.Y) or 0.0)
                                        + extent_y * sign_y,
                                    Z = (tonumber(local_origin.Z) or 0.0)
                                        + extent_z * sign_z,
                                }
                            )
                            local x = tonumber(corner.X) or 0.0
                            local y = tonumber(corner.Y) or 0.0
                            local z = tonumber(corner.Z) or 0.0
                            bounds_min.X = math.min(bounds_min.X, x)
                            bounds_min.Y = math.min(bounds_min.Y, y)
                            bounds_min.Z = math.min(bounds_min.Z, z)
                            bounds_max.X = math.max(bounds_max.X, x)
                            bounds_max.Y = math.max(bounds_max.Y, y)
                            bounds_max.Z = math.max(bounds_max.Z, z)
                        end
                    end
                end
                return
            end

            local mesh_center = math_library:TransformLocation(
                world_transform, local_origin
            )
            local scale = world_transform.Scale3D or {}
            local max_scale = math.max(
                math.abs(tonumber(scale.X) or 1.0),
                math.abs(tonumber(scale.Y) or 1.0),
                math.abs(tonumber(scale.Z) or 1.0)
            )
            local radius = math.max(
                tonumber(asset_bounds ~= nil
                    and asset_bounds.SphereRadius) or 50.0, 1.0
            ) * max_scale
            local x = tonumber(mesh_center.X) or 0.0
            local y = tonumber(mesh_center.Y) or 0.0
            local z = tonumber(mesh_center.Z) or 0.0
            bounds_min.X = math.min(bounds_min.X, x - radius)
            bounds_min.Y = math.min(bounds_min.Y, y - radius)
            bounds_min.Z = math.min(bounds_min.Z, z - radius)
            bounds_max.X = math.max(bounds_max.X, x + radius)
            bounds_max.Y = math.max(bounds_max.Y, y + radius)
            bounds_max.Z = math.max(bounds_max.Z, z + radius)
        end

        local prepared, prepare_error = pcall(function()
            for _, building in ipairs(blueprint.buildings) do
                local building_transform = restore_transform(
                    building.relative_transform
                )
                assert(building_transform ~= nil,
                    "invalid building transform instance="
                        .. tostring(building.source_instance_id))
                for _, descriptor in ipairs(building.preview_meshes or {}) do
                    instance_count = instance_count + 1
                    local preview_placeholder =
                        building.preview_placeholder == true
                    if preview_placeholder then
                        placeholder_instance_count =
                            placeholder_instance_count + 1
                    end
                    assert(instance_count <= renderer.max_instances,
                        "thumbnail instance safety limit exceeded requested>"
                            .. tostring(renderer.max_instances))
                    local mesh_transform = restore_transform(
                        descriptor.relative_transform
                    )
                    assert(mesh_transform ~= nil,
                        "invalid mesh transform instance="
                            .. tostring(building.source_instance_id))
                    local path, kind =
                        BlueprintPreviewMesh.asset_path(descriptor)
                    assert(path ~= nil and kind ~= nil,
                        "thumbnail mesh identity is unavailable")
                    local cache_key =
                        BlueprintPreviewMesh.cache_key(descriptor)
                    local mesh = resolved_assets[cache_key]
                    if mesh == nil then
                        local mesh_error = nil
                        mesh, mesh_error = resolve_mesh_asset(path, kind)
                        assert(mesh ~= nil, mesh_error)
                        resolved_assets[cache_key] = mesh
                    end
                    local mesh_bounds = mesh:GetBounds()
                    local world_transform = math_library:ComposeTransforms(
                        mesh_transform, building_transform
                    )
                    local material_slot_count = math.max(
                        1,
                        math.floor(tonumber(
                            descriptor.material_slot_count
                        ) or 1)
                    )
                    if kind == BlueprintPreviewMesh.SKELETAL then
                        skeletal_entries[#skeletal_entries + 1] = {
                            path = path,
                            mesh = mesh,
                            transform = world_transform,
                            preview_placeholder = preview_placeholder,
                            material_slot_count = material_slot_count,
                        }
                    else
                        local group_key = cache_key
                            .. (preview_placeholder
                                and "|placeholder" or "|original")
                        local group = groups[group_key]
                        if group == nil then
                            group = {
                                path = path,
                                mesh = mesh,
                                transforms = {},
                                preview_placeholder = preview_placeholder,
                                material_slot_count = material_slot_count,
                            }
                            groups[group_key] = group
                            group_order[#group_order + 1] = group
                        else
                            group.material_slot_count = math.max(
                                group.material_slot_count,
                                material_slot_count
                            )
                        end
                        group.transforms[#group.transforms + 1] =
                            world_transform
                    end
                    include_asset_bounds(mesh_bounds, world_transform)
                end
            end
        end)
        if not prepared then return false, tostring(prepare_error) end
        if instance_count == 0 then
            return false, "thumbnail blueprint contains no preview meshes"
        end
        local placeholder_material = nil
        if placeholder_instance_count > 0 then
            local material_error = nil
            placeholder_material, material_error =
                resolve_material_asset(PLACEHOLDER_MATERIAL_PATH)
            if placeholder_material == nil then
                return false, material_error
            end
        end
        local frame = compute_camera_frame(bounds_min, bounds_max)
        local camera_rotation = math_library:FindLookAtRotation(
            frame.location, frame.center
        )

        local components = {}
        local light_components = {}
        local capture_component = nil
        local render_target = nil
        local rendered, render_error = pcall(function()
            for _, spec in ipairs(THUMBNAIL_LIGHT_SPECS) do
                local light = unwrap(owner:AddComponentByClass(
                    directional_light_class, true,
                    identity_transform(), false
                ))
                assert(is_valid_object(light),
                    "thumbnail directional light creation failed")
                light_components[#light_components + 1] = light
                light:SetMobility(2)
                light:SetAbsolute(true, true, true)
                light:SetCastShadows(false)
                light:SetIntensity(spec.intensity)
                light:SetLightColor(spec.color, true)
                pcall(function() light:Activate(true) end)
                pcall(function() light.bAffectsWorld = true end)
                pcall(function()
                    light:SetIndirectLightingIntensity(0.0)
                end)
                pcall(function()
                    light:SetAffectGlobalIllumination(false)
                end)
                pcall(function() light:SetAffectReflection(false) end)
                pcall(function()
                    light:SetVolumetricScatteringIntensity(0.0)
                end)
                pcall(function() light.bAtmosphereSunLight = false end)
                light:K2_SetWorldRotation(
                    {
                        Pitch = (tonumber(camera_rotation.Pitch) or 0.0)
                            + spec.pitch_offset,
                        Yaw = (tonumber(camera_rotation.Yaw) or 0.0)
                            + spec.yaw_offset,
                        Roll = 0.0,
                    },
                    false, {}, true
                )
            end

            for _, group in ipairs(group_order) do
                local component = unwrap(owner:AddComponentByClass(
                    instanced_mesh_class, true, identity_transform(), false
                ))
                assert(is_valid_object(component),
                    "instanced mesh component creation failed path="
                        .. group.path)
                components[#components + 1] = component
                component:SetMobility(2)
                component:SetAbsolute(true, true, true)
                component:SetCollisionEnabled(0)
                component:SetGenerateOverlapEvents(false)
                component:SetCastShadow(false)
                component:SetReceivesDecals(false)
                component:SetRenderInMainPass(true)
                component:SetVisibleInSceneCaptureOnly(true)
                component:SetStaticMesh(group.mesh)
                if group.preview_placeholder then
                    for slot_index = 0,
                        group.material_slot_count - 1 do
                        component:SetMaterial(
                            slot_index, placeholder_material
                        )
                    end
                end
                for _, transform in ipairs(group.transforms) do
                    component:AddInstanceWorldSpace(transform)
                end
                component:SetHiddenInGame(false, true)
                component:SetVisibility(true, true)
            end

            for _, entry in ipairs(skeletal_entries) do
                local component = unwrap(owner:AddComponentByClass(
                    skeletal_mesh_class, true, identity_transform(), false
                ))
                assert(is_valid_object(component),
                    "skeletal mesh component creation failed path="
                        .. entry.path)
                components[#components + 1] = component
                component:SetMobility(2)
                component:SetAbsolute(true, true, true)
                component:SetCollisionEnabled(0)
                component:SetGenerateOverlapEvents(false)
                component:SetCastShadow(false)
                component:SetReceivesDecals(false)
                component:SetRenderInMainPass(true)
                component:SetVisibleInSceneCaptureOnly(true)
                component:SetSkeletalMeshAsset(entry.mesh)
                if entry.preview_placeholder then
                    for slot_index = 0,
                        entry.material_slot_count - 1 do
                        component:SetMaterial(
                            slot_index, placeholder_material
                        )
                    end
                end
                pcall(function() component:SetAnimationMode(1) end)
                pcall(function()
                    component.bPauseAnims = true
                    component.GlobalAnimRateScale = 0.0
                    component:SetComponentTickEnabled(false)
                end)
                component:K2_SetWorldTransform(
                    entry.transform, false, {}, true
                )
                component:SetHiddenInGame(false, true)
                component:SetVisibility(true, true)
            end

            render_target = unwrap(rendering_library:CreateRenderTarget2D(
                owner, CAPTURE_WIDTH, CAPTURE_HEIGHT, 2,
                { R = 0.012, G = 0.018, B = 0.030, A = 1.0 }, false
            ))
            assert(is_valid_object(render_target),
                "CreateRenderTarget2D returned no render target")
            rendering_library:ClearRenderTarget2D(
                owner, render_target,
                { R = 0.012, G = 0.018, B = 0.030, A = 1.0 }
            )
            capture_component = unwrap(owner:AddComponentByClass(
                capture_class, true, identity_transform(), false
            ))
            assert(is_valid_object(capture_component),
                "SceneCaptureComponent2D creation failed")
            capture_component:SetMobility(2)
            capture_component:SetAbsolute(true, true, true)
            capture_component.TextureTarget = render_target
            capture_component.PrimitiveRenderMode = 2
            capture_component.ProjectionType = 0
            capture_component.FOVAngle = CAPTURE_HORIZONTAL_FOV_DEGREES
            capture_component.CaptureSource = 2
            capture_component.bCaptureEveryFrame = false
            capture_component.bCaptureOnMovement = false
            capture_component:ClearShowOnlyComponents()
            for _, component in ipairs(components) do
                capture_component:ShowOnlyComponent(component)
            end

            capture_component:K2_SetWorldLocationAndRotation(
                frame.location, camera_rotation, false, {}, true
            )
            capture_component:CaptureScene()
            rendering_library:ExportRenderTarget(
                owner, render_target, output_directory, file_name
            )
            local png_ready, png_error = read_png_signature(output_path)
            assert(png_ready, png_error)
        end)
        destroy_component(capture_component)
        for index = #components, 1, -1 do
            destroy_component(components[index])
        end
        for index = #light_components, 1, -1 do
            destroy_component(light_components[index])
        end
        if not rendered then
            log("blueprint thumbnail render failed path="
                .. tostring(output_path) .. " error=" .. tostring(render_error))
            return false, tostring(render_error)
        end
        log("blueprint thumbnail rendered path=" .. tostring(output_path)
            .. " buildings=" .. tostring(#blueprint.buildings)
            .. " instances=" .. tostring(instance_count)
            .. " meshGroups=" .. tostring(#group_order)
            .. " skeletalMeshes=" .. tostring(#skeletal_entries)
            .. " placeholderInstances="
                .. tostring(placeholder_instance_count)
            .. " lights=" .. tostring(#THUMBNAIL_LIGHT_SPECS)
            .. " texture=" .. object_name(render_target))
        return true, nil, render_target
    end

    function renderer.probe(output_directory)
        if renderer.probe_attempted then
            return renderer.probe_succeeded,
                renderer.probe_succeeded and nil
                    or "thumbnail capability probe already failed"
        end
        renderer.probe_attempted = true
        if type(output_directory) ~= "string" or output_directory == "" then
            return false, "thumbnail probe output directory is unavailable"
        end

        local owner = unwrap(UEHelpers.GetPlayer())
        local math_library = unwrap(UEHelpers.GetKismetMathLibrary())
        local rendering_library = unwrap(StaticFindObject(
            "/Script/Engine.Default__KismetRenderingLibrary"
        ))
        local capture_class = unwrap(StaticFindObject(
            "/Script/Engine.SceneCaptureComponent2D"
        ))
        if not is_valid_object(owner)
            or not is_valid_object(math_library)
            or not is_valid_object(rendering_library)
            or not is_valid_object(capture_class) then
            return false, "thumbnail probe dependencies are unavailable"
        end

        local capture_component = nil
        local render_target = nil
        local texture = nil
        local file_name = "SBB_ThumbnailCapabilityProbe.png"
        local output_path = output_directory .. "\\" .. file_name
        local ok, error_value = pcall(function()
            render_target = unwrap(rendering_library:CreateRenderTarget2D(
                owner, 256, 144, 2,
                { R = 0.015, G = 0.020, B = 0.030, A = 1.0 }, false
            ))
            assert(is_valid_object(render_target),
                "CreateRenderTarget2D returned no render target")
            rendering_library:ClearRenderTarget2D(
                owner, render_target,
                { R = 0.015, G = 0.020, B = 0.030, A = 1.0 }
            )

            capture_component = unwrap(owner:AddComponentByClass(
                capture_class, true, identity_transform(), false
            ))
            assert(is_valid_object(capture_component),
                "SceneCaptureComponent2D creation failed")
            capture_component:SetMobility(2)
            capture_component:SetAbsolute(true, true, true)
            capture_component.TextureTarget = render_target
            capture_component.PrimitiveRenderMode = 2
            capture_component.ProjectionType = 0
            capture_component.FOVAngle = 40.0
            capture_component.CaptureSource = 2
            capture_component.bCaptureEveryFrame = false
            capture_component.bCaptureOnMovement = false
            capture_component:ClearShowOnlyComponents()
            capture_component:ShowOnlyActorComponents(owner, true)

            local target_location = owner:K2_GetActorLocation()
            local camera_location = {
                X = (tonumber(target_location.X) or 0.0) - 260.0,
                Y = (tonumber(target_location.Y) or 0.0) - 260.0,
                Z = (tonumber(target_location.Z) or 0.0) + 190.0,
            }
            local camera_rotation = math_library:FindLookAtRotation(
                camera_location, target_location
            )
            capture_component:K2_SetWorldLocationAndRotation(
                camera_location, camera_rotation, false, {}, true
            )
            capture_component:CaptureScene()
            rendering_library:ExportRenderTarget(
                owner, render_target, output_directory, file_name
            )

            local file = assert(io.open(output_path, "rb"),
                "ExportRenderTarget did not create the PNG")
            local signature = file:read(8)
            file:close()
            assert(signature == "\137PNG\13\10\26\10",
                "ExportRenderTarget output is not a PNG")
            texture = unwrap(rendering_library:ImportFileAsTexture2D(
                owner, output_path
            ))
            assert(is_valid_object(texture),
                "ImportFileAsTexture2D returned no texture")
        end)
        destroy_component(capture_component)

        if not ok then
            log("blueprint thumbnail capability probe failed error="
                .. tostring(error_value))
            return false, tostring(error_value)
        end
        renderer.probe_succeeded = true
        renderer.probe_path = output_path
        log("blueprint thumbnail capability probe succeeded capture="
            .. object_name(texture) .. " path=" .. output_path)
        return true, nil
    end

    function renderer.get_probe_state()
        return {
            attempted = renderer.probe_attempted,
            succeeded = renderer.probe_succeeded,
            path = renderer.probe_path,
        }
    end

    return renderer
end

return BlueprintThumbnailRenderer

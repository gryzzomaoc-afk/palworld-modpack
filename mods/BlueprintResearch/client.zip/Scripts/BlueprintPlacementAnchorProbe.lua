local BlueprintPerformance = require("BlueprintPerformance")

local AnchorProbe = {}

local STRATEGY_OBJECT_PROPERTIES = {
    "TargetBuildObject",
    "ReplaceTargetBuildObject",
    "SnapHitBuildObjectCache",
    "SnapHitActorCache",
    "HitBuildObjectCache",
}

local CHECKER_RESULT_PROPERTIES = {
    "OperationResult",
    "CurrentOperationResult",
    "InstallResult",
    "Result",
}

local STOCK_INVALID_PREVIEW_SCALE = 1.02
local STOCK_INVALID_PREVIEW_SCALE_TOLERANCE = 0.001

local function array_count(value)
    local count = 0
    pcall(function() count = #value end)
    return count
end

function AnchorProbe.install(deps)
    deps = type(deps) == "table" and deps or {}
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object dependency is required"
    )
    local safe_property = assert(
        deps.safe_property, "safe_property dependency is required"
    )
    local safe_object_address = assert(
        deps.safe_object_address,
        "safe_object_address dependency is required"
    )
    local object_name = assert(
        deps.object_name, "object_name dependency is required"
    )
    local value_to_string = assert(
        deps.value_to_string, "value_to_string dependency is required"
    )
    local format_transform = assert(
        deps.format_transform, "format_transform dependency is required"
    )
    local format_vector = assert(
        deps.format_vector, "format_vector dependency is required"
    )
    local get_math_library = assert(
        deps.get_math_library, "get_math_library dependency is required"
    )
    local log_probe = deps.log_probe or function() end
    local enabled = deps.enabled == true

    local controller = {
        enabled = enabled,
        last_signature = nil,
        sample_count = 0,
    }

    local function number_property(value, property_name)
        return tonumber(safe_property(value, property_name))
    end

    local function vector_numbers(value)
        if value == nil then return nil end
        local x = number_property(value, "X")
        local y = number_property(value, "Y")
        local z = number_property(value, "Z")
        if x == nil or y == nil or z == nil then return nil end
        return { x = x, y = y, z = z }
    end

    local function quaternion_numbers(value)
        if value == nil then return nil end
        local x = number_property(value, "X")
        local y = number_property(value, "Y")
        local z = number_property(value, "Z")
        local w = number_property(value, "W")
        if x == nil or y == nil or z == nil or w == nil then
            return nil
        end
        return { x = x, y = y, z = z, w = w }
    end

    local function rotate_vector(rotation, vector)
        -- q * v * inverse(q), expanded to avoid another reflected UE call.
        local tx = 2.0 * (
            rotation.y * vector.z - rotation.z * vector.y
        )
        local ty = 2.0 * (
            rotation.z * vector.x - rotation.x * vector.z
        )
        local tz = 2.0 * (
            rotation.x * vector.y - rotation.y * vector.x
        )
        return {
            x = vector.x + rotation.w * tx
                + rotation.y * tz - rotation.z * ty,
            y = vector.y + rotation.w * ty
                + rotation.z * tx - rotation.x * tz,
            z = vector.z + rotation.w * tz
                + rotation.x * ty - rotation.y * tx,
        }
    end

    local function local_bounds_snapshot(anchor)
        local bounds = safe_property(anchor, "LocalBounds")
        local minimum = bounds and vector_numbers(
            safe_property(bounds, "Min")
        ) or nil
        local maximum = bounds and vector_numbers(
            safe_property(bounds, "Max")
        ) or nil
        if minimum == nil or maximum == nil then return nil end
        return {
            minimum = minimum,
            maximum = maximum,
            center = {
                x = (minimum.x + maximum.x) * 0.5,
                y = (minimum.y + maximum.y) * 0.5,
                z = (minimum.z + maximum.z) * 0.5,
            },
        }
    end

    local function box_snapshot(value)
        if value == nil then return nil end
        local minimum = vector_numbers(safe_property(value, "Min"))
        local maximum = vector_numbers(safe_property(value, "Max"))
        if minimum == nil or maximum == nil then return nil end
        return {
            minimum = minimum,
            maximum = maximum,
            center = {
                x = (minimum.x + maximum.x) * 0.5,
                y = (minimum.y + maximum.y) * 0.5,
                z = (minimum.z + maximum.z) * 0.5,
            },
        }
    end

    local function component_local_bounds_snapshot(component)
        component = unwrap(component)
        if not is_valid_object(component) then return nil end
        local minimum = {}
        local maximum = {}
        local ok = pcall(function()
            component:GetLocalBounds(minimum, maximum)
        end)
        if not ok then return nil end
        local minimum_value = vector_numbers(minimum)
        local maximum_value = vector_numbers(maximum)
        if minimum_value == nil or maximum_value == nil then return nil end
        return {
            minimum = minimum_value,
            maximum = maximum_value,
            center = {
                x = (minimum_value.x + maximum_value.x) * 0.5,
                y = (minimum_value.y + maximum_value.y) * 0.5,
                z = (minimum_value.z + maximum_value.z) * 0.5,
            },
        }
    end

    local function static_mesh_bounds_snapshot(component)
        component = unwrap(component)
        if not is_valid_object(component) then return nil end
        local mesh = unwrap(safe_property(component, "StaticMesh"))
        if not is_valid_object(mesh) then return nil end
        local box = nil
        pcall(function() box = mesh:GetBoundingBox() end)
        return box_snapshot(box)
    end

    local function actor_world_bounds_snapshot(anchor)
        anchor = unwrap(anchor)
        if not is_valid_object(anchor) then return nil end
        local origin = {}
        local extent = {}
        local ok = pcall(function()
            anchor:GetActorBounds(false, origin, extent, true)
        end)
        if not ok then return nil end
        local origin_value = vector_numbers(origin)
        local extent_value = vector_numbers(extent)
        if origin_value == nil or extent_value == nil then return nil end
        return {
            origin = origin_value,
            extent = extent_value,
        }
    end

    local function deterministic_canonical_snapshot(anchor, raw_transform)
        local translation = raw_transform and vector_numbers(
            safe_property(raw_transform, "Translation")
        ) or nil
        local rotation = raw_transform and quaternion_numbers(
            safe_property(raw_transform, "Rotation")
        ) or nil
        local scale = raw_transform and vector_numbers(
            safe_property(raw_transform, "Scale3D")
        ) or nil
        local bounds = local_bounds_snapshot(anchor)
        if translation == nil or rotation == nil or scale == nil
            or bounds == nil then
            return nil
        end
        local presentation_scale =
            math.abs(scale.x - STOCK_INVALID_PREVIEW_SCALE)
                <= STOCK_INVALID_PREVIEW_SCALE_TOLERANCE
            and math.abs(scale.y - STOCK_INVALID_PREVIEW_SCALE)
                <= STOCK_INVALID_PREVIEW_SCALE_TOLERANCE
            and math.abs(scale.z - STOCK_INVALID_PREVIEW_SCALE)
                <= STOCK_INVALID_PREVIEW_SCALE_TOLERANCE
        local target_scale = presentation_scale
            and { x = 1.0, y = 1.0, z = 1.0 }
            or { x = scale.x, y = scale.y, z = scale.z }
        local local_pivot_offset = {
            x = (target_scale.x - scale.x) * bounds.center.x,
            y = (target_scale.y - scale.y) * bounds.center.y,
            z = (target_scale.z - scale.z) * bounds.center.z,
        }
        local world_pivot_offset =
            rotate_vector(rotation, local_pivot_offset)
        return {
            presentation_scale = presentation_scale,
            bounds = bounds,
            local_pivot_offset = local_pivot_offset,
            world_pivot_offset = world_pivot_offset,
            translation = {
                x = translation.x - world_pivot_offset.x,
                y = translation.y - world_pivot_offset.y,
                z = translation.z - world_pivot_offset.z,
            },
            rotation = rotation,
            scale = target_scale,
        }
    end

    local function vector_text(value)
        if value == nil then return "(nil)" end
        return string.format(
            "(%.6f,%.6f,%.6f)",
            tonumber(value.x) or 0.0,
            tonumber(value.y) or 0.0,
            tonumber(value.z) or 0.0
        )
    end

    local function bounds_snapshot_text(value)
        if value == nil then return "<unavailable>" end
        return "min=" .. vector_text(value.minimum)
            .. ",max=" .. vector_text(value.maximum)
            .. ",center=" .. vector_text(value.center)
    end

    local function quaternion_text(value)
        if value == nil then return "(nil)" end
        return string.format(
            "(%.6f,%.6f,%.6f,%.6f)",
            tonumber(value.x) or 0.0,
            tonumber(value.y) or 0.0,
            tonumber(value.z) or 0.0,
            tonumber(value.w) or 1.0
        )
    end

    local function identity(value)
        value = unwrap(value)
        if not is_valid_object(value) then
            return "<invalid>@<nil>"
        end
        return tostring(object_name(value))
            .. "@" .. tostring(safe_object_address(value))
    end

    local function actor_transform(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local transform = nil
        pcall(function() transform = value:GetTransform() end)
        return transform
    end

    local function component_transform(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local transform = nil
        pcall(function()
            transform = value:K2_GetComponentToWorld()
        end)
        return transform
    end

    local function model_of(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local model = nil
        pcall(function() model = unwrap(value:GetModel()) end)
        if not is_valid_object(model) then
            model = unwrap(safe_property(value, "MapObjectModel"))
        end
        return is_valid_object(model) and model or nil
    end

    local function model_transform(value)
        local model = model_of(value)
        if not is_valid_object(model) then return nil end
        return safe_property(model, "InitialTransformCache")
    end

    local function reference_transform(value)
        return model_transform(value)
            or actor_transform(value)
            or component_transform(value)
    end

    local function relative_transform(value, reference)
        local value_transform = reference_transform(value)
        local reference_value = reference_transform(reference)
        local math_library = unwrap(get_math_library())
        if value_transform == nil or reference_value == nil
            or not is_valid_object(math_library) then
            return nil
        end
        local relative = nil
        pcall(function()
            relative = math_library:MakeRelativeTransform(
                value_transform, reference_value
            )
        end)
        return relative
    end

    local function bounds_text(component)
        component = unwrap(component)
        if not is_valid_object(component) then return "<unavailable>" end
        local bounds = safe_property(component, "Bounds")
        if bounds == nil then return "<unavailable>" end
        return "origin=" .. format_vector(safe_property(bounds, "Origin"))
            .. ",extent="
            .. format_vector(safe_property(bounds, "BoxExtent"))
            .. ",sphere="
            .. tostring(tonumber(safe_property(bounds, "SphereRadius")))
    end

    local function component_text(component)
        component = unwrap(component)
        if not is_valid_object(component) then return "<invalid>" end
        return string.format(
            "%s world={%s} relativeLocation=%s relativeRotation=%s relativeScale=%s bounds={%s}",
            identity(component),
            format_transform(component_transform(component)),
            format_vector(safe_property(component, "RelativeLocation")),
            tostring(value_to_string(
                safe_property(component, "RelativeRotation")
            )),
            format_vector(safe_property(component, "RelativeScale3D")),
            bounds_text(component)
        )
    end

    local function object_text(value, snap_reference)
        value = unwrap(value)
        if not is_valid_object(value) then return "<invalid>" end
        local root = unwrap(safe_property(value, "RootComponent"))
        return string.format(
            "%s actor={%s} model={%s} root={%s} relativeToSnap={%s}",
            identity(value),
            format_transform(actor_transform(value)),
            format_transform(model_transform(value)),
            format_transform(component_transform(root)),
            format_transform(relative_transform(value, snap_reference))
        )
    end

    local function readable_checker_result(checker)
        for _, property_name in ipairs(CHECKER_RESULT_PROPERTIES) do
            local value = safe_property(checker, property_name)
            if value ~= nil then
                return property_name .. "=" .. value_to_string(value)
            end
        end
        return "<no-reflected-result-property>"
    end

    local function first_valid_strategy_reference(strategy)
        for _, property_name in ipairs({
            "SnapHitBuildObjectCache",
            "HitBuildObjectCache",
            "SnapHitActorCache",
            "ReplaceTargetBuildObject",
        }) do
            local value = unwrap(safe_property(strategy, property_name))
            if is_valid_object(value) then return value, property_name end
        end
        return nil, "<none>"
    end

    local function mesh_components(anchor)
        local values = {}
        local seen = {}
        local function add(value)
            value = unwrap(value)
            local address = safe_object_address(value)
            if is_valid_object(value) and address ~= nil
                and not seen[address] then
                seen[address] = true
                values[#values + 1] = value
            end
        end
        local meshes = safe_property(anchor, "AllMeshes")
        for index = 1, array_count(meshes) do
            local mesh = nil
            pcall(function() mesh = meshes[index] end)
            add(mesh)
        end
        add(safe_property(anchor, "MainMesh"))
        return values
    end

    function controller.observe(references, source)
        if not enabled or type(references) ~= "table" then return false end
        local started_at = BlueprintPerformance.now()
        local builder = unwrap(references.builder)
        local checker = unwrap(references.checker)
        local anchor = unwrap(references.anchor)
        if not is_valid_object(builder)
            or not is_valid_object(checker)
            or not is_valid_object(anchor) then
            return false
        end

        local strategy = unwrap(safe_property(
            checker, "InstallStrategy"
        ))
        local snap_reference, snap_reference_property =
            first_valid_strategy_reference(strategy)
        local raw_transform = actor_transform(anchor)
        local enable_build = "<unavailable>"
        pcall(function()
            enable_build = value_to_string(builder:IsEnableBuild())
        end)
        local signature = table.concat({
            tostring(safe_object_address(anchor)),
            format_transform(raw_transform),
            tostring(enable_build),
            identity(strategy),
            tostring(snap_reference_property),
            identity(snap_reference),
            readable_checker_result(checker),
        }, "|")
        if signature == controller.last_signature then return false end
        controller.last_signature = signature
        controller.sample_count = controller.sample_count + 1

        log_probe(string.format(
            "blueprint performance placement-anchor-context sample=%d source=%s enableBuild=%s checkerResult=%s builder=%s checker=%s strategy=%s snapReferenceProperty=%s snapReference=%s anchor=%s elapsedMs=%.3f",
            controller.sample_count,
            tostring(source or "unknown"),
            tostring(enable_build),
            readable_checker_result(checker),
            identity(builder),
            identity(checker),
            identity(strategy),
            tostring(snap_reference_property),
            identity(snap_reference),
            object_text(anchor, snap_reference),
            BlueprintPerformance.elapsed_ms(started_at)
        ))

        local canonical =
            deterministic_canonical_snapshot(anchor, raw_transform)
        if canonical ~= nil then
            log_probe(string.format(
                "blueprint performance placement-anchor-canonical sample=%d presentationScale=%s localBoundsMin=%s localBoundsMax=%s localBoundsCenter=%s localPivotOffset=%s worldPivotOffset=%s canonical={T%s R%s S%s}",
                controller.sample_count,
                tostring(canonical.presentation_scale),
                vector_text(canonical.bounds.minimum),
                vector_text(canonical.bounds.maximum),
                vector_text(canonical.bounds.center),
                vector_text(canonical.local_pivot_offset),
                vector_text(canonical.world_pivot_offset),
                vector_text(canonical.translation),
                quaternion_text(canonical.rotation),
                vector_text(canonical.scale)
            ))
        else
            log_probe(string.format(
                "blueprint performance placement-anchor-canonical sample=%d unavailable=true",
                controller.sample_count
            ))
        end

        local root = unwrap(safe_property(anchor, "RootComponent"))
        local overlap_component = unwrap(safe_property(
            checker, "OverlapComponent"
        ))
        local overlap_checker = unwrap(safe_property(
            checker, "OverlapChecker"
        ))
        local overlap_collision = unwrap(safe_property(
            overlap_checker, "Collision"
        ))
        local actor_overlap_collision = unwrap(safe_property(
            anchor, "OverlapCheckCollision"
        ))
        log_probe(string.format(
            "blueprint performance placement-anchor-components sample=%d root={%s} checkerOverlap={%s} checkerCollision={%s} actorCollision={%s}",
            controller.sample_count,
            component_text(root),
            component_text(overlap_component),
            component_text(overlap_collision),
            component_text(actor_overlap_collision)
        ))

        for index, mesh in ipairs(mesh_components(anchor)) do
            if index > 8 then break end
            log_probe(string.format(
                "blueprint performance placement-anchor-mesh sample=%d item=%d component={%s}",
                controller.sample_count, index, component_text(mesh)
            ))
            log_probe(string.format(
                "blueprint performance placement-anchor-mesh-bounds sample=%d item=%d componentLocal={%s} staticMeshAsset={%s}",
                controller.sample_count,
                index,
                bounds_snapshot_text(
                    component_local_bounds_snapshot(mesh)
                ),
                bounds_snapshot_text(
                    static_mesh_bounds_snapshot(mesh)
                )
            ))
        end

        local actor_world_bounds =
            actor_world_bounds_snapshot(anchor)
        log_probe(string.format(
            "blueprint performance placement-anchor-actor-bounds sample=%d origin=%s extent=%s",
            controller.sample_count,
            vector_text(
                actor_world_bounds and actor_world_bounds.origin
            ),
            vector_text(
                actor_world_bounds and actor_world_bounds.extent
            )
        ))

        for _, property_name in ipairs(
            STRATEGY_OBJECT_PROPERTIES
        ) do
            local value = unwrap(safe_property(strategy, property_name))
            log_probe(string.format(
                "blueprint performance placement-anchor-strategy-object sample=%d property=%s value={%s}",
                controller.sample_count,
                property_name,
                object_text(value, snap_reference)
            ))
        end
        return true
    end

    function controller.reset()
        controller.last_signature = nil
    end

    if enabled then
        log_probe(
            "blueprint performance placement-anchor-context-probe-ready"
        )
    end
    return controller
end

return AnchorProbe

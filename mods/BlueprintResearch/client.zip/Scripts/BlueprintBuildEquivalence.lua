-- Pure-data matching for blueprint records which already exist in the world.
--
-- All locations are Palworld/Unreal centimetres. No UObject or UE4SS wrapper
-- may enter or leave this module.

local Equivalence = {}

Equivalence.DEFAULT_POSITION_TOLERANCE = 3.0
Equivalence.DEFAULT_ANGLE_TOLERANCE_DEGREES = 1.0
-- Palworld presents invalid/occupied anchors at 102% scale. If that
-- presentation frame is reused as the blueprint root, every 400 cm grid
-- interval expands by eight centimetres. Invalid previews are also presented
-- two centimetres above their canonical model frame. These values are stock
-- presentation constants, not equivalence tolerances.
Equivalence.STOCK_INVALID_PREVIEW_SCALE = 1.02
Equivalence.STOCK_INVALID_PREVIEW_SCALE_TOLERANCE = 0.001
Equivalence.STOCK_INVALID_PREVIEW_Z_OFFSET_CM = 2.0

local function number_field(value, lower_name, upper_name)
    if type(value) ~= "table" then return nil end
    return tonumber(value[lower_name] ~= nil
        and value[lower_name] or value[upper_name])
end

local function vector(value)
    local x = number_field(value, "x", "X")
    local y = number_field(value, "y", "Y")
    local z = number_field(value, "z", "Z")
    if x == nil or y == nil or z == nil then return nil end
    return { x = x, y = y, z = z }
end

local function quaternion(value)
    local x = number_field(value, "x", "X")
    local y = number_field(value, "y", "Y")
    local z = number_field(value, "z", "Z")
    local w = number_field(value, "w", "W")
    if x == nil or y == nil or z == nil or w == nil then return nil end
    local magnitude = math.sqrt(x * x + y * y + z * z + w * w)
    if magnitude <= 1.0e-8 then return nil end
    return {
        x = x / magnitude,
        y = y / magnitude,
        z = z / magnitude,
        w = w / magnitude,
    }
end

local function normalized_build_object_id(value)
    return string.lower(tostring(value or ""))
end

local function contains_any(value, tokens)
    for _, token in ipairs(tokens) do
        if string.find(value, token, 1, true) ~= nil then return true end
    end
    return false
end

-- Returns the smallest yaw period which produces an equivalent state.
-- A 360-degree period means only the original orientation is equivalent.
function Equivalence.rotation_period_degrees(build_object_id, install_strategy)
    local id = normalized_build_object_id(build_object_id)
    -- Stairs are directional even when a broad install strategy or naming
    -- fallback might otherwise look structural.
    if contains_any(id, { "stair" }) then return 360 end
    if contains_any(id, { "foundation" }) then return 90 end
    if contains_any(id, { "wall" }) then return 180 end
    if tonumber(install_strategy) == 13
        or contains_any(id, { "pillar", "column" }) then
        return 90
    end
    return 360
end

local function multiply_quaternion(left, right)
    return {
        x = left.w * right.x + left.x * right.w
            + left.y * right.z - left.z * right.y,
        y = left.w * right.y - left.x * right.z
            + left.y * right.w + left.z * right.x,
        z = left.w * right.z + left.x * right.y
            - left.y * right.x + left.z * right.w,
        w = left.w * right.w - left.x * right.x
            - left.y * right.y - left.z * right.z,
    }
end

local function yaw_quaternion(degrees)
    local half_radians = math.rad(degrees) * 0.5
    return {
        x = 0.0,
        y = 0.0,
        z = math.sin(half_radians),
        w = math.cos(half_radians),
    }
end

local function angular_error_degrees(left, right)
    local dot = math.abs(
        left.x * right.x + left.y * right.y
            + left.z * right.z + left.w * right.w
    )
    dot = math.max(-1.0, math.min(dot, 1.0))
    return math.deg(2.0 * math.acos(dot))
end

local function equivalent_rotation_error(
    expected, candidate, build_object_id, install_strategy
)
    local period =
        Equivalence.rotation_period_degrees(build_object_id, install_strategy)
    local best_error = math.huge
    local best_yaw = nil
    for yaw = 0, 359, period do
        local equivalent = multiply_quaternion(
            expected, yaw_quaternion(yaw)
        )
        local error_degrees =
            angular_error_degrees(equivalent, candidate)
        if error_degrees < best_error then
            best_error = error_degrees
            best_yaw = yaw
        end
    end
    return best_error, best_yaw
end

local function record_location(record)
    return vector(record and (
        record.model_location or record.location
    ))
end

local function record_rotation(record)
    return quaternion(record and (
        record.model_rotation or record.rotation
    ))
end

local function record_scale(record)
    return vector(record and (
        record.model_scale or record.scale
    )) or { x = 1.0, y = 1.0, z = 1.0 }
end

local function approximately(value, expected, tolerance)
    return math.abs(value - expected) <= tolerance
end

function Equivalence.is_stock_invalid_anchor_preview(record)
    if type(record) ~= "table" then return false end
    local scale = record_scale(record)
    local expected = Equivalence.STOCK_INVALID_PREVIEW_SCALE
    local tolerance =
        Equivalence.STOCK_INVALID_PREVIEW_SCALE_TOLERANCE
    return approximately(scale.x, expected, tolerance)
        and approximately(scale.y, expected, tolerance)
        and approximately(scale.z, expected, tolerance)
end

-- Removes stock invalid-preview presentation from an anchor model frame.
-- Both scale and translation correction are presentation-frame rules and are
-- therefore type-independent. This function does not assert that the object
-- occupying the preview position is equivalent.
function Equivalence.normalize_stock_invalid_anchor_preview(record)
    if not Equivalence.is_stock_invalid_anchor_preview(record) then
        return nil
    end
    local location = record_location(record)
    local rotation = record_rotation(record)
    if location == nil or rotation == nil then return nil end
    local raw_scale = record_scale(record)
    local z_offset = Equivalence.STOCK_INVALID_PREVIEW_Z_OFFSET_CM
    return {
        status = "normalized-presentation",
        presentation_normalized = true,
        translation_normalized = z_offset ~= 0.0,
        normalization_kind = "stock-invalid-scale-and-z",
        correction_delta = { x = 0.0, y = 0.0, z = -z_offset },
        raw_model_scale = raw_scale,
        corrected_model_scale = { x = 1.0, y = 1.0, z = 1.0 },
        corrected_model_transform = {
            translation = {
                x = location.x,
                y = location.y,
                z = location.z - z_offset,
            },
            rotation = rotation,
            scale = { x = 1.0, y = 1.0, z = 1.0 },
        },
    }
end

function Equivalence.compare(expected, candidate, options)
    options = options or {}
    if type(expected) ~= "table" or type(candidate) ~= "table" then
        return false, { reason = "record-unavailable" }
    end
    local expected_id =
        normalized_build_object_id(expected.build_object_id)
    local candidate_id =
        normalized_build_object_id(candidate.build_object_id)
    if expected_id == "" or candidate_id == ""
        or expected_id ~= candidate_id then
        return false, { reason = "build-object-id-mismatch" }
    end

    local expected_location = record_location(expected)
    local candidate_location = record_location(candidate)
    local expected_rotation = record_rotation(expected)
    local candidate_rotation = record_rotation(candidate)
    if expected_location == nil or candidate_location == nil
        or expected_rotation == nil or candidate_rotation == nil then
        return false, { reason = "transform-unavailable" }
    end

    local dx = expected_location.x - candidate_location.x
    local dy = expected_location.y - candidate_location.y
    local dz = expected_location.z - candidate_location.z
    local position_error = math.sqrt(dx * dx + dy * dy + dz * dz)
    local position_tolerance = math.max(
        tonumber(options.position_tolerance)
            or Equivalence.DEFAULT_POSITION_TOLERANCE,
        0.0
    )
    local angle_error, matched_equivalent_yaw =
        equivalent_rotation_error(
            expected_rotation, candidate_rotation,
            expected.build_object_id, expected.install_strategy
        )
    local angle_tolerance = math.max(
        tonumber(options.angle_tolerance_degrees)
            or Equivalence.DEFAULT_ANGLE_TOLERANCE_DEGREES,
        0.0
    )
    if position_error > position_tolerance then
        return false, {
            reason = "position-outside-tolerance",
            position_error = position_error,
            position_tolerance = position_tolerance,
            angle_error_degrees = angle_error,
            angle_tolerance_degrees = angle_tolerance,
            matched_equivalent_yaw = matched_equivalent_yaw,
            expected_location = expected_location,
            candidate_location = candidate_location,
            expected_rotation = expected_rotation,
            candidate_rotation = candidate_rotation,
        }
    end

    if angle_error > angle_tolerance then
        return false, {
            reason = "rotation-outside-tolerance",
            position_error = position_error,
            angle_error_degrees = angle_error,
            angle_tolerance_degrees = angle_tolerance,
            matched_equivalent_yaw = matched_equivalent_yaw,
            expected_location = expected_location,
            candidate_location = candidate_location,
            expected_rotation = expected_rotation,
            candidate_rotation = candidate_rotation,
        }
    end

    return true, {
        reason = "equivalent",
        position_error = position_error,
        position_tolerance = position_tolerance,
        angle_error_degrees = angle_error,
        angle_tolerance_degrees = angle_tolerance,
        matched_equivalent_yaw = matched_equivalent_yaw,
        expected_location = expected_location,
        candidate_location = candidate_location,
        expected_rotation = expected_rotation,
        candidate_rotation = candidate_rotation,
    }
end

local function grid_coordinate(value, cell_size)
    return math.floor(value / cell_size)
end

local function bucket_key(build_object_id, x, y, z)
    return table.concat({
        normalized_build_object_id(build_object_id),
        tostring(x), tostring(y), tostring(z),
    }, "|")
end

local function expectation_less(left, right)
    local left_index = tonumber(left.selection_index) or math.huge
    local right_index = tonumber(right.selection_index) or math.huge
    if left_index ~= right_index then return left_index < right_index end
    return tostring(left.source_instance_id or "")
        < tostring(right.source_instance_id or "")
end

-- Performs deterministic one-to-one matching. A world building can satisfy
-- only one blueprint member, even if duplicate blueprint records share a
-- centre and orientation.
function Equivalence.match(expectations, candidates, options)
    options = options or {}
    local position_tolerance = math.max(
        tonumber(options.position_tolerance)
            or Equivalence.DEFAULT_POSITION_TOLERANCE,
        0.001
    )
    local buckets = {}
    local indexed_candidate_count = 0
    for candidate_ordinal, candidate in ipairs(candidates or {}) do
        local location = record_location(candidate)
        local build_object_id = candidate and candidate.build_object_id
        if location ~= nil
            and normalized_build_object_id(build_object_id) ~= "" then
            local key = bucket_key(
                build_object_id,
                grid_coordinate(location.x, position_tolerance),
                grid_coordinate(location.y, position_tolerance),
                grid_coordinate(location.z, position_tolerance)
            )
            buckets[key] = buckets[key] or {}
            candidate.ordinal =
                tonumber(candidate.ordinal) or candidate_ordinal
            table.insert(buckets[key], candidate)
            indexed_candidate_count = indexed_candidate_count + 1
        end
    end

    local ordered_expectations = {}
    for _, expectation in ipairs(expectations or {}) do
        table.insert(ordered_expectations, expectation)
    end
    table.sort(ordered_expectations, expectation_less)

    local claimed_candidates = {}
    local matches_by_source_id = {}
    local candidate_checks = 0
    local bucket_visits = 0
    local matched_count = 0
    for _, expectation in ipairs(ordered_expectations) do
        local location = record_location(expectation)
        local source_id = expectation.source_instance_id
        if location ~= nil and source_id ~= nil then
            local base_x = grid_coordinate(location.x, position_tolerance)
            local base_y = grid_coordinate(location.y, position_tolerance)
            local base_z = grid_coordinate(location.z, position_tolerance)
            local best_candidate = nil
            local best_details = nil
            for offset_x = -1, 1 do
                for offset_y = -1, 1 do
                    for offset_z = -1, 1 do
                        local bucket = buckets[bucket_key(
                            expectation.build_object_id,
                            base_x + offset_x,
                            base_y + offset_y,
                            base_z + offset_z
                        )]
                        bucket_visits = bucket_visits + 1
                        for _, candidate in ipairs(bucket or {}) do
                            local candidate_key = candidate.instance_id
                                or candidate.actor_address
                                or candidate.ordinal
                            if not claimed_candidates[candidate_key] then
                                candidate_checks = candidate_checks + 1
                                local equivalent, details =
                                    Equivalence.compare(
                                        expectation, candidate, options
                                    )
                                if equivalent and (
                                    best_details == nil
                                    or details.position_error
                                        < best_details.position_error
                                    or (
                                        details.position_error
                                            == best_details.position_error
                                        and details.angle_error_degrees
                                            < best_details.angle_error_degrees
                                    )
                                    or (
                                        details.position_error
                                            == best_details.position_error
                                        and details.angle_error_degrees
                                            == best_details.angle_error_degrees
                                        and (candidate.ordinal or math.huge)
                                            < (
                                                best_candidate.ordinal
                                                    or math.huge
                                            )
                                    )
                                ) then
                                    best_candidate = candidate
                                    best_details = details
                                end
                            end
                        end
                    end
                end
            end
            if best_candidate ~= nil then
                local candidate_key = best_candidate.instance_id
                    or best_candidate.actor_address
                    or best_candidate.ordinal
                claimed_candidates[candidate_key] = source_id
                matches_by_source_id[source_id] = {
                    candidate = best_candidate,
                    details = best_details,
                }
                matched_count = matched_count + 1
            end
        end
    end

    return {
        matches_by_source_id = matches_by_source_id,
        matched_count = matched_count,
        expectation_count = #ordered_expectations,
        indexed_candidate_count = indexed_candidate_count,
        candidate_checks = candidate_checks,
        bucket_visits = bucket_visits,
    }
end

return Equivalence

local UEHelpers = require("UEHelpers")
local BlueprintJsonSchema = require("BlueprintJsonSchema")
local BlueprintPreviewMesh = require("BlueprintPreviewMesh")
local RuntimeUtils = require("BlueprintRuntimeUtils")

local BlueprintSelectionData = {}
local BlueprintTypeRuntimeCache = {}
local log = function(message) print("[BlueprintSelectionData] " .. tostring(message)) end
local PLACEHOLDER_MESH_PATH = "/Engine/BasicShapes/Cube.Cube"
local PLACEHOLDER_BOX_EXTENT = { x = 150.0, y = 150.0, z = 100.0 }

local unwrap = RuntimeUtils.unwrap
local is_valid_object = RuntimeUtils.is_valid_object
local is_usable_class_object = RuntimeUtils.is_usable_class_object
local class_object_name = RuntimeUtils.class_object_name
local object_name = RuntimeUtils.object_name
local value_to_string = RuntimeUtils.value_to_string
local safe_property = RuntimeUtils.safe_property
local format_guid = RuntimeUtils.format_guid
local copy_transform = RuntimeUtils.copy_transform
local get_asset_path = RuntimeUtils.get_asset_path
local format_transform = RuntimeUtils.format_transform
local copy_vector = RuntimeUtils.copy_vector
local safe_object_address = RuntimeUtils.safe_object_address

function BlueprintSelectionData.install(deps)
    deps = deps or {}
    if type(deps.log) == "function" then log = deps.log end
    return BlueprintSelectionData
end

local function get_build_object_identity(build_object)
    build_object = unwrap(build_object)
    if not is_valid_object(build_object) then return nil end

    local model = nil
    pcall(function() model = build_object:GetModel() end)
    model = unwrap(model)
    if not is_valid_object(model) then return nil end

    local build_object_id = value_to_string(safe_property(model, "BuildObjectId"))
    local source_instance_id = format_guid(safe_property(model, "InstanceId"))
    if build_object_id == "None" or build_object_id == "<nil>"
        or source_instance_id == "<nil>"
        or source_instance_id == "None"
        or source_instance_id
            == "00000000-00000000-00000000-00000000" then
        return nil
    end

    return {
        source_instance_id = source_instance_id,
        build_object_id = build_object_id,
        map_object_master_data_id = value_to_string(
            safe_property(model, "MapObjectMasterDataId")
        ),
    }, model
end

local function make_identity_record(identity, source)
    if type(identity) ~= "table"
        or identity.source_instance_id == nil
        or identity.build_object_id == nil then
        return nil
    end
    return {
        source = tostring(source),
        build_object_id = identity.build_object_id,
        map_object_master_data_id = identity.map_object_master_data_id,
        source_instance_id = identity.source_instance_id,
    }
end

local function make_building_record(build_object, source, suppress_success_log)
    build_object = unwrap(build_object)
    if not is_valid_object(build_object) then
        log("selection record aborted: target is invalid source=" .. tostring(source))
        return nil
    end

    local identity, model = get_build_object_identity(build_object)
    if identity == nil then
        log("selection record aborted: target identity is invalid target="
            .. object_name(build_object))
        return nil
    end

    local model_transform = safe_property(model, "InitialTransformCache")
    local build_object_class = nil
    pcall(function() build_object_class = build_object:GetClass() end)
    local record = make_identity_record(identity, source)
    record.world_transform = copy_transform(model_transform)
    record.build_object_class_path = get_asset_path(build_object_class)
    if record.build_object_class_path == nil then
        log("selection record aborted: target class path unavailable target="
            .. object_name(build_object))
        return nil
    end
    if not suppress_success_log then
        log(string.format(
            "selection record source=%s target=%s model=%s instance=%s build=%s map=%s worldTransform=%s",
            tostring(source), object_name(build_object), object_name(model),
            record.source_instance_id, record.build_object_id,
            record.map_object_master_data_id, format_transform(model_transform)
        ))
    end
    return record, model_transform
end

local CONNECT_INFO_PROPERTY_NAMES = {
    "ConnectInfoAnyPlace",
    "FrontConnectInfo",
    "BackConnectInfo",
    "LeftConnectInfo",
    "RightConnectInfo",
    "UpConnectInfo",
    "DownConnectInfo",
    "DiagonalUpConnectInfo",
    "DiagonalDownConnectInfo",
    "DiagonalLeftConnectInfo",
    "DiagonalRightConnectInfo",
    "DiagonalBackConnectInfo",
    "DiagonalConnectInfo",
    "CornerFrontLeftConnectInfo",
    "CornerFrontRightConnectInfo",
    "CornerBackLeftConnectInfo",
    "CornerBackRightConnectInfo",
}

local function connector_has_index(connector, expected_index)
    local expected = tostring(expected_index or "")
    local normalized = string.lower(expected)
    if normalized == "" or normalized == "nil" or normalized == "<nil>"
        or normalized == "none" or normalized == "null" then
        return true
    end

    connector = unwrap(connector)
    if not is_valid_object(connector) then return false end

    for _, property_name in ipairs(CONNECT_INFO_PROPERTY_NAMES) do
        local connect_info = safe_property(connector, property_name)
        if connect_info ~= nil and value_to_string(
            safe_property(connect_info, "ConnectIndex")
        ) == expected then
            return true
        end
    end
    return false
end

local function capture_connector_index_set(connector)
    local indexes = {}
    connector = unwrap(connector)
    if not is_valid_object(connector) then return indexes end

    for _, property_name in ipairs(CONNECT_INFO_PROPERTY_NAMES) do
        local connect_info = safe_property(connector, property_name)
        if connect_info ~= nil then
            indexes[value_to_string(
                safe_property(connect_info, "ConnectIndex")
            )] = true
        end
    end
    return indexes
end

local function capture_connector_connections(
    connector, map_object_manager, anchor_transform, math_library
)
    connector = unwrap(connector)
    if not is_valid_object(connector) then return {} end

    local connections = {}
    local seen = {}
    for _, property_name in ipairs(CONNECT_INFO_PROPERTY_NAMES) do
        local connect_info = safe_property(connector, property_name)
        if connect_info ~= nil then
            local source_connect_index = value_to_string(
                safe_property(connect_info, "ConnectIndex")
            )
            local targets = unwrap(safe_property(connect_info, "ConnectToInfos"))
            local target_count = 0
            pcall(function() target_count = #targets end)
            for target_index = 1, target_count do
                local target_info = nil
                pcall(function() target_info = unwrap(targets[target_index]) end)
                if target_info ~= nil then
                    local target_instance_id_value = safe_property(
                        target_info, "ConnectToModelInstanceId"
                    )
                    local target_instance_id = format_guid(target_instance_id_value)
                    local target_connect_index = value_to_string(
                        safe_property(target_info, "ConnectIndex")
                    )
                    if target_instance_id ~= "<nil>"
                        and target_instance_id ~= "None"
                        and target_instance_id
                            ~= "00000000-00000000-00000000-00000000" then
                        local key = table.concat({
                            target_instance_id,
                            property_name,
                            source_connect_index,
                            target_connect_index,
                        }, "|")
                        if not seen[key] then
                            seen[key] = true
                            local connection = {
                                target_source_instance_id = target_instance_id,
                                source_property = property_name,
                                source_connect_index = source_connect_index,
                                target_connect_index = target_connect_index,
                            }
                            -- Preserve an exact external-support stub while the
                            -- target FGuid is still a live hook-frame value.  A
                            -- manager lookup is local/hash based and avoids a
                            -- world-wide PalMapObjectModel enumeration.
                            local target_model = nil
                            if is_valid_object(map_object_manager) then
                                pcall(function()
                                    target_model = unwrap(
                                        map_object_manager:FindModel(
                                            target_instance_id_value
                                        )
                                    )
                                end)
                            end
                            if is_valid_object(target_model) then
                                connection.target_build_object_id = value_to_string(
                                    safe_property(target_model, "BuildObjectId")
                                )
                                local target_connector = unwrap(safe_property(
                                    target_model, "Connector"
                                ))
                                connection.target_connector_class =
                                    is_valid_object(target_connector)
                                    and object_name(target_connector) or "<none>"
                                local target_world_transform = safe_property(
                                    target_model, "InitialTransformCache"
                                )
                                local target_relative_transform = nil
                                if target_world_transform ~= nil
                                    and anchor_transform ~= nil
                                    and is_valid_object(math_library) then
                                    pcall(function()
                                        target_relative_transform =
                                            math_library:MakeRelativeTransform(
                                                target_world_transform,
                                                anchor_transform
                                            )
                                    end)
                                end
                                connection.target_relative_to_anchor =
                                    copy_transform(target_relative_transform)
                            end
                            table.insert(connections, connection)
                        end
                    end
                end
            end
        end
    end
    return connections
end

local function collect_build_object_meshes(build_object)
    local result = {}
    local seen = {}
    local function add(mesh)
        mesh = unwrap(mesh)
        if not is_valid_object(mesh) then return end
        local identity = safe_object_address(mesh) or tostring(object_name(mesh))
        if seen[identity] then return end
        seen[identity] = true
        table.insert(result, mesh)
    end

    local meshes = safe_property(build_object, "AllMeshes")
    if meshes ~= nil then
        local ok, count = pcall(function() return #meshes end)
        if ok then
            for index = 1, count do
                local item_ok, mesh = pcall(function() return meshes[index] end)
                if item_ok then add(mesh) end
            end
        end
    end
    add(safe_property(build_object, "MainMesh"))
    return result
end

local function capture_preview_mesh_descriptors(
    build_object, building_world_transform, build_object_id
)
    local math_library = UEHelpers.GetKismetMathLibrary()
    if not is_valid_object(build_object) or building_world_transform == nil
        or not is_valid_object(math_library) then
        return nil, "preview mesh capture dependencies unavailable"
    end

    local descriptors = {}
    for _, mesh_component in ipairs(collect_build_object_meshes(build_object)) do
        local visible = true
        pcall(function() visible = mesh_component:IsVisible() end)
        local static_mesh = unwrap(safe_property(mesh_component, "StaticMesh"))
        local skeletal_mesh = nil
        local asset_path = get_asset_path(static_mesh)
        local mesh_kind = BlueprintPreviewMesh.STATIC
        if asset_path == nil then
            skeletal_mesh = unwrap(safe_property(
                mesh_component, "SkeletalMesh"
            ))
            if not is_valid_object(skeletal_mesh) then
                skeletal_mesh = unwrap(safe_property(
                    mesh_component, "SkinnedAsset"
                ))
            end
            asset_path = get_asset_path(skeletal_mesh)
            mesh_kind = BlueprintPreviewMesh.SKELETAL
        end
        if visible and asset_path ~= nil then
            local component_world_transform = nil
            pcall(function()
                component_world_transform = mesh_component:K2_GetComponentToWorld()
            end)
            local relative_transform = nil
            if component_world_transform ~= nil then
                pcall(function()
                    relative_transform = math_library:MakeRelativeTransform(
                        component_world_transform, building_world_transform
                    )
                end)
            end
            if relative_transform ~= nil then
                local materials = nil
                local material_slot_count = 1
                pcall(function()
                    materials = mesh_component:GetMaterials()
                    material_slot_count = math.max(#materials, 1)
                end)
                local descriptor = {
                    relative_transform = copy_transform(relative_transform),
                    material_slot_count = material_slot_count,
                }
                if mesh_kind == BlueprintPreviewMesh.SKELETAL then
                    descriptor.mesh_kind = BlueprintPreviewMesh.SKELETAL
                    descriptor.skeletal_mesh_path = asset_path
                else
                    descriptor.static_mesh_path = asset_path
                end
                table.insert(descriptors, descriptor)
            end
        end
    end
    descriptors = BlueprintPreviewMesh.filter_descriptors(
        build_object_id, descriptors
    )
    if #descriptors == 0 then
        return nil, "no visible static or skeletal meshes captured"
    end
    return descriptors, nil
end

local function capture_overlap_descriptor(build_object, building_world_transform)
    local math_library = UEHelpers.GetKismetMathLibrary()
    if not is_valid_object(build_object) or building_world_transform == nil
        or not is_valid_object(math_library) then
        return nil, "overlap descriptor dependencies unavailable"
    end

    local overlap_checker = unwrap(safe_property(build_object, "OverlapChecker"))
    local collision = unwrap(safe_property(build_object, "OverlapCheckCollision"))
    if not is_valid_object(collision) and is_valid_object(overlap_checker) then
        collision = unwrap(safe_property(overlap_checker, "Collision"))
    end
    if not is_valid_object(collision) then
        return nil, "build object has no overlap collision component"
    end

    local collision_world_transform = nil
    local collision_relative_transform = nil
    pcall(function()
        collision_world_transform = collision:K2_GetComponentToWorld()
        collision_relative_transform = math_library:MakeRelativeTransform(
            collision_world_transform, building_world_transform
        )
    end)
    if collision_relative_transform == nil then
        return nil, "overlap collision transform unavailable"
    end

    local descriptor = {
        relative_transform = copy_transform(collision_relative_transform),
        allowed_collision_profiles = {},
    }
    local capsule_radius = tonumber(safe_property(collision, "CapsuleRadius"))
    local capsule_half_height = tonumber(safe_property(collision, "CapsuleHalfHeight"))
    local sphere_radius = tonumber(safe_property(collision, "SphereRadius"))
    local box_extent = copy_vector(safe_property(collision, "BoxExtent"))
    if capsule_radius ~= nil and capsule_half_height ~= nil then
        descriptor.shape_type = "capsule"
        descriptor.radius = capsule_radius
        descriptor.half_height = capsule_half_height
    elseif sphere_radius ~= nil then
        descriptor.shape_type = "sphere"
        descriptor.radius = sphere_radius
    elseif box_extent ~= nil and box_extent.x ~= nil
        and box_extent.y ~= nil and box_extent.z ~= nil then
        descriptor.shape_type = "box"
        descriptor.box_extent = box_extent
    else
        return nil, "unsupported overlap collision class=" .. object_name(collision)
    end

    if is_valid_object(overlap_checker) then
        local profiles = safe_property(overlap_checker, "AllowOverlapCollisionPresetNames")
        local profile_count = 0
        pcall(function() profile_count = #profiles end)
        for index = 1, profile_count do
            local profile = nil
            pcall(function() profile = profiles[index] end)
            local profile_name = value_to_string(profile)
            if profile_name ~= "<nil>" and profile_name ~= "None" then
                table.insert(descriptor.allowed_collision_profiles, profile_name)
            end
        end
    end
    return descriptor, nil, collision
end

local function blueprint_identity_transform()
    return {
        translation = { x = 0.0, y = 0.0, z = 0.0 },
        rotation = { x = 0.0, y = 0.0, z = 0.0, w = 1.0 },
        scale = { x = 1.0, y = 1.0, z = 1.0 },
    }
end

local function make_blueprint_type_template(record)
    if type(record) ~= "table" or type(record.build_object_id) ~= "string" then
        return nil, "type source record is invalid"
    end
    local template = {
        build_object_id = record.build_object_id,
        map_object_master_data_id = record.map_object_master_data_id,
        build_object_class_path = record.build_object_class_path,
        actor_relative_to_model = record.actor_relative_to_model,
        preview_meshes = record.preview_meshes,
        overlap_descriptor = record.overlap_descriptor,
        install_strategy = record.install_strategy,
        install_capacity_sink_rate_by_height =
            record.install_capacity_sink_rate_by_height,
        install_capacity_slope_angle = record.install_capacity_slope_angle,
        install_location_offset = record.install_location_offset,
        spawn_location_offset = record.spawn_location_offset,
        connector_class = record.connector_class,
        connector_supported_level = record.connector_supported_level,
        preview_placeholder = record.preview_placeholder == true,
        skip_overlap_validation =
            record.skip_overlap_validation == true,
    }
    local preview_valid = type(template.preview_meshes) == "table"
        and #template.preview_meshes > 0
    if preview_valid then
        for _, descriptor in ipairs(template.preview_meshes) do
            if BlueprintPreviewMesh.asset_path(descriptor) == nil
                or type(descriptor.relative_transform) ~= "table" then
                preview_valid = false
                break
            end
        end
    end
    if type(template.actor_relative_to_model) ~= "table"
        or not preview_valid
        or type(template.overlap_descriptor) ~= "table" then
        return nil, "type source record is missing preview metadata"
    end
    return BlueprintJsonSchema.copy_type_template(template), nil
end

local function make_placeholder_type_template(
    build_object_id, map_object_id, class_path, cdo, reason
)
    local placeholder_transform = {
        translation = { x = 0.0, y = 0.0, z = PLACEHOLDER_BOX_EXTENT.z },
        rotation = { x = 0.0, y = 0.0, z = 0.0, w = 1.0 },
        scale = {
            x = PLACEHOLDER_BOX_EXTENT.x / 50.0,
            y = PLACEHOLDER_BOX_EXTENT.y / 50.0,
            z = PLACEHOLDER_BOX_EXTENT.z / 50.0,
        },
    }
    local template = {
        build_object_id = build_object_id,
        map_object_master_data_id = map_object_id,
        build_object_class_path = class_path,
        actor_relative_to_model = blueprint_identity_transform(),
        preview_meshes = {
            {
                static_mesh_path = PLACEHOLDER_MESH_PATH,
                relative_transform = placeholder_transform,
                material_slot_count = 1,
            },
        },
        overlap_descriptor = {
            shape_type = "box",
            relative_transform = {
                translation = {
                    x = placeholder_transform.translation.x,
                    y = placeholder_transform.translation.y,
                    z = placeholder_transform.translation.z,
                },
                rotation = {
                    x = 0.0, y = 0.0, z = 0.0, w = 1.0,
                },
                scale = { x = 1.0, y = 1.0, z = 1.0 },
            },
            box_extent = {
                x = PLACEHOLDER_BOX_EXTENT.x,
                y = PLACEHOLDER_BOX_EXTENT.y,
                z = PLACEHOLDER_BOX_EXTENT.z,
            },
            allowed_collision_profiles = {},
        },
        install_strategy = cdo ~= nil and value_to_string(
            safe_property(cdo, "InstallStrategy")
        ) or nil,
        install_capacity_sink_rate_by_height = cdo ~= nil and tonumber(
            safe_property(cdo, "InstallCapacitySinkRateByHeight")
        ) or nil,
        install_capacity_slope_angle = cdo ~= nil and tonumber(safe_property(
            cdo, "InstallCapacitySlopeAngle"
        )) or nil,
        install_location_offset = cdo ~= nil and copy_vector(safe_property(
            cdo, "InstallLocationOffset"
        )) or nil,
        spawn_location_offset = cdo ~= nil and copy_vector(safe_property(
            cdo, "SpawnLocationOffset"
        )) or nil,
        connector_class = "<none>",
        connector_supported_level = nil,
        preview_placeholder = true,
        skip_overlap_validation = true,
    }
    local copied, copy_error = make_blueprint_type_template(template)
    if copied == nil then return nil, copy_error end
    BlueprintTypeRuntimeCache[build_object_id] = copied
    log("blueprint type template using error-box placeholder build="
        .. tostring(build_object_id) .. " class=" .. tostring(class_path)
        .. " reason=" .. tostring(reason))
    return copied, nil
end

local function cache_blueprint_type_template(record)
    local template, template_error = make_blueprint_type_template(record)
    if template == nil then return false, template_error end
    BlueprintTypeRuntimeCache[record.build_object_id] = template
    return true, nil
end

local function same_runtime_world(candidate, world)
    candidate = unwrap(candidate)
    world = unwrap(world)
    if not is_valid_object(candidate) or not is_valid_object(world) then
        return false
    end
    local candidate_world = nil
    pcall(function() candidate_world = unwrap(candidate:GetWorld()) end)
    if not is_valid_object(candidate_world) then return false end
    local candidate_address = safe_object_address(candidate_world)
    local world_address = safe_object_address(world)
    return candidate_address ~= nil and candidate_address == world_address
end

local function hydrate_blueprint_type_template_from_actor(
    actor, build_object_id, map_object_id, class_path
)
    actor = unwrap(actor)
    if not is_valid_object(actor) then return nil, "live actor is invalid" end
    local model = nil
    pcall(function() model = unwrap(actor:GetModel()) end)
    if not is_valid_object(model) then return nil, "live actor model is invalid" end
    local candidate_id = value_to_string(safe_property(model, "BuildObjectId"))
    if candidate_id ~= build_object_id then
        return nil, "live actor BuildObjectId mismatch"
    end
    local model_transform = safe_property(model, "InitialTransformCache")
    local actor_transform = nil
    local actor_relative_to_model = nil
    local math_library = UEHelpers.GetKismetMathLibrary()
    if model_transform ~= nil and is_valid_object(math_library) then
        pcall(function()
            actor_transform = actor:GetTransform()
            actor_relative_to_model = math_library:MakeRelativeTransform(
                actor_transform, model_transform
            )
        end)
    end
    if actor_relative_to_model == nil then
        return nil, "live actor transform calibration failed"
    end
    local preview_meshes, preview_error = capture_preview_mesh_descriptors(
        actor, model_transform, build_object_id
    )
    if preview_meshes == nil then return nil, preview_error end
    local overlap_descriptor, overlap_error = capture_overlap_descriptor(
        actor, model_transform
    )
    if overlap_descriptor == nil then return nil, overlap_error end
    local connector = unwrap(safe_property(model, "Connector"))
    local template = {
        build_object_id = build_object_id,
        map_object_master_data_id = map_object_id,
        build_object_class_path = class_path,
        actor_relative_to_model = copy_transform(actor_relative_to_model),
        preview_meshes = preview_meshes,
        overlap_descriptor = overlap_descriptor,
        install_strategy = value_to_string(
            safe_property(actor, "InstallStrategy")
        ),
        install_capacity_sink_rate_by_height = tonumber(safe_property(
            actor, "InstallCapacitySinkRateByHeight"
        )),
        install_capacity_slope_angle = tonumber(safe_property(
            actor, "InstallCapacitySlopeAngle"
        )),
        install_location_offset = copy_vector(safe_property(
            actor, "InstallLocationOffset"
        )),
        spawn_location_offset = copy_vector(safe_property(
            actor, "SpawnLocationOffset"
        )),
        connector_class = is_valid_object(connector)
            and object_name(connector) or "<none>",
        connector_supported_level = tonumber(safe_property(
            connector, "SupportedLevel"
        )),
    }
    local copied, copy_error = make_blueprint_type_template(template)
    if copied == nil then return nil, copy_error end
    BlueprintTypeRuntimeCache[build_object_id] = copied
    return copied, nil
end

local function hydrate_blueprint_type_template_from_live_instance(
    build_class, build_object_id, map_object_id, class_path
)
    local short_class_name = string.match(tostring(class_path), "%.([^%.]+)$")
    if short_class_name == nil then return nil, "generated class name unavailable" end
    local candidates = nil
    local find_ok, find_error = pcall(function()
        candidates = FindAllOf(short_class_name) or {}
    end)
    if not find_ok then return nil, "live class scan failed: " .. tostring(find_error) end
    local world = unwrap(UEHelpers.GetWorld())
    local last_error = "no matching live instance"
    for _, candidate in ipairs(candidates or {}) do
        candidate = unwrap(candidate)
        if same_runtime_world(candidate, world)
            and not string.find(object_name(candidate), "Default__", 1, true) then
            local template, template_error =
                hydrate_blueprint_type_template_from_actor(
                    candidate, build_object_id, map_object_id, class_path
                )
            if template ~= nil then
                log("blueprint type template hydrated from live instance build="
                    .. tostring(build_object_id))
                return template, nil
            end
            last_error = tostring(template_error)
        end
    end
    return nil, last_error
end

local function collect_generated_component_templates(build_class, cdo)
    local result = {}
    local seen = {}
    local stats = {
        classes = 0,
        component_templates = 0,
        scs_nodes = 0,
        reflected_object_values = 0,
    }
    local function add(value)
        value = unwrap(value)
        if not is_valid_object(value) then return end
        local key = safe_object_address(value) or object_name(value)
        if seen[key] then return end
        seen[key] = true
        table.insert(result, value)
    end
    local function add_array(values, stat_name)
        if values == nil or type(values) == "string"
            or type(values) == "number" or type(values) == "boolean" then
            return
        end
        local count = 0
        pcall(function() count = #values end)
        if stat_name ~= nil then
            stats[stat_name] = stats[stat_name] + count
        end
        for index = 1, count do
            local value = nil
            pcall(function() value = values[index] end)
            add(value)
        end
    end

    local current_class = unwrap(build_class)
    local visited_classes = {}
    for _ = 1, 16 do
        -- UE4SS may report a freshly soft-loaded UClass as IsValid()==false
        -- even though its reflection data is immediately usable. The class
        -- resolver already accepts that state; keep the generated-template
        -- walk on the same class-specific validity policy.
        if not is_usable_class_object(current_class) then break end
        local class_key = safe_object_address(current_class)
            or class_object_name(current_class)
        if visited_classes[class_key] then break end
        visited_classes[class_key] = true
        stats.classes = stats.classes + 1

        add_array(
            safe_property(current_class, "ComponentTemplates"),
            "component_templates"
        )
        local scs = unwrap(safe_property(
            current_class, "SimpleConstructionScript"
        ))
        if is_valid_object(scs) then
            local nodes = safe_property(scs, "AllNodes")
            local count = 0
            pcall(function() count = #nodes end)
            for index = 1, count do
                local node = nil
                pcall(function() node = unwrap(nodes[index]) end)
                if is_valid_object(node) then
                    add(safe_property(node, "ComponentTemplate"))
                    stats.scs_nodes = stats.scs_nodes + 1
                end
            end
        end

        -- Cooked BlueprintGeneratedClass assets may strip/empty both
        -- ComponentTemplates and SCS nodes while retaining default subobjects
        -- as reflected object properties on the CDO (for example StaticMesh1
        -- or CheckOverlapCollision). Enumerate those properties generically so
        -- cold hydration does not depend on editor-only template containers.
        if is_valid_object(cdo) then
            pcall(function()
                current_class:ForEachProperty(function(property)
                    local property_name = nil
                    pcall(function()
                        property_name = value_to_string(property:GetFName())
                    end)
                    if property_name ~= nil and property_name ~= "<nil>"
                        and property_name ~= "None" then
                        local property_value = safe_property(
                            cdo, property_name
                        )
                        local before = #result
                        add(property_value)
                        add_array(property_value)
                        stats.reflected_object_values =
                            stats.reflected_object_values + (#result - before)
                    end
                    return false
                end)
            end)
        end

        local parent_class = nil
        pcall(function() parent_class = unwrap(current_class:GetSuperClass()) end)
        if not is_usable_class_object(parent_class) then
            parent_class = unwrap(safe_property(current_class, "SuperStruct"))
        end
        current_class = parent_class
    end
    stats.unique_components = #result
    return result, stats
end

local function capture_generated_class_template(
    build_class, cdo, build_object_id, map_object_id, class_path
)
    local components, component_stats =
        collect_generated_component_templates(build_class, cdo)
    local preview_meshes = {}
    local overlap_candidates = {}
    local overlap_reference_name = value_to_string(safe_property(
        safe_property(cdo, "OverlapCheckCollisionRef"), "ComponentProperty"
    ))
    for _, component in ipairs(components) do
        local relative_transform = nil
        pcall(function() relative_transform = component:GetRelativeTransform() end)
        local static_mesh = unwrap(safe_property(component, "StaticMesh"))
        local static_mesh_path = get_asset_path(static_mesh)
        local skeletal_mesh = nil
        local skeletal_mesh_path = nil
        if static_mesh_path == nil then
            skeletal_mesh = unwrap(safe_property(component, "SkeletalMesh"))
            if not is_valid_object(skeletal_mesh) then
                skeletal_mesh = unwrap(safe_property(component, "SkinnedAsset"))
            end
            skeletal_mesh_path = get_asset_path(skeletal_mesh)
        end
        if relative_transform ~= nil
            and (static_mesh_path ~= nil or skeletal_mesh_path ~= nil) then
            local visible = true
            pcall(function() visible = component:IsVisible() end)
            if visible then
                local materials = nil
                local material_slot_count = 1
                pcall(function()
                    materials = component:GetMaterials()
                    material_slot_count = math.max(#materials, 1)
                end)
                local descriptor = {
                    relative_transform = copy_transform(relative_transform),
                    material_slot_count = material_slot_count,
                }
                if skeletal_mesh_path ~= nil then
                    descriptor.mesh_kind = BlueprintPreviewMesh.SKELETAL
                    descriptor.skeletal_mesh_path = skeletal_mesh_path
                else
                    descriptor.static_mesh_path = static_mesh_path
                end
                table.insert(preview_meshes, descriptor)
            end
        end

        local component_label = object_name(component)
        local capsule_radius = tonumber(safe_property(component, "CapsuleRadius"))
        local capsule_half_height = tonumber(safe_property(
            component, "CapsuleHalfHeight"
        ))
        local sphere_radius = tonumber(safe_property(component, "SphereRadius"))
        local box_extent = copy_vector(safe_property(component, "BoxExtent"))
        if relative_transform ~= nil and (
            (capsule_radius ~= nil and capsule_half_height ~= nil)
            or sphere_radius ~= nil
            or (box_extent ~= nil and box_extent.x ~= nil
                and box_extent.y ~= nil and box_extent.z ~= nil)
        ) then
            local score = 0
            if overlap_reference_name ~= "<nil>"
                and overlap_reference_name ~= "None"
                and string.find(
                    component_label, overlap_reference_name, 1, true
                ) then
                score = score + 100
            end
            if string.find(component_label, "CheckOverlapCollision", 1, true)
                or string.find(component_label, "OverlapCheckCollision", 1, true) then
                score = score + 50
            elseif string.find(component_label, "Overlap", 1, true) then
                score = score + 10
            end
            table.insert(overlap_candidates, {
                component = component,
                relative_transform = relative_transform,
                capsule_radius = capsule_radius,
                capsule_half_height = capsule_half_height,
                sphere_radius = sphere_radius,
                box_extent = box_extent,
                score = score,
            })
        end
    end
    if #preview_meshes == 0 then
        return nil, string.format(
            "generated class has no static or skeletal mesh component templates"
                .. " classes=%d componentTemplates=%d scsNodes=%d"
                .. " reflectedObjects=%d uniqueCandidates=%d",
            tonumber(component_stats.classes) or 0,
            tonumber(component_stats.component_templates) or 0,
            tonumber(component_stats.scs_nodes) or 0,
            tonumber(component_stats.reflected_object_values) or 0,
            tonumber(component_stats.unique_components) or 0
        )
    end
    table.sort(overlap_candidates, function(left, right)
        return left.score > right.score
    end)
    local overlap = overlap_candidates[1]
    if overlap == nil or overlap.score <= 0 then
        return nil, "generated class overlap component template is unavailable"
    end
    local overlap_descriptor = {
        relative_transform = copy_transform(overlap.relative_transform),
        allowed_collision_profiles = {},
    }
    if overlap.capsule_radius ~= nil
        and overlap.capsule_half_height ~= nil then
        overlap_descriptor.shape_type = "capsule"
        overlap_descriptor.radius = overlap.capsule_radius
        overlap_descriptor.half_height = overlap.capsule_half_height
    elseif overlap.sphere_radius ~= nil then
        overlap_descriptor.shape_type = "sphere"
        overlap_descriptor.radius = overlap.sphere_radius
    else
        overlap_descriptor.shape_type = "box"
        overlap_descriptor.box_extent = overlap.box_extent
    end

    local template = {
        build_object_id = build_object_id,
        map_object_master_data_id = map_object_id,
        build_object_class_path = class_path,
        actor_relative_to_model = blueprint_identity_transform(),
        preview_meshes = preview_meshes,
        overlap_descriptor = overlap_descriptor,
        install_strategy = value_to_string(
            safe_property(cdo, "InstallStrategy")
        ),
        install_capacity_sink_rate_by_height = tonumber(safe_property(
            cdo, "InstallCapacitySinkRateByHeight"
        )),
        install_capacity_slope_angle = tonumber(safe_property(
            cdo, "InstallCapacitySlopeAngle"
        )),
        install_location_offset = copy_vector(safe_property(
            cdo, "InstallLocationOffset"
        )),
        spawn_location_offset = copy_vector(safe_property(
            cdo, "SpawnLocationOffset"
        )),
        connector_class = "<none>",
        connector_supported_level = nil,
    }
    local copied, copy_error = make_blueprint_type_template(template)
    if copied == nil then return nil, copy_error end
    BlueprintTypeRuntimeCache[build_object_id] = copied
    log("blueprint type template hydrated from generated component templates build="
        .. tostring(build_object_id) .. " meshes="
        .. tostring(#preview_meshes) .. " overlap="
        .. tostring(overlap_descriptor.shape_type))
    return copied, nil
end

local function resolve_blueprint_build_class(build_object_id)
    local world = unwrap(UEHelpers.GetWorld())
    local utility = unwrap(StaticFindObject(
        "/Script/Pal.Default__PalMasterDataTablesUtility"
    ))
    if not is_valid_object(world) or not is_valid_object(utility) then
        return nil, nil, nil, "master-data dependencies unavailable"
    end
    local build_table = nil
    local map_table = nil
    local build_row = nil
    local map_row = nil
    local ok, resolve_error = pcall(function()
        build_table = unwrap(utility:GetBuildObjectDataTable(world))
        build_row = build_table:FindRow(build_object_id)
        local map_object_id = value_to_string(
            safe_property(build_row, "MapObjectId")
        )
        map_table = unwrap(utility:GetMapObjectDataTable(world))
        map_row = map_table:FindRow(map_object_id)
    end)
    if not ok or build_row == nil or map_row == nil then
        return nil, nil, nil, "master-data lookup failed error="
            .. tostring(resolve_error)
    end
    local map_object_id = value_to_string(safe_property(build_row, "MapObjectId"))
    local soft_class = safe_property(map_row, "BlueprintClassSoft")
    local class_path = nil
    local path_error = nil
    local path_ok, path_result = pcall(function()
        local soft_path = soft_class:GetObjectID()
        return value_to_string(soft_path:GetAssetPathName())
    end)
    if path_ok then class_path = path_result else path_error = path_result end
    if class_path == nil or class_path == "None" or class_path == "<nil>" then
        return nil, map_object_id, nil,
            "BlueprintClassSoft path unavailable error=" .. tostring(path_error)
    end

    class_path = tostring(class_path)
    local game_path = string.match(class_path, "(/Game/[^%s'\"]+)")
    if game_path ~= nil then class_path = game_path end
    class_path = string.gsub(class_path, "[:].*$", "")

    local package_path = string.match(class_path, "^([^%.]+)%.")
    local short_class_name = string.match(class_path, "%.([^%.]+)$")
    if package_path == nil and string.sub(class_path, 1, 1) == "/" then
        package_path = string.gsub(class_path, "_C$", "")
        local asset_name = string.match(package_path, "([^/]+)$")
        if asset_name ~= nil then
            class_path = package_path .. "." .. asset_name .. "_C"
            short_class_name = asset_name .. "_C"
        end
    end
    if short_class_name == nil then
        short_class_name = string.match(class_path, "([^/]+)$")
    end

    local load_diagnostics = {}
    local function is_expected_build_class(value)
        if not is_usable_class_object(value) then return false end
        local full_name = tostring(class_object_name(value))
        return string.find(full_name, "Class", 1, true) ~= nil
            and string.find(full_name, tostring(class_path), 1, true) ~= nil
    end
    local function record_load(label, ok, value)
        load_diagnostics[#load_diagnostics + 1] = tostring(label)
            .. "=" .. (ok and class_object_name(value)
                or ("error:" .. tostring(value)))
    end

    -- Fast path for a class already loaded by the current world/build menu.
    local find_ok, find_result = pcall(StaticFindObject, class_path)
    local build_class = find_ok and unwrap(find_result) or nil
    if is_expected_build_class(build_class) then
        return build_class, map_object_id, class_path, nil
    end
    record_load("exact-find", find_ok, find_result)

    -- BlueprintClassSoft is the authoritative master-data reference. Calling
    -- the engine's blocking soft-class loader is the reliable cold-start path;
    -- LoadAsset(package_path) alone may return a package/Blueprint asset
    -- without registering its generated class in the UObject array.
    local system_library = nil
    local system_ok, system_error = pcall(function()
        system_library = unwrap(UEHelpers.GetKismetSystemLibrary())
    end)
    if system_ok and is_valid_object(system_library) then
        local soft_load_ok, soft_load_result = pcall(function()
            return unwrap(system_library:LoadClassAsset_Blocking(soft_class))
        end)
        if soft_load_ok then build_class = unwrap(soft_load_result) end
        record_load("soft-class-blocking", soft_load_ok, soft_load_result)
        if is_expected_build_class(build_class) then
            return build_class, map_object_id, class_path, nil
        end
    else
        record_load(
            "kismet-system-library", system_ok,
            system_ok and system_library or system_error
        )
    end

    -- Some UE4SS/engine combinations return the UBlueprint asset rather than
    -- its generated class. Try both complete object paths and recover the
    -- GeneratedClass property before consulting the UObject array again.
    local asset_name = package_path ~= nil
        and string.match(package_path, "([^/]+)$") or nil
    local asset_object_path = package_path ~= nil and asset_name ~= nil
        and (package_path .. "." .. asset_name) or nil
    local load_paths = {
        class_path,
        asset_object_path,
        package_path,
    }
    local attempted_paths = {}
    for _, load_path in ipairs(load_paths) do
        if load_path ~= nil and string.sub(load_path, 1, 1) == "/"
            and not attempted_paths[load_path] then
            attempted_paths[load_path] = true
            local load_ok, load_result = pcall(LoadAsset, load_path)
            load_result = load_ok and unwrap(load_result) or load_result
            record_load("LoadAsset(" .. load_path .. ")", load_ok, load_result)
            if is_expected_build_class(load_result) then
                build_class = load_result
            else
                local generated_class = unwrap(safe_property(
                    load_result, "GeneratedClass"
                ))
                if is_expected_build_class(generated_class) then
                    build_class = generated_class
                end
            end
            if is_expected_build_class(build_class) then
                return build_class, map_object_id, class_path, nil
            end
        end
    end

    find_ok, find_result = pcall(StaticFindObject, class_path)
    build_class = find_ok and unwrap(find_result) or nil
    record_load("exact-find-after-load", find_ok, find_result)
    if not is_expected_build_class(build_class) then
        local class_find_ok, class_find_result = pcall(
            FindObject, "Class", short_class_name
        )
        local short_candidate = class_find_ok
            and unwrap(class_find_result) or nil
        record_load("short-class-find", class_find_ok, class_find_result)
        -- A short-name search is only a final compatibility fallback. Reject
        -- another mod's same-named generated class instead of hydrating the
        -- wrong BuildObject type.
        local candidate_name = class_object_name(short_candidate)
        if is_expected_build_class(short_candidate)
            and string.find(
                tostring(candidate_name), tostring(class_path), 1, true
            ) ~= nil then
            build_class = short_candidate
        end
    end
    if not is_expected_build_class(build_class) then
        return nil, map_object_id, class_path,
            "resolved build class is not loaded package="
                .. tostring(package_path) .. " attempts=["
                .. table.concat(load_diagnostics, "; ") .. "]"
    end
    return build_class, map_object_id, class_path, nil
end

local function hydrate_blueprint_type_template_from_cdo(build_object_id)
    local build_class, map_object_id, class_path, resolve_error =
        resolve_blueprint_build_class(build_object_id)
    if not is_usable_class_object(build_class) then return nil, resolve_error end
    local live_template, live_error =
        hydrate_blueprint_type_template_from_live_instance(
            build_class, build_object_id, map_object_id, class_path
        )
    if live_template ~= nil then return live_template, nil end
    local cdo = nil
    local cdo_ok, cdo_error = pcall(function()
        cdo = unwrap(build_class:GetCDO())
    end)
    if not cdo_ok or not is_valid_object(cdo) then
        return make_placeholder_type_template(
            build_object_id, map_object_id, class_path, nil,
            "build class CDO unavailable error=" .. tostring(cdo_error)
        )
    end
    local reference_transform = nil
    pcall(function() reference_transform = cdo:GetTransform() end)
    if reference_transform == nil then
        reference_transform = {
            Translation = { X = 0.0, Y = 0.0, Z = 0.0 },
            Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 },
            Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
        }
    end
    local preview_meshes, preview_error = capture_preview_mesh_descriptors(
        cdo, reference_transform, build_object_id
    )
    if preview_meshes == nil then
        local generated_template, generated_error =
            capture_generated_class_template(
                build_class, cdo, build_object_id, map_object_id, class_path
            )
        if generated_template ~= nil then return generated_template, nil end
        return make_placeholder_type_template(
            build_object_id, map_object_id, class_path, cdo,
            "live instance hydration failed: " .. tostring(live_error)
                .. "; CDO mesh hydration failed: " .. tostring(preview_error)
                .. "; generated template hydration failed: "
                .. tostring(generated_error)
        )
    end
    local overlap_descriptor, overlap_error = capture_overlap_descriptor(
        cdo, reference_transform
    )
    if overlap_descriptor == nil then
        return make_placeholder_type_template(
            build_object_id, map_object_id, class_path, cdo,
            "CDO overlap hydration failed: " .. tostring(overlap_error)
        )
    end
    local template = {
        build_object_id = build_object_id,
        map_object_master_data_id = map_object_id,
        build_object_class_path = class_path,
        actor_relative_to_model = blueprint_identity_transform(),
        preview_meshes = preview_meshes,
        overlap_descriptor = overlap_descriptor,
        install_strategy = value_to_string(safe_property(cdo, "InstallStrategy")),
        install_capacity_sink_rate_by_height = tonumber(safe_property(
            cdo, "InstallCapacitySinkRateByHeight"
        )),
        install_capacity_slope_angle = tonumber(safe_property(
            cdo, "InstallCapacitySlopeAngle"
        )),
        install_location_offset = copy_vector(safe_property(
            cdo, "InstallLocationOffset"
        )),
        spawn_location_offset = copy_vector(safe_property(
            cdo, "SpawnLocationOffset"
        )),
        connector_class = "<none>",
        connector_supported_level = nil,
    }
    BlueprintTypeRuntimeCache[build_object_id] =
        BlueprintJsonSchema.copy_type_template(template)
    log(string.format(
        "schema-9 type hydrated from CDO build=%s map=%s class=%s meshes=%d overlap=%s",
        build_object_id, tostring(map_object_id), tostring(class_path),
        #preview_meshes, tostring(overlap_descriptor.shape_type)
    ))
    return BlueprintTypeRuntimeCache[build_object_id], nil
end

local function ensure_blueprint_type_templates(compact_blueprint)
    if type(compact_blueprint) ~= "table"
        or type(compact_blueprint.t) ~= "table" then
        return false, "compact blueprint type dictionary is unavailable"
    end
    local required_type_indices = {}
    for _, building in ipairs(compact_blueprint.b or {}) do
        required_type_indices[building[1]] = true
    end
    for type_index, _ in pairs(required_type_indices) do
        local build_object_id = compact_blueprint.t[type_index]
        local cached_template = BlueprintTypeRuntimeCache[build_object_id]
        if cached_template == nil
            or cached_template.preview_placeholder == true then
            local template, template_error =
                hydrate_blueprint_type_template_from_cdo(build_object_id)
            if template == nil then
                return false, "cannot hydrate BuildObjectId="
                    .. tostring(build_object_id) .. " error="
                    .. tostring(template_error)
            end
        end
    end
    return true, nil
end


BlueprintSelectionData.get_build_object_identity = get_build_object_identity
BlueprintSelectionData.make_identity_record = make_identity_record
BlueprintSelectionData.make_building_record = make_building_record
BlueprintSelectionData.connector_has_index = connector_has_index
BlueprintSelectionData.capture_connector_index_set =
    capture_connector_index_set
BlueprintSelectionData.capture_connector_connections = capture_connector_connections
BlueprintSelectionData.collect_build_object_meshes = collect_build_object_meshes
BlueprintSelectionData.capture_preview_mesh_descriptors = capture_preview_mesh_descriptors
BlueprintSelectionData.capture_overlap_descriptor = capture_overlap_descriptor
BlueprintSelectionData.blueprint_identity_transform = blueprint_identity_transform
BlueprintSelectionData.make_blueprint_type_template = make_blueprint_type_template
BlueprintSelectionData.make_placeholder_type_template =
    make_placeholder_type_template
BlueprintSelectionData.cache_blueprint_type_template = cache_blueprint_type_template
BlueprintSelectionData.collect_generated_component_templates =
    collect_generated_component_templates
BlueprintSelectionData.resolve_blueprint_build_class = resolve_blueprint_build_class
BlueprintSelectionData.hydrate_blueprint_type_template_from_cdo = hydrate_blueprint_type_template_from_cdo
BlueprintSelectionData.ensure_blueprint_type_templates = ensure_blueprint_type_templates
BlueprintSelectionData.type_runtime_cache = BlueprintTypeRuntimeCache

return BlueprintSelectionData

local BlueprintRegionPreview = {}

local COMPONENT_ARRAY = "SBB_SelectionRegionPreviewComponents"
local EDGE_PROPERTIES = {}
for index = 1, 12 do
    EDGE_PROPERTIES[index] = string.format(
        "SBB_SelectionRegionPreviewEdge%02d", index
    )
end
local RESOURCE_PROPERTIES = {
    {
        property = "SBB_SelectionRegionPreviewMesh",
        path = "/Engine/BasicShapes/Cube.Cube",
    },
    {
        property = "SBB_SelectionRegionPreviewRed",
        path = "/Game/Pal/Material/Debug/MI_Debug_Red.MI_Debug_Red",
    },
    {
        property = "SBB_SelectionRegionPreviewGreen",
        path = "/Game/Pal/Material/Debug/MI_Debug_Green.MI_Debug_Green",
    },
    {
        property = "SBB_SelectionRegionPreviewBlue",
        path = "/Game/Pal/Material/Debug/MI_Debug_Blue.MI_Debug_Blue",
    },
}

function BlueprintRegionPreview.install(deps)
    assert(type(deps) == "table",
        "BlueprintRegionPreview dependencies are required")

    local log = assert(deps.log, "log dependency is required")
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object dependency is required")
    local safe_property = assert(
        deps.safe_property, "safe_property dependency is required")
    local with_session = assert(
        deps.with_session, "with_session dependency is required")
    local preview = {}
    local components_ready_logged = false
    local error_logged = false

    local function get_component_array(session)
        return safe_property(session, COMPONENT_ARRAY)
    end

    local function collect_components(session)
        local values = get_component_array(session)
        local count = 0
        pcall(function() count = #values end)
        local components = {}
        for index = 1, count do
            pcall(function()
                components[index] = unwrap(values[index])
            end)
        end
        local valid = #components == 12
        if valid then
            for index = 1, 12 do
                if not is_valid_object(components[index]) then
                    valid = false
                    break
                end
            end
        end
        if valid then return components, values end

        components = {}
        pcall(function() values:Empty() end)
        for index, property_name in ipairs(EDGE_PROPERTIES) do
            local component = unwrap(safe_property(session, property_name))
            if not is_valid_object(component) then
                return components, values
            end
            components[index] = component
            pcall(function() values[index] = component end)
        end
        return components, values
    end

    local function hide_components(session)
        error_logged = false
        local components = collect_components(session)
        for _, component in ipairs(components) do
            if is_valid_object(component) then
                pcall(function()
                    component:SetVisibility(false, true)
                    component:SetHiddenInGame(true, true)
                end)
            end
        end
    end

    local function load_session_resource(session, descriptor)
        local value = unwrap(safe_property(
            session, descriptor.property
        ))
        if is_valid_object(value) then return value end
        pcall(LoadAsset, descriptor.path)
        value = unwrap(StaticFindObject(descriptor.path))
        if is_valid_object(value) then
            pcall(function()
                session[descriptor.property] = value
            end)
        end
        return value
    end

    local function get_resources(session)
        local resources = {}
        for index, descriptor in ipairs(RESOURCE_PROPERTIES) do
            resources[index] = load_session_resource(
                session, descriptor
            )
            if not is_valid_object(resources[index]) then
                return nil, "region preview resource unavailable index="
                    .. tostring(index)
            end
        end
        return {
            mesh = resources[1],
            materials = {
                resources[2], resources[3], resources[4],
            },
        }, nil
    end

    local function ensure_components(session)
        local components, values = collect_components(session)
        local valid = #components == 12
        if valid then
            for index = 1, 12 do
                if not is_valid_object(components[index]) then
                    valid = false
                    break
                end
            end
        end
        if not valid then
            return nil, "SelectionSession region edge components unavailable"
        end

        local resources, resource_error = get_resources(session)
        if resources == nil then return nil, resource_error end
        for index, component in ipairs(components) do
            local material_index = math.floor((index - 1) / 4) + 1
            local setup_ok, setup_error = pcall(function()
                component:SetMobility(2)
                component:SetStaticMesh(resources.mesh)
                component:SetMaterial(
                    0, resources.materials[material_index]
                )
                component:SetCollisionEnabled(0)
                component:SetGenerateOverlapEvents(false)
                component:SetCastShadow(false)
                component:SetReceivesDecals(false)
                component:SetRenderInMainPass(true)
                component:SetRenderInDepthPass(true)
                component:SetVisibility(false, true)
                component:SetHiddenInGame(true, true)
                values[index] = component
            end)
            if not setup_ok then
                return nil, "component setup failed index="
                    .. tostring(index) .. " error="
                    .. tostring(setup_error)
            end
        end
        if not components_ready_logged then
            components_ready_logged = true
            log("region preview renderer ready owner=SelectionSession "
                .. "components=12 mesh=Engine.BasicShapes.Cube "
                .. "materials=Pal.Debug.RGB")
        end
        return components, nil
    end

    function preview.clear()
        local active = with_session(function(session)
            local ok = pcall(function()
                session:SBB_SelectionHideRegionPreview()
            end)
            if not ok then hide_components(session) end
        end)
        error_logged = false
        return active == true
    end

    function preview.prepare(session_hint)
        local prepared = false
        local active = with_session(function(session)
            local components, component_error = ensure_components(session)
            if components == nil then
                if not error_logged then
                    error_logged = true
                    log("region preview component unavailable: "
                        .. tostring(component_error))
                end
                return
            end
            hide_components(session)
            prepared = true
        end, session_hint)
        return active == true and prepared
    end

    function preview.abandon_world()
        -- Session-owned components and resources die with the World. Lua
        -- retains diagnostics only, never their UObject wrappers.
        components_ready_logged = false
        error_logged = false
        return true
    end

    function preview.refresh(_, session_hint)
        local active = with_session(function(session)
            local draw_ok, draw_error = pcall(function()
                session:SBB_SelectionUpdateRegionPreview()
            end)
            if not draw_ok then
                hide_components(session)
                if not error_logged then
                    error_logged = true
                    log("native region preview update failed: "
                        .. tostring(draw_error))
                end
            end
        end, session_hint)
        return active == true
    end

    return preview
end

return BlueprintRegionPreview

local BlueprintPerformance = require("BlueprintPerformance")

local BlueprintBuildQueueProbe = {}

local function finite_number(value)
    value = tonumber(value)
    if value == nil or value ~= value
        or value == math.huge or value == -math.huge then
        return 0.0
    end
    return math.max(value, 0.0)
end

function BlueprintBuildQueueProbe.new_session(session_id, started_at)
    return {
        session_id = tonumber(session_id) or 0,
        started_at = tonumber(started_at) or BlueprintPerformance.now(),
        phases = {},
        counters = {},
    }
end

function BlueprintBuildQueueProbe.record_ms(
    stats, phase_name, elapsed_ms, context
)
    if type(stats) ~= "table" or type(phase_name) ~= "string"
        or phase_name == "" then
        return 0.0
    end
    local phases = stats.phases
    if type(phases) ~= "table" then
        phases = {}
        stats.phases = phases
    end
    local bucket = phases[phase_name]
    if type(bucket) ~= "table" then
        bucket = {
            count = 0,
            total_ms = 0.0,
            max_ms = 0.0,
            max_context = nil,
        }
        phases[phase_name] = bucket
    end
    local measured_ms = finite_number(elapsed_ms)
    bucket.count = bucket.count + 1
    bucket.total_ms = bucket.total_ms + measured_ms
    if measured_ms >= bucket.max_ms then
        bucket.max_ms = measured_ms
        bucket.max_context = context ~= nil
            and tostring(context) or bucket.max_context
    end
    return measured_ms
end

function BlueprintBuildQueueProbe.record_elapsed(
    stats, phase_name, started_at, context
)
    return BlueprintBuildQueueProbe.record_ms(
        stats, phase_name,
        BlueprintPerformance.elapsed_ms(started_at), context
    )
end

function BlueprintBuildQueueProbe.increment(stats, counter_name, amount)
    if type(stats) ~= "table" or type(counter_name) ~= "string"
        or counter_name == "" then
        return 0
    end
    local counters = stats.counters
    if type(counters) ~= "table" then
        counters = {}
        stats.counters = counters
    end
    counters[counter_name] =
        (tonumber(counters[counter_name]) or 0) + (tonumber(amount) or 1)
    return counters[counter_name]
end

function BlueprintBuildQueueProbe.stamp(subject, stamp_name, at)
    if type(subject) ~= "table" or type(stamp_name) ~= "string"
        or stamp_name == "" then
        return nil
    end
    local stamps = subject.build_queue_probe_stamps
    if type(stamps) ~= "table" then
        stamps = {}
        subject.build_queue_probe_stamps = stamps
    end
    local value = tonumber(at) or BlueprintPerformance.now()
    stamps[stamp_name] = value
    return value
end

function BlueprintBuildQueueProbe.record_interval(
    stats, phase_name, subject, start_stamp, end_stamp, context
)
    local stamps = type(subject) == "table"
        and subject.build_queue_probe_stamps or nil
    local started_at = type(stamps) == "table"
        and tonumber(stamps[start_stamp]) or nil
    local ended_at = type(stamps) == "table"
        and tonumber(stamps[end_stamp]) or nil
    if started_at == nil or ended_at == nil then return nil end
    return BlueprintBuildQueueProbe.record_ms(
        stats, phase_name, (ended_at - started_at) * 1000.0, context
    )
end

function BlueprintBuildQueueProbe.phase(stats, phase_name)
    local bucket = type(stats) == "table"
        and type(stats.phases) == "table"
        and stats.phases[phase_name] or nil
    return {
        count = tonumber(bucket and bucket.count) or 0,
        total_ms = tonumber(bucket and bucket.total_ms) or 0.0,
        max_ms = tonumber(bucket and bucket.max_ms) or 0.0,
        max_context = bucket and bucket.max_context or nil,
    }
end

function BlueprintBuildQueueProbe.format_phases(stats, phase_names)
    local values = {}
    for _, phase_name in ipairs(phase_names or {}) do
        local phase = BlueprintBuildQueueProbe.phase(stats, phase_name)
        values[#values + 1] = string.format(
            "%s=%d/%.2f/%.2f@%s",
            phase_name, phase.count, phase.total_ms, phase.max_ms,
            tostring(phase.max_context or "-")
        )
    end
    return table.concat(values, " ")
end

function BlueprintBuildQueueProbe.session_elapsed_ms(stats)
    if type(stats) ~= "table" then return 0.0 end
    return BlueprintPerformance.elapsed_ms(stats.started_at)
end

return BlueprintBuildQueueProbe

-- Optional, pure-data support gate for blueprint wave planning.
--
-- This module deliberately knows nothing about Unreal objects, RPCs, jobs, or
-- the live game world.  It analyzes the saved connector graph against a set of
-- already-established support roots and exposes four gate decisions:
--
--   allow   - the candidate has support in the current simulated state;
--   defer   - the component can become supported, but not in this wave;
--   reject  - a known support-dependent candidate has no possible root;
--   abstain - available data is insufficient, so another gate/server decides.
--
-- The default policy is intentionally conservative.  Nodes in a component
-- reachable from the anchor or an initial-world root are treated as ordinary
-- support-dependent connector nodes.  Rootless components are not rejected
-- unless the caller explicitly classifies them or enables strict_rootless.

local Gate = {}

Gate.SCHEMA_VERSION = 1
Gate.DECISION_ALLOW = "allow"
Gate.DECISION_DEFER = "defer"
Gate.DECISION_REJECT = "reject"
Gate.DECISION_ABSTAIN = "abstain"

local DEFAULT_MAX_NODES = 250000
local DEFAULT_MAX_EDGES = 2000000

local VALID_ROLES = {
    root = true,
    dependent = true,
    independent = true,
    unknown = true,
}

local function normalize_id(value)
    if value == nil then return nil end
    local result = tostring(value)
    if result == "" then return nil end
    return result
end

local function normalize_role(value)
    if value == nil then return nil end
    local role = string.lower(tostring(value))
    role = string.gsub(role, "[%s_%-]", "")
    if role == "root" or role == "supportroot"
        or role == "providessupport" then
        return "root"
    end
    if role == "dependent" or role == "requiressupport"
        or role == "supported" then
        return "dependent"
    end
    if role == "independent" or role == "standalone"
        or role == "nosupportrequired" then
        return "independent"
    end
    if role == "unknown" or role == "abstain" then return "unknown" end
    return nil
end

local function stable_request_less(left, right)
    local left_index = tonumber(left and left.selection_index) or math.huge
    local right_index = tonumber(right and right.selection_index) or math.huge
    if left_index ~= right_index then return left_index < right_index end
    return tostring(left and left.source_instance_id or "")
        < tostring(right and right.source_instance_id or "")
end

local function sorted_node_ids(id_set, node_by_id)
    local result = {}
    for source_id, present in pairs(id_set or {}) do
        if present and node_by_id[source_id] ~= nil then
            result[#result + 1] = source_id
        end
    end
    table.sort(result, function(left, right)
        return stable_request_less(
            node_by_id[left].request, node_by_id[right].request
        )
    end)
    return result
end

local function sorted_neighbour_ids(node, node_by_id)
    return sorted_node_ids(node and node.neighbours or {}, node_by_id)
end

local function add_node(node_by_id, ordered_ids, request, request_kind)
    if type(request) ~= "table" then
        return false, tostring(request_kind) .. " request is missing"
    end
    local source_id = normalize_id(request.source_instance_id)
    if source_id == nil then
        return false, tostring(request_kind) .. " source instance id is missing"
    end
    if node_by_id[source_id] ~= nil then
        return false, "duplicate source instance id=" .. source_id
    end
    request.source_instance_id = source_id
    node_by_id[source_id] = {
        source_id = source_id,
        request = request,
        request_kind = request_kind,
        neighbours = {},
        degree = 0,
        explicit_role = nil,
        role = nil,
        is_seed = false,
        component_index = nil,
        rooted_reachable = false,
        wave_index = nil,
    }
    ordered_ids[#ordered_ids + 1] = source_id
    return true, nil
end

local function infer_explicit_role(request, degree, options)
    if type(options.classify_request) == "function" then
        local ok, role_or_error = pcall(
            options.classify_request, request, degree
        )
        if not ok then
            return nil, "support role classifier failed source="
                .. tostring(request.source_instance_id)
                .. " error=" .. tostring(role_or_error)
        end
        if role_or_error ~= nil then
            local normalized = normalize_role(role_or_error)
            if normalized == nil then
                return nil, "support role classifier returned an invalid role source="
                    .. tostring(request.source_instance_id)
                    .. " role=" .. tostring(role_or_error)
            end
            return normalized, nil
        end
    end

    local role = normalize_role(
        request.support_role or request.support_kind
            or request.blueprint_support_role
    )
    if role ~= nil then return role, nil end
    if request.is_support_root == true or request.provides_support == true then
        return "root", nil
    end
    if request.support_independent == true
        or request.requires_support == false then
        return "independent", nil
    end
    if request.requires_support == true then return "dependent", nil end
    return nil, nil
end

local function build_graph(anchor_request, member_requests, options)
    local node_by_id = {}
    local ordered_ids = {}
    local added, add_error = add_node(
        node_by_id, ordered_ids, anchor_request, "anchor"
    )
    if not added then return nil, add_error end
    for _, request in ipairs(member_requests or {}) do
        added, add_error = add_node(
            node_by_id, ordered_ids, request, "member"
        )
        if not added then return nil, add_error end
    end

    local max_nodes = tonumber(options.max_nodes) or DEFAULT_MAX_NODES
    if #ordered_ids > max_nodes then
        return nil, string.format(
            "support gate node limit exceeded nodes=%d max=%d",
            #ordered_ids, max_nodes
        )
    end

    local seen_edges = {}
    local edge_count = 0
    local directed_connection_count = 0
    local max_edges = tonumber(options.max_edges) or DEFAULT_MAX_EDGES
    for _, source_id in ipairs(ordered_ids) do
        local node = node_by_id[source_id]
        for _, connection in ipairs(node.request.connections or {}) do
            local target_id = normalize_id(
                connection and connection.target_source_instance_id
            )
            if target_id == nil or node_by_id[target_id] == nil then
                return nil, string.format(
                    "saved connection has unknown target source=%s target=%s",
                    source_id, tostring(target_id)
                )
            end
            if target_id ~= source_id then
                directed_connection_count = directed_connection_count + 1
                local left, right = source_id, target_id
                if right < left then left, right = right, left end
                local edge_key = left .. "|" .. right
                if not seen_edges[edge_key] then
                    seen_edges[edge_key] = true
                    node.neighbours[target_id] = true
                    node_by_id[target_id].neighbours[source_id] = true
                    edge_count = edge_count + 1
                    if edge_count > max_edges then
                        return nil, string.format(
                            "support gate edge limit exceeded edges=%d max=%d",
                            edge_count, max_edges
                        )
                    end
                end
            end
        end
    end
    for _, source_id in ipairs(ordered_ids) do
        local degree = 0
        for _, present in pairs(node_by_id[source_id].neighbours) do
            if present then degree = degree + 1 end
        end
        node_by_id[source_id].degree = degree
    end

    table.sort(ordered_ids, function(left, right)
        return stable_request_less(
            node_by_id[left].request, node_by_id[right].request
        )
    end)
    return {
        node_by_id = node_by_id,
        ordered_ids = ordered_ids,
        edge_count = edge_count,
        directed_connection_count = directed_connection_count,
    }, nil
end

local function collect_components(graph)
    local components = {}
    local visited = {}
    for _, start_id in ipairs(graph.ordered_ids) do
        if not visited[start_id] then
            local component = {
                index = #components + 1,
                node_ids = {},
                node_count = 0,
                edge_count = 0,
                seed_ids = {},
                seed_count = 0,
                rooted = false,
            }
            local queue = { start_id }
            local queue_head = 1
            visited[start_id] = true
            local degree_sum = 0
            while queue_head <= #queue do
                local source_id = queue[queue_head]
                queue_head = queue_head + 1
                local node = graph.node_by_id[source_id]
                node.component_index = component.index
                component.node_ids[#component.node_ids + 1] = source_id
                degree_sum = degree_sum + node.degree
                for _, neighbour_id in ipairs(
                    sorted_neighbour_ids(node, graph.node_by_id)
                ) do
                    if not visited[neighbour_id] then
                        visited[neighbour_id] = true
                        queue[#queue + 1] = neighbour_id
                    end
                end
            end
            table.sort(component.node_ids, function(left, right)
                return stable_request_less(
                    graph.node_by_id[left].request,
                    graph.node_by_id[right].request
                )
            end)
            component.node_count = #component.node_ids
            component.edge_count = degree_sum / 2
            components[#components + 1] = component
        end
    end
    return components
end

local function add_seed(seed_set, source_id, graph)
    source_id = normalize_id(source_id)
    if source_id == nil or graph.node_by_id[source_id] == nil then return false end
    seed_set[source_id] = true
    graph.node_by_id[source_id].is_seed = true
    return true
end

local function assign_roles_and_seeds(
    graph, components, anchor_request, initial_root_ids, options
)
    local seed_set = {}
    local anchor_id = normalize_id(anchor_request.source_instance_id)
    if options.seed_anchor ~= false then add_seed(seed_set, anchor_id, graph) end
    local ignored_initial_roots = 0
    for source_id, present in pairs(initial_root_ids or {}) do
        if present and not add_seed(seed_set, source_id, graph) then
            ignored_initial_roots = ignored_initial_roots + 1
        end
    end

    for _, source_id in ipairs(graph.ordered_ids) do
        local node = graph.node_by_id[source_id]
        local role, role_error = infer_explicit_role(
            node.request, node.degree, options
        )
        if role_error ~= nil then return nil, role_error end
        node.explicit_role = role
        if role == "root" then add_seed(seed_set, source_id, graph) end
    end

    for _, component in ipairs(components) do
        for _, source_id in ipairs(component.node_ids) do
            if seed_set[source_id] then
                component.seed_ids[#component.seed_ids + 1] = source_id
            end
        end
        component.seed_count = #component.seed_ids
        component.rooted = component.seed_count > 0
    end
    return {
        anchor_id = anchor_id,
        seed_set = seed_set,
        ignored_initial_root_count = ignored_initial_roots,
    }, nil
end

local function traverse_from_seeds(graph, components, seed_info)
    local queue = sorted_node_ids(seed_info.seed_set, graph.node_by_id)
    local anchor_id = seed_info.anchor_id
    if seed_info.seed_set[anchor_id] and queue[1] ~= anchor_id then
        for index, source_id in ipairs(queue) do
            if source_id == anchor_id then
                table.remove(queue, index)
                table.insert(queue, 1, source_id)
                break
            end
        end
    end

    local queue_head = 1
    local wave_index_by_id = {}
    local root_source_by_id = {}
    for _, source_id in ipairs(queue) do
        wave_index_by_id[source_id] = 0
        root_source_by_id[source_id] = source_id
    end

    while queue_head <= #queue do
        local source_id = queue[queue_head]
        queue_head = queue_head + 1
        local node = graph.node_by_id[source_id]
        node.rooted_reachable = true
        node.wave_index = wave_index_by_id[source_id]
        for _, neighbour_id in ipairs(sorted_neighbour_ids(node, graph.node_by_id)) do
            if wave_index_by_id[neighbour_id] == nil then
                wave_index_by_id[neighbour_id] = node.wave_index + 1
                root_source_by_id[neighbour_id] = root_source_by_id[source_id]
                queue[#queue + 1] = neighbour_id
            end
        end
    end

    local waves = {}
    for source_id, wave_index in pairs(wave_index_by_id) do
        waves[wave_index + 1] = waves[wave_index + 1] or {}
        waves[wave_index + 1][#waves[wave_index + 1] + 1] = source_id
    end
    for _, wave in ipairs(waves) do
        table.sort(wave, function(left, right)
            return stable_request_less(
                graph.node_by_id[left].request,
                graph.node_by_id[right].request
            )
        end)
    end
    if waves[1] ~= nil and seed_info.seed_set[anchor_id]
        and waves[1][1] ~= anchor_id then
        for index, source_id in ipairs(waves[1]) do
            if source_id == anchor_id then
                table.remove(waves[1], index)
                table.insert(waves[1], 1, source_id)
                break
            end
        end
    end

    for _, component in ipairs(components) do
        if component.rooted then
            for _, source_id in ipairs(component.node_ids) do
                graph.node_by_id[source_id].rooted_reachable = true
            end
        end
    end
    return {
        waves = waves,
        wave_index_by_id = wave_index_by_id,
        root_source_by_id = root_source_by_id,
        traversal_order = queue,
    }
end

local function finalize_roles_and_stats(
    graph, components, seed_info, traversal, options
)
    local role_counts = {
        root = 0,
        dependent = 0,
        independent = 0,
        unknown = 0,
    }
    local rooted_reachable_count = 0
    local rejected_ids = {}
    local abstained_ids = {}
    local independent_ids = {}
    for _, source_id in ipairs(graph.ordered_ids) do
        local node = graph.node_by_id[source_id]
        local component = components[node.component_index]
        local role = node.explicit_role
        if node.is_seed then
            role = "root"
        elseif role == nil then
            if component.rooted and node.degree > 0 then
                role = "dependent"
            elseif options.strict_rootless == true and node.degree > 0 then
                role = "dependent"
            else
                role = "unknown"
            end
        end
        if not VALID_ROLES[role] then role = "unknown" end
        node.role = role
        role_counts[role] = role_counts[role] + 1
        if node.rooted_reachable then
            rooted_reachable_count = rooted_reachable_count + 1
        end
        if role == "dependent" and not node.rooted_reachable then
            rejected_ids[#rejected_ids + 1] = source_id
        elseif role == "unknown" then
            abstained_ids[#abstained_ids + 1] = source_id
        elseif role == "independent" then
            independent_ids[#independent_ids + 1] = source_id
        end
    end

    local rooted_component_count = 0
    local rootless_component_count = 0
    for _, component in ipairs(components) do
        if component.rooted then
            rooted_component_count = rooted_component_count + 1
        else
            rootless_component_count = rootless_component_count + 1
        end
    end

    local node_count = #graph.ordered_ids
    return {
        node_count = node_count,
        edge_count = graph.edge_count,
        directed_connection_count = graph.directed_connection_count,
        seed_count = #sorted_node_ids(seed_info.seed_set, graph.node_by_id),
        component_count = #components,
        rooted_component_count = rooted_component_count,
        rootless_component_count = rootless_component_count,
        rooted_reachable_count = rooted_reachable_count,
        unreachable_count = node_count - rooted_reachable_count,
        rejected_count = #rejected_ids,
        abstained_count = #abstained_ids,
        independent_count = #independent_ids,
        role_counts = role_counts,
        rejected_ids = rejected_ids,
        abstained_ids = abstained_ids,
        independent_ids = independent_ids,
        can_reach_all = rooted_reachable_count == node_count,
        can_schedule_all = rejected_ids[1] == nil
            and abstained_ids[1] == nil
            and rooted_reachable_count + #independent_ids == node_count,
        ignored_initial_root_count = seed_info.ignored_initial_root_count,
        wave_count = #traversal.waves,
    }
end

function Gate.analyze(anchor_request, member_requests, initial_root_ids, options)
    options = options or {}
    if type(options) ~= "table" then
        return nil, "support gate options must be a table"
    end
    local graph, graph_error = build_graph(
        anchor_request, member_requests, options
    )
    if graph == nil then return nil, graph_error end
    local components = collect_components(graph)
    local seed_info, seed_error = assign_roles_and_seeds(
        graph, components, anchor_request, initial_root_ids, options
    )
    if seed_info == nil then return nil, seed_error end
    local traversal = traverse_from_seeds(graph, components, seed_info)
    local stats = finalize_roles_and_stats(
        graph, components, seed_info, traversal, options
    )
    return {
        schema_version = Gate.SCHEMA_VERSION,
        options = options,
        anchor_id = seed_info.anchor_id,
        node_by_id = graph.node_by_id,
        ordered_ids = graph.ordered_ids,
        components = components,
        seed_ids = sorted_node_ids(seed_info.seed_set, graph.node_by_id),
        seed_set = seed_info.seed_set,
        waves = traversal.waves,
        traversal_order = traversal.traversal_order,
        wave_index_by_id = traversal.wave_index_by_id,
        root_source_by_id = traversal.root_source_by_id,
        stats = stats,
    }, nil
end

local function set_contains(values, source_id)
    if type(values) ~= "table" then return false end
    if values[source_id] == true then return true end
    for _, value in ipairs(values) do
        if normalize_id(value) == source_id then return true end
    end
    return false
end

function Gate.evaluate(analysis, source_id, state)
    if type(analysis) ~= "table" or type(analysis.node_by_id) ~= "table" then
        return Gate.DECISION_REJECT, {
            kind = "invalid_gate_analysis",
            reason = "support gate analysis is unavailable",
        }
    end
    source_id = normalize_id(source_id)
    local node = source_id and analysis.node_by_id[source_id] or nil
    if node == nil then
        return Gate.DECISION_REJECT, {
            kind = "unknown_candidate",
            source_id = source_id,
            reason = "candidate is not present in support gate analysis",
        }
    end
    if node.is_seed or node.role == "root" then
        return Gate.DECISION_ALLOW, {
            kind = "support_root",
            source_id = source_id,
            expected_wave = node.wave_index,
        }
    end
    if node.role == "independent" then
        return Gate.DECISION_ALLOW, {
            kind = "support_independent",
            source_id = source_id,
        }
    end
    if node.role == "unknown" then
        return Gate.DECISION_ABSTAIN, {
            kind = "support_unknown",
            source_id = source_id,
            component_index = node.component_index,
        }
    end
    if not node.rooted_reachable then
        return Gate.DECISION_REJECT, {
            kind = "rootless_support_component",
            source_id = source_id,
            component_index = node.component_index,
            reason = "known support-dependent component has no support root",
        }
    end

    state = state or {}
    local rooted_built = state.rooted_built or state.built or {}
    if set_contains(rooted_built, source_id) then
        return Gate.DECISION_ALLOW, {
            kind = "already_rooted_built",
            source_id = source_id,
        }
    end
    for _, neighbour_id in ipairs(
        sorted_neighbour_ids(node, analysis.node_by_id)
    ) do
        if set_contains(rooted_built, neighbour_id) then
            return Gate.DECISION_ALLOW, {
                kind = "saved_connection_to_rooted_built",
                source_id = source_id,
                support_source_id = neighbour_id,
                expected_wave = node.wave_index,
            }
        end
    end
    return Gate.DECISION_DEFER, {
        kind = "waiting_for_rooted_predecessor",
        source_id = source_id,
        expected_wave = node.wave_index,
        component_index = node.component_index,
    }
end

function Gate.summarize(analysis)
    local stats = analysis and analysis.stats or {}
    return string.format(
        "nodes=%d edges=%d directed=%d seeds=%d components=%d rootedComponents=%d rootlessComponents=%d reachable=%d unreachable=%d waves=%d rejected=%d abstained=%d canReachAll=%s canScheduleAll=%s",
        tonumber(stats.node_count) or 0,
        tonumber(stats.edge_count) or 0,
        tonumber(stats.directed_connection_count) or 0,
        tonumber(stats.seed_count) or 0,
        tonumber(stats.component_count) or 0,
        tonumber(stats.rooted_component_count) or 0,
        tonumber(stats.rootless_component_count) or 0,
        tonumber(stats.rooted_reachable_count) or 0,
        tonumber(stats.unreachable_count) or 0,
        tonumber(stats.wave_count) or 0,
        tonumber(stats.rejected_count) or 0,
        tonumber(stats.abstained_count) or 0,
        tostring(stats.can_reach_all == true),
        tostring(stats.can_schedule_all == true)
    )
end

return Gate

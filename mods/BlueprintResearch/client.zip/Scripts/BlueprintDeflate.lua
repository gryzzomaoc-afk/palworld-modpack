-- Minimal raw DEFLATE codec for BlueprintResearch clipboard transport.
--
-- The encoder emits one RFC 1951 fixed-Huffman block.  The decoder accepts
-- stored and fixed-Huffman blocks, which is sufficient for every stream this
-- module creates.  Keeping this in a separate module avoids any native zlib
-- DLL dependency inside UE4SS.

local Deflate = {}

Deflate.MAX_OUTPUT_BYTES = 8 * 1024 * 1024

local LENGTH_BASE = {
    3, 4, 5, 6, 7, 8, 9, 10,
    11, 13, 15, 17, 19, 23, 27, 31,
    35, 43, 51, 59, 67, 83, 99, 115,
    131, 163, 195, 227, 258,
}

local LENGTH_EXTRA = {
    0, 0, 0, 0, 0, 0, 0, 0,
    1, 1, 1, 1, 2, 2, 2, 2,
    3, 3, 3, 3, 4, 4, 4, 4,
    5, 5, 5, 5, 0,
}

local DISTANCE_BASE = {
    1, 2, 3, 4, 5, 7, 9, 13,
    17, 25, 33, 49, 65, 97, 129, 193,
    257, 385, 513, 769, 1025, 1537, 2049, 3073,
    4097, 6145, 8193, 12289, 16385, 24577,
}

local DISTANCE_EXTRA = {
    0, 0, 0, 0, 1, 1, 2, 2,
    3, 3, 4, 4, 5, 5, 6, 6,
    7, 7, 8, 8, 9, 9, 10, 10,
    11, 11, 12, 12, 13, 13,
}

local function reverse_bits(value, count)
    local reversed = 0
    for _ = 1, count do
        reversed = (reversed << 1) | (value & 1)
        value = value >> 1
    end
    return reversed
end

local function fixed_literal_code(symbol)
    if symbol <= 143 then
        return reverse_bits(0x30 + symbol, 8), 8
    elseif symbol <= 255 then
        return reverse_bits(0x190 + symbol - 144, 9), 9
    elseif symbol <= 279 then
        return reverse_bits(symbol - 256, 7), 7
    end
    return reverse_bits(0xC0 + symbol - 280, 8), 8
end

local function new_bit_writer()
    local writer = { output = {}, buffer = 0, count = 0 }

    function writer:write(value, count)
        if count <= 0 then return end
        local mask = (1 << count) - 1
        self.buffer = self.buffer | ((value & mask) << self.count)
        self.count = self.count + count
        while self.count >= 8 do
            self.output[#self.output + 1] = string.char(self.buffer & 0xFF)
            self.buffer = self.buffer >> 8
            self.count = self.count - 8
        end
    end

    function writer:finish()
        if self.count > 0 then
            self.output[#self.output + 1] = string.char(self.buffer & 0xFF)
            self.buffer = 0
            self.count = 0
        end
        return table.concat(self.output)
    end

    return writer
end

local function write_fixed_symbol(writer, symbol)
    local code, count = fixed_literal_code(symbol)
    writer:write(code, count)
end

local function find_length_code(length)
    for index = 1, #LENGTH_BASE do
        local base = LENGTH_BASE[index]
        local extra = LENGTH_EXTRA[index]
        local maximum = base + ((1 << extra) - 1)
        if length <= maximum then
            return 256 + index, length - base, extra
        end
    end
    error("DEFLATE match length is out of range")
end

local function find_distance_code(distance)
    for index = 1, #DISTANCE_BASE do
        local base = DISTANCE_BASE[index]
        local extra = DISTANCE_EXTRA[index]
        local maximum = base + ((1 << extra) - 1)
        if distance <= maximum then
            return index - 1, distance - base, extra
        end
    end
    error("DEFLATE match distance is out of range")
end

local function compress_fixed_impl(data)
    if type(data) ~= "string" then error("DEFLATE input must be a string") end
    local writer = new_bit_writer()
    -- BFINAL=1, BTYPE=01 (fixed Huffman).
    writer:write(1, 1)
    writer:write(1, 2)

    local candidates = {}
    local position = 1
    local data_length = #data

    local function add_position(candidate_position)
        if candidate_position + 2 > data_length then return end
        local key = string.sub(data, candidate_position, candidate_position + 2)
        local ring = candidates[key]
        if ring == nil then
            ring = { next = 1, count = 0 }
            candidates[key] = ring
        end
        ring[ring.next] = candidate_position
        ring.next = ring.next % 64 + 1
        ring.count = math.min(ring.count + 1, 64)
    end

    local function find_match(match_position)
        if match_position + 2 > data_length then return 0, 0 end
        local key = string.sub(data, match_position, match_position + 2)
        local ring = candidates[key]
        if ring == nil then return 0, 0 end
        local best_distance = 0
        local best_length = 0
        local maximum_length = math.min(258, data_length - match_position + 1)
        for age = 0, ring.count - 1 do
            local ring_index = ((ring.next - 2 - age) % 64) + 1
            local candidate = ring[ring_index]
            local distance = match_position - candidate
            if distance > 0 and distance <= 32768 then
                local match_length = 0
                while match_length < maximum_length
                    and string.byte(data, candidate + match_length)
                        == string.byte(data, match_position + match_length) do
                    match_length = match_length + 1
                end
                if match_length > best_length then
                    best_distance = distance
                    best_length = match_length
                    if best_length == maximum_length then break end
                end
            end
        end
        if best_length < 3 then return 0, 0 end
        return best_distance, best_length
    end

    while position <= data_length do
        local distance, match_length = find_match(position)
        if match_length >= 3 then
            local length_symbol, length_value, length_bits =
                find_length_code(match_length)
            write_fixed_symbol(writer, length_symbol)
            writer:write(length_value, length_bits)

            local distance_symbol, distance_value, distance_bits =
                find_distance_code(distance)
            writer:write(reverse_bits(distance_symbol, 5), 5)
            writer:write(distance_value, distance_bits)

            for consumed = 0, match_length - 1 do
                add_position(position + consumed)
            end
            position = position + match_length
        else
            write_fixed_symbol(writer, string.byte(data, position))
            add_position(position)
            position = position + 1
        end
    end

    write_fixed_symbol(writer, 256)
    return writer:finish()
end

local FIXED_LITERAL_DECODE = {}
for symbol = 0, 287 do
    local code, count = fixed_literal_code(symbol)
    local by_length = FIXED_LITERAL_DECODE[count]
    if by_length == nil then
        by_length = {}
        FIXED_LITERAL_DECODE[count] = by_length
    end
    by_length[code] = symbol
end

local FIXED_DISTANCE_DECODE = {}
for symbol = 0, 31 do
    FIXED_DISTANCE_DECODE[reverse_bits(symbol, 5)] = symbol
end

local function new_bit_reader(data)
    local reader = { data = data, position = 1, buffer = 0, count = 0 }

    function reader:read(count)
        if count <= 0 then return 0 end
        while self.count < count do
            local byte = string.byte(self.data, self.position)
            if byte == nil then error("truncated DEFLATE bitstream") end
            self.position = self.position + 1
            self.buffer = self.buffer | (byte << self.count)
            self.count = self.count + 8
        end
        local mask = (1 << count) - 1
        local result = self.buffer & mask
        self.buffer = self.buffer >> count
        self.count = self.count - count
        return result
    end

    function reader:align_byte()
        local discard = self.count % 8
        if discard > 0 then self:read(discard) end
    end

    return reader
end

local function read_fixed_literal(reader)
    local code = 0
    for count = 1, 9 do
        code = code | (reader:read(1) << (count - 1))
        local by_length = FIXED_LITERAL_DECODE[count]
        local symbol = by_length ~= nil and by_length[code] or nil
        if symbol ~= nil then return symbol end
    end
    error("invalid fixed-Huffman literal/length code")
end

local function append_byte(output, byte, maximum_size)
    if #output >= maximum_size then error("DEFLATE output exceeds declared size") end
    output[#output + 1] = string.char(byte)
end

local function inflate_impl(data, expected_size)
    if type(data) ~= "string" then error("DEFLATE input must be a string") end
    expected_size = tonumber(expected_size)
    if expected_size == nil or expected_size < 0
        or expected_size % 1 ~= 0
        or expected_size > Deflate.MAX_OUTPUT_BYTES then
        error("invalid DEFLATE output size")
    end

    local reader = new_bit_reader(data)
    local output = {}
    local is_final = false
    while not is_final do
        is_final = reader:read(1) == 1
        local block_type = reader:read(2)
        if block_type == 0 then
            reader:align_byte()
            local length = reader:read(16)
            local inverse_length = reader:read(16)
            if ((~length) & 0xFFFF) ~= inverse_length then
                error("stored DEFLATE block length check failed")
            end
            for _ = 1, length do
                append_byte(output, reader:read(8), expected_size)
            end
        elseif block_type == 1 then
            while true do
                local symbol = read_fixed_literal(reader)
                if symbol < 256 then
                    append_byte(output, symbol, expected_size)
                elseif symbol == 256 then
                    break
                elseif symbol <= 285 then
                    local length_index = symbol - 256
                    local length = LENGTH_BASE[length_index]
                        + reader:read(LENGTH_EXTRA[length_index])
                    local distance_symbol = FIXED_DISTANCE_DECODE[reader:read(5)]
                    if distance_symbol == nil or distance_symbol > 29 then
                        error("invalid fixed-Huffman distance code")
                    end
                    local distance_index = distance_symbol + 1
                    local distance = DISTANCE_BASE[distance_index]
                        + reader:read(DISTANCE_EXTRA[distance_index])
                    if distance <= 0 or distance > #output then
                        error("invalid DEFLATE match distance")
                    end
                    for _ = 1, length do
                        local source_index = #output - distance + 1
                        append_byte(
                            output, string.byte(output[source_index]), expected_size
                        )
                    end
                else
                    error("reserved DEFLATE literal/length code")
                end
            end
        elseif block_type == 2 then
            error("dynamic-Huffman DEFLATE blocks are not supported by PWB9D")
        else
            error("reserved DEFLATE block type")
        end
    end

    if #output ~= expected_size then
        error("DEFLATE output size mismatch")
    end
    return table.concat(output)
end

function Deflate.compress(data)
    local ok, result = pcall(compress_fixed_impl, data)
    if not ok then return nil, tostring(result) end
    return result, nil
end

function Deflate.decompress(data, expected_size)
    local ok, result = pcall(inflate_impl, data, expected_size)
    if not ok then return nil, tostring(result) end
    return result, nil
end

return Deflate

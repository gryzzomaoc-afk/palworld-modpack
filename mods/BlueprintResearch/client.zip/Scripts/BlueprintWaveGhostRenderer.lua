local UEHelpers = require("UEHelpers")
local BlueprintPerformance = require("BlueprintPerformance")
local BlueprintPreviewMesh = require("BlueprintPreviewMesh")

local BlueprintWaveGhostRenderer = {}

local COMPONENT_ARRAY = "SBB_BuildSessionGhostComponents"
local SOURCE_ORDINAL_ARRAY = "SBB_BuildSessionGhostSourceOrdinals"

local function identity_transform()
    return {
        Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 },
        Translation = { X = 0.0, Y = 0.0, Z = 0.0 },
        Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
    }
end

local function copy_snapshot_transform(value)
    if type(value) ~= "table"
        or type(value.translation) ~= "table"
        or type(value.rotation) ~= "table"
        or type(value.scale) ~= "table" then
        return nil
    end
    local copy = {
        translation = {
            x = tonumber(value.translation.x),
            y = tonumber(value.translation.y),
            z = tonumber(value.translation.z),
        },
        rotation = {
            x = tonumber(value.rotation.x),
            y = tonumber(value.rotation.y),
            z = tonumber(value.rotation.z),
            w = tonumber(value.rotation.w),
        },
        scale = {
            x = tonumber(value.scale.x),
            y = tonumber(value.scale.y),
            z = tonumber(value.scale.z),
        },
    }
    if copy.translation.x == nil or copy.translation.y == nil
        or copy.translation.z == nil or copy.rotation.x == nil
        or copy.rotation.y == nil or copy.rotation.z == nil
        or copy.rotation.w == nil or copy.scale.x == nil
        or copy.scale.y == nil or copy.scale.z == nil then
        return nil
    end
    return copy
end

function BlueprintWaveGhostRenderer.install(deps)
    assert(type(deps) == "table",
        "BlueprintWaveGhostRenderer dependencies are required")

    local log = assert(deps.log, "wave ghost renderer log is required")
    local unwrap = assert(deps.unwrap, "wave ghost renderer unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object,
        "wave ghost renderer is_valid_object is required")
    local safe_property = assert(
        deps.safe_property, "wave ghost renderer safe_property is required")
    local restore_transform = assert(
        deps.restore_transform,
        "wave ghost renderer restore_transform is required")
    local get_preview_material = assert(
        deps.get_preview_material,
        "wave ghost renderer get_preview_material is required")
    local get_asset_path = assert(
        deps.get_asset_path,
        "wave ghost renderer get_asset_path is required")
    local renderer = {}

    local function get_actor_array(actor, property_name)
        actor = unwrap(actor)
        if not is_valid_object(actor) then return nil end
        return safe_property(actor, property_name)
    end

    local function array_count(values)
        local count = 0
        if values ~= nil then pcall(function() count = #values end) end
        return count
    end

    local function get_component(actor, index)
        local values = get_actor_array(actor, COMPONENT_ARRAY)
        local component = nil
        if values ~= nil then
            pcall(function() component = unwrap(values[index]) end)
        end
        return is_valid_object(component) and component or nil
    end

    local function set_owned_component(
        actor, index, component, source_ordinal
    )
        local components = get_actor_array(actor, COMPONENT_ARRAY)
        local ordinals = get_actor_array(actor, SOURCE_ORDINAL_ARRAY)
        if components == nil or ordinals == nil then
            return false, "Build Session ghost arrays are unavailable"
        end
        local ok, error_value = pcall(function()
            components[index] = unwrap(component)
            ordinals[index] = tonumber(source_ordinal) or 0
        end)
        return ok, ok and nil or tostring(error_value)
    end

    local function empty_owned_arrays(actor)
        local components = get_actor_array(actor, COMPONENT_ARRAY)
        local ordinals = get_actor_array(actor, SOURCE_ORDINAL_ARRAY)
        if components == nil or ordinals == nil then
            return false, "Build Session ghost arrays are unavailable"
        end
        local ok, error_value = pcall(function()
            components:Empty()
            ordinals:Empty()
        end)
        return ok, ok and nil or tostring(error_value)
    end

    local function hide_component(component)
        component = unwrap(component)
        if not is_valid_object(component) then return false end
        return pcall(function()
            component:SetVisibility(false, true)
            component:SetHiddenInGame(true, true)
            component:SetGenerateOverlapEvents(false)
            component:SetCollisionEnabled(0)
        end)
    end

    local function log_summary(visual)
        if type(visual) ~= "table" or visual.summary_logged == true then
            return
        end
        visual.summary_logged = true
        local performance = visual.performance or {}
        log(string.format(
            "blueprint performance wave-ghost-summary ownership=build-session-actor createMs=%.2f assetLookupMs=%.2f componentCreateMs=%.2f componentSetupMs=%.2f materialMs=%.2f visibilityMs=%.2f requestHideTotalMs=%.2f requestHideMaxMs=%.2f requestHideCalls=%d components=%d hiddenOnAccept=%d residualHidden=%d",
            tonumber(performance.create_ms) or 0.0,
            tonumber(performance.asset_lookup_ms) or 0.0,
            tonumber(performance.component_create_ms) or 0.0,
            tonumber(performance.component_setup_ms) or 0.0,
            tonumber(performance.material_ms) or 0.0,
            tonumber(performance.visibility_ms) or 0.0,
            tonumber(performance.request_hide_total_ms) or 0.0,
            tonumber(performance.request_hide_max_ms) or 0.0,
            tonumber(performance.request_hide_calls) or 0,
            tonumber(visual.component_count) or 0,
            tonumber(performance.hidden_on_accept) or 0,
            tonumber(performance.residual_hidden) or 0
        ))
    end

    function renderer.snapshot(blueprint, excluded_source_ids)
        if type(blueprint) ~= "table"
            or type(blueprint.buildings) ~= "table" then
            return nil, "blueprint buildings unavailable"
        end
        local preview_material = unwrap(get_preview_material())
        local preview_material_path = is_valid_object(preview_material)
            and get_asset_path(preview_material) or nil
        if type(preview_material_path) ~= "string"
            or preview_material_path == "" then
            return nil, "wave preview material identity unavailable"
        end
        local snapshot = {
            buildings = {},
            preview_material_path = preview_material_path,
        }
        for building_ordinal, building in ipairs(blueprint.buildings) do
            if type(building) == "table"
                and not (
                    excluded_source_ids ~= nil
                    and excluded_source_ids[
                        building.source_instance_id
                    ] == true
                ) then
                local relative_transform = copy_snapshot_transform(
                    building.relative_transform)
                if relative_transform == nil then
                    return nil,
                        "invalid wave building transform sourceInstance="
                            .. tostring(building.source_instance_id)
                end
                local copy = {
                    is_anchor = building.is_anchor == true,
                    source_instance_id = building.source_instance_id,
                    source_ordinal = building_ordinal,
                    relative_transform = relative_transform,
                    preview_meshes = {},
                }
                for _, mesh in ipairs(building.preview_meshes or {}) do
                    local mesh_copy, mesh_error =
                        BlueprintPreviewMesh.copy_descriptor(
                            mesh, copy_snapshot_transform)
                    if mesh_copy == nil then
                        return nil,
                            "invalid wave mesh descriptor sourceInstance="
                                .. tostring(building.source_instance_id)
                                .. " error=" .. tostring(mesh_error)
                    end
                    table.insert(copy.preview_meshes, mesh_copy)
                end
                table.insert(snapshot.buildings, copy)
            end
        end
        return snapshot, nil
    end

    function renderer.create(snapshot, anchor_transform, owner_actor)
        local performance_started_at = BlueprintPerformance.now()
        owner_actor = unwrap(owner_actor)
        if type(snapshot) ~= "table"
            or type(snapshot.buildings) ~= "table"
            or anchor_transform == nil
            or not is_valid_object(owner_actor) then
            return nil,
                "wave snapshot, anchor transform or Build Session unavailable"
        end
        local arrays_empty, arrays_error =
            empty_owned_arrays(owner_actor)
        if not arrays_empty then return nil, arrays_error end

        local static_component_class = unwrap(
            StaticFindObject("/Script/Engine.StaticMeshComponent"))
        local skeletal_component_class = unwrap(
            StaticFindObject("/Script/Engine.SkeletalMeshComponent"))
        local math_library = UEHelpers.GetKismetMathLibrary()
        local material = nil
        if type(snapshot.preview_material_path) == "string" then
            material = unwrap(StaticFindObject(
                snapshot.preview_material_path))
        end
        if not is_valid_object(material) then
            material = unwrap(get_preview_material())
        end
        if not is_valid_object(static_component_class)
            or not is_valid_object(skeletal_component_class)
            or not is_valid_object(math_library)
            or not is_valid_object(material) then
            return nil, "wave ghost renderer dependencies unavailable"
        end

        -- This descriptor is pure Lua data. It retains only component indices;
        -- every UObject remains exclusively in the Build Session Actor arrays.
        local visual = {
            buildings_by_source_instance = {},
            component_count = 0,
            remaining_components = 0,
            abandoned = false,
            performance = {
                asset_lookup_ms = 0.0,
                component_create_ms = 0.0,
                component_setup_ms = 0.0,
                material_ms = 0.0,
                visibility_ms = 0.0,
                material_slots = 0,
                request_hide_total_ms = 0.0,
                request_hide_max_ms = 0.0,
                request_hide_calls = 0,
                hidden_on_accept = 0,
                residual_hidden = 0,
            },
        }
        local performance = visual.performance
        local resolved_meshes = {}
        local component_index = 0
        local create_ok, create_error = pcall(function()
            for _, building in ipairs(snapshot.buildings) do
                local building_relative = restore_transform(
                    building.relative_transform)
                if building_relative == nil then
                    error("invalid building transform sourceInstance="
                        .. tostring(building.source_instance_id))
                end
                local building_visual = {
                    component_indices = {},
                    disposed = false,
                }
                visual.buildings_by_source_instance[
                    building.source_instance_id] = building_visual
                for _, mesh_descriptor in ipairs(
                    building.preview_meshes or {}
                ) do
                    local mesh_path, mesh_kind =
                        BlueprintPreviewMesh.asset_path(mesh_descriptor)
                    if mesh_path == nil or mesh_kind == nil then
                        error("wave mesh identity unavailable sourceInstance="
                            .. tostring(building.source_instance_id))
                    end
                    local mesh_relative = restore_transform(
                        mesh_descriptor.relative_transform)
                    if mesh_relative == nil then
                        error("invalid mesh transform sourceInstance="
                            .. tostring(building.source_instance_id))
                    end
                    local mesh_cache_key =
                        BlueprintPreviewMesh.cache_key(mesh_descriptor)
                    local mesh_asset = resolved_meshes[mesh_cache_key]
                    if mesh_asset == nil then
                        local asset_started_at = BlueprintPerformance.now()
                        mesh_asset = unwrap(StaticFindObject(mesh_path))
                        BlueprintPerformance.add_elapsed(
                            performance, "asset_lookup_ms", asset_started_at)
                        if is_valid_object(mesh_asset) then
                            resolved_meshes[mesh_cache_key] = mesh_asset
                        end
                    end
                    if not is_valid_object(mesh_asset) then
                        error(tostring(mesh_kind)
                            .. " mesh unavailable path=" .. tostring(mesh_path))
                    end

                    local component_started_at = BlueprintPerformance.now()
                    local component_class =
                        mesh_kind == BlueprintPreviewMesh.SKELETAL
                        and skeletal_component_class
                        or static_component_class
                    local component = unwrap(owner_actor:AddComponentByClass(
                        component_class, true, identity_transform(), false))
                    BlueprintPerformance.add_elapsed(
                        performance, "component_create_ms",
                        component_started_at)
                    if not is_valid_object(component) then
                        error("wave ghost component creation failed")
                    end
                    component_index = component_index + 1
                    local stored, store_error = set_owned_component(
                        owner_actor, component_index, component,
                        building.source_ordinal)
                    if not stored then
                        error("wave ghost ownership write failed index="
                            .. tostring(component_index) .. " error="
                            .. tostring(store_error))
                    end
                    building_visual.component_indices[
                        #building_visual.component_indices + 1
                    ] = component_index
                    visual.component_count = component_index
                    visual.remaining_components =
                        visual.remaining_components + 1

                    local root_relative = math_library:ComposeTransforms(
                        mesh_relative, building_relative)
                    local world_transform = math_library:ComposeTransforms(
                        root_relative, anchor_transform)
                    local material_slots = math.max(
                        tonumber(mesh_descriptor.material_slot_count) or 1, 1)
                    local setup_started_at = BlueprintPerformance.now()
                    component:SetMobility(2)
                    component:SetAbsolute(true, true, true)
                    component:SetCollisionEnabled(0)
                    component:SetGenerateOverlapEvents(false)
                    component:SetCastShadow(false)
                    component:SetReceivesDecals(false)
                    component:SetRenderInMainPass(true)
                    if mesh_kind == BlueprintPreviewMesh.SKELETAL then
                        component:SetSkeletalMeshAsset(mesh_asset)
                        pcall(function() component:SetAnimationMode(1) end)
                        pcall(function()
                            component.bPauseAnims = true
                            component.GlobalAnimRateScale = 0.0
                            component:SetComponentTickEnabled(false)
                        end)
                    else
                        component:SetStaticMesh(mesh_asset)
                    end
                    component:K2_SetWorldTransform(
                        world_transform, false, {}, true)
                    BlueprintPerformance.add_elapsed(
                        performance, "component_setup_ms", setup_started_at)
                    local material_started_at = BlueprintPerformance.now()
                    for slot_index = 0, material_slots - 1 do
                        component:SetMaterial(slot_index, material)
                    end
                    BlueprintPerformance.add_elapsed(
                        performance, "material_ms", material_started_at)
                    performance.material_slots =
                        performance.material_slots + material_slots
                    local visibility_started_at = BlueprintPerformance.now()
                    component:SetHiddenInGame(false, true)
                    component:SetVisibility(true, true)
                    BlueprintPerformance.add_elapsed(
                        performance, "visibility_ms", visibility_started_at)
                    -- The wrapper is deliberately not stored in visual.
                    component = nil
                end
            end
        end)
        if not create_ok then
            renderer.hide_all(visual, owner_actor)
            return nil, tostring(create_error)
        end
        performance.create_ms =
            BlueprintPerformance.elapsed_ms(performance_started_at)
        log(string.format(
            "blueprint performance wave-ghost-create ownership=build-session-actor totalMs=%.2f components=%d materialSlots=%d assetLookupMs=%.2f componentCreateMs=%.2f componentSetupMs=%.2f materialMs=%.2f visibilityMs=%.2f",
            performance.create_ms, visual.component_count,
            performance.material_slots, performance.asset_lookup_ms,
            performance.component_create_ms,
            performance.component_setup_ms, performance.material_ms,
            performance.visibility_ms
        ))
        return visual, nil
    end

    function renderer.dispose_request(visual, request, owner_actor)
        if type(visual) ~= "table" or visual.abandoned == true
            or request == nil or not is_valid_object(unwrap(owner_actor)) then
            return false
        end
        local building = visual.buildings_by_source_instance[
            request.source_instance_id]
        if building == nil or building.disposed == true then return true end
        building.disposed = true
        local performance_started_at = BlueprintPerformance.now()
        local hidden = 0
        for _, index in ipairs(building.component_indices or {}) do
            if hide_component(get_component(owner_actor, index)) then
                hidden = hidden + 1
                visual.remaining_components =
                    math.max(visual.remaining_components - 1, 0)
            end
        end
        building.component_indices = {}
        visual.buildings_by_source_instance[
            request.source_instance_id] = nil
        local elapsed_ms =
            BlueprintPerformance.elapsed_ms(performance_started_at)
        local performance = visual.performance
        performance.request_hide_calls =
            performance.request_hide_calls + 1
        performance.request_hide_total_ms =
            performance.request_hide_total_ms + elapsed_ms
        performance.request_hide_max_ms = math.max(
            performance.request_hide_max_ms, elapsed_ms)
        performance.hidden_on_accept =
            performance.hidden_on_accept + hidden
        return true
    end

    function renderer.hide_all(visual, owner_actor)
        if type(visual) ~= "table" or visual.abandoned == true then
            return true
        end
        local hidden = 0
        if is_valid_object(unwrap(owner_actor)) then
            local components = get_actor_array(
                owner_actor, COMPONENT_ARRAY)
            for index = 1, array_count(components) do
                if hide_component(get_component(owner_actor, index)) then
                    hidden = hidden + 1
                end
            end
        end
        visual.performance.residual_hidden =
            visual.performance.residual_hidden + hidden
        visual.remaining_components = 0
        visual.buildings_by_source_instance = {}
        visual.abandoned = true
        log_summary(visual)
        return true
    end

    function renderer.abandon(visual, reason)
        if type(visual) ~= "table" or visual.abandoned == true then
            return true
        end
        local remaining = tonumber(visual.remaining_components) or 0
        visual.remaining_components = 0
        visual.buildings_by_source_instance = {}
        visual.abandoned = true
        if remaining > 0 then
            log("blueprint wave ghost pure descriptor abandoned components="
                .. tostring(remaining) .. " reason=" .. tostring(reason))
        end
        log_summary(visual)
        return true
    end

    return renderer
end

return BlueprintWaveGhostRenderer

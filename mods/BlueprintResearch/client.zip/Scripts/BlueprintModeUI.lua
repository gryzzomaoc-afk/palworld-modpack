local RuntimeUtils = require("BlueprintRuntimeUtils")
local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local unwrap = RuntimeUtils.unwrap
local value_to_string = RuntimeUtils.value_to_string
local object_name = RuntimeUtils.object_name
local is_valid_object = RuntimeUtils.is_valid_object
local is_usable_class_object = RuntimeUtils.is_usable_class_object
local class_object_name = RuntimeUtils.class_object_name
local safe_object_address = RuntimeUtils.safe_object_address
local safe_property = RuntimeUtils.safe_property
local get_asset_path = RuntimeUtils.get_asset_path

local function make_object_handle(value)
    value = unwrap(value)
    if not is_valid_object(value) then return nil end
    local path = get_asset_path(value)
    local address = safe_object_address(value)
    if type(path) ~= "string" or path == "" or address == nil then
        return nil
    end
    return { path = path, address = address }
end

local function resolve_object_handle(handle)
    if type(handle) ~= "table" or type(handle.path) ~= "string"
        or handle.address == nil then
        return nil
    end
    local ok, value = pcall(StaticFindObject, handle.path)
    value = ok and unwrap(value) or nil
    if not is_valid_object(value)
        or safe_object_address(value) ~= handle.address then
        return nil
    end
    return value
end

local UEHelpers = nil
local log = function() end
local localize = function(key) return tostring(key or "") end

local BlueprintModeUI = {
    widget_package_path = "/Game/Mods/BlueprintResearch/UI/" ..
        "WBP_BlueprintModeButtons",
    widget_asset_path = "/Game/Mods/BlueprintResearch/UI/" ..
        "WBP_BlueprintModeButtons.WBP_BlueprintModeButtons",
    widget_class_path = "/Game/Mods/BlueprintResearch/UI/" ..
        "WBP_BlueprintModeButtons.WBP_BlueprintModeButtons_C",
    original_input_class_path = "/Game/Pal/Blueprint/UI/System/Style/" ..
        "WBP_PalInvisibleButton.WBP_PalInvisibleButton_C",
    gradient_material_path = "/Game/Pal/Material/UI/Ingame/" ..
        "M_UI_BaseGrd_Vertical.M_UI_BaseGrd_Vertical",
    pal_font_path = "/Game/Pal/Font/" ..
        "Ft_PalDefaultFont.Ft_PalDefaultFont",
    pal_font_material_path = "/Game/Pal/Material/UI/Fontcolor/" ..
        "MI_UI_Color_White_02.MI_UI_Color_White_02",
    input_action_table_package_path =
        "/Game/Pal/DataTable/UI/DT_UIInputAction",
    input_action_table_path =
        "/Game/Pal/DataTable/UI/DT_UIInputAction.DT_UIInputAction",
    input_action_rows = {
        create = {
            name = "BlueprintResearch_CreateBlueprint",
            key = "G",
            widget = "KeyGuide_BlueprintCreate",
        },
        place = {
            name = "BlueprintResearch_PlaceBlueprint",
            key = "K",
            widget = "KeyGuide_BlueprintPlace",
        },
    },
    input_action_rows_ready = false,
    active_widget_handle = nil,
    active_menu_name = nil,
    active_menu_address = nil,
    active_handler_addresses = {},
    click_handlers = {},
    request_hooks = { create = false, place = false },
    request_hook_callbacks = {},
    registered_hook_callbacks = {},
    scheduled_callbacks = {},
    injection_states = {},
    injection_retry_delays_ms = { 16, 16, 33, 50, 100, 150 },
    transition = nil,
    transition_sequence = 0,
    transition_release_delay_ms = 300,
    transition_release_callbacks = {},
    prewarm_in_progress = false,
    prewarm_assets_ready = false,
    prewarm_ready = false,
    prewarm_callback = nil,
    request_hook_registration_scheduled = false,
    request_hook_registration_callback = nil,
    notify_callback = nil,
    notify_ok = false,
    notify_error = nil,
    load_diagnostic_emitted = false,
}

BlueprintModeUI.callbacks = {}
BlueprintModeUI.installed = false
BlueprintModeUI.common_button_hook_callback = nil

local function retain_ui_hook_callback(path, callback)
    local retained = function(...)
        local ok, error_value = pcall(callback, ...)
        if not ok then
            log("blueprint mode UI hook isolated error path="
                .. tostring(path) .. " error=" .. tostring(error_value))
        end
    end
    table.insert(BlueprintModeUI.registered_hook_callbacks, retained)
    return retained
end

local function register_ui_hook(path, callback)
    local retained = retain_ui_hook_callback(path, callback)
    local ok, pre_id, post_id = pcall(RegisterHook, path, retained)
    if ok then
        log(string.format("hooked %s pre=%s post=%s", path,
            tostring(pre_id), tostring(post_id)))
        return true
    end
    log(string.format("hook failed %s error=%s", path, tostring(pre_id)))
    return false
end

function BlueprintModeUI.get_open_construction_menu()
    -- Several build-list widgets can remain alive under /Engine/Transient after
    -- reopening the construction menu.  Looking up only the first nested
    -- WBP_IngameMenu_Construction_Menu can therefore select a stale, hidden
    -- instance.  Inspect every root build-list widget and use the one Slate
    -- currently considers active or visible.
    local menus = FindAllOf("WBP_PalBuildObjectList_ForDisplay_C") or {}
    for _, candidate in ipairs(menus) do
        candidate = unwrap(candidate)
        if is_valid_object(candidate)
            and string.find(object_name(candidate), "/Engine/Transient", 1, true) then
            local activated_ok, is_activated = pcall(function()
                return candidate:IsActivated()
            end)
            if activated_ok and is_activated == true then
                return candidate
            end

            local visibility_ok, is_visible = pcall(function()
                return candidate:IsVisible()
            end)
            if visibility_ok and is_visible == true then
                return candidate
            end
        end
    end
    return nil
end

function BlueprintModeUI.short_widget_name(widget)
    widget = unwrap(widget)
    if not is_valid_object(widget) then return "<invalid>" end
    local ok, name = pcall(function()
        return value_to_string(widget:GetFName())
    end)
    if ok and name ~= nil and name ~= "<nil>" then return name end
    local full_name = object_name(widget)
    return string.match(full_name, "([^%.:]+)$") or full_name
end

function BlueprintModeUI.find_descendant(root, wanted_name, depth)
    root = unwrap(root)
    depth = depth or 0
    if not is_valid_object(root) or depth > 48 then return nil end
    if BlueprintModeUI.short_widget_name(root) == wanted_name then return root end

    local count_ok, count = pcall(function() return root:GetChildrenCount() end)
    if not count_ok or type(count) ~= "number" then return nil end
    for index = 0, count - 1 do
        local child = nil
        pcall(function() child = unwrap(root:GetChildAt(index)) end)
        local found = BlueprintModeUI.find_descendant(
            child, wanted_name, depth + 1
        )
        if is_valid_object(found) then return found end
    end
    return nil
end

function BlueprintModeUI.find_in_instance(instance, wanted_name)
    instance = unwrap(instance)
    if not is_valid_object(instance) then return nil end
    local direct = unwrap(safe_property(instance, wanted_name))
    if is_valid_object(direct) then return direct end

    local named_widget = nil
    pcall(function()
        named_widget = unwrap(instance:GetWidgetFromName(FName(wanted_name)))
    end)
    if is_valid_object(named_widget) then return named_widget end

    -- Cooked Widget Blueprint members only become direct UObject properties
    -- when "Is Variable" was enabled in the editor.  Non-variable widgets are
    -- still present in the runtime WidgetTree, so query that tree by name before
    -- falling back to a recursive panel walk.
    local widget_tree = unwrap(safe_property(instance, "WidgetTree"))
    if is_valid_object(widget_tree) then
        local tree_match = nil
        pcall(function()
            tree_match = unwrap(widget_tree:FindWidget(FName(wanted_name)))
        end)
        if is_valid_object(tree_match) then return tree_match end

        local tree_root = unwrap(safe_property(widget_tree, "RootWidget"))
        local found = BlueprintModeUI.find_descendant(
            tree_root, wanted_name, 0
        )
        if is_valid_object(found) then return found end
    end

    local root = unwrap(safe_property(instance, "SizeBox_Root"))
    if not is_valid_object(root) then
        root = unwrap(safe_property(instance, "Canvas_ModeEntry"))
    end
    return BlueprintModeUI.find_descendant(root, wanted_name, 0)
end

function BlueprintModeUI.find_active_construction_menu()
    local build_list = BlueprintModeUI.get_open_construction_menu()
    local nested = unwrap(safe_property(
        build_list, "WBP_IngameMenu_Construction_Menu"
    ))
    if is_valid_object(nested) then return nested end

    local menus = FindAllOf("WBP_IngameMenu_Construction_Menu_C") or {}
    for _, candidate in ipairs(menus) do
        candidate = unwrap(candidate)
        if is_valid_object(candidate)
            and string.find(object_name(candidate), "/Engine/Transient", 1, true) then
            local visible_ok, visible = pcall(function()
                return candidate:IsVisible()
            end)
            if visible_ok and visible == true then return candidate end
        end
    end
    return nil
end

function BlueprintModeUI.load_widget_class()
    -- UE4SS LoadAsset expects a package path.  Loading the generated-class
    -- object path directly does not load the package on all UE4SS builds.
    local package_ok, package_result = pcall(
        LoadAsset, BlueprintModeUI.widget_package_path
    )

    local widget_class = unwrap(StaticFindObject(
        BlueprintModeUI.widget_class_path
    ))
    if is_usable_class_object(widget_class) then return widget_class end

    -- Depending on the UE4SS build, LoadAsset may return the package asset or
    -- generated class directly instead of only populating the object array.
    local returned_class = unwrap(package_result)
    if is_usable_class_object(returned_class) then
        local returned_name = class_object_name(returned_class)
        if string.find(returned_name, "BlueprintGeneratedClass", 1, true) then
            return returned_class
        end
    end

    -- Loading the package asset can expose its GeneratedClass even when a
    -- direct StaticFindObject lookup has not resolved the _C object yet.
    local asset = unwrap(package_result)
    local generated_class = nil
    if is_valid_object(asset) then
        generated_class = unwrap(safe_property(asset, "GeneratedClass"))
        if is_usable_class_object(generated_class) then return generated_class end
    end

    -- StaticFindObject is the preferred exact-path lookup.  FindObject is a
    -- compatibility fallback for builds where the class was loaded under the
    -- expected short name but exact-path resolution has not caught up yet.
    local find_ok, find_result = pcall(
        FindObject,
        "WidgetBlueprintGeneratedClass",
        "WBP_BlueprintModeButtons_C"
    )
    local found_class = unwrap(find_result)
    if find_ok and is_usable_class_object(found_class) then return found_class end

    local class_find_ok, class_find_result = pcall(
        FindObject,
        "Class",
        "WBP_BlueprintModeButtons_C"
    )
    found_class = unwrap(class_find_result)
    if class_find_ok and is_usable_class_object(found_class) then
        return found_class
    end

    if not BlueprintModeUI.load_diagnostic_emitted then
        BlueprintModeUI.load_diagnostic_emitted = true
        log("blueprint mode UI asset load diagnostic package_ok="
            .. tostring(package_ok)
            .. " package_result=" .. tostring(value_to_string(package_result))
            .. " exact_class=" .. tostring(class_object_name(widget_class))
            .. " generated_class=" .. tostring(class_object_name(generated_class))
            .. " find_ok=" .. tostring(find_ok)
            .. " find_result=" .. tostring(value_to_string(find_result))
            .. " class_find_ok=" .. tostring(class_find_ok)
            .. " class_find_result="
            .. tostring(value_to_string(class_find_result)))
    end
    return nil
end

function BlueprintModeUI.load_input_action_table()
    local load_result = nil
    pcall(function()
        load_result = unwrap(LoadAsset(
            BlueprintModeUI.input_action_table_package_path
        ))
    end)
    local data_table = unwrap(StaticFindObject(
        BlueprintModeUI.input_action_table_path
    ))
    if is_valid_object(data_table) then return data_table end
    if is_valid_object(load_result) then return load_result end
    return nil
end

function BlueprintModeUI.install_input_action_row(
    data_table, row_name, key_name
)
    local base_row = nil
    local base_ok, base_error = pcall(function()
        base_row = data_table:FindRow("OpenTechnologyMenu")
    end)
    if not base_ok or base_row == nil then
        return false, "base UI input row unavailable: "
            .. tostring(base_error)
    end

    local add_ok, add_error = pcall(function()
        -- AddRow copies the source struct.  The original T-key row remains
        -- untouched; only the new mod-owned row is changed below.
        data_table:AddRow(row_name, base_row)
    end)
    if not add_ok then
        return false, "AddRow failed: " .. tostring(add_error)
    end

    local installed_row = nil
    local write_ok, write_error = pcall(function()
        installed_row = data_table:FindRow(row_name)
        installed_row.KeyboardInputTypeInfo.Key.KeyName = FName(key_name)
    end)
    if not write_ok or installed_row == nil then
        pcall(function() data_table:RemoveRow(row_name) end)
        return false, "keyboard key write failed: "
            .. tostring(write_error)
    end

    local read_key = nil
    local verify_ok, verify_error = pcall(function()
        read_key = value_to_string(
            installed_row.KeyboardInputTypeInfo.Key.KeyName
        )
    end)
    if not verify_ok or read_key ~= key_name then
        pcall(function() data_table:RemoveRow(row_name) end)
        return false, "keyboard key verify failed expected="
            .. tostring(key_name) .. " actual=" .. tostring(read_key)
            .. " error=" .. tostring(verify_error)
    end
    return true, nil
end

function BlueprintModeUI.ensure_input_action_rows()
    if BlueprintModeUI.input_action_rows_ready then return true, nil end
    local data_table = BlueprintModeUI.load_input_action_table()
    if not is_valid_object(data_table) then
        return false, "DT_UIInputAction unavailable"
    end
    for _, action_name in ipairs({ "create", "place" }) do
        local row = BlueprintModeUI.input_action_rows[action_name]
        local ok, error_value = BlueprintModeUI.install_input_action_row(
            data_table, row.name, row.key
        )
        if not ok then
            return false, action_name .. " action row failed: "
                .. tostring(error_value)
        end
    end
    BlueprintModeUI.input_action_rows_ready = true
    log("blueprint mode UI input rows installed create=G place=K")
    return true, nil
end

function BlueprintModeUI.configure_key_guides(instance)
    local rows_ok, rows_error = BlueprintModeUI.ensure_input_action_rows()
    if not rows_ok then return false, rows_error end

    for _, action_name in ipairs({ "create", "place" }) do
        local row = BlueprintModeUI.input_action_rows[action_name]
        local key_guide = BlueprintModeUI.find_in_instance(
            instance, row.widget
        )
        if not is_valid_object(key_guide) then
            return false, "key guide missing: " .. tostring(row.widget)
        end
        local bind_ok, bind_error = pcall(function()
            key_guide:SetInputAction(FName(row.name))
            key_guide:SetVisibility(0)
        end)
        if not bind_ok then
            return false, row.widget .. " SetInputAction failed: "
                .. tostring(bind_error)
        end
    end
    log("blueprint mode UI key guides bound create=G place=K")
    return true, nil
end

function BlueprintModeUI.configure_footer_spacing(instance)
    -- The stock footer is laid out as:
    --   Fill, 266 px button canvas, 16 px gap, 266 px button canvas, Fill.
    -- Each canvas contains a 46 px key-guide area plus a 220 px text area.
    -- Our authored widget was cloned from that complete two-button footer, so
    -- its left/right Fill spacers must be converted before it is appended to
    -- the stock HorizontalBox.  The resulting combined layout is exactly:
    --   Fill, 266, 16, 266, 16, 266, 16, 266, Fill.
    local root = BlueprintModeUI.find_in_instance(instance, "SizeBox_Root")
    if not is_valid_object(root) then
        return false, "SizeBox_Root missing"
    end

    local function configure_spacer(widget_name, width)
        local spacer = BlueprintModeUI.find_in_instance(instance, widget_name)
        if not is_valid_object(spacer) then
            return false, widget_name .. " missing"
        end
        local ok, error_value = pcall(function()
            spacer:SetSize({ X = width, Y = 1.0 })
            local slot = unwrap(safe_property(spacer, "Slot"))
            if is_valid_object(slot) then
                slot:SetSize({ Value = 1.0, SizeRule = 0 })
            end
        end)
        if not ok then
            return false, widget_name .. " configure failed: "
                .. tostring(error_value)
        end
        return true, nil
    end

    local root_ok, root_error = pcall(function()
        root:SetWidthOverride(564.0)
        root:SetHeightOverride(40.0)
    end)
    if not root_ok then
        return false, "SizeBox_Root override failed: " .. tostring(root_error)
    end

    for _, spacer_spec in ipairs({
        { "Spacer_BlueprintModeLeft", 16.0 },
        { "Spacer_BlueprintModeBetween", 16.0 },
        { "Spacer_BlueprintModeRight", 0.0 },
    }) do
        local ok, error_value = configure_spacer(
            spacer_spec[1], spacer_spec[2]
        )
        if not ok then return false, error_value end
    end
    return true, nil
end

function BlueprintModeUI.restore_runtime_materials(instance)
    pcall(LoadAsset, BlueprintModeUI.gradient_material_path)
    local material = unwrap(StaticFindObject(
        BlueprintModeUI.gradient_material_path
    ))
    if not is_valid_object(material) then
        return false, "original gradient material unavailable"
    end
    for _, widget_name in ipairs({ "Image_4", "Image_9" }) do
        local image = BlueprintModeUI.find_in_instance(instance, widget_name)
        if not is_valid_object(image) then
            return false, "runtime material target missing: " .. widget_name
        end
        local ok, error_value = pcall(function()
            image:SetBrushFromMaterial(material)
        end)
        if not ok then
            return false, widget_name .. " material bind failed: "
                .. tostring(error_value)
        end
    end

    -- The PMK has dummy Pal text classes but not the original font assets, so
    -- those strong references cannot be authored into our cooked WBP.  Bind
    -- the real game assets once, on the persistent text widgets; this is not a
    -- polling or per-frame operation.
    pcall(LoadAsset, BlueprintModeUI.pal_font_path)
    pcall(LoadAsset, BlueprintModeUI.pal_font_material_path)
    local pal_font = unwrap(StaticFindObject(BlueprintModeUI.pal_font_path))
    local pal_font_material = unwrap(StaticFindObject(
        BlueprintModeUI.pal_font_material_path
    ))
    if not is_valid_object(pal_font) then
        return false, "original Pal font unavailable"
    end
    for _, widget_name in ipairs({
        "Text_BlueprintCreate", "Text_BlueprintPlace"
    }) do
        local text_widget = BlueprintModeUI.find_in_instance(
            instance, widget_name
        )
        if not is_valid_object(text_widget) then
            return false, "runtime font target missing: " .. widget_name
        end
        local ok, error_value = pcall(function()
            text_widget:SetFont({
                FontObject = pal_font,
                FontMaterial = pal_font_material,
                TypefaceFontName = FName("Medium"),
                Size = 16,
                LetterSpacing = 0,
                SkewAmount = 0.0,
            })
        end)
        if not ok then
            return false, widget_name .. " font bind failed: "
                .. tostring(error_value)
        end
    end
    return true, nil
end

function BlueprintModeUI.configure_localized_labels(instance)
    local labels = {
        { widget = "Text_BlueprintCreate", key = "ui.button.create" },
        { widget = "Text_BlueprintPlace", key = "ui.button.place" },
    }
    for _, label in ipairs(labels) do
        local text_widget = BlueprintModeUI.find_in_instance(
            instance, label.widget
        )
        if not is_valid_object(text_widget) then
            return false, "localized label target missing: " .. label.widget
        end
        local ok, error_value = pcall(function()
            text_widget:SetText(FText(localize(label.key)))
        end)
        if not ok then
            return false, label.widget .. " localization failed: "
                .. tostring(error_value)
        end
    end
    return true, nil
end

function BlueprintModeUI.create_original_input_button(
    instance, canvas_name, placeholder_name, action_name
)
    local canvas = BlueprintModeUI.find_in_instance(instance, canvas_name)
    local placeholder = BlueprintModeUI.find_in_instance(
        instance, placeholder_name
    )
    -- Non-variable WidgetTree panels are present in the cooked hierarchy but
    -- are not exposed as generated-class properties.  The placeholder button
    -- is intentionally a variable, so use its real runtime parent as the
    -- authoritative canvas instead of requiring the panel to be reflected.
    if not is_valid_object(canvas) and is_valid_object(placeholder) then
        pcall(function() canvas = unwrap(placeholder:GetParent()) end)
    end
    if not is_valid_object(canvas) or not is_valid_object(placeholder) then
        return nil, "canvas or placeholder missing canvas=" .. object_name(canvas)
            .. " placeholder=" .. object_name(placeholder)
    end

    local widget_library = unwrap(StaticFindObject(
        "/Script/UMG.Default__WidgetBlueprintLibrary"
    ))
    local input_class = unwrap(StaticFindObject(
        BlueprintModeUI.original_input_class_path
    ))
    if not is_valid_object(input_class) then
        pcall(LoadAsset, BlueprintModeUI.original_input_class_path)
        input_class = unwrap(StaticFindObject(
            BlueprintModeUI.original_input_class_path
        ))
    end
    local player_controller = unwrap(UEHelpers.GetPlayerController())
    if not is_valid_object(widget_library)
        or not is_valid_object(input_class)
        or not is_valid_object(player_controller) then
        return nil, "input widget dependencies unavailable"
    end

    local input_button = nil
    local create_ok, create_error = pcall(function()
        input_button = unwrap(widget_library:Create(
            player_controller, input_class, player_controller
        ))
    end)
    if not create_ok or not is_valid_object(input_button) then
        return nil, "original invisible button creation failed: "
            .. tostring(create_error)
    end

    local setup_ok, setup_error = pcall(function()
        placeholder:SetVisibility(3)
        local placeholder_slot = unwrap(safe_property(placeholder, "Slot"))
        local layout = placeholder_slot:GetLayout()
        local z_order = placeholder_slot:GetZOrder()
        local input_slot = canvas:AddChildToCanvas(input_button)
        input_slot:SetLayout(layout)
        input_slot:SetZOrder((tonumber(z_order) or 0) + 10)
        input_button:SetIsInteractionEnabled(true)
        input_button:SetIsFocusable(false)
        input_button:SetVisibility(0)
    end)
    if not setup_ok then
        return nil, "original invisible button setup failed: "
            .. tostring(setup_error)
    end

    local address = safe_object_address(input_button)
    if address == nil then return nil, "input button has no stable address" end
    return input_button, nil, tostring(address)
end

function BlueprintModeUI.prepare_authored_input_button(instance, widget_name)
    local button = BlueprintModeUI.find_in_instance(instance, widget_name)
    if not is_valid_object(button) then
        return nil, "authored input button missing: " .. tostring(widget_name)
    end
    local setup_ok, setup_error = pcall(function()
        button:SetIsEnabled(true)
        button:SetVisibility(0)
        pcall(function() button:SetIsFocusable(false) end)
    end)
    if not setup_ok then
        return nil, "authored input button setup failed: "
            .. tostring(setup_error)
    end
    return button, nil
end

function BlueprintModeUI.invoke_callback(callback_name)
    local callback = BlueprintModeUI.callbacks[callback_name]
    if type(callback) ~= "function" then
        log("blueprint mode UI callback unavailable name=" .. tostring(callback_name))
        return false
    end
    local ok, result_or_error = pcall(callback)
    if not ok then
        log("blueprint mode UI callback failed name=" .. tostring(callback_name)
            .. " error=" .. tostring(result_or_error))
        return false
    end
    return result_or_error ~= false
end

function BlueprintModeUI.release_transition(reason)
    local transition = BlueprintModeUI.transition
    if transition == nil then return end
    BlueprintModeUI.transition = nil
    log("blueprint mode UI transition released id="
        .. tostring(transition.id) .. " action="
        .. tostring(transition.action) .. " reason=" .. tostring(reason))
end

function BlueprintModeUI.schedule_transition_release(transition)
    if transition == nil then return end
    local transition_id = transition.id
    local callback = nil
    callback = function()
        BlueprintModeUI.transition_release_callbacks[transition_id] = nil
        local active = BlueprintModeUI.transition
        if active ~= nil and active.id == transition_id then
            BlueprintModeUI.release_transition("settled-after-success")
        end
    end
    BlueprintModeUI.transition_release_callbacks[transition_id] = callback
    BlueprintCallbackScheduler.game_thread(
        BlueprintModeUI.transition_release_delay_ms,
        "mode-ui-transition-release:" .. tostring(transition_id), callback
    )
end

function BlueprintModeUI.begin_transition(action_name, source)
    if action_name ~= "create" and action_name ~= "place" then
        log("blueprint mode UI transition rejected: invalid action="
            .. tostring(action_name))
        return false
    end
    local active = BlueprintModeUI.transition
    if active ~= nil then
        log("blueprint mode UI transition ignored: already in progress active="
            .. tostring(active.action) .. " requested=" .. tostring(action_name)
            .. " source=" .. tostring(source))
        return false
    end
    BlueprintModeUI.transition_sequence =
        BlueprintModeUI.transition_sequence + 1
    BlueprintModeUI.transition = {
        id = BlueprintModeUI.transition_sequence,
        action = action_name,
        source = source,
        dispatched = false,
    }
    log("blueprint mode UI transition acquired id="
        .. tostring(BlueprintModeUI.transition_sequence)
        .. " action=" .. tostring(action_name)
        .. " source=" .. tostring(source))
    return true
end

function BlueprintModeUI.dispatch_current_transition(action_name)
    local transition = BlueprintModeUI.transition
    if transition == nil or transition.action ~= action_name
        or transition.dispatched == true then
        return false
    end
    transition.dispatched = true
    local callback_name = action_name == "create" and "on_create" or "on_place"
    local accepted = BlueprintModeUI.invoke_callback(callback_name)
    if not accepted then
        BlueprintModeUI.release_transition("business-rejected")
    else
        BlueprintModeUI.schedule_transition_release(transition)
    end
    return accepted
end

function BlueprintModeUI.dispatch_click(action_name, source)
    source = source or "direct"
    if not BlueprintModeUI.begin_transition(action_name, source) then
        return false
    end
    BlueprintCallbackScheduler.game_thread_now(
        "mode-ui-dispatch-click:" .. tostring(action_name), function()
            BlueprintModeUI.dispatch_current_transition(action_name)
        end
    )
    return true
end

function BlueprintModeUI.queue_request_hook_dispatch(action_name)
    local transition = BlueprintModeUI.transition
    if transition == nil then
        if not BlueprintModeUI.begin_transition(
            action_name, "authored-request-hook"
        ) then
            return false
        end
    elseif transition.action ~= action_name or transition.dispatched == true then
        log("blueprint mode UI request hook ignored action="
            .. tostring(action_name) .. " active="
            .. tostring(transition.action))
        return false
    end
    BlueprintCallbackScheduler.game_thread_now(
        "mode-ui-request-hook:" .. tostring(action_name), function()
            BlueprintModeUI.dispatch_current_transition(action_name)
        end
    )
    return true
end

function BlueprintModeUI.ensure_request_hook(action_name, function_name)
    if BlueprintModeUI.request_hooks[action_name] == true then return true end
    local path = BlueprintModeUI.widget_class_path .. ":" .. function_name
    local callback = function(context)
        log("blueprint mode UI request hook action=" .. tostring(action_name)
            .. " context=" .. object_name(context))
        BlueprintModeUI.queue_request_hook_dispatch(action_name)
    end
    -- UE4SS script hooks keep a registry reference, but retaining the Lua
    -- closure here avoids callback-GC races on long-lived cooked UFunctions.
    local retained = retain_ui_hook_callback(path, callback)
    BlueprintModeUI.request_hook_callbacks[action_name] = retained
    local ok, pre_id, post_id = pcall(RegisterHook, path, retained)
    if not ok then
        BlueprintModeUI.request_hook_callbacks[action_name] = nil
        log("blueprint mode UI request hook unavailable action="
            .. tostring(action_name) .. " path=" .. path
            .. " error=" .. tostring(pre_id))
        return false
    end
    BlueprintModeUI.request_hooks[action_name] = true
    log("blueprint mode UI request hook registered action="
        .. tostring(action_name) .. " path=" .. path
        .. " pre=" .. tostring(pre_id) .. " post=" .. tostring(post_id))
    return true
end

function BlueprintModeUI.ensure_request_hooks()
    return BlueprintModeUI.ensure_request_hook(
        "create", "RequestCreateBlueprint"
    ), BlueprintModeUI.ensure_request_hook(
        "place", "RequestPlaceBlueprint"
    )
end

function BlueprintModeUI.schedule_request_hook_registration(source)
    -- RegisterHook against an unresolved cooked UFunction is not a harmless
    -- probe on every UE4SS build.  A partial installation can leave the Lua
    -- payload active while its PAK is not mounted, so never touch the custom
    -- request paths until the authored widget class has been resolved.
    if BlueprintModeUI.prewarm_assets_ready ~= true then
        BlueprintModeUI.prewarm_ready = false
        return false
    end
    if BlueprintModeUI.request_hooks.create == true
        and BlueprintModeUI.request_hooks.place == true then
        BlueprintModeUI.prewarm_ready =
            BlueprintModeUI.prewarm_assets_ready == true
        return true
    end
    if BlueprintModeUI.request_hook_registration_scheduled then
        return false
    end
    BlueprintModeUI.request_hook_registration_scheduled = true
    local callback = nil
    callback = function()
        BlueprintModeUI.request_hook_registration_scheduled = false
        BlueprintModeUI.request_hook_registration_callback = nil
        local create_hook, place_hook = BlueprintModeUI.ensure_request_hooks()
        BlueprintModeUI.prewarm_ready =
            BlueprintModeUI.prewarm_assets_ready == true
            and create_hook == true and place_hook == true
        log("blueprint mode UI async request-hook registration source="
            .. tostring(source) .. " hooks=" .. tostring(create_hook)
            .. "/" .. tostring(place_hook) .. " ready="
            .. tostring(BlueprintModeUI.prewarm_ready))
    end
    BlueprintModeUI.request_hook_registration_callback = callback
    -- RegisterHook is a UE4SS registry operation normally performed on the Lua
    -- mod thread.  Asset loading above remains on the game thread; only this
    -- hook-registration step is sent back to the asynchronous scheduler.
    BlueprintCallbackScheduler.async(
        1, "mode-ui-register-request-hooks", callback,
        { survive_world = true }
    )
    return true
end

function BlueprintModeUI.prewarm_runtime_assets(source)
    if BlueprintModeUI.prewarm_assets_ready then
        BlueprintModeUI.schedule_request_hook_registration(source)
        return true
    end
    if BlueprintModeUI.prewarm_in_progress then return false end
    BlueprintModeUI.prewarm_in_progress = true

    local ok, result_or_error = pcall(function()
        local widget_class = BlueprintModeUI.load_widget_class()
        if not is_usable_class_object(widget_class) then
            return {
                widget_class = nil,
                rows_ok = false,
                rows_error = "custom-widget-class-unavailable",
            }
        end
        pcall(LoadAsset, BlueprintModeUI.original_input_class_path)
        pcall(LoadAsset, BlueprintModeUI.gradient_material_path)
        pcall(LoadAsset, BlueprintModeUI.pal_font_path)
        pcall(LoadAsset, BlueprintModeUI.pal_font_material_path)
        local rows_ok, rows_error = BlueprintModeUI.ensure_input_action_rows()
        return {
            widget_class = widget_class,
            rows_ok = rows_ok,
            rows_error = rows_error,
        }
    end)
    BlueprintModeUI.prewarm_in_progress = false
    if not ok then
        log("blueprint mode UI prewarm failed source=" .. tostring(source)
            .. " error=" .. tostring(result_or_error))
        return false
    end

    local result = result_or_error
    BlueprintModeUI.prewarm_assets_ready =
        is_usable_class_object(result.widget_class)
        and result.rows_ok == true
    if BlueprintModeUI.prewarm_assets_ready then
        BlueprintModeUI.schedule_request_hook_registration(source)
    end
    BlueprintModeUI.prewarm_ready =
        BlueprintModeUI.prewarm_assets_ready == true
        and BlueprintModeUI.request_hooks.create == true
        and BlueprintModeUI.request_hooks.place == true

    log("blueprint mode UI prewarm source=" .. tostring(source)
        .. " assetsReady=" .. tostring(BlueprintModeUI.prewarm_assets_ready)
        .. " ready=" .. tostring(BlueprintModeUI.prewarm_ready)
        .. " class=" .. tostring(class_object_name(result.widget_class))
        .. " rows=" .. tostring(result.rows_ok)
        .. " rowError=" .. tostring(result.rows_error)
        .. " hooks=" .. tostring(BlueprintModeUI.request_hooks.create)
        .. "/" .. tostring(BlueprintModeUI.request_hooks.place))
    return BlueprintModeUI.prewarm_assets_ready
end

function BlueprintModeUI.clear_active_registration(reason)
    BlueprintModeUI.release_transition(reason or "menu-retired")
    for _, address in ipairs(BlueprintModeUI.active_handler_addresses) do
        BlueprintModeUI.click_handlers[address] = nil
    end
    if BlueprintModeUI.active_menu_address ~= nil then
        BlueprintModeUI.injection_states[
            BlueprintModeUI.active_menu_address
        ] = nil
    end
    BlueprintModeUI.active_handler_addresses = {}
    BlueprintModeUI.active_widget_handle = nil
    BlueprintModeUI.active_menu_name = nil
    BlueprintModeUI.active_menu_address = nil
end

function BlueprintModeUI.abandon_world(reason)
    BlueprintModeUI.clear_active_registration(
        "world-travel:" .. tostring(reason)
    )
    BlueprintModeUI.click_handlers = {}
    BlueprintModeUI.injection_states = {}
    -- Scheduled callbacks remain retained until UE4SS invokes them. Their
    -- object handles cannot resolve in the new world and become safe no-ops.
    return true
end

function BlueprintModeUI.get_runtime_menu_identity(menu)
    menu = unwrap(menu)
    if not is_valid_object(menu) then return nil, nil end
    local address = safe_object_address(menu)
    local name = object_name(menu)
    if address == nil
        or not string.find(name, "/Engine/Transient", 1, true) then
        return nil, name
    end
    return tostring(address), name
end

function BlueprintModeUI.inject(menu, source)
    menu = unwrap(menu)
    local menu_address, menu_name =
        BlueprintModeUI.get_runtime_menu_identity(menu)
    if menu_address == nil then
        return false, "invalid-or-non-runtime-menu"
    end
    if BlueprintModeUI.active_menu_address == menu_address
        and is_valid_object(resolve_object_handle(
            BlueprintModeUI.active_widget_handle
        )) then
        return true, nil
    end

    local dismantle_canvas = unwrap(safe_property(menu, "Canvas_Dismantle"))
    local paint_canvas = unwrap(safe_property(menu, "Canvas_Paint"))
    local parent = nil
    local paint_parent = nil
    pcall(function() parent = unwrap(dismantle_canvas:GetParent()) end)
    pcall(function() paint_parent = unwrap(paint_canvas:GetParent()) end)
    local parent_address = safe_object_address(parent)
    if parent_address == nil
        or tostring(parent_address) ~= tostring(safe_object_address(paint_parent)) then
        return false, "original-button-parent-not-ready"
    end

    if not BlueprintModeUI.prewarm_runtime_assets(
        "inject:" .. tostring(source)
    ) then
        return false, "cooked-widget-assets-unavailable"
    end
    local widget_class = BlueprintModeUI.load_widget_class()
    local widget_library = unwrap(StaticFindObject(
        "/Script/UMG.Default__WidgetBlueprintLibrary"
    ))
    local player_controller = unwrap(UEHelpers.GetPlayerController())
    if not is_usable_class_object(widget_class)
        or not is_valid_object(widget_library)
        or not is_valid_object(player_controller) then
        return false, "cooked-widget-dependencies-not-ready"
    end
    local exact_create_hook = BlueprintModeUI.request_hooks.create == true
    local exact_place_hook = BlueprintModeUI.request_hooks.place == true

    local instance = nil
    local create_ok, create_error = pcall(function()
        instance = unwrap(widget_library:Create(
            player_controller, widget_class, player_controller
        ))
    end)
    if not create_ok or not is_valid_object(instance) then
        return false, "WBP-create-failed:" .. tostring(create_error)
    end

    -- Fully prepare the custom subtree before touching the stock footer.  This
    -- prevents a clickable, only-partially-initialized widget from ever being
    -- visible to CommonUI/Slate.
    local spacing_ok, spacing_error =
        BlueprintModeUI.configure_footer_spacing(instance)
    if not spacing_ok then
        log("blueprint mode UI footer spacing warning: "
            .. tostring(spacing_error))
    end
    local material_ok, material_error =
        BlueprintModeUI.restore_runtime_materials(instance)
    if not material_ok then
        log("blueprint mode UI material warning: " .. tostring(material_error))
    end
    local labels_ok, labels_error =
        BlueprintModeUI.configure_localized_labels(instance)
    if not labels_ok then
        log("blueprint mode UI localization warning: "
            .. tostring(labels_error))
    end
    local key_guides_ok, key_guides_error =
        BlueprintModeUI.configure_key_guides(instance)
    if not key_guides_ok then
        log("blueprint mode UI key guide warning: "
            .. tostring(key_guides_error))
    end

    -- Keep the original Pal CommonUI button on top of the authored placeholder:
    -- it owns the stock hover/focus/pressed visuals.  Handler registration is
    -- staged until after the complete subtree has been attached successfully.
    local create_input, create_input_error, create_address =
        BlueprintModeUI.create_original_input_button(
            instance, "Canvas_BlueprintCreate",
            "Button_BlueprintCreate", "create"
        )
    local place_input, place_input_error, place_address =
        BlueprintModeUI.create_original_input_button(
            instance, "Canvas_BlueprintPlace",
            "Button_BlueprintPlace", "place"
        )
    if not is_valid_object(create_input) or create_address == nil
        or not is_valid_object(place_input) or place_address == nil then
        return false, "input-setup-failed:create="
            .. tostring(create_input_error) .. ",place="
            .. tostring(place_input_error)
    end

    -- The notification is tied to one exact UObject.  Validate that identity
    -- and its stock parent again immediately before the only external-tree
    -- mutation; never substitute whichever menu happens to be globally found.
    local current_menu_address = safe_object_address(menu)
    local current_dismantle = unwrap(safe_property(menu, "Canvas_Dismantle"))
    local current_parent = nil
    pcall(function() current_parent = unwrap(current_dismantle:GetParent()) end)
    if not is_valid_object(menu)
        or tostring(current_menu_address) ~= menu_address
        or tostring(safe_object_address(current_parent))
            ~= tostring(parent_address) then
        return false, "menu-identity-changed-before-attach"
    end

    local trailing_spacer = nil
    local trailing_removed = false
    local instance_added = false
    local attach_ok, attach_error = pcall(function()
        local child_count = parent:GetChildrenCount()
        if child_count > 0 then
            local candidate = unwrap(parent:GetChildAt(child_count - 1))
            if string.find(
                BlueprintModeUI.short_widget_name(candidate), "Spacer", 1, true
            ) then
                trailing_spacer = candidate
                trailing_removed = parent:RemoveChild(candidate) == true
            end
        end

        local instance_slot = unwrap(parent:AddChild(instance))
        if not is_valid_object(instance_slot) then
            error("AddChild returned no valid slot")
        end
        instance_added = true
        pcall(function() instance_slot:SetVerticalAlignment(2) end)
        pcall(function()
            instance_slot:SetSize({ Value = 1.0, SizeRule = 0 })
        end)
    end)

    local spacer_restored = true
    local spacer_restore_error = nil
    if trailing_removed and is_valid_object(trailing_spacer) then
        spacer_restored, spacer_restore_error = pcall(function()
            local trailing_slot = unwrap(parent:AddChild(trailing_spacer))
            if not is_valid_object(trailing_slot) then
                error("trailing spacer AddChild returned no valid slot")
            end
            pcall(function()
                trailing_slot:SetSize({ Value = 1.0, SizeRule = 1 })
            end)
        end)
    end
    if not attach_ok or not spacer_restored then
        if instance_added then
            pcall(function() parent:RemoveChild(instance) end)
        end
        if trailing_removed and not spacer_restored
            and is_valid_object(trailing_spacer) then
            pcall(function() parent:AddChild(trailing_spacer) end)
        end
        return false, "parent-attach-failed:" .. tostring(attach_error)
            .. ",spacer=" .. tostring(spacer_restore_error)
    end

    local request_widget_handle = make_object_handle(instance)
    local menu_handle = make_object_handle(menu)
    if request_widget_handle == nil or menu_handle == nil then
        pcall(function() parent:RemoveChild(instance) end)
        return false, "runtime-widget-identity-unavailable"
    end

    BlueprintModeUI.clear_active_registration("new-menu-installed")
    BlueprintModeUI.active_widget_handle = request_widget_handle
    BlueprintModeUI.active_menu_name = menu_name
    BlueprintModeUI.active_menu_address = menu_address
    BlueprintModeUI.active_handler_addresses = {
        create_address, place_address,
    }
    BlueprintModeUI.click_handlers[create_address] = {
        action = "create",
        request_widget_handle = request_widget_handle,
        menu_handle = menu_handle,
        menu_address = menu_address,
    }
    BlueprintModeUI.click_handlers[place_address] = {
        action = "place",
        request_widget_handle = request_widget_handle,
        menu_handle = menu_handle,
        menu_address = menu_address,
    }
    log(string.format(
        "blueprint mode UI injected source=%s menu=%s menuAddress=%s parent=%s widget=%s createInput=%s placeInput=%s exactHooks=%s/%s spacingApplied=%s authoredWidth=%s",
        tostring(source), menu_name, menu_address, object_name(parent),
        object_name(instance), object_name(create_input),
        object_name(place_input), tostring(exact_create_hook),
        tostring(exact_place_hook), tostring(spacing_ok),
        spacing_ok and "564" or "unchanged"
    ))
    return true, nil
end

function BlueprintModeUI.schedule_injection_attempt(state, delay_ms)
    local callback = nil
    callback = function()
        state.callback = nil
        if BlueprintModeUI.injection_states[state.address] ~= state then
            return
        end
        local menu = resolve_object_handle(state.menu_handle)
        local address = safe_object_address(menu)
        if not is_valid_object(menu)
            or tostring(address) ~= state.address then
            BlueprintModeUI.injection_states[state.address] = nil
            log("blueprint mode UI injection cancelled: target menu expired address="
                .. tostring(state.address))
            return
        end
        if BlueprintModeUI.transition ~= nil then
            BlueprintModeUI.injection_states[state.address] = nil
            log("blueprint mode UI injection cancelled: menu transition already started address="
                .. tostring(state.address) .. " action="
                .. tostring(BlueprintModeUI.transition.action))
            return
        end

        state.attempt = state.attempt + 1
        state.status = "injecting"
        local ok, injected, failure_reason = pcall(
            BlueprintModeUI.inject,
            menu,
            tostring(state.source) .. "#" .. tostring(state.attempt)
        )
        if ok and injected == true then
            state.status = "installed"
            return
        end

        state.status = "pending"
        state.last_error = ok and failure_reason or injected
        if state.last_error == "cooked-widget-assets-unavailable" then
            BlueprintModeUI.injection_states[state.address] = nil
            log("blueprint mode UI injection skipped: custom PAK assets "
                .. "are unavailable address=" .. tostring(state.address))
            return
        end
        local retry_delay = BlueprintModeUI.injection_retry_delays_ms[
            state.attempt
        ]
        if retry_delay == nil then
            BlueprintModeUI.injection_states[state.address] = nil
            log("blueprint mode UI injection abandoned address="
                .. tostring(state.address) .. " attempts="
                .. tostring(state.attempt) .. " error="
                .. tostring(state.last_error))
            return
        end
        log("blueprint mode UI injection retry address="
            .. tostring(state.address) .. " attempt="
            .. tostring(state.attempt) .. " delayMs="
            .. tostring(retry_delay) .. " reason="
            .. tostring(state.last_error))
        BlueprintModeUI.schedule_injection_attempt(state, retry_delay)
    end
    state.callback = callback
    BlueprintCallbackScheduler.game_thread(
        delay_ms,
        "mode-ui-injection-attempt:" .. tostring(state.address), callback
    )
end

function BlueprintModeUI.begin_menu_injection(menu, source)
    menu = unwrap(menu)
    local address, menu_name = BlueprintModeUI.get_runtime_menu_identity(menu)
    log("construction menu lifecycle observed source=" .. tostring(source)
        .. " context=" .. tostring(menu_name)
        .. " address=" .. tostring(address))
    if address == nil then
        BlueprintModeUI.prewarm_runtime_assets(
            tostring(source) .. ":non-runtime-template"
        )
        return false
    end
    if not BlueprintModeUI.prewarm_runtime_assets(
        tostring(source) .. ":asset-gate"
    ) then
        log("blueprint mode UI injection skipped: custom PAK assets "
            .. "are unavailable address=" .. tostring(address))
        return false
    end
    if BlueprintModeUI.active_menu_address ~= nil
        and BlueprintModeUI.active_menu_address ~= address then
        BlueprintModeUI.clear_active_registration("new-menu-observed")
    end
    local existing = BlueprintModeUI.injection_states[address]
    if existing ~= nil and (existing.status == "pending"
        or existing.status == "injecting"
        or existing.status == "installed") then
        log("blueprint mode UI injection deduplicated address="
            .. tostring(address) .. " status=" .. tostring(existing.status))
        return existing.status == "installed"
    end
    local menu_handle = make_object_handle(menu)
    if menu_handle == nil then
        log("blueprint mode UI injection skipped: menu identity unavailable address="
            .. tostring(address))
        return false
    end
    local state = {
        address = address,
        menu_handle = menu_handle,
        menu_name = menu_name,
        source = source,
        attempt = 0,
        status = "pending",
        callback = nil,
        last_error = nil,
    }
    BlueprintModeUI.injection_states[address] = state
    BlueprintModeUI.schedule_injection_attempt(state, 1)
    return true
end

function BlueprintModeUI.try_inject(source)
    local menu = BlueprintModeUI.find_active_construction_menu()
    if not is_valid_object(menu) then
        log("blueprint mode UI manual injection found no active construction menu source="
            .. tostring(source))
        return false
    end
    return BlueprintModeUI.begin_menu_injection(menu, source)
end

function BlueprintModeUI.schedule_injection(menu, source)
    local menu_handle = make_object_handle(menu)
    if menu_handle == nil then return false end
    local callback = nil
    callback = function()
        BlueprintModeUI.scheduled_callbacks[callback] = nil
        local live_menu = resolve_object_handle(menu_handle)
        if live_menu == nil then return end
        local ok, error_value = pcall(
            BlueprintModeUI.begin_menu_injection, live_menu, source
        )
        if not ok then
            log("blueprint mode UI isolated injection scheduling error: "
                .. tostring(error_value))
        end
    end
    BlueprintModeUI.scheduled_callbacks[callback] = callback
    -- NotifyOnNewObject can arrive while the WidgetTree is still being built.
    -- Yield one millisecond, then perform every UObject read/write on the game
    -- thread and retry only this exact validated menu instance if needed.
    BlueprintCallbackScheduler.game_thread(
        1, "mode-ui-schedule-injection", callback
    )
    return true
end

function BlueprintModeUI.install(deps)
    deps = deps or {}
    UEHelpers = deps.UEHelpers or UEHelpers
    log = deps.log or log
    localize = deps.localize or localize
    BlueprintModeUI.callbacks.on_create = deps.on_create
    BlueprintModeUI.callbacks.on_place = deps.on_place
    if BlueprintModeUI.installed then return true end

    BlueprintModeUI.common_button_hook_callback = function(context)
        local button = unwrap(context)
        local address = safe_object_address(button)
        local address_key = address ~= nil and tostring(address) or nil
        local handler = address_key ~= nil
            and BlueprintModeUI.click_handlers[address_key] or nil
        if type(handler) ~= "table" then return end

        local request_widget = resolve_object_handle(
            handler.request_widget_handle
        )
        local menu = resolve_object_handle(handler.menu_handle)
        local handler_is_current = BlueprintModeUI.active_menu_address
                == handler.menu_address
            and is_valid_object(button)
            and is_valid_object(request_widget)
            and is_valid_object(menu)
            and tostring(safe_object_address(menu)) == handler.menu_address
        if not handler_is_current then
            BlueprintModeUI.click_handlers[address_key] = nil
            log("blueprint mode UI stale click handler retired address="
                .. tostring(address_key))
            return
        end

        local action_name = handler.action
        if not BlueprintModeUI.begin_transition(
            action_name, "common-button:" .. tostring(address_key)
        ) then
            return
        end
        log("blueprint mode UI click accepted action="
            .. tostring(action_name) .. " address=" .. tostring(address_key))
        BlueprintCallbackScheduler.game_thread_now(
            "mode-ui-common-button:" .. tostring(action_name), function()
            local live_request_widget = resolve_object_handle(
                handler.request_widget_handle
            )
            local live_menu = resolve_object_handle(handler.menu_handle)
            if BlueprintModeUI.active_menu_address ~= handler.menu_address
                or not is_valid_object(live_request_widget)
                or not is_valid_object(live_menu)
                or tostring(safe_object_address(live_menu))
                    ~= handler.menu_address then
                BlueprintModeUI.release_transition(
                    "button-context-expired-before-dispatch"
                )
                return
            end

            local exact_hook =
                BlueprintModeUI.request_hooks[action_name] == true
            if exact_hook then
                local request_ok, request_error = pcall(function()
                    if action_name == "create" then
                        live_request_widget:RequestCreateBlueprint()
                    elseif action_name == "place" then
                        live_request_widget:RequestPlaceBlueprint()
                    end
                end)
                if not request_ok then
                    log("blueprint mode UI PMK request bridge failed action="
                        .. tostring(action_name) .. " error="
                        .. tostring(request_error))
                end
            end
            -- Dispatch after the request UFunction stack has returned.  Its
            -- hook also queues this transition, but the dispatched flag makes
            -- the business callback exactly-once.
            BlueprintModeUI.dispatch_current_transition(action_name)
            end
        )
    end
    register_ui_hook(
        "/Script/CommonUI.CommonButtonBase:HandleButtonClicked",
        BlueprintModeUI.common_button_hook_callback
    )

    BlueprintModeUI.notify_callback = function(context)
        local ok, error_value = pcall(
            BlueprintModeUI.schedule_injection,
            context, "NotifyOnNewObject"
        )
        if not ok then
            log("blueprint mode UI object notification isolated error="
                .. tostring(error_value))
        end
    end
    BlueprintModeUI.notify_ok, BlueprintModeUI.notify_error = pcall(
        NotifyOnNewObject,
        "/Game/Pal/Blueprint/UI/UserInterface/IngameMenu/Construction/" ..
            "WBP_IngameMenu_Construction_Menu." ..
            "WBP_IngameMenu_Construction_Menu_C",
        BlueprintModeUI.notify_callback
    )
    if BlueprintModeUI.notify_ok then
        log("blueprint mode UI construction-menu listener registered")
    else
        log("blueprint mode UI listener failed: "
            .. tostring(BlueprintModeUI.notify_error))
    end

    BlueprintModeUI.prewarm_callback = function()
        local ok, error_value = pcall(
            BlueprintModeUI.prewarm_runtime_assets, "install+1000ms"
        )
        if not ok then
            log("blueprint mode UI prewarm isolated error: "
                .. tostring(error_value))
        end
    end
    BlueprintCallbackScheduler.game_thread(
        1000, "mode-ui-prewarm", BlueprintModeUI.prewarm_callback
    )

    BlueprintModeUI.installed = true
    return true
end

return BlueprintModeUI

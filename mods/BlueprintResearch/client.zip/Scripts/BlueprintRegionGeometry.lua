local UEHelpers = require("UEHelpers")

local BlueprintRegionGeometry = {}

function BlueprintRegionGeometry.install(deps)
    assert(type(deps) == "table", "BlueprintRegionGeometry dependencies are required")

    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(deps.is_valid_object,
        "is_valid_object dependency is required")
    local safe_property = assert(deps.safe_property,
        "safe_property dependency is required")
    local find_valid_instance = assert(deps.find_valid_instance,
        "find_valid_instance dependency is required")
    local value_to_string = assert(deps.value_to_string,
        "value_to_string dependency is required")

    local geometry = {}

    local function get_valid_extent(minimum, maximum)
        minimum = tonumber(minimum)
        maximum = tonumber(maximum)
        if minimum == nil or maximum == nil then return 0.0 end
        local extent = math.abs(maximum - minimum) * 0.5
        if extent ~= extent or extent == math.huge or extent > 10000.0 then
            return 0.0
        end
        return extent
    end

    local function get_actor_model_data(actor)
        actor = unwrap(actor)
        if not is_valid_object(actor) then return nil end
        local model = nil
        pcall(function() model = actor:GetModel() end)
        model = unwrap(model)
        if not is_valid_object(model) then return nil end
        local transform = safe_property(model, "InitialTransformCache")
        if transform == nil then return nil end

        local mesh_bounds = safe_property(model, "MeshBoxBounds")
        local bounds_min = safe_property(mesh_bounds, "Min")
        local bounds_max = safe_property(mesh_bounds, "Max")
        local min_x = tonumber(safe_property(bounds_min, "X"))
        local min_y = tonumber(safe_property(bounds_min, "Y"))
        local min_z = tonumber(safe_property(bounds_min, "Z"))
        local max_x = tonumber(safe_property(bounds_max, "X"))
        local max_y = tonumber(safe_property(bounds_max, "Y"))
        local max_z = tonumber(safe_property(bounds_max, "Z"))
        return {
            model = model,
            transform = transform,
            extent_x = get_valid_extent(min_x, max_x),
            extent_y = get_valid_extent(min_y, max_y),
            extent_z = get_valid_extent(min_z, max_z),
        }
    end

    function geometry.get_relative_position(math_library, transform, reference_transform)
        local relative_transform = nil
        pcall(function()
            relative_transform = math_library:MakeRelativeTransform(
                transform, reference_transform
            )
        end)
        local translation = safe_property(relative_transform, "Translation")
        local x = tonumber(safe_property(translation, "X"))
        local y = tonumber(safe_property(translation, "Y"))
        local z = tonumber(safe_property(translation, "Z"))
        if x == nil or y == nil or z == nil then return nil end
        return { x = x, y = y, z = z }
    end

    function geometry.get_overlap_object_types()
        local result = {}
        local seen = {}
        local manager = find_valid_instance("PalMapObjectManager", "/Game/Pal/Maps/")
        local configured_types = safe_property(manager, "SearchObjectTypes")
        local count = 0
        pcall(function() count = #configured_types end)
        for index = 1, count do
            local value = nil
            pcall(function() value = configured_types[index] end)
            local number = tonumber(value_to_string(value))
            if number ~= nil and not seen[number] then
                seen[number] = true
                table.insert(result, number)
            end
        end
        local used_fallback = false
        if #result == 0 then
            used_fallback = true
            for number = 0, 31 do table.insert(result, number) end
        end
        return result, used_fallback
    end

    function geometry.transform_point(math_library, transform, x, y, z)
        local world_point = nil
        pcall(function()
            world_point = math_library:TransformLocation(
                transform, { X = x, Y = y, Z = z }
            )
        end)
        local world_x = tonumber(safe_property(world_point, "X"))
        local world_y = tonumber(safe_property(world_point, "Y"))
        local world_z = tonumber(safe_property(world_point, "Z"))
        if world_x == nil or world_y == nil or world_z == nil then return nil end
        return { x = world_x, y = world_y, z = world_z }
    end

    local function get_world_aabb(
        math_library, transform,
        min_x, min_y, min_z, max_x, max_y, max_z
    )
        local world_min_x, world_min_y, world_min_z = nil, nil, nil
        local world_max_x, world_max_y, world_max_z = nil, nil, nil
        for _, x in ipairs({ min_x, max_x }) do
            for _, y in ipairs({ min_y, max_y }) do
                for _, z in ipairs({ min_z, max_z }) do
                    local point = geometry.transform_point(
                        math_library, transform, x, y, z
                    )
                    if point == nil then return nil end
                    world_min_x = world_min_x == nil and point.x
                        or math.min(world_min_x, point.x)
                    world_min_y = world_min_y == nil and point.y
                        or math.min(world_min_y, point.y)
                    world_min_z = world_min_z == nil and point.z
                        or math.min(world_min_z, point.z)
                    world_max_x = world_max_x == nil and point.x
                        or math.max(world_max_x, point.x)
                    world_max_y = world_max_y == nil and point.y
                        or math.max(world_max_y, point.y)
                    world_max_z = world_max_z == nil and point.z
                        or math.max(world_max_z, point.z)
                end
            end
        end
        return {
            center = {
                X = (world_min_x + world_max_x) * 0.5,
                Y = (world_min_y + world_max_y) * 0.5,
                Z = (world_min_z + world_max_z) * 0.5,
            },
            extent = {
                X = (world_max_x - world_min_x) * 0.5,
                Y = (world_max_y - world_min_y) * 0.5,
                Z = (world_max_z - world_min_z) * 0.5,
            },
        }
    end

    function geometry.get_geometry(start_actor, end_actor)
        local math_library = UEHelpers.GetKismetMathLibrary()
        local start_data = get_actor_model_data(start_actor)
        local end_data = get_actor_model_data(end_actor)
        if math_library == nil or start_data == nil or end_data == nil then
            return nil, "start or end transform is unavailable"
        end

        local end_position = geometry.get_relative_position(
            math_library, end_data.transform, start_data.transform
        )
        if end_position == nil then
            return nil, "could not transform the end into the start-local frame"
        end

        local padding_x = math.max(start_data.extent_x, end_data.extent_x, 200.0)
        local padding_y = math.max(start_data.extent_y, end_data.extent_y, 200.0)
        local padding_z = math.max(start_data.extent_z, end_data.extent_z, 50.0)
        local min_x = math.min(0.0, end_position.x) - padding_x
        local min_y = math.min(0.0, end_position.y) - padding_y
        local min_z = math.min(0.0, end_position.z) - padding_z
        local max_x = math.max(0.0, end_position.x) + padding_x
        local max_y = math.max(0.0, end_position.y) + padding_y
        local max_z = math.max(0.0, end_position.z) + padding_z
        local world_aabb = get_world_aabb(
            math_library, start_data.transform,
            min_x, min_y, min_z, max_x, max_y, max_z
        )
        if world_aabb == nil then
            return nil, "could not transform the local selection box into world space"
        end

        return {
            math_library = math_library,
            start_data = start_data,
            end_data = end_data,
            end_position = end_position,
            padding_x = padding_x,
            padding_y = padding_y,
            padding_z = padding_z,
            min_x = min_x,
            min_y = min_y,
            min_z = min_z,
            max_x = max_x,
            max_y = max_y,
            max_z = max_z,
            world_aabb = world_aabb,
        }
    end

    return geometry
end

return BlueprintRegionGeometry

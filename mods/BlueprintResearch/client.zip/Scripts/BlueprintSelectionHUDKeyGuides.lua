local BlueprintSelectionHUDKeyGuides = {}

local ROW_PACKAGE_PATH =
    "/Game/Pal/Blueprint/UI/UserInterface/InGame/Construction/" ..
    "WBP_Ingameconstruction_KeyGuide"
local ROW_CLASS_PATH = ROW_PACKAGE_PATH ..
    ".WBP_Ingameconstruction_KeyGuide_C"
local KEY_ICON_PACKAGE_PATH =
    "/Game/Pal/Blueprint/UI/CommonWidget/ActionWidget/" ..
    "WBP_PalKeyGuideIcon"
local KEY_ICON_CLASS_PATH = KEY_ICON_PACKAGE_PATH ..
    ".WBP_PalKeyGuideIcon_C"

-- The placeholder order mirrors the stock construction HUD's VerticalBox:
-- four blueprint-mode actions, the stock separator, then exit/save.
local GUIDE_ROWS = {
    {
        id = "select",
        action = "BlueprintResearch_SelectToggle",
        key = "LeftMouseButton",
        text_key = "ui.guide.select",
        placeholder =
            "Info_WBP_Ingameconstruction_KeyGuide_BuildObject_ForGamepad",
    },
    {
        id = "region",
        action = "BlueprintResearch_RegionCorner",
        key = "MiddleMouseButton",
        text_key = "ui.guide.region",
        placeholder =
            "Info_WBP_Ingameconstruction_KeyGuide_BuildObjectContinuous_ForGamepad",
    },
    {
        id = "anchor",
        action = "BlueprintResearch_SetAnchor",
        key = "RightMouseButton",
        text_key = "ui.guide.anchor",
        placeholder =
            "Info_WBP_Ingameconstruction_KeyGuide_BuildObjectContinuous_ForMouse",
    },
    {
        id = "camera",
        action = "BlueprintResearch_SelectionToggleFreeCamera",
        key = "CapsLock",
        text_key = "ui.guide.camera",
        placeholder = "Info_WBP_Ingameconstruction_KeyGuide_Rotate",
    },
    {
        id = "exit",
        action = "BlueprintResearch_ExitSelection",
        key = "Escape",
        text_key = "ui.guide.exit",
        placeholder = "Info_WBP_Ingameconstruction_KeyGuide_Cancel",
    },
    {
        id = "save",
        action = "BlueprintResearch_SaveBlueprint",
        key = "Z",
        text_key = "ui.guide.save",
        placeholder = "Info_WBP_Ingameconstruction_KeyGuide_End",
    },
}

local UNUSED_PLACEHOLDERS = {
    "Info_WBP_Ingameconstruction_KeyGuide_5",
    "Info_WBP_Ingameconstruction_KeyGuide_6",
    "Info_WBP_Ingameconstruction_KeyGuide_7",
}

function BlueprintSelectionHUDKeyGuides.install(mode, deps)
    assert(type(mode) == "table",
        "BlueprintSelectionHUDKeyGuides requires a mode table")
    assert(type(deps) == "table",
        "BlueprintSelectionHUDKeyGuides requires dependencies")

    local UEHelpers = deps.UEHelpers
    local mode_ui = deps.mode_ui
    local log = deps.log
    local unwrap = deps.unwrap
    local object_name = deps.object_name
    local is_valid_object = deps.is_valid_object
    local is_usable_class_object = deps.is_usable_class_object
    local safe_property = deps.safe_property
    local find_in_instance = deps.find_in_instance
    local localize = assert(deps.localize,
        "BlueprintSelectionHUDKeyGuides requires localize")

    local action_rows_ready = {}

    local function ensure_action_rows()
        if type(mode_ui) ~= "table"
            or type(mode_ui.load_input_action_table) ~= "function"
            or type(mode_ui.install_input_action_row) ~= "function" then
            return false, "BlueprintModeUI input-action helpers unavailable"
        end

        local data_table = mode_ui.load_input_action_table()
        if not is_valid_object(data_table) then
            return false, "DT_UIInputAction unavailable"
        end
        for _, guide in ipairs(GUIDE_ROWS) do
            if action_rows_ready[guide.action] ~= true then
                local ok, error_value = mode_ui.install_input_action_row(
                    data_table, guide.action, guide.key
                )
                if not ok then
                    return false, guide.id .. " input-action row failed: "
                        .. tostring(error_value)
                end
                action_rows_ready[guide.action] = true
            end
        end
        return true, nil
    end

    local function load_widget_class(package_path, class_path, cached_class)
        cached_class = unwrap(cached_class)
        if is_usable_class_object(cached_class) then return cached_class end

        local exact_class = unwrap(StaticFindObject(class_path))
        if is_usable_class_object(exact_class) then return exact_class end

        local package_result = nil
        pcall(function()
            package_result = unwrap(LoadAsset(package_path))
        end)

        exact_class = unwrap(StaticFindObject(class_path))
        if is_usable_class_object(exact_class) then return exact_class end
        if is_usable_class_object(package_result) then return package_result end

        local generated_class = unwrap(safe_property(
            package_result, "GeneratedClass"
        ))
        if is_usable_class_object(generated_class) then
            return generated_class
        end
        return nil
    end

    local function load_row_class()
        return load_widget_class(
            ROW_PACKAGE_PATH, ROW_CLASS_PATH, nil
        )
    end

    local function load_key_icon_class()
        return load_widget_class(
            KEY_ICON_PACKAGE_PATH, KEY_ICON_CLASS_PATH, nil
        )
    end

    local function create_widget(player_controller, widget_class, label)
        local widget_library = unwrap(StaticFindObject(
            "/Script/UMG.Default__WidgetBlueprintLibrary"
        ))
        if not is_usable_class_object(widget_class)
            or not is_valid_object(widget_library) then
            return nil, label .. " class or UMG library unavailable"
        end

        local create_ok, widget = pcall(function()
            return unwrap(widget_library:Create(
                player_controller, widget_class, player_controller
            ))
        end)
        widget = unwrap(widget)
        if not create_ok or not is_valid_object(widget) then
            return nil, label .. " CreateWidget failed: " .. tostring(widget)
        end
        return widget, nil
    end

    local function create_stock_key_icon(player_controller, row, guide)
        local icon, create_error = create_widget(
            player_controller, load_key_icon_class(), "stock key-guide icon"
        )
        if not is_valid_object(icon) then return nil, create_error end

        local horizontal_box = unwrap(find_in_instance(
            row, "HorizontalBox_46"
        ))
        if not is_valid_object(horizontal_box) then
            return nil, "stock key-guide HorizontalBox_46 unavailable"
        end

        local setup_ok, setup_error = pcall(function()
            icon:SetInputAction(FName(guide.action))
            icon:SetVisibility(0)
            horizontal_box:AddChildToHorizontalBox(icon)
            -- The working construction-menu G/K guides use the same original
            -- widget and runtime DT row.  Refresh keyboard/mouse after the
            -- dynamically created icon has acquired its Slate slot.
            icon:OverrideInputType(0)
            local action_widget = unwrap(safe_property(
                icon, "PalUIActionWidgetBase_24"
            ))
            if is_valid_object(action_widget) then
                action_widget:SetVisibility(0)
            end
        end)
        if not setup_ok then
            pcall(function() icon:RemoveFromParent() end)
            return nil, "stock key-guide icon binding failed: "
                .. tostring(setup_error)
        end

        local child_count = "?"
        local desired_size = "?"
        pcall(function()
            row:ForceLayoutPrepass()
            child_count = tostring(horizontal_box:GetChildrenCount())
            local desired = icon:GetDesiredSize()
            desired_size = tostring(desired.X) .. "x" .. tostring(desired.Y)
        end)
        log("selection HUD stock key icon bound id=" .. guide.id
            .. " key=" .. guide.key .. " children=" .. child_count
            .. " desired=" .. desired_size)
        return icon, nil
    end

    local function create_stock_guide_row(
        player_controller, placeholder, guide
    )
        local row, create_error = create_widget(
            player_controller, load_row_class(),
            "stock construction key-guide row"
        )
        if not is_valid_object(row) then return nil, nil, create_error end

        local setup_ok, setup_error = pcall(function()
            -- Setup's TArray<FName>& cannot be filled reliably from a Lua
            -- table in UE4SS 3.0.1.  Use the original function for its stock
            -- text styling, then add the same stock icon explicitly.
            placeholder:AddChild(row)
            row:Setup({}, FText(localize(guide.text_key)))
            row:SetVisibility(4)
            placeholder:SetVisibility(4)
        end)
        if not setup_ok then
            pcall(function() row:RemoveFromParent() end)
            return nil, nil, "stock construction key-guide Setup failed: "
                .. tostring(setup_error)
        end

        local icon, icon_error = create_stock_key_icon(
            player_controller, row, guide
        )
        if not is_valid_object(icon) then
            pcall(function() row:RemoveFromParent() end)
            return nil, nil, icon_error
        end
        return row, icon, nil
    end

    function mode.clear_hud_key_guide_cache()
        -- Rows and icons are owned by the current HUD widget tree.
    end

    function mode.setup_hud_key_guides(instance, player_controller)
        instance = unwrap(instance)
        player_controller = unwrap(player_controller)
        if not is_valid_object(instance) then
            return false, "selection HUD unavailable"
        end

        if not is_valid_object(player_controller) then
            player_controller = unwrap(UEHelpers.GetPlayerController())
        end
        if not is_valid_object(player_controller) then
            return false, "local player controller unavailable"
        end

        local placeholders = {}
        for _, guide in ipairs(GUIDE_ROWS) do
            local placeholder = unwrap(find_in_instance(
                instance, guide.placeholder
            ))
            if not is_valid_object(placeholder) then
                return false, guide.id .. " key-guide placeholder missing: "
                    .. guide.placeholder
            end
            placeholders[guide.id] = placeholder
        end

        local action_ok, action_error = ensure_action_rows()
        if not action_ok then return false, action_error end

        -- Remove the three unused stock construction slots so their VerticalBox
        -- padding does not leave empty gaps above the separator.
        for _, placeholder_name in ipairs(UNUSED_PLACEHOLDERS) do
            local unused = unwrap(find_in_instance(instance, placeholder_name))
            if is_valid_object(unused) then
                pcall(function() unused:SetVisibility(1) end)
            end
        end
        local separator = unwrap(find_in_instance(instance, "Info_Overlay_Line"))
        if is_valid_object(separator) then
            pcall(function() separator:SetVisibility(4) end)
        end

        local installed_rows = {}
        local installed_icons = {}
        for _, guide in ipairs(GUIDE_ROWS) do
            local row, icon, row_error = create_stock_guide_row(
                player_controller, placeholders[guide.id], guide
            )
            if not is_valid_object(row) or not is_valid_object(icon) then
                for _, installed_row in ipairs(installed_rows) do
                    pcall(function() installed_row:RemoveFromParent() end)
                end
                return false, guide.id .. " key-guide failed: "
                    .. tostring(row_error)
            end
            installed_rows[#installed_rows + 1] = row
            installed_icons[#installed_icons + 1] = icon
        end

        log("selection HUD stock key guides installed above=4 below=2"
            .. " separator=Info_Overlay_Line")
        return true, nil
    end

    return mode
end

return BlueprintSelectionHUDKeyGuides

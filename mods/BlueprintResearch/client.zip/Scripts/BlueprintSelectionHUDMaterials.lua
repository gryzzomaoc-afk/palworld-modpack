local BlueprintSelectionHUDMaterials = {}

function BlueprintSelectionHUDMaterials.install(mode)
    assert(type(mode) == "table", "selection HUD materials requires mode")

    -- Creation-mode material statistics are intentionally retired. The
    -- selection HUD asset authors Info_MaterialsScroll as Collapsed, so this
    -- compatibility surface must remain pure Lua and must never cross the
    -- Lua/UE reflection boundary.
    function mode.clear_hud_material_cache()
        mode.hud_material_signature = nil
        mode.hud_material_last_error = nil
    end

    function mode.refresh_hud_materials()
        return true, {
            disabled = true,
            total_ms = 0.0,
        }
    end

    return mode
end

return BlueprintSelectionHUDMaterials

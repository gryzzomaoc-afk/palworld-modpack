local BlueprintLibraryStore = require("BlueprintLibraryStore")
local BlueprintLibraryFileSystem = require("BlueprintLibraryFileSystem")

local BlueprintLibraryRuntime = {}

function BlueprintLibraryRuntime.install(deps)
    assert(type(deps) == "table",
        "BlueprintLibraryRuntime dependencies are required")
    local log = assert(deps.log, "BlueprintLibraryRuntime log is required")
    local unwrap = assert(
        deps.unwrap, "BlueprintLibraryRuntime unwrap is required"
    )
    local is_valid_object = assert(
        deps.is_valid_object,
        "BlueprintLibraryRuntime is_valid_object is required"
    )
    local value_to_string = assert(
        deps.value_to_string,
        "BlueprintLibraryRuntime value_to_string is required"
    )
    local decode_blueprint_code = assert(
        deps.decode_blueprint_code,
        "BlueprintLibraryRuntime decode_blueprint_code is required"
    )
    local get_blueprint_library_directory = assert(
        deps.get_blueprint_library_directory,
        "BlueprintLibraryRuntime get_blueprint_library_directory is required"
    )
    local resource_manager = deps.resource_manager

    local runtime = {
        initialized = false,
        initialize_error = nil,
    }

    local function get_project_saved_directory()
        local system_library = unwrap(StaticFindObject(
            "/Script/Engine.Default__KismetSystemLibrary"
        ))
        if not is_valid_object(system_library) then
            return nil, "KismetSystemLibrary is unavailable"
        end
        local call_ok, path_or_error = pcall(function()
            return system_library:GetProjectSavedDirectory()
        end)
        if not call_ok then return nil, tostring(path_or_error) end
        local path = value_to_string(path_or_error)
        if type(path) ~= "string" or path == "" then
            return nil, "GetProjectSavedDirectory returned no path"
        end
        return path, nil
    end

    local project_saved_directory = nil
    local configured_primary_value = nil

    local function get_storage_directories()
        configured_primary_value =
            get_blueprint_library_directory()
        local primary_directory, primary_error =
            BlueprintLibraryFileSystem.resolve_configured_directory(
                configured_primary_value
            )
        local saved_directory, saved_error = get_project_saved_directory()
        project_saved_directory =
            BlueprintLibraryFileSystem.normalize_directory(saved_directory)
        local legacy_directory = nil
        if project_saved_directory ~= nil then
            legacy_directory = BlueprintLibraryFileSystem.join_path(
                project_saved_directory, "SaveGames"
            )
        end
        return {
            primary_directory = primary_directory,
            legacy_directory = legacy_directory,
        }, primary_error or saved_error
    end

    local function create_primary_directory(expected_path)
        return BlueprintLibraryFileSystem.create_configured_directory(
            configured_primary_value, expected_path
        )
    end

    local function create_legacy_directory(expected_path)
        if project_saved_directory == nil then
            local saved_directory, saved_error =
                get_project_saved_directory()
            project_saved_directory =
                BlueprintLibraryFileSystem.normalize_directory(saved_directory)
            if project_saved_directory == nil then
                return false, saved_error
            end
        end
        return BlueprintLibraryFileSystem.create_child_directory(
            project_saved_directory, "SaveGames", expected_path
        )
    end

    runtime.store = BlueprintLibraryStore.install({
        get_storage_directories = get_storage_directories,
        create_primary_directory = create_primary_directory,
        create_legacy_directory = create_legacy_directory,
        filesystem = BlueprintLibraryFileSystem,
        decode_blueprint_code = decode_blueprint_code,
        log = log,
        on_index_changed = resource_manager ~= nil
            and resource_manager.publish_index or nil,
    })

    function runtime.initialize()
        if resource_manager ~= nil then
            resource_manager.initialize()
        end
        local initialized, initialize_error = runtime.store.initialize()
        runtime.initialized = initialized == true
        runtime.initialize_error = initialize_error
        if not runtime.initialized then
            log("blueprint library initialization failed error="
                .. tostring(initialize_error))
            return false, initialize_error
        end
        local state = runtime.store.get_state()
        log(string.format(
            "blueprint library initialized entries=%d recovered=%s "
                .. "primaryEntries=%d legacyEntries=%d "
                .. "storage=%s path=%s",
            tonumber(state.entry_count) or 0,
            tostring(state.loaded_from_backup),
            tonumber(state.primary_entry_count) or 0,
            tonumber(state.legacy_entry_count) or 0,
            tostring(state.storage_kind),
            tostring(state.index_path)
        ))
        if resource_manager ~= nil then
            local entries = runtime.store.list()
            if entries ~= nil then
                resource_manager.publish_index({
                    schema_version =
                        BlueprintLibraryStore.INDEX_SCHEMA_VERSION,
                    entries = entries,
                })
                resource_manager.prewarm(
                    entries,
                    runtime.store.get_thumbnail_path
                )
            end
        end
        return true, nil
    end

    function runtime.get_state()
        local state = runtime.store.get_state()
        state.initialized = runtime.initialized
        state.initialize_error = runtime.initialize_error
        if resource_manager ~= nil then
            state.resource_manager = resource_manager.get_state()
        end
        return state
    end

    return runtime
end

return BlueprintLibraryRuntime

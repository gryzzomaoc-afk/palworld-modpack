local UEHelpers = require("UEHelpers")
local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local BlueprintUserMessage = {}

function BlueprintUserMessage.install(deps)
    assert(type(deps) == "table",
        "BlueprintUserMessage.install requires deps")

    local log = assert(deps.log, "BlueprintUserMessage requires log")
    local unwrap = assert(deps.unwrap, "BlueprintUserMessage requires unwrap")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintUserMessage requires is_valid_object")

    local WARNING_DURATION_MS = 3500
    local DUPLICATE_COOLDOWN_SECONDS = 0.75
    local WARNING_PRESERVE_ID = {
        A = 1112690775,
        B = 1095913033,
        C = 1313297737,
        D = 1144008753,
    }
    local warning_generation = 0
    local last_message = nil
    local last_message_clock = -math.huge
    local warning_failure_logged = false
    local log_failure_logged = false

    local warning_markers = {
        "失败",
        "无法",
        "不足",
        "错误",
        "不可用",
        "失效",
        "重叠",
        "拒绝",
        "未能",
        "异常",
        "failed",
        "failure",
        "error",
        "unavailable",
        "invalid",
        "rejected",
        "blocked",
    }

    local function get_pal_utility_and_world()
        local utility = unwrap(StaticFindObject("/Script/Pal.Default__PalUtility"))
        local world = unwrap(UEHelpers.GetWorld())
        if not is_valid_object(utility) or not is_valid_object(world) then
            return nil, nil
        end
        return utility, world
    end

    local function is_warning_message(message)
        local normalized = string.lower(tostring(message or ""))
        for _, marker in ipairs(warning_markers) do
            if string.find(normalized, marker, 1, true) ~= nil then
                return true
            end
        end
        return false
    end

    local function is_duplicate_message(message)
        local now = os.clock()
        if message == last_message
            and now - last_message_clock < DUPLICATE_COOLDOWN_SECONDS then
            return true
        end
        last_message = message
        last_message_clock = now
        return false
    end

    local function add_native_log(message, priority)
        local utility, world = get_pal_utility_and_world()
        if utility == nil then
            return false, "PalUtility or world unavailable"
        end

        local manager = nil
        local get_ok, get_error = pcall(function()
            manager = unwrap(utility:GetLogManager(world))
        end)
        if not get_ok or not is_valid_object(manager) then
            return false, get_error or "PalLogManager unavailable"
        end

        local add_ok, add_error = pcall(function()
            manager:AddLog(
                tonumber(priority) or 1,
                FText(tostring(message)),
                {}
            )
        end)
        if not add_ok then return false, add_error end
        return true, nil
    end

    local function hide_warning_if_current(generation)
        if generation ~= warning_generation then return end
        local utility, world = get_pal_utility_and_world()
        if utility == nil then return end

        local service = nil
        local get_ok = pcall(function()
            service = unwrap(utility:GetHUDService(world))
        end)
        if not get_ok or not is_valid_object(service) then return end
        pcall(function()
            service:HideCommonWarning(WARNING_PRESERVE_ID)
        end)
    end

    local function show_native_warning(message)
        local utility, world = get_pal_utility_and_world()
        if utility == nil then
            return false, "PalUtility or world unavailable"
        end

        local service = nil
        local get_ok, get_error = pcall(function()
            service = unwrap(utility:GetHUDService(world))
        end)
        if not get_ok or not is_valid_object(service) then
            return false, get_error or "PalHUDService unavailable"
        end

        warning_generation = warning_generation + 1
        local generation = warning_generation
        local show_ok, show_error = pcall(function()
            service:ShowCommonWarning({
                Message = FText(tostring(message)),
                DisplayType = 0,
                PreserveID = WARNING_PRESERVE_ID,
            })
        end)
        if not show_ok then return false, show_error end

        if type(ExecuteInGameThreadWithDelay) == "function" then
            BlueprintCallbackScheduler.game_thread(
                WARNING_DURATION_MS,
                "hide-native-blueprint-warning:" .. tostring(generation),
                function()
                    hide_warning_if_current(generation)
                end
            )
        end
        return true, nil
    end

    local function show(message, requested_kind)
        message = tostring(message or "")
        if message == "" then return false end
        if is_duplicate_message(message) then return true end

        local kind = requested_kind
        if kind == nil or kind == "auto" then
            kind = is_warning_message(message) and "warning" or "info"
        end

        if kind == "warning" or kind == "error" then
            local warning_ok, warning_error = show_native_warning(message)
            if warning_ok then return true end

            local log_ok, log_error = add_native_log(message, 2)
            if not log_ok and not warning_failure_logged then
                warning_failure_logged = true
                log("native blueprint warning unavailable warningError="
                    .. tostring(warning_error)
                    .. " logError=" .. tostring(log_error))
            end
            return log_ok
        end

        local log_ok, log_error = add_native_log(message, 1)
        if not log_ok and not log_failure_logged then
            log_failure_logged = true
            log("native blueprint message unavailable error="
                .. tostring(log_error))
        end
        return log_ok
    end

    local function reset_for_world_travel()
        warning_generation = warning_generation + 1
        last_message = nil
        last_message_clock = -math.huge
        warning_failure_logged = false
        log_failure_logged = false
    end

    return {
        show = show,
        show_info = function(message) return show(message, "info") end,
        show_warning = function(message) return show(message, "warning") end,
        reset_for_world_travel = reset_for_world_travel,
    }
end

return BlueprintUserMessage

local UEHelpers = require("UEHelpers")
local BlueprintPerformance = require("BlueprintPerformance")
local BlueprintPreviewMesh = require("BlueprintPreviewMesh")

local BlueprintGhostRenderer = {}

local PLACEHOLDER_MATERIAL_PATH =
    "/Game/Pal/Material/MapObject/BuildObject/BuildingProcess/"
        .. "MI_LooksPredicatorDismantle.MI_LooksPredicatorDismantle"

local function clear_array(values)
    for index = #values, 1, -1 do
        values[index] = nil
    end
end

local IDENTITY_TRANSFORM = {
    Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 },
    Translation = { X = 0.0, Y = 0.0, Z = 0.0 },
    Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
}

function BlueprintGhostRenderer.install(deps)
    assert(type(deps) == "table",
        "BlueprintGhostRenderer dependencies are required")

    local log = assert(deps.log, "log dependency is required")
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local object_name = assert(
        deps.object_name, "object_name dependency is required"
    )
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object dependency is required"
    )
    local safe_object_address = assert(
        deps.safe_object_address, "safe_object_address dependency is required"
    )
    local find_valid_instance = assert(
        deps.find_valid_instance, "find_valid_instance dependency is required"
    )
    local safe_property = assert(
        deps.safe_property, "safe_property dependency is required"
    )
    local restore_transform = assert(
        deps.restore_transform, "restore_transform dependency is required"
    )
    local get_original_anchor_material = assert(
        deps.get_original_anchor_material,
        "get_original_anchor_material dependency is required"
    )
    local component_store = assert(
        deps.component_store, "component_store dependency is required"
    )
    local max_query_buildings =
        tonumber(deps.max_query_buildings) or 1024

    -- Only pure blueprint data and integer Session-array indices live here.
    -- Every UObject is reacquired from the current Placement Session.
    local state = {
        bindings = {},
        buildings = {},
        anchor_proxy_bindings = {},
        terrain_snap_active = false,
        terrain_effect_ready = false,
        terrain_effect_failure_logged = false,
        anchor_actor_relative_to_model = nil,
        anchor_overlap_relative_transform = nil,
    }

    local renderer = { state = state }

    local function reset_pure_state()
        clear_array(state.bindings)
        clear_array(state.buildings)
        clear_array(state.anchor_proxy_bindings)
        state.terrain_snap_active = false
        state.terrain_effect_ready = false
        state.terrain_effect_failure_logged = false
        state.anchor_actor_relative_to_model = nil
        state.anchor_overlap_relative_transform = nil
    end

    local function stop_terrain_effect(effect)
        effect = unwrap(effect)
        if not is_valid_object(effect) then return true, nil end
        local ok, error_value = pcall(function()
            effect:Deactivate()
            effect:SetRenderingEnabled(false)
            effect:ResetSystem()
            effect:SetHiddenInGame(true, true)
            effect:SetVisibility(false, true)
        end)
        return ok, ok and nil or tostring(error_value)
    end

    local function set_terrain_snap_visual_visibility(session, visible)
        visible = visible == true
        local effect = component_store.get_reference(
            session, "terrain_anchor_effect"
        )
        if is_valid_object(effect) then
            stop_terrain_effect(effect)
        end
        local function set_bindings_visible(bindings, show)
            for _, binding in ipairs(bindings) do
                local component = component_store.get_array_item(
                    session,
                    binding.component_store_key or "preview_meshes",
                    binding.component_index
                )
                if is_valid_object(component) then
                    component:SetHiddenInGame(not show, true)
                    component:SetVisibility(show, true)
                end
            end
        end
        local ok, error_value = pcall(function()
            set_bindings_visible(state.anchor_proxy_bindings, visible)
        end)
        return ok, ok and nil or tostring(error_value)
    end

    function renderer.abandon_world(reason)
        local building_count = #state.buildings
        local binding_count = #state.bindings
        reset_pure_state()
        if building_count > 0 or binding_count > 0 then
            log("blueprint preview pure state abandoned reason="
                .. tostring(reason) .. " buildings="
                .. tostring(building_count) .. " bindings="
                .. tostring(binding_count))
        end
        return true
    end

    function renderer.hide(session)
        local performance_started_at = BlueprintPerformance.now()
        local component_count = 0
        for _, store_key in ipairs({
            "preview_meshes",
            "preview_skeletal_meshes",
        }) do
            component_count = component_count
                + component_store.array_count(session, store_key)
            component_store.for_each(session, store_key, function(component)
                if is_valid_object(component) then
                    pcall(function()
                        component:SetVisibility(false, true)
                        component:SetHiddenInGame(true, true)
                    end)
                end
            end)
        end
        set_terrain_snap_visual_visibility(session, false)
        pcall(function() session.SBB_PreviewVisible = false end)
        local elapsed_ms =
            BlueprintPerformance.elapsed_ms(performance_started_at)
        if component_count > 0 then
            log(string.format(
                "blueprint performance preview-hide elapsedMs=%.2f sessionComponents=%d activeBindings=%d",
                elapsed_ms, component_count, #state.bindings
            ))
        end
        return true
    end

    function renderer.show(session)
        if safe_property(session, "SBB_PreviewVisible") == true then
            return true, nil
        end
        local performance_started_at = BlueprintPerformance.now()
        local ok, show_error = pcall(function()
            for _, binding in ipairs(state.bindings) do
                local component = component_store.get_array_item(
                    session,
                    binding.component_store_key or "preview_meshes",
                    binding.component_index
                )
                if is_valid_object(component) then
                    local terrain_snap_only =
                        binding.terrain_anchor_proxy == true
                    local visible = not terrain_snap_only
                        or state.terrain_snap_active == true
                    component:SetHiddenInGame(not visible, true)
                    component:SetVisibility(visible, true)
                end
            end
            session.SBB_PreviewVisible = true
        end)
        if not ok then return false, tostring(show_error) end
        local elapsed_ms =
            BlueprintPerformance.elapsed_ms(performance_started_at)
        if elapsed_ms >= 4.0 then
            log(string.format(
                "blueprint performance preview-show elapsedMs=%.2f activeBindings=%d",
                elapsed_ms, #state.bindings
            ))
        end
        return true, nil
    end

    function renderer.destroy_session(session, reason)
        local diagnostics = component_store.get_diagnostics(session)
        renderer.hide(session)
        reset_pure_state()
        log("blueprint preview Session ownership released reason="
            .. tostring(reason) .. " meshComponents="
            .. tostring(
                diagnostics.preview_meshes
                    + diagnostics.preview_skeletal_meshes
            )
            .. " queryComponents="
            .. tostring(
                diagnostics.query_box
                + diagnostics.query_sphere
                + diagnostics.query_capsule
            ))
        -- Do not destroy or clear owned components here. K2_DestroyActor on
        -- the Placement Session is the only native destruction path.
        return true
    end

    function renderer.clear_active(session)
        return renderer.destroy_session(session, "clear-active")
    end

    local function get_placeholder_preview_material()
        local placeholder_material =
            unwrap(StaticFindObject(PLACEHOLDER_MATERIAL_PATH))
        if not is_valid_object(placeholder_material) then
            pcall(LoadAsset, PLACEHOLDER_MATERIAL_PATH)
            placeholder_material =
                unwrap(StaticFindObject(PLACEHOLDER_MATERIAL_PATH))
        end
        return placeholder_material
    end

    local function get_blueprint_preview_materials()
        local manager =
            find_valid_instance("PalMapObjectManager", "/Game/Pal/Maps/")
        local material_set =
            safe_property(manager, "BuildingSurfaceMaterialSet")
        local normal_material =
            unwrap(safe_property(material_set, "Highlight"))
        local error_material =
            unwrap(safe_property(material_set, "Error"))
        if not is_valid_object(normal_material) then
            normal_material = get_original_anchor_material()
        end
        if not is_valid_object(error_material) then
            pcall(
                LoadAsset,
                "/Game/Pal/Material/MapObject/BuildObject/"
                    .. "BuildingProcess/MI_LooksPredicatorError."
                    .. "MI_LooksPredicatorError"
            )
            error_material = unwrap(StaticFindObject(
                "/Game/Pal/Material/MapObject/BuildObject/"
                    .. "BuildingProcess/MI_LooksPredicatorError."
                    .. "MI_LooksPredicatorError"
            ))
        end
        local placeholder_material =
            get_placeholder_preview_material()
        if not is_valid_object(placeholder_material) then
            placeholder_material = normal_material
        end
        return normal_material, error_material, placeholder_material
    end

    local function create_owned_component(
        session, component_class, label
    )
        local ok, created_or_error = pcall(function()
            return session:AddComponentByClass(
                component_class, true, IDENTITY_TRANSFORM, false
            )
        end)
        local component = ok and unwrap(created_or_error) or nil
        if not is_valid_object(component) then
            return nil, tostring(label) .. " creation failed error="
                .. tostring(created_or_error)
        end
        return component, nil
    end

    local function ensure_blueprint_ghost_root(session)
        local root_component =
            component_store.get_reference(session, "preview_root")
        if is_valid_object(root_component) then
            return root_component, nil
        end
        local component_class =
            unwrap(StaticFindObject("/Script/Engine.SceneComponent"))
        if not is_valid_object(component_class) then
            return nil, "scene component class unavailable"
        end
        local component, create_error = create_owned_component(
            session, component_class, "ghost root"
        )
        if not is_valid_object(component) then
            return nil, create_error
        end
        local setup_ok, setup_error = pcall(function()
            component:SetMobility(2)
            component:SetAbsolute(true, true, true)
        end)
        if not setup_ok then
            return nil, "ghost root setup failed error="
                .. tostring(setup_error)
        end
        local stored, store_error = component_store.set_reference(
            session, "preview_root", component
        )
        if not stored then
            return nil, "ghost root ownership write failed error="
                .. tostring(store_error)
        end
        return component, nil
    end

    local function ensure_blueprint_ghost_component(
        index, session, store_key, component_class, root_component
    )
        local component = component_store.get_array_item(
            session, store_key, index
        )
        if not is_valid_object(component) then
            local create_error = nil
            component, create_error = create_owned_component(
                session, component_class,
                "ghost component index=" .. tostring(index)
            )
            if not is_valid_object(component) then
                return nil, create_error
            end
            local stored, store_error =
                component_store.set_array_item(
                    session, store_key, index, component
                )
            if not stored then
                return nil, "ghost component ownership write failed index="
                    .. tostring(index) .. " error="
                    .. tostring(store_error)
            end
        end
        local setup_ok, setup_error = pcall(function()
            component:SetMobility(2)
            component:K2_AttachToComponent(
                root_component, FName("None"), 0, 0, 0, false
            )
            component:SetAbsolute(false, false, false)
            component:SetCollisionEnabled(0)
            component:SetGenerateOverlapEvents(false)
            component:SetCastShadow(false)
            component:SetReceivesDecals(false)
            component:SetRenderInMainPass(true)
            component:SetRenderInDepthPass(true)
            component:SetVisibility(false, true)
            component:SetHiddenInGame(true, true)
        end)
        if not setup_ok then
            return nil, "component setup failed index=" .. tostring(index)
                .. " error=" .. tostring(setup_error)
        end
        return component, nil
    end

    local function ensure_blueprint_query_component(
        pool_index, session, descriptor
    )
        local shape_type =
            descriptor ~= nil and descriptor.shape_type or nil
        local class_paths = {
            box = "/Script/Engine.BoxComponent",
            sphere = "/Script/Engine.SphereComponent",
            capsule = "/Script/Engine.CapsuleComponent",
        }
        if class_paths[shape_type] == nil then
            return nil, "unsupported query shape=" .. tostring(shape_type)
        end
        local component = component_store.get_query_component(
            session, shape_type, pool_index
        )
        if not is_valid_object(component) then
            local component_class =
                unwrap(StaticFindObject(class_paths[shape_type]))
            if not is_valid_object(component_class) then
                return nil, "query component class unavailable shape="
                    .. tostring(shape_type)
            end
            local create_error = nil
            component, create_error = create_owned_component(
                session, component_class,
                "query component shape=" .. tostring(shape_type)
            )
            if not is_valid_object(component) then
                return nil, create_error
            end
            local stored, store_error =
                component_store.set_query_component(
                    session, shape_type, pool_index, component
                )
            if not stored then
                return nil, "query ownership write failed shape="
                    .. tostring(shape_type) .. " error="
                    .. tostring(store_error)
            end
            local setup_ok, setup_error = pcall(function()
                component:SetMobility(2)
                component:SetAbsolute(true, true, true)
                -- Never call SetCollisionProfileName on these runtime shapes.
                component:SetCollisionResponseToAllChannels(1)
                -- Query shapes are persistent Session-owned geometry, but
                -- must not remain registered as overlap candidates between
                -- validation passes. SBB_RunOverlapSnapshot temporarily
                -- enables them inside one synchronous Blueprint VM call.
                component:SetCollisionEnabled(0)
                component:SetGenerateOverlapEvents(false)
                component:SetVisibility(false, true)
                component:SetHiddenInGame(true, true)
            end)
            if not setup_ok then
                return nil, "query component setup failed shape="
                    .. tostring(shape_type) .. " error="
                    .. tostring(setup_error)
            end
        end

        local shape_ok, shape_error = pcall(function()
            if shape_type == "box" then
                component:SetBoxExtent({
                    X = descriptor.box_extent.x,
                    Y = descriptor.box_extent.y,
                    Z = descriptor.box_extent.z,
                }, false)
            elseif shape_type == "sphere" then
                component:SetSphereRadius(descriptor.radius, false)
            else
                component:SetCapsuleSize(
                    descriptor.radius, descriptor.half_height, false
                )
            end
            component:SetCollisionResponseToAllChannels(1)
            component:SetCollisionEnabled(0)
            component:SetGenerateOverlapEvents(false)
        end)
        if not shape_ok then
            return nil, "query shape configuration failed shape="
                .. tostring(shape_type) .. " error="
                .. tostring(shape_error)
        end
        return component, nil
    end

    function renderer.configure(session, blueprint_clipboard)
        local performance_started_at = BlueprintPerformance.now()
        local performance = {
            query_setup_ms = 0.0,
            asset_lookup_ms = 0.0,
            component_acquire_ms = 0.0,
            mesh_setup_ms = 0.0,
            material_ms = 0.0,
            unused_hide_ms = 0.0,
            material_slots = 0,
        }
        if not is_valid_object(session) then
            return false, "placement Session unavailable"
        end
        reset_pure_state()
        local reset_ok, reset_error =
            component_store.reset_preview(session)
        if not reset_ok then return false, reset_error end

        local static_component_class =
            unwrap(StaticFindObject("/Script/Engine.StaticMeshComponent"))
        local skeletal_component_class =
            unwrap(StaticFindObject("/Script/Engine.SkeletalMeshComponent"))
        local math_library = UEHelpers.GetKismetMathLibrary()
        local normal_material, error_material, placeholder_material =
            get_blueprint_preview_materials()
        if not is_valid_object(static_component_class)
            or not is_valid_object(skeletal_component_class)
            or not is_valid_object(math_library)
            or not is_valid_object(normal_material)
            or not is_valid_object(error_material)
            or not is_valid_object(placeholder_material) then
            return false, "ghost renderer dependencies unavailable"
        end
        if not component_store.set_reference(
            session, "normal_material", normal_material
        ) then
            return false, "normal preview material ownership write failed"
        end
        if not component_store.set_reference(
            session, "error_material", error_material
        ) then
            return false, "error preview material ownership write failed"
        end

        local anchor_record = nil
        for _, building in ipairs(blueprint_clipboard.buildings or {}) do
            if building.is_anchor == true
                and building.source_instance_id
                    == blueprint_clipboard.anchor_instance_id then
                anchor_record = building
                break
            end
        end
        state.anchor_actor_relative_to_model =
            anchor_record ~= nil and restore_transform(
                anchor_record.actor_relative_to_model
            ) or nil
        if state.anchor_actor_relative_to_model == nil then
            return false,
                "anchor actor/model calibration is missing after schema-9 hydration"
        end
        state.anchor_overlap_relative_transform =
            anchor_record ~= nil
                and anchor_record.overlap_descriptor ~= nil
                and restore_transform(
                    anchor_record.overlap_descriptor.relative_transform
                ) or nil
        if state.anchor_overlap_relative_transform == nil then
            return false,
                "anchor overlap calibration is missing after schema-9 hydration"
        end

        local root_component, root_error =
            ensure_blueprint_ghost_root(session)
        if root_component == nil then return false, root_error end

        local requested_buildings = 0
        for _, building in ipairs(blueprint_clipboard.buildings) do
            if building.is_anchor ~= true then
                requested_buildings = requested_buildings + 1
            end
        end
        if requested_buildings > max_query_buildings then
            return false,
                "overlap query safety limit exceeded requested="
                    .. tostring(requested_buildings) .. " limit="
                    .. tostring(max_query_buildings),
                {
                    code = "collision_query_limit_exceeded",
                    requested = requested_buildings,
                    limit = max_query_buildings,
                }
        end

        local component_indices = {
            [BlueprintPreviewMesh.STATIC] = 0,
            [BlueprintPreviewMesh.SKELETAL] = 0,
        }
        local component_total = 0
        local building_count = 0
        local query_pool_counts = { box = 0, sphere = 0, capsule = 0 }
        for _, building in ipairs(blueprint_clipboard.buildings) do
            if building.is_anchor ~= true then
                local building_relative_transform =
                    restore_transform(building.relative_transform)
                if building_relative_transform == nil then
                    return false,
                        "invalid building relative transform instance="
                            .. tostring(building.source_instance_id)
                end
                local actor_relative_to_model =
                    restore_transform(building.actor_relative_to_model)
                if actor_relative_to_model == nil then
                    return false,
                        "invalid actor/model calibration instance="
                            .. tostring(building.source_instance_id)
                end
                local overlap_descriptor = building.overlap_descriptor
                local overlap_relative_transform =
                    overlap_descriptor ~= nil and restore_transform(
                        overlap_descriptor.relative_transform
                    ) or nil
                if overlap_relative_transform == nil then
                    return false, "invalid overlap descriptor instance="
                        .. tostring(building.source_instance_id)
                end
                building_count = building_count + 1
                local shape_type = overlap_descriptor.shape_type
                if query_pool_counts[shape_type] == nil then
                    return false,
                        "unsupported overlap descriptor shape="
                            .. tostring(shape_type) .. " instance="
                            .. tostring(building.source_instance_id)
                end
                query_pool_counts[shape_type] =
                    query_pool_counts[shape_type] + 1
                local query_index = query_pool_counts[shape_type]
                local query_started_at = BlueprintPerformance.now()
                local query_component, query_error =
                    ensure_blueprint_query_component(
                        query_index, session, overlap_descriptor
                    )
                BlueprintPerformance.add_elapsed(
                    performance, "query_setup_ms", query_started_at
                )
                if query_component == nil then
                    return false, query_error
                end
                local flat_query_stored, flat_query_error =
                    component_store.set_array_item(
                        session,
                        "overlap_query_components",
                        building_count,
                        query_component
                    )
                if not flat_query_stored then
                    return false,
                        "flat overlap query ownership write failed index="
                            .. tostring(building_count)
                            .. " error=" .. tostring(flat_query_error)
                end

                local allowed_profiles = {}
                for _, profile_name in ipairs(
                    overlap_descriptor.allowed_collision_profiles or {}
                ) do
                    allowed_profiles[tostring(profile_name)] = true
                end
                local building_state = {
                    building_relative_transform =
                        building_relative_transform,
                    actor_relative_to_model = actor_relative_to_model,
                    overlap_relative_transform =
                        overlap_relative_transform,
                    overlap_descriptor = overlap_descriptor,
                    query_shape = shape_type,
                    query_index = query_index,
                    allowed_profiles = allowed_profiles,
                    build_object_id = building.build_object_id,
                    build_object_class_path =
                        building.build_object_class_path,
                    source_instance_id = building.source_instance_id,
                    install_strategy = building.install_strategy,
                    install_capacity_sink_rate_by_height =
                        building.install_capacity_sink_rate_by_height,
                    install_capacity_slope_angle =
                        building.install_capacity_slope_angle,
                    selection_index = building.selection_index,
                    mesh_bindings = {},
                    preview_placeholder =
                        building.preview_placeholder == true,
                    skip_overlap_validation =
                        building.skip_overlap_validation == true,
                    material_kind = nil,
                    blocked = nil,
                    blocker = nil,
                    water_surface_overlap = false,
                    world_transform = nil,
                }
                state.buildings[#state.buildings + 1] = building_state

                for _, mesh_descriptor in ipairs(
                    building.preview_meshes or {}
                ) do
                    local mesh_path, mesh_kind =
                        BlueprintPreviewMesh.asset_path(mesh_descriptor)
                    if mesh_path == nil or mesh_kind == nil then
                        return false,
                            "preview mesh identity unavailable instance="
                                .. tostring(building.source_instance_id)
                    end
                    local component_store_key =
                        mesh_kind == BlueprintPreviewMesh.SKELETAL
                        and "preview_skeletal_meshes" or "preview_meshes"
                    local component_class =
                        mesh_kind == BlueprintPreviewMesh.SKELETAL
                        and skeletal_component_class
                        or static_component_class
                    component_indices[mesh_kind] =
                        component_indices[mesh_kind] + 1
                    local component_index = component_indices[mesh_kind]
                    component_total = component_total + 1
                    local mesh_relative_transform =
                        restore_transform(mesh_descriptor.relative_transform)
                    if mesh_relative_transform == nil then
                        return false,
                            "invalid mesh relative transform instance="
                                .. tostring(building.source_instance_id)
                    end
                    local asset_started_at = BlueprintPerformance.now()
                    pcall(LoadAsset, mesh_path)
                    local mesh_asset = unwrap(StaticFindObject(mesh_path))
                    BlueprintPerformance.add_elapsed(
                        performance, "asset_lookup_ms", asset_started_at
                    )
                    if not is_valid_object(mesh_asset) then
                        return false, tostring(mesh_kind)
                            .. " mesh unavailable path="
                            .. tostring(mesh_path)
                    end
                    local component_started_at =
                        BlueprintPerformance.now()
                    local component, component_error =
                        ensure_blueprint_ghost_component(
                            component_index, session, component_store_key,
                            component_class, root_component
                        )
                    BlueprintPerformance.add_elapsed(
                        performance, "component_acquire_ms",
                        component_started_at
                    )
                    if component == nil then
                        return false, component_error
                    end
                    local root_relative_transform =
                        math_library:ComposeTransforms(
                            mesh_relative_transform,
                            building_relative_transform
                        )
                    local material_slot_count = math.max(
                        tonumber(
                            mesh_descriptor.material_slot_count
                        ) or 1,
                        1
                    )
                    local setup_ok, setup_error = pcall(function()
                        local mesh_setup_started_at =
                            BlueprintPerformance.now()
                        if mesh_kind == BlueprintPreviewMesh.SKELETAL then
                            component:SetSkeletalMeshAsset(mesh_asset)
                            pcall(function()
                                component:SetAnimationMode(1)
                            end)
                            pcall(function()
                                component.bPauseAnims = true
                                component.GlobalAnimRateScale = 0.0
                                component:SetComponentTickEnabled(false)
                            end)
                        else
                            component:SetStaticMesh(mesh_asset)
                        end
                        component:K2_SetRelativeTransform(
                            root_relative_transform, false, {}, true
                        )
                        BlueprintPerformance.add_elapsed(
                            performance, "mesh_setup_ms",
                            mesh_setup_started_at
                        )
                        local material_started_at =
                            BlueprintPerformance.now()
                        for slot_index = 0,
                            material_slot_count - 1 do
                            component:SetMaterial(
                                slot_index,
                                building_state.preview_placeholder
                                    and placeholder_material
                                    or normal_material
                            )
                        end
                        BlueprintPerformance.add_elapsed(
                            performance, "material_ms",
                            material_started_at
                        )
                        performance.material_slots =
                            performance.material_slots
                                + material_slot_count
                    end)
                    if not setup_ok then
                        return false, "ghost mesh setup failed index="
                            .. tostring(component_index) .. " error="
                            .. tostring(setup_error)
                    end
                    local binding = {
                        component_index = component_index,
                        component_store_key = component_store_key,
                        mesh_kind = mesh_kind,
                        mesh_relative_transform =
                            mesh_relative_transform,
                        material_slot_count = material_slot_count,
                        build_object_id = building.build_object_id,
                        source_instance_id =
                            building.source_instance_id,
                    }
                    state.bindings[#state.bindings + 1] = binding
                    building_state.mesh_bindings[
                        #building_state.mesh_bindings + 1
                    ] = binding
                end
            end
        end

        -- The stock placement actor remains under Palworld's cursor-driven
        -- transform. Original-position snap makes our non-anchor root absolute, so the
        -- stock anchor can no longer represent the fixed target. Allocate a
        -- collision-free visual proxy once for blueprints carrying a saved
        -- world transform and reveal it only while that snap is active. It is
        -- deliberately not
        -- inserted into state.buildings and therefore cannot participate in
        -- member overlap, support, material, or wave planning.
        local saved_anchor_world_transform = restore_transform(
            blueprint_clipboard.anchor_world_transform
        )
        if saved_anchor_world_transform ~= nil and anchor_record ~= nil then
            local anchor_relative_transform = restore_transform(
                anchor_record.relative_transform
            )
            if anchor_relative_transform == nil then
                return false, "invalid anchor proxy relative transform"
            end
            for _, mesh_descriptor in ipairs(
                anchor_record.preview_meshes or {}
            ) do
                local mesh_path, mesh_kind =
                    BlueprintPreviewMesh.asset_path(mesh_descriptor)
                if mesh_path == nil or mesh_kind == nil then
                    return false,
                        "terrain anchor preview mesh identity unavailable"
                end
                local component_store_key =
                    mesh_kind == BlueprintPreviewMesh.SKELETAL
                    and "preview_skeletal_meshes" or "preview_meshes"
                local component_class =
                    mesh_kind == BlueprintPreviewMesh.SKELETAL
                    and skeletal_component_class or static_component_class
                component_indices[mesh_kind] =
                    component_indices[mesh_kind] + 1
                local component_index = component_indices[mesh_kind]
                component_total = component_total + 1
                local mesh_relative_transform = restore_transform(
                    mesh_descriptor.relative_transform
                )
                if mesh_relative_transform == nil then
                    return false,
                        "invalid terrain anchor mesh relative transform"
                end
                local asset_started_at = BlueprintPerformance.now()
                pcall(LoadAsset, mesh_path)
                local mesh_asset = unwrap(StaticFindObject(mesh_path))
                BlueprintPerformance.add_elapsed(
                    performance, "asset_lookup_ms", asset_started_at
                )
                if not is_valid_object(mesh_asset) then
                    return false, "terrain anchor " .. tostring(mesh_kind)
                        .. " mesh unavailable path=" .. tostring(mesh_path)
                end
                local component_started_at = BlueprintPerformance.now()
                local component, component_error =
                    ensure_blueprint_ghost_component(
                        component_index, session, component_store_key,
                        component_class, root_component
                    )
                BlueprintPerformance.add_elapsed(
                    performance, "component_acquire_ms",
                    component_started_at
                )
                if component == nil then return false, component_error end
                local root_relative_transform =
                    math_library:ComposeTransforms(
                        mesh_relative_transform,
                        anchor_relative_transform
                    )
                local material_slot_count = math.max(
                    tonumber(mesh_descriptor.material_slot_count) or 1, 1
                )
                local setup_ok, setup_error = pcall(function()
                    if mesh_kind == BlueprintPreviewMesh.SKELETAL then
                        component:SetSkeletalMeshAsset(mesh_asset)
                        pcall(function()
                            component:SetAnimationMode(1)
                            component.bPauseAnims = true
                            component.GlobalAnimRateScale = 0.0
                            component:SetComponentTickEnabled(false)
                        end)
                    else
                        component:SetStaticMesh(mesh_asset)
                    end
                    component:K2_SetRelativeTransform(
                        root_relative_transform, false, {}, true
                    )
                    for slot_index = 0, material_slot_count - 1 do
                        component:SetMaterial(
                            slot_index,
                            anchor_record.preview_placeholder == true
                                and placeholder_material or normal_material
                        )
                    end
                    component:SetHiddenInGame(true, true)
                    component:SetVisibility(false, true)
                end)
                if not setup_ok then
                    return false, "terrain anchor ghost setup failed index="
                        .. tostring(component_index) .. " error="
                        .. tostring(setup_error)
                end
                performance.material_slots =
                    performance.material_slots + material_slot_count
                local binding = {
                    component_index = component_index,
                    component_store_key = component_store_key,
                    mesh_kind = mesh_kind,
                    mesh_relative_transform = mesh_relative_transform,
                    material_slot_count = material_slot_count,
                    build_object_id = anchor_record.build_object_id,
                    source_instance_id = anchor_record.source_instance_id,
                    terrain_anchor_proxy = true,
                }
                state.bindings[#state.bindings + 1] = binding
                state.anchor_proxy_bindings[
                    #state.anchor_proxy_bindings + 1
                ] = binding
            end
        end

        -- Native exact-overlap repair uses one flat query component per
        -- native checker request member. Non-anchor buildings already occupy
        -- slots 1..building_count; append the stock anchor as the final slot
        -- so a representative OverlappedActor can be expanded into a complete
        -- world-building candidate set without a global object search.
        local anchor_overlap_descriptor =
            anchor_record and anchor_record.overlap_descriptor or nil
        local anchor_shape_type = anchor_overlap_descriptor
            and anchor_overlap_descriptor.shape_type or nil
        if query_pool_counts[anchor_shape_type] == nil then
            return false,
                "unsupported anchor overlap descriptor shape="
                    .. tostring(anchor_shape_type)
        end
        query_pool_counts[anchor_shape_type] =
            query_pool_counts[anchor_shape_type] + 1
        local anchor_query_index = query_pool_counts[anchor_shape_type]
        local anchor_query_started_at = BlueprintPerformance.now()
        local anchor_query_component, anchor_query_error =
            ensure_blueprint_query_component(
                anchor_query_index, session, anchor_overlap_descriptor
            )
        BlueprintPerformance.add_elapsed(
            performance, "query_setup_ms", anchor_query_started_at
        )
        if anchor_query_component == nil then
            return false, anchor_query_error
        end
        local anchor_query_stored, anchor_query_store_error =
            component_store.set_array_item(
                session,
                "overlap_query_components",
                building_count + 1,
                anchor_query_component
            )
        if not anchor_query_stored then
            return false,
                "anchor overlap query ownership write failed error="
                    .. tostring(anchor_query_store_error)
        end

        log(string.format(
            "blueprint ghost renderer configured ownership=session buildings=%d meshComponents=%d staticMeshes=%d skeletalMeshes=%d normalMaterial=%s invalidMaterial=%s placeholderMaterial=%s queryShapes=box:%d,sphere:%d,capsule:%d",
            building_count, component_total,
            component_indices[BlueprintPreviewMesh.STATIC],
            component_indices[BlueprintPreviewMesh.SKELETAL],
            object_name(normal_material), object_name(error_material),
            object_name(placeholder_material),
            query_pool_counts.box, query_pool_counts.sphere,
            query_pool_counts.capsule
        ))
        log(string.format(
            "blueprint performance preview-configure totalMs=%.2f buildings=%d meshComponents=%d materialSlots=%d querySetupMs=%.2f assetLookupMs=%.2f componentAcquireMs=%.2f meshSetupMs=%.2f materialMs=%.2f poolSize=0",
            BlueprintPerformance.elapsed_ms(performance_started_at),
            building_count, component_total, performance.material_slots,
            performance.query_setup_ms, performance.asset_lookup_ms,
            performance.component_acquire_ms,
            performance.mesh_setup_ms, performance.material_ms
        ))
        return true, nil
    end

    function renderer.get_query_component(session, building_state)
        return component_store.get_query_component(
            session, building_state.query_shape,
            building_state.query_index
        )
    end

    function renderer.get_preview_material(session)
        return component_store.get_reference(
            session, "normal_material"
        )
    end

    function renderer.update_root_transform(session, anchor_transform)
        local root_component =
            component_store.get_reference(session, "preview_root")
        if not is_valid_object(root_component)
            or anchor_transform == nil then
            return false,
                "ghost root transform dependencies unavailable"
        end
        local ok, update_error = pcall(function()
            root_component:K2_SetWorldTransform(
                anchor_transform, false, {}, true
            )
        end)
        if not ok then return false, tostring(update_error) end
        return renderer.show(session)
    end

    function renderer.attach_root_to_anchor(session, anchor_actor)
        local root_component =
            component_store.get_reference(session, "preview_root")
        anchor_actor = unwrap(anchor_actor)
        if not is_valid_object(root_component)
            or not is_valid_object(anchor_actor) then
            return false,
                "ghost root attachment dependencies unavailable"
        end
        local anchor_root =
            unwrap(safe_property(anchor_actor, "RootComponent"))
        if not is_valid_object(anchor_root) then
            return false, "anchor root component unavailable"
        end
        local attached_root = component_store.get_reference(
            session, "attached_anchor_root"
        )
        if safe_object_address(attached_root)
            == safe_object_address(anchor_root) then
            return renderer.show(session)
        end
        local ok, attach_result = pcall(function()
            -- Stock invalid/occupied previews temporarily scale the anchor to
            -- 1.02. Blueprint member spacing is authored in canonical model
            -- space and must never inherit that presentation-only scale.
            -- Position and rotation remain attached natively every frame.
            root_component:SetAbsolute(false, false, true)
            return root_component:K2_AttachToComponent(
                anchor_root, FName("None"), 2, 2, 2, false
            )
        end)
        if not ok or attach_result == false then
            return false, "ghost root attachment failed error="
                .. tostring(attach_result)
        end
        local stored, store_error = component_store.set_reference(
            session, "attached_anchor_root", anchor_root
        )
        if not stored then
            return false, "anchor root ownership write failed error="
                .. tostring(store_error)
        end
        return renderer.show(session)
    end

    function renderer.set_terrain_snap(
        session, anchor_actor, enabled, target_transform
    )
        local root_component =
            component_store.get_reference(session, "preview_root")
        anchor_actor = unwrap(anchor_actor)
        if not is_valid_object(root_component)
            or not is_valid_object(anchor_actor) then
            return false, "terrain snap root dependencies unavailable"
        end
        if enabled == true then
            if target_transform == nil then
                return false, "terrain snap target transform is unavailable"
            end
            local ok, error_value = pcall(function()
                -- The root may remain attached for ownership, but absolute
                -- location/rotation/scale make the saved terrain frame the
                -- authoritative native transform between monitor ticks.
                root_component:SetAbsolute(true, true, true)
                root_component:K2_SetWorldTransform(
                    target_transform, false, {}, true
                )
            end)
            if not ok then return false, tostring(error_value) end
            state.terrain_snap_active = true
            local proxy_ok, proxy_error =
                set_terrain_snap_visual_visibility(
                session, true
            )
            if not proxy_ok then return false, proxy_error end
            return renderer.show(session)
        end

        local anchor_root = unwrap(safe_property(
            anchor_actor, "RootComponent"
        ))
        if not is_valid_object(anchor_root) then
            return false, "terrain snap anchor root is unavailable"
        end
        local ok, attach_result = pcall(function()
            root_component:SetAbsolute(false, false, true)
            return root_component:K2_AttachToComponent(
                anchor_root, FName("None"), 2, 2, 2, false
            )
        end)
        if not ok or attach_result == false then
            return false, "terrain snap release failed error="
                .. tostring(attach_result)
        end
        local stored, store_error = component_store.set_reference(
            session, "attached_anchor_root", anchor_root
        )
        if not stored then
            return false, "terrain snap release ownership write failed error="
                .. tostring(store_error)
        end
        state.terrain_snap_active = false
        local proxy_ok, proxy_error =
            set_terrain_snap_visual_visibility(
            session, false
        )
        if not proxy_ok then return false, proxy_error end
        return renderer.show(session)
    end

    function renderer.refresh_world_transforms(
        session, anchor_transform
    )
        if not is_valid_object(session) then
            return false, "placement Session unavailable"
        end
        local math_library = UEHelpers.GetKismetMathLibrary()
        if not is_valid_object(math_library)
            or anchor_transform == nil then
            return false, "transform dependencies unavailable"
        end
        local ok, update_error = pcall(function()
            -- Blueprint relative transforms are recorded in model space, not
            -- actor space. Reconstruct the current anchor model frame before
            -- computing member model centres. This is required for tight
            -- exact-state matching because some stock build actors have a
            -- small actor/model offset.
            local model_relative_to_actor = math_library:InvertTransform(
                state.anchor_actor_relative_to_model
            )
            local anchor_model_transform =
                math_library:ComposeTransforms(
                    model_relative_to_actor, anchor_transform
                )
            for _, building_state in ipairs(state.buildings) do
                building_state.world_transform =
                    math_library:ComposeTransforms(
                        building_state.building_relative_transform,
                        anchor_model_transform
                    )
            end
        end)
        if not ok then return false, tostring(update_error) end
        return true, nil
    end

    function renderer.set_building_blocked(
        session, building_state, blocked
    )
        blocked = blocked == true
        local material_kind = blocked and "error"
            or (
                building_state.preview_placeholder == true
                    and "placeholder" or "normal"
            )
        if building_state.blocked == blocked
            and building_state.material_kind == material_kind then
            return true
        end
        local material = nil
        if material_kind == "placeholder" then
            material = get_placeholder_preview_material()
            if not is_valid_object(material) then
                material = component_store.get_reference(
                    session, "normal_material"
                )
            end
        else
            material = component_store.get_reference(
                session, material_kind == "error"
                    and "error_material" or "normal_material"
            )
        end
        if not is_valid_object(material) then return false end
        local performance_started_at = BlueprintPerformance.now()
        local material_slots = 0
        local ok, update_error = pcall(function()
            for _, binding in ipairs(building_state.mesh_bindings) do
                local component = component_store.get_array_item(
                    session,
                    binding.component_store_key or "preview_meshes",
                    binding.component_index
                )
                if not is_valid_object(component) then
                    error("Session preview component unavailable index="
                        .. tostring(binding.component_index))
                end
                for slot_index = 0,
                    binding.material_slot_count - 1 do
                    component:SetMaterial(slot_index, material)
                    material_slots = material_slots + 1
                end
            end
            session.SBB_PreviewInvalidGhostIndex =
                blocked and (
                    tonumber(building_state.selection_index) or -1
                ) or -1
        end)
        if not ok then
            log("blueprint ghost material update failed instance="
                .. tostring(building_state.source_instance_id)
                .. " error=" .. tostring(update_error))
            return false
        end
        local elapsed_ms =
            BlueprintPerformance.elapsed_ms(performance_started_at)
        if elapsed_ms >= 4.0 then
            log(string.format(
                "blueprint performance preview-material-switch elapsedMs=%.2f blocked=%s materialSlots=%d sourceInstance=%s",
                elapsed_ms, tostring(blocked), material_slots,
                tostring(building_state.source_instance_id)
            ))
        end
        building_state.blocked = blocked
        building_state.material_kind = material_kind
        return true
    end

    function renderer.get_state()
        return state
    end

    return renderer
end

return BlueprintGhostRenderer

local BlueprintNativeOverlapGate = {}

local STATUS_IDLE = 0
local STATUS_RUNNING = 1
local STATUS_COMPLETE = 2
local STATUS_ERROR = 3

local RESULT_BRIDGE_ERROR = -2
local RESULT_PENDING = -1
local RESULT_NONE = 0
local RESULT_NOT_READY = 23
local RESULT_OVERLAP = 28
local RESULT_INTERSECT = 29
local RESULT_SUCCESS = 60

local function is_overlap_result(result)
    return result == RESULT_OVERLAP
        or result == RESULT_INTERSECT
end

local function is_error_result(result)
    return result == nil
        or result == RESULT_BRIDGE_ERROR
        or result == RESULT_PENDING
        or result == RESULT_NONE
        or result == RESULT_NOT_READY
end

function BlueprintNativeOverlapGate.install(deps)
    assert(type(deps) == "table",
        "BlueprintNativeOverlapGate dependencies are required")
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object dependency is required"
    )
    local safe_property = assert(
        deps.safe_property, "safe_property dependency is required"
    )
    local write_property = assert(
        deps.write_property, "write_property dependency is required"
    )
    local make_name = assert(
        deps.make_name, "make_name dependency is required"
    )
    local get_math_library = assert(
        deps.get_math_library, "get_math_library dependency is required"
    )
    local component_store = assert(
        deps.component_store, "component_store dependency is required"
    )
    local value_to_string = assert(
        deps.value_to_string, "value_to_string dependency is required"
    )
    local compare_equivalence = assert(
        deps.compare_equivalence,
        "compare_equivalence dependency is required"
    )

    local gate = {}
    local pending_generation = nil
    local pending_expected = nil
    local pending_members = nil

    local function array_count(values)
        if values == nil then return 0 end
        local count = 0
        pcall(function() count = #values end)
        return count
    end

    local function array_item(values, index)
        if values == nil then return nil end
        local value = nil
        pcall(function() value = unwrap(values[index]) end)
        return value
    end

    local function write_scalar(session, name, value)
        local ok, result = pcall(
            write_property, session, name, value
        )
        return ok and result ~= false,
            ok and nil or tostring(result)
    end

    local function number_field(value, lower_name, upper_name)
        return tonumber(safe_property(value, lower_name))
            or tonumber(safe_property(value, upper_name))
            or 0.0
    end

    local function copy_location(value)
        return {
            x = number_field(value, "x", "X"),
            y = number_field(value, "y", "Y"),
            z = number_field(value, "z", "Z"),
        }
    end

    local function copy_rotation(value)
        return {
            pitch = number_field(value, "pitch", "Pitch"),
            yaw = number_field(value, "yaw", "Yaw"),
            roll = number_field(value, "roll", "Roll"),
        }
    end

    local function copy_quaternion(value)
        return {
            x = number_field(value, "x", "X"),
            y = number_field(value, "y", "Y"),
            z = number_field(value, "z", "Z"),
            w = number_field(value, "w", "W"),
        }
    end

    local function decode_candidate_arrays(session)
        local member_indices = component_store.get_array(
            session, "native_overlap_candidate_member_indices"
        )
        local build_ids = component_store.get_array(
            session, "native_overlap_candidate_build_ids"
        )
        local transforms = component_store.get_array(
            session, "native_overlap_candidate_transforms"
        )
        local object_names = component_store.get_array(
            session, "native_overlap_candidate_object_names"
        )
        local count = array_count(member_indices)
        local consistent = array_count(build_ids) == count
            and array_count(transforms) == count
            and array_count(object_names) == count
        local by_member = {}
        if consistent then
            for candidate_index = 1, count do
                local member_index = tonumber(array_item(
                    member_indices, candidate_index
                ))
                local transform = array_item(
                    transforms, candidate_index
                )
                local location = safe_property(transform, "Translation")
                local rotation = safe_property(transform, "Rotation")
                if member_index ~= nil and location ~= nil
                    and rotation ~= nil then
                    by_member[member_index] =
                        by_member[member_index] or {}
                    table.insert(by_member[member_index], {
                        build_object_id = value_to_string(array_item(
                            build_ids, candidate_index
                        )),
                        location = copy_location(location),
                        rotation = copy_quaternion(rotation),
                        instance_id = value_to_string(array_item(
                            object_names, candidate_index
                        )),
                    })
                end
            end
        end
        return member_indices, count, consistent, by_member
    end

    local function is_better_rejection(details, current_details)
        if type(details) ~= "table" then return false end
        if details.reason == "build-object-id-mismatch"
            or details.reason == "record-unavailable"
            or details.reason == "transform-unavailable" then
            return false
        end
        if type(current_details) ~= "table" then return true end
        local position_error =
            tonumber(details.position_error) or math.huge
        local current_position_error =
            tonumber(current_details.position_error) or math.huge
        if position_error ~= current_position_error then
            return position_error < current_position_error
        end
        return (tonumber(details.angle_error_degrees) or math.huge)
            < (
                tonumber(current_details.angle_error_degrees)
                    or math.huge
            )
    end

    local function clear_request_arrays(session)
        for _, key in ipairs({
            "native_overlap_build_ids",
            "native_overlap_locations",
            "native_overlap_rotations",
            "native_overlap_collision_transforms",
            "native_overlap_results",
            "native_overlap_candidate_member_indices",
            "native_overlap_candidate_build_ids",
            "native_overlap_candidate_transforms",
            "native_overlap_candidate_object_names",
            "native_overlap_blocker_member_indices",
            "native_overlap_blocker_build_ids",
            "native_overlap_blocker_object_names",
            "native_overlap_blocker_class_names",
            "native_overlap_blocker_is_build",
        }) do
            local ok, error_value =
                component_store.empty_array(session, key)
            if not ok then return false, error_value end
        end
        return true, nil
    end

    function gate.reset()
        -- Deliberately retain no UObject.  These are only primitive request
        -- identifiers and a pure-data copy used for shadow comparison.
        pending_generation = nil
        pending_expected = nil
        pending_members = nil
    end

    function gate.has_pending()
        return pending_generation ~= nil
    end

    function gate.submit(session, building_states)
        session = unwrap(session)
        if not is_valid_object(session) then
            return nil, "placement Session unavailable"
        end
        if pending_generation ~= nil then
            return nil, "native overlap request already pending"
        end
        building_states = building_states or {}
        if #building_states == 0 then
            return nil, "native overlap request is empty"
        end

        local math_library = unwrap(get_math_library())
        if not is_valid_object(math_library) then
            return nil, "native overlap rotation dependency unavailable"
        end

        local cleared, clear_error = clear_request_arrays(session)
        if not cleared then return nil, clear_error end

        local submitted_members = {}
        for index, building_state in ipairs(building_states) do
            local transform = nil
            local collision_transform = nil
            local composed, compose_error = pcall(function()
                transform = math_library:ComposeTransforms(
                    building_state.actor_relative_to_model,
                    building_state.world_transform
                )
                collision_transform = math_library:ComposeTransforms(
                    building_state.overlap_relative_transform,
                    building_state.world_transform
                )
            end)
            local location = composed
                and safe_property(transform, "Translation") or nil
            local quaternion = composed
                and safe_property(transform, "Rotation") or nil
            local rotation = nil
            local converted, conversion_error = pcall(function()
                rotation = math_library:Quat_Rotator(quaternion)
            end)
            if not converted or location == nil or rotation == nil
                or collision_transform == nil
                or building_state.build_object_id == nil then
                clear_request_arrays(session)
                return nil,
                    "native overlap member transform unavailable index="
                        .. tostring(index) .. " error="
                        .. tostring(compose_error or conversion_error)
            end

            submitted_members[index] = {
                index = index,
                build_object_id = tostring(building_state.build_object_id),
                source_instance_id = building_state.source_instance_id,
                selection_index = building_state.selection_index,
                location = copy_location(location),
                rotation = copy_rotation(rotation),
                rotation_quaternion = copy_quaternion(quaternion),
                install_strategy = building_state.install_strategy,
                query_role = building_state.native_overlap_query_role,
            }

            local values = {
                {"native_overlap_build_ids",
                 make_name(building_state.build_object_id)},
                {"native_overlap_locations", location},
                {"native_overlap_rotations", rotation},
                {"native_overlap_collision_transforms",
                 collision_transform},
                {"native_overlap_results", RESULT_PENDING},
            }
            for _, item in ipairs(values) do
                local stored, store_error =
                    component_store.set_array_item(
                        session, item[1], index, item[2]
                    )
                if not stored then
                    clear_request_arrays(session)
                    return nil,
                        "native overlap request write failed index="
                            .. tostring(index) .. " field="
                            .. tostring(item[1]) .. " error="
                            .. tostring(store_error)
                end
            end
        end

        local request_generation = (
            tonumber(safe_property(
                session, "SBB_NativeOverlapRequestGeneration"
            )) or 0
        ) + 1
        if request_generation > 2000000000 then
            request_generation = 1
        end
        for _, scalar in ipairs({
            {"SBB_NativeOverlapCompletedCount", 0},
            {"SBB_NativeOverlapStatus", STATUS_IDLE},
            -- Publish the generation last.  The native bridge treats this
            -- write as the request's release/commit point.
            {"SBB_NativeOverlapRequestGeneration", request_generation},
        }) do
            local wrote, write_error =
                write_scalar(session, scalar[1], scalar[2])
            if not wrote then
                clear_request_arrays(session)
                return nil,
                    "native overlap scalar write failed field="
                        .. tostring(scalar[1]) .. " error="
                        .. tostring(write_error)
            end
        end

        pending_generation = request_generation
        pending_expected = nil
        pending_members = submitted_members
        return request_generation, nil
    end

    function gate.remember_expected(generation, building_states)
        generation = tonumber(generation)
        if generation == nil or generation ~= pending_generation then
            return false
        end
        local expected = {}
        for index, building_state in ipairs(building_states or {}) do
            local blocker = building_state.blocker
            local submitted = pending_members
                and pending_members[index] or {}
            expected[index] = {
                build_object_id = tostring(
                    building_state.build_object_id or "<unknown>"
                ),
                index = index,
                location = submitted.location,
                rotation = submitted.rotation,
                custom_overlap = blocker ~= nil
                    and blocker.category ~= "water",
                custom_category = blocker
                    and tostring(blocker.category or "<unknown>")
                    or "<none>",
                custom_reason = blocker
                    and tostring(blocker.reason or "<unknown>")
                    or "<none>",
                custom_blocker_build_object_id = blocker
                    and tostring(
                        blocker.build_object_id or "<none>"
                    ) or "<none>",
                custom_blocker_component = blocker
                    and tostring(
                        blocker.component_label or "<none>"
                    ) or "<none>",
                exact_world_match =
                    building_state.existing_world_match ~= nil,
            }
        end
        pending_expected = expected
        return true
    end

    function gate.poll(session)
        session = unwrap(session)
        if pending_generation == nil or not is_valid_object(session) then
            return nil
        end
        local completed_generation = tonumber(safe_property(
            session, "SBB_NativeOverlapCompletedGeneration"
        )) or 0
        local status = tonumber(safe_property(
            session, "SBB_NativeOverlapStatus"
        )) or STATUS_IDLE
        if completed_generation ~= pending_generation
            or (status ~= STATUS_COMPLETE and status ~= STATUS_ERROR) then
            return nil
        end

        local results = component_store.get_array(
            session, "native_overlap_results"
        )
        local blocker_member_indices = component_store.get_array(
            session, "native_overlap_blocker_member_indices"
        )
        local blocker_build_ids = component_store.get_array(
            session, "native_overlap_blocker_build_ids"
        )
        local blocker_object_names = component_store.get_array(
            session, "native_overlap_blocker_object_names"
        )
        local blocker_class_names = component_store.get_array(
            session, "native_overlap_blocker_class_names"
        )
        local blocker_is_build = component_store.get_array(
            session, "native_overlap_blocker_is_build"
        )
        local result_count = array_count(results)
        local candidate_member_indices, candidate_count,
            candidate_arrays_consistent, candidates_by_member =
                decode_candidate_arrays(session)
        local blocker_count = array_count(blocker_member_indices)
        local blocker_arrays_consistent =
            array_count(blocker_build_ids) == blocker_count
            and array_count(blocker_object_names) == blocker_count
            and array_count(blocker_class_names) == blocker_count
            and array_count(blocker_is_build) == blocker_count
        local blockers_by_member = {}
        if blocker_arrays_consistent then
            for blocker_index = 1, blocker_count do
                local member_index = tonumber(array_item(
                    blocker_member_indices, blocker_index
                ))
                if member_index ~= nil then
                    local is_build_value =
                        array_item(blocker_is_build, blocker_index)
                    local is_build_object =
                        is_build_value == true
                        or tonumber(is_build_value) == 1
                        or string.lower(tostring(is_build_value))
                            == "true"
                    blockers_by_member[member_index] =
                        blockers_by_member[member_index] or {}
                    table.insert(blockers_by_member[member_index], {
                        build_object_id = value_to_string(array_item(
                            blocker_build_ids, blocker_index
                        )),
                        object_name = value_to_string(array_item(
                            blocker_object_names, blocker_index
                        )),
                        class_name = value_to_string(array_item(
                            blocker_class_names, blocker_index
                        )),
                        is_build_object = is_build_object,
                    })
                end
            end
        end
        local function select_primary_blocker(blockers)
            for _, blocker in ipairs(blockers or {}) do
                if blocker.is_build_object == true then
                    return blocker
                end
            end
            for _, blocker in ipairs(blockers or {}) do
                local class_name =
                    string.lower(tostring(blocker.class_name or ""))
                if class_name ~= ""
                    and string.find(
                        class_name, "component", 1, true
                    ) == nil then
                    return blocker
                end
            end
            return blockers and blockers[1] or nil
        end
        local completed_count = tonumber(safe_property(
            session, "SBB_NativeOverlapCompletedCount"
        )) or 0
        local report = {
            generation = pending_generation,
            status = status,
            completed_count = completed_count,
            result_count = result_count,
            native_overlap_count = 0,
            native_candidate_count = candidate_count,
            native_candidate_arrays_consistent =
                candidate_arrays_consistent,
            native_blocker_count = blocker_count,
            native_blocker_arrays_consistent =
                blocker_arrays_consistent,
            native_satisfied_overlap_count = 0,
            native_unresolved_overlap_count = 0,
            native_clear_exact_match_count = 0,
            native_clear_exact_matches = {},
            native_clear_candidate_member_count = 0,
            native_clear_candidate_count = 0,
            native_clear_candidates = {},
            native_error_count = 0,
            blocked_count = 0,
            existing_match_count = 0,
            placeable = false,
            member_results = {},
            custom_overlap_count = 0,
            exact_match_count = 0,
            tolerated_exact_overlap_count = 0,
            hard_mismatch_count = 0,
            hard_mismatches = {},
        }

        local member_count = #(pending_members or {})
        local claimed_candidate_instances = {}
        for index = 1, member_count do
            local result = tonumber(array_item(results, index))
            local expected = pending_expected
                and pending_expected[index] or nil
            local native_overlap = is_overlap_result(result)
            local native_satisfied = false
            local matched_candidate = nil
            local matched_details = nil
            local rejected_candidate = nil
            local rejection_details = nil
            local submitted = pending_members
                and pending_members[index] or nil
            local member_candidates =
                candidates_by_member[index] or {}
            local member_blockers =
                blockers_by_member[index] or {}
            if native_overlap then
                report.native_overlap_count =
                    report.native_overlap_count + 1
                if submitted ~= nil and candidate_arrays_consistent then
                    for _, candidate in ipairs(
                        candidates_by_member[index] or {}
                    ) do
                        local equivalent, details = compare_equivalence({
                            build_object_id =
                                submitted.build_object_id,
                            location = submitted.location,
                            rotation =
                                submitted.rotation_quaternion,
                            install_strategy =
                                submitted.install_strategy,
                        }, candidate)
                        local candidate_instance =
                            tostring(candidate.instance_id or "")
                        local candidate_available =
                            candidate_instance == ""
                            or candidate_instance == "<nil>"
                            or candidate_instance == "None"
                            or claimed_candidate_instances[
                                candidate_instance
                            ] ~= true
                        if equivalent and candidate_available then
                            native_satisfied = true
                            matched_candidate = candidate
                            matched_details = details
                            if candidate_instance ~= ""
                                and candidate_instance ~= "<nil>"
                                and candidate_instance ~= "None" then
                                claimed_candidate_instances[
                                    candidate_instance
                                ] = true
                            end
                            break
                        end
                        if not equivalent
                            and is_better_rejection(
                                details, rejection_details
                            ) then
                            rejected_candidate = candidate
                            rejection_details = details
                        end
                    end
                end
                if native_satisfied then
                    report.native_satisfied_overlap_count =
                        report.native_satisfied_overlap_count + 1
                else
                    report.native_unresolved_overlap_count =
                        report.native_unresolved_overlap_count + 1
                end
            elseif is_error_result(result) then
                report.native_error_count =
                    report.native_error_count + 1
            end
            local blocked = is_error_result(result)
                or (native_overlap and not native_satisfied)
            if blocked then
                report.blocked_count = report.blocked_count + 1
            end
            if native_satisfied then
                report.existing_match_count =
                    report.existing_match_count + 1
            end
            report.member_results[index] = {
                index = index,
                source_instance_id =
                    submitted and submitted.source_instance_id or nil,
                selection_index =
                    submitted and submitted.selection_index or nil,
                query_role =
                    submitted and submitted.query_role or nil,
                build_object_id =
                    submitted and submitted.build_object_id
                        or "<unknown>",
                native_result = result,
                native_overlap = native_overlap,
                native_error = is_error_result(result),
                blocked = blocked,
                existing_world_match = native_satisfied,
                matched_candidate = matched_candidate,
                equivalence_details = matched_details,
                rejected_candidate = rejected_candidate,
                equivalence_rejection = rejection_details,
                candidate_count = #member_candidates,
                candidates = member_candidates,
                blocker_count = #member_blockers,
                blockers = member_blockers,
                primary_blocker =
                    select_primary_blocker(member_blockers),
            }
            if not native_overlap
                and not is_error_result(result)
                and #member_candidates > 0 then
                report.native_clear_candidate_member_count =
                    report.native_clear_candidate_member_count + 1
                report.native_clear_candidate_count =
                    report.native_clear_candidate_count
                        + #member_candidates
                for _, candidate in ipairs(member_candidates) do
                    table.insert(report.native_clear_candidates, {
                        index = index,
                        source_instance_id =
                            submitted
                                and submitted.source_instance_id
                                or nil,
                        build_object_id =
                            submitted
                                and submitted.build_object_id
                                or "<unknown>",
                        native_result = result,
                        candidate = candidate,
                    })
                end
            end
            if expected ~= nil then
                if expected.custom_overlap then
                    report.custom_overlap_count =
                        report.custom_overlap_count + 1
                end
                if expected.exact_world_match then
                    report.exact_match_count =
                        report.exact_match_count + 1
                    if not native_overlap
                        and not is_error_result(result) then
                        report.native_clear_exact_match_count =
                            report.native_clear_exact_match_count + 1
                        table.insert(
                            report.native_clear_exact_matches,
                            {
                                index = expected.index or index,
                                build_object_id =
                                    expected.build_object_id,
                                location = expected.location,
                                rotation = expected.rotation,
                                native_result = result,
                            }
                        )
                    end
                end
                if native_overlap and (
                    native_satisfied or expected.exact_world_match
                )
                    and not expected.custom_overlap then
                    report.tolerated_exact_overlap_count =
                        report.tolerated_exact_overlap_count + 1
                elseif (not native_overlap
                    and not is_error_result(result)
                    and expected.custom_overlap)
                    or (native_overlap
                        and not expected.custom_overlap
                        and not native_satisfied
                        and not expected.exact_world_match) then
                    report.hard_mismatch_count =
                        report.hard_mismatch_count + 1
                    report.hard_mismatches[
                        #report.hard_mismatches + 1
                    ] = {
                        index = expected.index or index,
                        build_object_id = expected.build_object_id,
                        location = expected.location,
                        rotation = expected.rotation,
                        native_result = result,
                        mismatch_kind = native_overlap
                            and "native-overlap/custom-clear"
                            or "native-clear/custom-overlap",
                        custom_overlap = expected.custom_overlap,
                        custom_category = expected.custom_category,
                        custom_reason = expected.custom_reason,
                        custom_blocker_build_object_id =
                            expected.custom_blocker_build_object_id,
                        custom_blocker_component =
                            expected.custom_blocker_component,
                        exact_world_match =
                            expected.exact_world_match,
                        native_candidate_satisfied =
                            native_satisfied,
                        native_candidate_count =
                            #(candidates_by_member[index] or {}),
                    }
                end
            end
        end
        report.placeable = report.blocked_count == 0
            and report.native_error_count == 0
            and completed_count >= member_count
            and result_count >= member_count

        pending_generation = nil
        pending_expected = nil
        pending_members = nil
        return report
    end

    gate.STATUS_RUNNING = STATUS_RUNNING
    gate.STATUS_COMPLETE = STATUS_COMPLETE
    gate.STATUS_ERROR = STATUS_ERROR
    gate.RESULT_BRIDGE_ERROR = RESULT_BRIDGE_ERROR
    gate.RESULT_PENDING = RESULT_PENDING
    gate.RESULT_NONE = RESULT_NONE
    gate.RESULT_NOT_READY = RESULT_NOT_READY
    gate.RESULT_OVERLAP = RESULT_OVERLAP
    gate.RESULT_INTERSECT = RESULT_INTERSECT
    gate.RESULT_SUCCESS = RESULT_SUCCESS
    return gate
end

return BlueprintNativeOverlapGate

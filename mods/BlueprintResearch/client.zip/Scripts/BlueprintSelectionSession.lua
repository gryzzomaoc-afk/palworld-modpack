local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local BlueprintSelectionSession = {}

local SESSION_PACKAGE =
    "/Game/Mods/BlueprintResearch/BP_BlueprintSelectionSession"
local SESSION_ASSET_PATH = SESSION_PACKAGE
    .. ".BP_BlueprintSelectionSession"
local SESSION_CLASS_PATH = SESSION_PACKAGE
    .. ".BP_BlueprintSelectionSession_C"
local SESSION_CLASS_NAME = "BP_BlueprintSelectionSession_C"
local MOD_ACTOR_CLASS_NAME = "ModActor_C"
local MOD_ACTOR_CLASS_FULL_NAME =
    "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/"
        .. "ModActor.ModActor_C"
local SESSION_CLASS_REFERENCE_PROPERTY = "SBB_SelectionSessionClass"
local SESSION_INSTANCE_PROPERTY = "SBB_SelectionSession"
local SESSION_INPUT_ACTOR_PROPERTY = "SBB_SelectionInputActor"
local TARGET_CHANGED_FUNCTION_PATH = SESSION_CLASS_PATH
    .. ":SBB_SelectionTargetChanged"
local TERRAIN_PROBE_INPUT_FUNCTION_PATH =
    "/Game/Mods/BlueprintResearch/ModActor.ModActor_C:"
        .. "SBB_InputSetBlueprintAnchor"
local CAMERA_STOCK_EXIT_FUNCTION_PATH =
    "/Game/Mods/BlueprintResearch/BP_BlueprintPlacementCamera."
    .. "BP_BlueprintPlacementCamera_C:SBB_RequestStockCameraExit"
local MATERIAL_LIBRARY_PATH =
    "/Script/Engine.Default__KismetMaterialLibrary"
local TERRAIN_MARKER_SCALE = 0.32
local FALLBACK_HIGHLIGHT_MATERIAL =
    "/Game/Pal/Material/MapObject/BuildObject/BuildingProcess/"
    .. "MI_LooksPredicatorNormal.MI_LooksPredicatorNormal"
local FALLBACK_DISMANTLE_MATERIAL =
    "/Game/Pal/Material/MapObject/BuildObject/BuildingProcess/"
    .. "MI_LooksPredicatorDismantle.MI_LooksPredicatorDismantle"
local MATERIAL_ROOT =
    "/Game/Pal/Material/MapObject/BuildObject/BuildingProcess/"
local FALLBACK_MATERIALS = {
    highlight = FALLBACK_HIGHLIGHT_MATERIAL,
    highlight_two_sided = MATERIAL_ROOT
        .. "MI_LooksPredicatorNormal_TwoSided."
        .. "MI_LooksPredicatorNormal_TwoSided",
    highlight_work_position = MATERIAL_ROOT
        .. "MI_LooksPredicatorNormal_WorkPositionVisualizer."
        .. "MI_LooksPredicatorNormal_WorkPositionVisualizer",
    dismantle = FALLBACK_DISMANTLE_MATERIAL,
    dismantle_two_sided = MATERIAL_ROOT
        .. "MI_LooksPredicatorDismantle_TwoSided."
        .. "MI_LooksPredicatorDismantle_TwoSided",
    error = MATERIAL_ROOT
        .. "MI_LooksPredicatorError.MI_LooksPredicatorError",
    error_two_sided = MATERIAL_ROOT
        .. "MI_LooksPredicatorError_TwoSided."
        .. "MI_LooksPredicatorError_TwoSided",
    error_work_position = MATERIAL_ROOT
        .. "MI_LooksPredicatorError_WorkPositionVisualizer."
        .. "MI_LooksPredicatorError_WorkPositionVisualizer",
}

BlueprintSelectionSession.ROLE_NORMAL = 0
BlueprintSelectionSession.ROLE_HOVER = 1
BlueprintSelectionSession.ROLE_SELECTED = 2
BlueprintSelectionSession.ROLE_ANCHOR = 3
BlueprintSelectionSession.ROLE_SERIALIZATION_ERROR = 4

function BlueprintSelectionSession.install(deps)
    assert(type(deps) == "table",
        "BlueprintSelectionSession dependencies are required")

    local UEHelpers = assert(
        deps.UEHelpers, "BlueprintSelectionSession UEHelpers is required")
    local log = assert(
        deps.log, "BlueprintSelectionSession log is required")
    local unwrap = assert(
        deps.unwrap, "BlueprintSelectionSession unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object,
        "BlueprintSelectionSession is_valid_object is required")
    local is_usable_class_object = assert(
        deps.is_usable_class_object,
        "BlueprintSelectionSession is_usable_class_object is required")
    local safe_property = assert(
        deps.safe_property,
        "BlueprintSelectionSession safe_property is required")
    local safe_object_address = assert(
        deps.safe_object_address,
        "BlueprintSelectionSession safe_object_address is required")
    local object_name = assert(
        deps.object_name, "BlueprintSelectionSession object_name is required")
    local get_asset_path = assert(
        deps.get_asset_path,
        "BlueprintSelectionSession get_asset_path is required")
    local copy_transform = assert(
        deps.copy_transform,
        "BlueprintSelectionSession copy_transform is required")
    local get_build_object_instance_id = assert(
        deps.get_build_object_instance_id,
        "BlueprintSelectionSession get_build_object_instance_id is required")
    local get_actor_from_hit_result = assert(
        deps.get_actor_from_hit_result,
        "BlueprintSelectionSession get_actor_from_hit_result is required")
    local on_target_changed = assert(
        deps.on_target_changed,
        "BlueprintSelectionSession on_target_changed is required")
    local on_camera_stock_exit = deps.on_camera_stock_exit

    local controller = {
        active = false,
        target_hook_ready = false,
        target_hook_callback = nil,
        terrain_probe_hook_ready = false,
        terrain_probe_hook_callback = nil,
        camera_exit_hook_ready = false,
        camera_exit_hook_callback = nil,
        flash_generation = 0,
        active_session = nil,
        active_session_address = nil,
        active_world_generation = nil,
        performance_now = deps.performance_now or os.clock,
        performance_elapsed_ms = deps.performance_elapsed_ms
            or function(started_at)
                return (os.clock() - started_at) * 1000.0
            end,
        is_probe_logging_enabled = deps.is_probe_logging_enabled
            or function() return false end,
        last_surface_probe = nil,
        terrain_effect_ready = false,
    }

    local function stop_terrain_effect(effect)
        effect = unwrap(effect)
        if not is_valid_object(effect) then return true, nil end
        local ok, error_value = pcall(function()
            effect:Deactivate()
            effect:SetRenderingEnabled(false)
            effect:ResetSystem()
            effect:SetHiddenInGame(true, true)
            effect:SetVisibility(false, true)
        end)
        return ok, ok and nil or tostring(error_value)
    end

    local function make_direct_handle(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local path = get_asset_path(value)
        local address = safe_object_address(value)
        if type(path) ~= "string" or path == "" or address == nil then
            return nil
        end
        return {
            path = path,
            address = address,
            world_generation =
                BlueprintCallbackScheduler.get_world_generation(),
        }
    end

    local function resolve_direct_handle(handle)
        if type(handle) ~= "table"
            or type(handle.path) ~= "string"
            or handle.address == nil
            or handle.world_generation
                ~= BlueprintCallbackScheduler.get_world_generation() then
            return nil
        end
        local ok, value = pcall(StaticFindObject, handle.path)
        value = ok and unwrap(value) or nil
        if not is_valid_object(value)
            or safe_object_address(value) ~= handle.address then
            return nil
        end
        return value
    end

    local function matches_active_session(session)
        session = unwrap(session)
        return controller.active == true
            and controller.active_world_generation
                == BlueprintCallbackScheduler.get_world_generation()
            and controller.active_session_address ~= nil
            and is_valid_object(session)
            and safe_object_address(session)
                == controller.active_session_address
    end

    local function get_class_full_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return "<invalid>" end
        local ok, result = pcall(function()
            return unwrap(value:GetClass()):GetFullName()
        end)
        return ok and tostring(result) or "<unavailable>"
    end

    local function capture_surface_probe(session)
        local hit = safe_property(session, "SBB_SelectionLastHit")
        if hit == nil then return nil end

        local function member(value, ...)
            for index = 1, select("#", ...) do
                local result = safe_property(value, select(index, ...))
                if result ~= nil then return result end
            end
            return nil
        end

        local blocking = member(hit, "bBlockingHit", "BlockingHit")
        local is_blocking = blocking == true or tonumber(blocking) == 1

        local function resolve_object(value)
            value = unwrap(value)
            if is_valid_object(value) then return value end
            local ok, resolved = pcall(function()
                return unwrap(value:Get())
            end)
            if ok and is_valid_object(resolved) then return resolved end
            return nil
        end

        local function vector(value)
            if value == nil then return nil end
            local x = tonumber(member(value, "X", "x"))
            local y = tonumber(member(value, "Y", "y"))
            local z = tonumber(member(value, "Z", "z"))
            if x == nil or y == nil or z == nil then return nil end
            return { x = x, y = y, z = z }
        end

        local function vector_text(value)
            if type(value) ~= "table" then return "<nil>" end
            return string.format(
                "(%.3f,%.3f,%.3f)", value.x, value.y, value.z
            )
        end

        local function call_value(value, function_name)
            value = resolve_object(value)
            if not is_valid_object(value) then return nil end
            local ok, result = pcall(function()
                return value[function_name](value)
            end)
            return ok and result or nil
        end

        local actor = nil
        pcall(function()
            actor = resolve_object(get_actor_from_hit_result(hit))
        end)
        local component = resolve_object(member(
            hit, "Component", "HitComponent"
        ))
        local mesh = resolve_object(call_value(component, "GetStaticMesh"))
        if not is_valid_object(mesh) then
            mesh = resolve_object(safe_property(component, "StaticMesh"))
        end

        local bounds = safe_property(component, "Bounds")
        local component_world_transform = copy_transform(
            call_value(component, "K2_GetComponentToWorld")
        )
        local record = {
            blocking_hit = is_blocking,
            blocking_raw = tostring(blocking),
            actor_name = object_name(actor),
            actor_class = get_class_full_name(actor),
            component_name = object_name(component),
            component_class = get_class_full_name(component),
            component_asset = get_asset_path(component),
            static_mesh = get_asset_path(mesh),
            impact_point = vector(member(hit, "ImpactPoint")),
            impact_normal = vector(member(hit, "ImpactNormal")),
            location = vector(member(hit, "Location")),
            normal = vector(member(hit, "Normal")),
            trace_start = vector(member(hit, "TraceStart")),
            trace_end = vector(member(hit, "TraceEnd")),
            distance = tonumber(member(hit, "Distance")),
            face_index = tonumber(member(hit, "FaceIndex")),
            item = tonumber(member(hit, "Item", "HitItem")),
            bone = tostring(member(hit, "BoneName", "HitBoneName") or ""),
            collision_profile = tostring(
                call_value(component, "GetCollisionProfileName")
                    or safe_property(component, "CollisionProfileName")
                    or "<unavailable>"
            ),
            collision_object_type = tostring(
                call_value(component, "GetCollisionObjectType")
                    or "<unavailable>"
            ),
            component_location = vector(
                call_value(component, "K2_GetComponentLocation")
            ),
            component_world_transform = component_world_transform,
            component_rotation = tostring(
                call_value(component, "K2_GetComponentRotation")
                    or "<unavailable>"
            ),
            bounds_origin = vector(member(bounds, "Origin")),
            bounds_extent = vector(member(bounds, "BoxExtent")),
            section_base_x = tonumber(
                safe_property(component, "SectionBaseX")
            ),
            section_base_y = tonumber(
                safe_property(component, "SectionBaseY")
            ),
            component_size_quads = tonumber(
                safe_property(component, "ComponentSizeQuads")
            ),
        }

        local actor_class = tostring(record.actor_class or "")
        local component_class = tostring(record.component_class or "")
        if record.blocking_hit
            and string.find(
                actor_class, "LandscapeStreamingProxy", 1, true
            ) ~= nil
            and string.find(
                component_class,
                "LandscapeHeightfieldCollisionComponent", 1, true
            ) ~= nil then
            record.terrain_kind = "landscape"
            record.terrain_signature = string.format(
                "landscape:%s:%s",
                tostring(record.section_base_x or "?"),
                tostring(record.section_base_y or "?")
            )
        elseif record.blocking_hit
            and string.find(actor_class, "StaticMeshActor", 1, true) ~= nil
            and string.find(
                component_class, "StaticMeshComponent", 1, true
            ) ~= nil
            and type(record.static_mesh) == "string"
            and record.static_mesh ~= "" then
            record.terrain_kind = "static_mesh"
            record.terrain_signature = record.static_mesh
        end

        log(string.format(
            "terrain selection probe blocking=%s rawBlocking=%s actor=%s actorClass=%s component=%s componentClass=%s componentAsset=%s mesh=%s",
            tostring(record.blocking_hit),
            record.blocking_raw,
            record.actor_name,
            record.actor_class,
            record.component_name,
            record.component_class,
            tostring(record.component_asset),
            tostring(record.static_mesh)
        ))
        log(string.format(
            "terrain selection probe hit impact=%s impactNormal=%s location=%s normal=%s traceStart=%s traceEnd=%s distance=%s face=%s item=%s bone=%s",
            vector_text(record.impact_point),
            vector_text(record.impact_normal),
            vector_text(record.location),
            vector_text(record.normal),
            vector_text(record.trace_start),
            vector_text(record.trace_end),
            tostring(record.distance),
            tostring(record.face_index),
            tostring(record.item),
            record.bone
        ))
        log(string.format(
            "terrain selection probe surface profile=%s objectType=%s componentLocation=%s componentRotation=%s boundsOrigin=%s boundsExtent=%s sectionBase=%s/%s componentSizeQuads=%s",
            record.collision_profile,
            record.collision_object_type,
            vector_text(record.component_location),
            record.component_rotation,
            vector_text(record.bounds_origin),
            vector_text(record.bounds_extent),
            tostring(record.section_base_x),
            tostring(record.section_base_y),
            tostring(record.component_size_quads)
        ))
        return record
    end

    local function copy_pure_data(value, active)
        if type(value) ~= "table" then return value end
        active = active or {}
        if active[value] then return nil end
        active[value] = true
        local result = {}
        for key, child in pairs(value) do
            result[copy_pure_data(key, active)] = copy_pure_data(child, active)
        end
        active[value] = nil
        return result
    end

    local function belongs_to_current_world(value)
        value = unwrap(value)
        local world = unwrap(UEHelpers.GetWorld())
        if not is_valid_object(value) or not is_valid_object(world) then
            return false
        end
        local value_world = nil
        pcall(function() value_world = unwrap(value:GetWorld()) end)
        return is_valid_object(value_world)
            and safe_object_address(value_world)
                == safe_object_address(world)
    end

    local function find_current_session()
        local direct = unwrap(controller.active_session)
        if matches_active_session(direct) then
            return direct
        end
        for _, candidate_value in ipairs(
            FindAllOf(SESSION_CLASS_NAME) or {}
        ) do
            local candidate = unwrap(candidate_value)
            if is_valid_object(candidate)
                and get_class_full_name(candidate)
                    == "BlueprintGeneratedClass " .. SESSION_CLASS_PATH
                and belongs_to_current_world(candidate) then
                return candidate
            end
        end
        return nil
    end

    local function load_session_class()
        for _, candidate_value in ipairs(
            FindAllOf(MOD_ACTOR_CLASS_NAME) or {}
        ) do
            local candidate = unwrap(candidate_value)
            if is_valid_object(candidate)
                and get_class_full_name(candidate)
                    == MOD_ACTOR_CLASS_FULL_NAME
                and belongs_to_current_world(candidate) then
                local referenced_class = unwrap(safe_property(
                    candidate, SESSION_CLASS_REFERENCE_PROPERTY
                ))
                if is_usable_class_object(referenced_class) then
                    return referenced_class
                end
            end
        end

        local actor_class = unwrap(StaticFindObject(SESSION_CLASS_PATH))
        if is_usable_class_object(actor_class) then return actor_class end

        local diagnostics = {}
        for _, load_path in ipairs({
            SESSION_CLASS_PATH,
            SESSION_ASSET_PATH,
            SESSION_PACKAGE,
        }) do
            local loaded = nil
            local load_ok, load_error = pcall(function()
                loaded = unwrap(LoadAsset(load_path))
            end)
            actor_class = unwrap(StaticFindObject(SESSION_CLASS_PATH))
            if is_usable_class_object(actor_class) then
                return actor_class
            end
            if is_usable_class_object(loaded) then
                return loaded
            end
            actor_class = unwrap(safe_property(loaded, "GeneratedClass"))
            if is_usable_class_object(actor_class) then
                return actor_class
            end
            diagnostics[#diagnostics + 1] =
                tostring(load_path) .. "="
                    .. (load_ok
                        and object_name(loaded)
                        or tostring(load_error))
        end
        log("selection session class load failed attempts="
            .. table.concat(diagnostics, " | "))
        return nil
    end

    local function find_surface_materials()
        local materials = {}
        for _, manager_value in ipairs(
            FindAllOf("PalMapObjectManager") or {}
        ) do
            local manager = unwrap(manager_value)
            if is_valid_object(manager)
                and belongs_to_current_world(manager) then
                local material_set = unwrap(safe_property(
                    manager, "BuildingSurfaceMaterialSet"
                ))
                materials.highlight = unwrap(safe_property(
                    material_set, "Highlight"
                ))
                materials.highlight_two_sided = unwrap(safe_property(
                    material_set, "HighlightTwoSided"
                ))
                materials.highlight_work_position = unwrap(safe_property(
                    material_set, "HighlightWorkPositionVisualizer"
                ))
                materials.dismantle = unwrap(safe_property(
                    material_set, "Dismantle"
                ))
                materials.dismantle_two_sided = unwrap(safe_property(
                    material_set, "DismantleTwoSided"
                ))
                materials.error = unwrap(safe_property(
                    material_set, "Error"
                ))
                materials.error_two_sided = unwrap(safe_property(
                    material_set, "ErrorTwoSided"
                ))
                materials.error_work_position = unwrap(safe_property(
                    material_set, "ErrorWorkPositionVisualizer"
                ))
                break
            end
        end
        for _, key in ipairs({ "highlight", "dismantle" }) do
            local path = FALLBACK_MATERIALS[key]
            if not is_valid_object(materials[key]) then
                materials[key] = unwrap(StaticFindObject(path))
            end
        end
        return materials
    end

    local function create_mid(
        material_library, session, parent, name
    )
        if not is_valid_object(material_library)
            or not is_valid_object(session)
            or not is_valid_object(parent) then
            return nil
        end
        local result = nil
        local ok = pcall(function()
            result = unwrap(
                material_library:CreateDynamicMaterialInstance(
                    session, parent, FName(name), 0
                )
            )
        end)
        return ok and is_valid_object(result) and result or nil
    end

    local function configure_shared_materials(session)
        local materials = find_surface_materials()
        local material_library = unwrap(StaticFindObject(
            MATERIAL_LIBRARY_PATH
        ))
        if not is_valid_object(materials.highlight) then
            return false, "selection material is unavailable: highlight"
        end
        if not is_valid_object(materials.dismantle) then
            return false, "selection material is unavailable: dismantle"
        end
        if not is_valid_object(material_library) then
            return false, "selection material dependencies are unavailable"
        end

        local mids = {
            hover = create_mid(
                material_library, session, materials.highlight,
                "SBB_SelectionHover"
            ),
            selected = create_mid(
                material_library, session, materials.dismantle,
                "SBB_SelectionSelected"
            ),
            anchor = create_mid(
                material_library, session, materials.highlight,
                "SBB_SelectionAnchor"
            ),
            error = create_mid(
                material_library, session, materials.highlight,
                "SBB_SelectionError"
            ),
        }
        for key, mid in pairs(mids) do
            if not is_valid_object(mid) then
                return false, "shared selection MID creation failed: "
                    .. tostring(key)
            end
        end

        local style_ok, style_error = pcall(function()
            local orange = { R = 1.0, G = 0.3, B = 0.0, A = 1.0 }
            local red = { R = 1.0, G = 0.02, B = 0.0, A = 1.0 }
            mids.hover:SetScalarParameterValue(FName("Progress"), 0.0)
            mids.hover:SetVectorParameterValue(
                FName("RimInitialColor"), orange
            )
            mids.hover:SetVectorParameterValue(
                FName("RimCompleteColor"), orange
            )
            mids.hover:SetVectorParameterValue(
                FName("RimBorderColor"), orange
            )
            mids.selected:SetScalarParameterValue(
                FName("Progress"), 1.0
            )
            mids.selected:SetScalarParameterValue(
                FName("Opacity"), 0.55
            )
            mids.anchor:SetScalarParameterValue(FName("Progress"), 0.0)
            mids.error:SetScalarParameterValue(FName("Progress"), 0.0)
            mids.error:SetVectorParameterValue(
                FName("RimInitialColor"), red
            )
            mids.error:SetVectorParameterValue(
                FName("RimCompleteColor"), red
            )
            mids.error:SetVectorParameterValue(
                FName("RimBorderColor"), red
            )
        end)
        if not style_ok then
            return false, "shared selection MID styling failed: "
                .. tostring(style_error)
        end

        local assign_ok, assign_error = pcall(function()
            session.SBB_SelectionHighlightBase = materials.highlight
            session.SBB_SelectionDismantleBase = materials.dismantle
            session.SBB_SelectionHoverMID = mids.hover
            session.SBB_SelectionSelectedMID = mids.selected
            session.SBB_SelectionAnchorMID = mids.anchor
            session.SBB_SelectionErrorMID = mids.error
        end)
        if not assign_ok then
            return false, "shared selection MID assignment failed: "
                .. tostring(assign_error)
        end
        -- No MID, material, manager, or library reference escapes this call.
        return true
    end

    local function configure_terrain_marker(session)
        local marker = unwrap(safe_property(
            session, "SBB_SelectionTerrainMarker"
        ))
        local highlight_material = unwrap(safe_property(
            session, "SBB_SelectionHighlightBase"
        ))
        if not is_valid_object(marker)
            or not is_valid_object(highlight_material) then
            return false, "terrain anchor marker dependencies unavailable"
        end
        local marker_material = nil
        local ok, error_value = pcall(function()
            marker_material = unwrap(
                marker:CreateAndSetMaterialInstanceDynamicFromMaterial(
                    0, highlight_material
                )
            )
            if not is_valid_object(marker_material) then
                error("terrain anchor marker MID creation failed")
            end
            local initial_blue = {
                R = 0.10, G = 12.0, B = 96.0, A = 1.0,
            }
            local complete_blue = {
                R = 0.40, G = 36.0, B = 216.0, A = 1.0,
            }
            local border_blue = {
                R = 1.25, G = 60.0, B = 288.0, A = 1.0,
            }
            marker_material:SetScalarParameterValue(
                FName("Progress"), 0.0
            )
            marker_material:SetScalarParameterValue(
                FName("Opacity"), 1.0
            )
            marker_material:SetVectorParameterValue(
                FName("RimInitialColor"), initial_blue
            )
            marker_material:SetVectorParameterValue(
                FName("RimCompleteColor"), complete_blue
            )
            marker_material:SetVectorParameterValue(
                FName("RimBorderColor"), border_blue
            )
            marker:SetCollisionEnabled(0)
            marker:SetGenerateOverlapEvents(false)
            marker:SetWorldScale3D({
                X = TERRAIN_MARKER_SCALE,
                Y = TERRAIN_MARKER_SCALE,
                Z = TERRAIN_MARKER_SCALE,
            })
            marker:SetHiddenInGame(true, true)
            marker:SetVisibility(false, true)
        end)
        if not ok then return false, tostring(error_value) end

        controller.terrain_effect_ready = false
        local effect = unwrap(safe_property(
            session, "SBB_SelectionTerrainEffect"
        ))
        stop_terrain_effect(effect)
        return true, nil
    end

    local function show_terrain_marker(session, record)
        local marker = unwrap(safe_property(
            session, "SBB_SelectionTerrainMarker"
        ))
        local point = type(record) == "table"
            and record.impact_point or nil
        if not is_valid_object(marker) or type(point) ~= "table" then
            return false, "terrain anchor marker or impact point unavailable"
        end
        local x = tonumber(point.x)
        local y = tonumber(point.y)
        local z = tonumber(point.z)
        local normal = record.impact_normal
        local nx = type(normal) == "table" and tonumber(normal.x) or 0.0
        local ny = type(normal) == "table" and tonumber(normal.y) or 0.0
        local nz = type(normal) == "table" and tonumber(normal.z) or 0.0
        if x == nil or y == nil or z == nil then
            return false, "terrain anchor marker impact point is invalid"
        end
        local world_location = {
            X = x + nx * 15.0,
            Y = y + ny * 15.0,
            Z = z + nz * 15.0,
        }
        local ok, error_value = pcall(function()
            marker:SetAbsolute(true, true, true)
            marker:K2_SetWorldLocation(
                world_location,
                false, {}, true
            )
            marker:SetHiddenInGame(false, true)
            marker:SetVisibility(true, true)
        end)
        return ok, ok and nil or tostring(error_value)
    end

    local function ensure_target_hook()
        if not controller.target_hook_ready then
            local callback = function(context)
                if not controller.active then return end
                local session = unwrap(context)
                if not matches_active_session(session) then
                    return
                end
            local target = unwrap(safe_property(
                session, "SBB_SelectionCurrentTarget"
            ))
            local ok, error_value = pcall(
                on_target_changed, session, target
            )
            if not ok then
                log("selection session target transition isolated error="
                    .. tostring(error_value))
            end
            end
            local ok, pre_id, post_id = pcall(
                RegisterHook, TARGET_CHANGED_FUNCTION_PATH, callback
            )
            if not ok then return false, tostring(pre_id) end
            controller.target_hook_callback = callback
            controller.target_hook_ready = true
            log("selection session target hook registered pre="
                .. tostring(pre_id) .. " post=" .. tostring(post_id))
        end
        -- Empty-space RMB is intentionally left to the authored anchor action.
        -- Original-position snapping uses the selected building anchor's saved
        -- world transform, so creation mode no longer samples terrain or owns a
        -- separate terrain marker.
        if not controller.camera_exit_hook_ready
            and type(on_camera_stock_exit) == "function" then
            local callback = function(context)
                if not controller.active then return end
                local ok, error_value = pcall(
                    on_camera_stock_exit, unwrap(context)
                )
                if not ok then
                    log("selection session camera stock exit isolated error="
                        .. tostring(error_value))
                end
            end
            local ok, pre_id, post_id = pcall(
                RegisterHook, CAMERA_STOCK_EXIT_FUNCTION_PATH, callback
            )
            if not ok then return false, tostring(pre_id) end
            controller.camera_exit_hook_callback = callback
            controller.camera_exit_hook_ready = true
            log("selection session camera stock exit hook registered pre="
                .. tostring(pre_id) .. " post=" .. tostring(post_id))
        end
        return true, nil
    end

    function controller.with_session(callback, session_hint)
        if type(callback) ~= "function" then
            return false, "selection session callback is required"
        end
        if not controller.active then
            return false, "selection session is inactive"
        end
        local session = unwrap(session_hint)
        if not matches_active_session(session) then
            session = find_current_session()
        end
        if not is_valid_object(session) then
            return false, "current selection session is unavailable"
        end
        return true, callback(session)
    end

    function controller.is_current_session(session)
        return matches_active_session(session)
    end

    function controller.begin(context)
        context = type(context) == "table" and context or {}
        local world = unwrap(UEHelpers.GetWorld())
        if not is_valid_object(world) then
            return false, "selection World is unavailable"
        end

        for _, existing_value in ipairs(
            FindAllOf(SESSION_CLASS_NAME) or {}
        ) do
            local existing = unwrap(existing_value)
            if is_valid_object(existing)
                and get_class_full_name(existing)
                    == "BlueprintGeneratedClass " .. SESSION_CLASS_PATH
                and belongs_to_current_world(existing) then
                pcall(function() existing:SBB_SelectionEnd() end)
                pcall(function() existing:K2_DestroyActor() end)
            end
        end

        local session_class = load_session_class()
        if not is_usable_class_object(session_class) then
            return false, "selection session class is unavailable"
        end
        local hook_ok, hook_error = ensure_target_hook()
        if not hook_ok then
            return false, "selection target hook failed: "
                .. tostring(hook_error)
        end

        local session = nil
        local spawn_ok, spawn_error = pcall(function()
            session = unwrap(world:SpawnActor(session_class, {}, {}))
        end)
        if not spawn_ok or not is_valid_object(session) then
            return false, "selection session spawn failed: "
                .. tostring(spawn_error)
        end

        local configure_ok, configure_error = pcall(function()
            session.SBB_SelectionInputActor = unwrap(context.input_actor)
            session.SBB_SelectionPawn = unwrap(context.pawn)
            session.SBB_SelectionBuilder = unwrap(context.builder)
            session.SBB_SelectionController = unwrap(context.controller)
            session.SBB_SelectionCameraManager =
                unwrap(context.camera_manager)
            session.SBB_SelectionHUD = unwrap(context.hud)
            session.SBB_SelectionTraceRange =
                tonumber(context.trace_range) or 1000.0
            session.SBB_SelectionCameraActive = false
        end)
        if not configure_ok then
            pcall(function() session:K2_DestroyActor() end)
            return false, "selection session configuration failed: "
                .. tostring(configure_error)
        end

        local materials_ok, materials_error =
            configure_shared_materials(session)
        if not materials_ok then
            pcall(function() session:K2_DestroyActor() end)
            return false, "selection session material setup failed: "
                .. tostring(materials_error)
        end
        local marker_ok, marker_error = configure_terrain_marker(session)
        if not marker_ok then
            log("selection terrain anchor marker setup failed error="
                .. tostring(marker_error))
        end

        local input_actor = unwrap(context.input_actor)
        local bind_ok, bind_error = pcall(function()
            input_actor[SESSION_INSTANCE_PROPERTY] = session
        end)
        if not bind_ok then
            pcall(function() session:K2_DestroyActor() end)
            return false, "selection session direct-index bind failed: "
                .. tostring(bind_error)
        end

        local begin_ok, begin_error = pcall(function()
            session:SBB_SelectionBegin()
        end)
        if not begin_ok then
            pcall(function()
                input_actor[SESSION_INSTANCE_PROPERTY] = nil
            end)
            pcall(function() session:K2_DestroyActor() end)
            return false, "selection session begin failed: "
                .. tostring(begin_error)
        end
        controller.active_session_address = safe_object_address(session)
        controller.active_session = session
        controller.active_world_generation =
            BlueprintCallbackScheduler.get_world_generation()
        controller.active = true
        controller.last_surface_probe = nil
        log("selection session entered backend=ue-selection-session "
            .. "lookup=modactor-direct-index")
        return true, nil, session
    end

    function controller.finish(reason, session_hint)
        controller.flash_generation = controller.flash_generation + 1
        local finished = true
        local active, result = controller.with_session(
            function(session)
                local input_actor = unwrap(safe_property(
                    session, SESSION_INPUT_ACTOR_PROPERTY
                ))
                local terrain_effect = unwrap(safe_property(
                    session, "SBB_SelectionTerrainEffect"
                ))
                local effect_ok, effect_error =
                    stop_terrain_effect(terrain_effect)
                if not effect_ok then
                    log("selection terrain effect shutdown failed reason="
                        .. tostring(reason) .. " error="
                        .. tostring(effect_error))
                end
                if is_valid_object(input_actor) then
                    pcall(function()
                        input_actor[SESSION_INSTANCE_PROPERTY] = nil
                    end)
                end
                pcall(function()
                    session[SESSION_INPUT_ACTOR_PROPERTY] = nil
                end)
                local end_ok, end_error = pcall(function()
                    session:SBB_SelectionEnd()
                end)
                local destroy_ok, destroy_error = pcall(function()
                    session:K2_DestroyActor()
                end)
                if not end_ok or not destroy_ok then
                    log("selection session finish error reason="
                        .. tostring(reason) .. " end=" .. tostring(end_error)
                        .. " destroy=" .. tostring(destroy_error))
                    return false
                end
                return true
            end,
            session_hint
        )
        if active then finished = result == true end
        controller.active = false
        controller.active_session = nil
        controller.active_session_address = nil
        controller.active_world_generation = nil
        controller.last_surface_probe = nil
        controller.terrain_effect_ready = false
        log("selection session exited reason=" .. tostring(reason)
            .. " ok=" .. tostring(finished))
        return finished
    end

    function controller.abandon_world()
        -- The independent Selection Session, camera, HUD, and selected Actor
        -- references all belong to the departing World. Never dereference
        -- them from teardown or the next World.
        controller.flash_generation = controller.flash_generation + 1
        controller.active = false
        controller.active_session = nil
        controller.active_session_address = nil
        controller.active_world_generation = nil
        controller.last_surface_probe = nil
        controller.terrain_effect_ready = false
        return true
    end

    function controller.get_bound_session(input_actor)
        input_actor = unwrap(input_actor)
        if not is_valid_object(input_actor) then return nil end
        local session = unwrap(safe_property(
            input_actor, SESSION_INSTANCE_PROPERTY
        ))
        return matches_active_session(session) and session or nil
    end

    function controller.capture_action_context(input_actor)
        local session = controller.get_bound_session(input_actor)
        if not is_valid_object(session) then
            return nil, "selection session direct index is unavailable"
        end
        local target = unwrap(safe_property(
            session, "SBB_SelectionCurrentTarget"
        ))
        return {
            session = make_direct_handle(session),
            target = make_direct_handle(target),
            target_instance_id =
                get_build_object_instance_id(target),
        }, nil
    end

    function controller.resolve_action_context(action_context)
        if type(action_context) ~= "table" then
            return nil, nil, "selection action context is unavailable"
        end
        local session = resolve_direct_handle(action_context.session)
        if not matches_active_session(session) then
            return nil, nil, "selection action Session expired"
        end
        local target = resolve_direct_handle(action_context.target)
        return session, target, nil
    end

    function controller.get_current_target(session_hint)
        local result = nil
        controller.with_session(function(session)
            result = unwrap(safe_property(
                session, "SBB_SelectionCurrentTarget"
            ))
        end, session_hint)
        return is_valid_object(result) and result or nil
    end

    function controller.get_selection_snapshot(session_hint)
        local selected = {}
        local anchor = nil
        local active, result_or_error = controller.with_session(
            function(session)
                local actors = safe_property(
                    session, "SBB_SelectionSelectedActors"
                )
                local count = 0
                pcall(function() count = #actors end)
                for index = 1, count do
                    local actor = nil
                    pcall(function()
                        actor = unwrap(actors[index])
                    end)
                    if is_valid_object(actor) then
                        selected[#selected + 1] = actor
                    end
                end
                anchor = unwrap(safe_property(
                    session, "SBB_SelectionAnchor"
                ))
                return true
            end,
            session_hint
        )
        if not active or result_or_error ~= true then
            return nil, nil, tostring(result_or_error)
        end
        if not is_valid_object(anchor) then anchor = nil end
        return selected, anchor, nil
    end

    function controller.get_terrain_anchor_snapshot()
        if not controller.active
            or type(controller.last_surface_probe) ~= "table" then
            return nil
        end
        return copy_pure_data(controller.last_surface_probe)
    end

    function controller.reassert_current_hover(session_hint)
        local reapplied = false
        controller.with_session(function(session)
            local target = unwrap(safe_property(
                session, "SBB_SelectionCurrentTarget"
            ))
            if is_valid_object(target) then
                reapplied = select(1, controller.set_hover_actor(
                    target, true, session
                ))
            end
        end, session_hint)
        return reapplied
    end

    function controller.apply_actor_visual_role(
        target, role, session_hint
    )
        local probe_enabled =
            controller.is_probe_logging_enabled() == true
        local total_started_at = probe_enabled
            and controller.performance_now() or nil
        local metrics = probe_enabled and {
            role = math.floor(tonumber(role) or -1),
            session_resolve_ms = 0.0,
            ue_call_ms = 0.0,
            acknowledgement_ms = 0.0,
            total_ms = 0.0,
        } or nil
        target = unwrap(target)
        if not is_valid_object(target) then
            return false, "selection visual target is unavailable", metrics
        end
        role = math.floor(tonumber(role) or -1)
        if role < 0 or role > 4 then
            return false, "selection visual role is invalid", metrics
        end
        local active, applied, apply_error = controller.with_session(
            function(session)
                if metrics ~= nil then
                    metrics.session_resolve_ms =
                        controller.performance_elapsed_ms(total_started_at)
                end
                local ue_started_at = metrics ~= nil
                    and controller.performance_now() or nil
                local event_ok, event_error = pcall(function()
                    session:SBB_SelectionApplyRoleVisual(
                        target, role
                    )
                end)
                if metrics ~= nil then
                    metrics.ue_call_ms =
                        controller.performance_elapsed_ms(ue_started_at)
                end
                if not event_ok then
                    return false, tostring(event_error)
                end
                local acknowledgement_started_at = metrics ~= nil
                    and controller.performance_now() or nil
                local acknowledgement = tonumber(unwrap(safe_property(
                    session, "SBB_SelectionNativeHoverApplied"
                ))) or 0
                if metrics ~= nil then
                    metrics.acknowledgement_ms =
                        controller.performance_elapsed_ms(
                            acknowledgement_started_at
                        )
                end
                if acknowledgement ~= 1 then
                    return false,
                        "UE selection role visual was not applied"
                end
                return true, nil
            end,
            session_hint
        )
        if metrics ~= nil then
            metrics.total_ms = controller.performance_elapsed_ms(
                total_started_at
            )
            metrics.success = active == true and applied == true
        end
        if not active then
            return false, tostring(applied), metrics
        end
        return applied == true, apply_error, metrics
    end

    function controller.set_hover_actor(target, enabled, session_hint)
        return controller.apply_actor_visual_role(
            target, enabled == true and 1 or 0, session_hint
        )
    end

    function controller.get_hud(session_hint)
        local result = nil
        controller.with_session(function(session)
            result = unwrap(safe_property(
                session, "SBB_SelectionHUD"
            ))
        end, session_hint)
        return is_valid_object(result) and result or nil
    end

    function controller.get_builder(session_hint)
        local result = nil
        controller.with_session(function(session)
            result = unwrap(safe_property(
                session, "SBB_SelectionBuilder"
            ))
        end, session_hint)
        return is_valid_object(result) and result or nil
    end

    function controller.get_player_controller(session_hint)
        local result = nil
        controller.with_session(function(session)
            result = unwrap(safe_property(
                session, "SBB_SelectionController"
            ))
        end, session_hint)
        return is_valid_object(result) and result or nil
    end

    function controller.resolve_actor(instance_id, session_hint)
        if instance_id == nil then return nil end
        local result = nil
        controller.with_session(function(session)
            local actors = safe_property(
                session, "SBB_SelectionTrackedActors"
            )
            local count = 0
            pcall(function() count = #actors end)
            for index = 1, count do
                local actor = nil
                pcall(function() actor = unwrap(actors[index]) end)
                if is_valid_object(actor)
                    and get_build_object_instance_id(actor)
                        == instance_id then
                    result = actor
                    break
                end
            end
        end, session_hint)
        return result
    end

    local function actor_or_resolve(value, session_hint)
        value = unwrap(value)
        if is_valid_object(value) then return value end
        if value ~= nil then
            return controller.resolve_actor(value, session_hint)
        end
        return nil
    end

    function controller.set_persistent_role(value, role, session_hint)
        local actor = actor_or_resolve(value, session_hint)
        if not is_valid_object(actor) then return false end
        local applied = false
        controller.with_session(function(session)
            applied = pcall(function()
                session:SBB_SelectionSetPersistentRole(
                    actor, tonumber(role) or 0
                )
            end)
        end, session_hint)
        return applied
    end

    function controller.add_selected_actor(value, session_hint)
        local actor = actor_or_resolve(value, session_hint)
        if not is_valid_object(actor) then return false end
        local added = false
        controller.with_session(function(session)
            added = pcall(function()
                session:SBB_SelectionAddSelectedActor(actor)
            end)
        end, session_hint)
        return added
    end

    function controller.refresh(value, session_hint)
        local actor = actor_or_resolve(value, session_hint)
        if not is_valid_object(actor) then return false end
        local refreshed = false
        controller.with_session(function(session)
            refreshed = pcall(function()
                session:SBB_SelectionRefreshActor(actor)
            end)
        end, session_hint)
        return refreshed
    end

    function controller.set_anchor(value, session_hint)
        local actor = actor_or_resolve(value, session_hint)
        local written = false
        controller.with_session(function(session)
            written = pcall(function()
                session.SBB_SelectionAnchor = actor
            end)
        end, session_hint)
        return written
    end

    function controller.set_region_endpoint(which, value, session_hint)
        local property_name = which == "end"
            and "SBB_SelectionRegionEnd"
            or "SBB_SelectionRegionStart"
        local actor = actor_or_resolve(value, session_hint)
        local written = false
        controller.with_session(function(session)
            written = pcall(function()
                session[property_name] = actor
            end)
        end, session_hint)
        return written
    end

    function controller.get_region_endpoint(which, session_hint)
        local property_name = which == "end"
            and "SBB_SelectionRegionEnd"
            or "SBB_SelectionRegionStart"
        local actor = nil
        controller.with_session(function(session)
            actor = unwrap(safe_property(session, property_name))
        end, session_hint)
        return is_valid_object(actor) and actor or nil
    end

    function controller.begin_region_candidates(actors, session_hint)
        if type(actors) ~= "table" then
            return false, "region candidate array is unavailable"
        end
        local accepted = 0
        local started, start_error = controller.with_session(
            function(session)
                session:SBB_SelectionClearRegionCandidates()
                for _, actor_value in ipairs(actors) do
                    local actor = unwrap(actor_value)
                    if is_valid_object(actor) then
                        session:SBB_SelectionAddRegionCandidate(actor)
                        accepted = accepted + 1
                    end
                end
                session:SBB_SelectionStartRegionJob()
                return true
            end
        , session_hint)
        if not started or start_error ~= true then
            return false, start_error
                or "selection session region setup failed"
        end
        return true, nil, accepted
    end

    function controller.end_region_candidates()
        local ended = false
        controller.with_session(function(session)
            ended = pcall(function()
                session:SBB_SelectionClearRegionCandidates()
            end)
        end)
        return ended
    end

    function controller.get_region_candidate(index, session_hint)
        local result = nil
        controller.with_session(function(session)
            local actors = safe_property(
                session, "SBB_SelectionRegionCandidates"
            )
            pcall(function()
                result = unwrap(actors[tonumber(index) or 0])
            end)
        end, session_hint)
        return is_valid_object(result) and result or nil
    end

    function controller.set_tick_paused(paused, session_hint)
        local updated = false
        controller.with_session(function(session)
            updated = pcall(function()
                session.SBB_SelectionTickPaused = paused == true
            end)
        end, session_hint)
        return updated, updated and nil
            or "selection session is unavailable"
    end

    function controller.is_camera_active()
        local active = false
        controller.with_session(function(session)
            active = safe_property(
                session, "SBB_SelectionCameraActive"
            ) == true
        end)
        return active
    end

    function controller.flash_serialization_errors(instance_ids)
        if type(instance_ids) ~= "table" or #instance_ids == 0 then
            return false
        end
        controller.flash_generation = controller.flash_generation + 1
        local generation = controller.flash_generation
        local scalar_ids = {}
        for index, instance_id in ipairs(instance_ids) do
            scalar_ids[index] = tostring(instance_id)
        end
        local function apply_error(enabled)
            if generation ~= controller.flash_generation then return end
            for _, instance_id in ipairs(scalar_ids) do
                local actor = controller.resolve_actor(instance_id)
                if is_valid_object(actor) then
                    controller.with_session(function(session)
                        pcall(function()
                            if enabled then
                                session:SBB_SelectionSetTransientRole(
                                    actor,
                                    BlueprintSelectionSession
                                        .ROLE_SERIALIZATION_ERROR
                                )
                            else
                                session:SBB_SelectionRefreshActor(actor)
                            end
                        end)
                    end)
                end
            end
        end
        apply_error(true)
        for pulse = 1, 5 do
            BlueprintCallbackScheduler.game_thread(
                pulse * 180,
                "selection-serialization-error-flash:" .. pulse,
                function()
                    apply_error(pulse % 2 == 0)
                end
            )
        end
        BlueprintCallbackScheduler.game_thread(
            1080, "selection-serialization-error-restore", function()
                apply_error(false)
            end
        )
        return true
    end

    controller.class_name = SESSION_CLASS_NAME
    return controller
end

return BlueprintSelectionSession

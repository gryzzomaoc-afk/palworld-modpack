local RuntimeUtils = require("BlueprintRuntimeUtils")
local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local BlueprintLibraryUI = {}

local PANEL_PACKAGE =
    "/Game/Mods/BlueprintResearch/UI/WBP_BlueprintLibraryPanel"
local PANEL_CLASS = PANEL_PACKAGE
    .. ".WBP_BlueprintLibraryPanel_C"
local PANEL_ESCAPE_PRESSED_PATH = PANEL_CLASS .. ":BR_OnEscapePressed"
local PANEL_ESCAPE_RELEASED_PATH = PANEL_CLASS .. ":BR_OnEscapeReleased"
local CARD_PACKAGE =
    "/Game/Mods/BlueprintResearch/UI/WBP_BlueprintLibraryCard"
local CARD_CLASS = CARD_PACKAGE
    .. ".WBP_BlueprintLibraryCard_C"
local ORIGINAL_BUTTON_CLASS =
    "/Game/Pal/Blueprint/UI/System/Style/"
        .. "WBP_PalInvisibleButton.WBP_PalInvisibleButton_C"
local ORIGINAL_COMMON_BUTTON_CLASS =
    "/Game/Pal/Blueprint/UI/UserInterface/Common/"
        .. "WBP_CommonButton.WBP_CommonButton_C"
local ORIGINAL_CLOSE_BUTTON_CLASS =
    "/Game/Pal/Blueprint/UI/UserInterface/MainMenu/"
        .. "WBP_Menu_btn.WBP_Menu_btn_C"
local COMMON_BUTTON_CLICK =
    "/Script/CommonUI.CommonButtonBase:HandleButtonClicked"
local WIDGET_LIBRARY_PATH =
    "/Script/UMG.Default__WidgetBlueprintLibrary"
local RENDERING_LIBRARY_PATH =
    "/Script/Engine.Default__KismetRenderingLibrary"
local PAL_FONT_PACKAGE = "/Game/Pal/Font/Ft_PalDefaultFont"
local PAL_FONT_PATH = PAL_FONT_PACKAGE .. ".Ft_PalDefaultFont"
local WHITE_FONT_PACKAGE =
    "/Game/Pal/Material/UI/Fontcolor/MI_UI_Color_White_01"
local WHITE_FONT_PATH = WHITE_FONT_PACKAGE .. ".MI_UI_Color_White_01"

local PANEL_IMAGE_BINDINGS = {
    {
        widget = "Library_Stock_BaseGray",
        package = "/Game/Pal/Material/UI/Menu/MI_UI_Menu_BGGrd_1",
        path = "/Game/Pal/Material/UI/Menu/"
            .. "MI_UI_Menu_BGGrd_1.MI_UI_Menu_BGGrd_1",
    },
    {
        widget = "Library_Stock_Image",
        package = "/Game/Pal/Material/UI/Ingame/M_UI_BaseGrd",
        path = "/Game/Pal/Material/UI/Ingame/"
            .. "M_UI_BaseGrd.M_UI_BaseGrd",
    },
}

local CARD_IMAGE_BINDINGS = {
    {
        widget = "Card_BaseGradient",
        package = "/Game/Pal/Material/UI/Ingame/MI_UI_BaseGrd_2",
        path = "/Game/Pal/Material/UI/Ingame/"
            .. "MI_UI_BaseGrd_2.MI_UI_BaseGrd_2",
    },
    {
        widget = "Card_Frame",
        package = "/Game/Pal/Texture/UI/IngameMenu/T_prt_frame_1px",
        path = "/Game/Pal/Texture/UI/IngameMenu/"
            .. "T_prt_frame_1px.T_prt_frame_1px",
    },
}

local PANEL_TEXT_WIDGETS = {
    { name = "Library_TitleText", size = 18 },
    { name = "Library_EmptyText", size = 18 },
    { name = "Library_StatusText", size = 13 },
}

local CARD_TEXT_WIDGETS = {
    { name = "Card_NameText", size = 15 },
    { name = "Card_ThumbnailStateText", size = 13 },
}

function BlueprintLibraryUI.install(deps)
    assert(type(deps) == "table",
        "BlueprintLibraryUI dependencies are required")
    local UEHelpers = assert(deps.UEHelpers,
        "BlueprintLibraryUI UEHelpers is required")
    local log = assert(deps.log, "BlueprintLibraryUI log is required")
    local localize = assert(deps.localize,
        "BlueprintLibraryUI localize is required")
    local store = assert(deps.store,
        "BlueprintLibraryUI store is required")
    local find_in_instance = assert(deps.find_in_instance,
        "BlueprintLibraryUI find_in_instance is required")
    local read_clipboard = assert(deps.read_clipboard,
        "BlueprintLibraryUI read_clipboard is required")
    local copy_clipboard = assert(deps.copy_clipboard,
        "BlueprintLibraryUI copy_clipboard is required")
    local decode_blueprint = assert(deps.decode_blueprint,
        "BlueprintLibraryUI decode_blueprint is required")
    local import_blueprint = assert(deps.import_blueprint,
        "BlueprintLibraryUI import_blueprint is required")
    local on_place = assert(deps.on_place,
        "BlueprintLibraryUI on_place is required")
    local request_confirm = assert(deps.request_confirm,
        "BlueprintLibraryUI request_confirm is required")
    local request_name = assert(deps.request_name,
        "BlueprintLibraryUI request_name is required")
    local cancel_name = deps.cancel_name or function() return false end
    local cancel_confirm = deps.cancel_confirm or function() return false end
    local native_ui_stack = deps.native_ui_stack
    local resource_manager = deps.resource_manager
    local send_message = deps.send_message or function() end

    local unwrap = RuntimeUtils.unwrap
    local value_to_string = RuntimeUtils.value_to_string
    local object_name = RuntimeUtils.object_name
    local is_valid_object = RuntimeUtils.is_valid_object
    local is_usable_class_object = RuntimeUtils.is_usable_class_object
    local class_object_name = RuntimeUtils.class_object_name
    local safe_object_address = RuntimeUtils.safe_object_address
    local safe_property = RuntimeUtils.safe_property
    local get_asset_path = RuntimeUtils.get_asset_path

    local ui = {
        generation = 0,
        closing = false,
        click_handlers = {},
        panel_handler_addresses = {},
        panel_button_handles = {},
        card_handler_addresses = {},
        -- Card registries retain only strings, numbers, and route tables.
        -- Live widget wrappers are resolved from the current panel tree for
        -- each mutation so a closed panel or unloaded world cannot leak a
        -- stale UObject into the next UI generation.
        card_handler_addresses_by_entry = {},
        card_handles_by_entry = {},
        rendered_entry_ids = {},
        layout_spacer_address = nil,
        common_button_hook_registered = false,
        common_button_hook_callback = nil,
        escape_hooks_registered = false,
        escape_hook_callbacks = {},
        escape_armed_generation = nil,
        native_entry = nil,
        pending_delete_id = nil,
        pending_name_action = nil,
        name_modal_library_hidden = false,
        placement_request_sequence = 0,
        template_style_prepared = false,
        reuse_eligible = false,
        reuse_snapshot = nil,
    }
    local cards = {}

    local function quiet(callback, fallback)
        local ok, result = pcall(callback)
        if ok then return result end
        return fallback
    end

    local function resolve(path)
        if type(StaticFindObject) ~= "function" then return nil end
        return unwrap(quiet(function() return StaticFindObject(path) end, nil))
    end

    local function make_object_handle(value)
        value = unwrap(value)
        local path = get_asset_path(value)
        local address = safe_object_address(value)
        if type(path) ~= "string" or path == "" or address == nil then
            return nil
        end
        return { path = path, address = tostring(address) }
    end

    local function resolve_object_handle(handle)
        if type(handle) ~= "table" or type(handle.path) ~= "string"
            or handle.address == nil then
            return nil
        end
        local value = resolve(handle.path)
        if not is_valid_object(value)
            or safe_object_address(value) ~= tostring(handle.address) then
            return nil
        end
        return value
    end

    local function load_class(package_path, class_path)
        local class = resolve(class_path)
        if is_usable_class_object(class) then return class end
        local package_ok = false
        local package_result = nil
        if type(LoadAsset) == "function" then
            package_ok, package_result = pcall(LoadAsset, package_path)
        end
        class = resolve(class_path)
        if is_usable_class_object(class) then return class end

        local returned = unwrap(package_result)
        if package_ok and is_usable_class_object(returned) then
            local returned_name = class_object_name(returned)
            if string.find(
                returned_name, "BlueprintGeneratedClass", 1, true
            ) then
                return returned
            end
        end

        local generated_class = nil
        if is_valid_object(returned) then
            generated_class = unwrap(safe_property(
                returned, "GeneratedClass"
            ))
            if is_usable_class_object(generated_class) then
                return generated_class
            end
        end

        local short_name = string.match(class_path, "%.([^%.]+)$")
            or class_path
        local find_ok, find_result = pcall(
            FindObject, "WidgetBlueprintGeneratedClass", short_name
        )
        local found_class = unwrap(find_result)
        if find_ok and is_usable_class_object(found_class) then
            return found_class
        end
        local class_find_ok, class_find_result = pcall(
            FindObject, "Class", short_name
        )
        found_class = unwrap(class_find_result)
        if class_find_ok and is_usable_class_object(found_class) then
            return found_class
        end

        return nil, "packageOk=" .. tostring(package_ok)
            .. " packageResult=" .. tostring(value_to_string(package_result))
            .. " exactClass=" .. tostring(class_object_name(class))
            .. " generatedClass="
            .. tostring(class_object_name(generated_class))
            .. " findOk=" .. tostring(find_ok)
            .. " findResult=" .. tostring(value_to_string(find_result))
            .. " classFindOk=" .. tostring(class_find_ok)
            .. " classFindResult="
            .. tostring(value_to_string(class_find_result))
    end

    local function load_asset(package_path, object_path)
        local asset = resolve(object_path)
        if is_valid_object(asset) then return asset end
        if type(LoadAsset) == "function" then
            quiet(function() LoadAsset(package_path) end, nil)
        end
        asset = resolve(object_path)
        if is_valid_object(asset) then return asset end
        return nil
    end

    local function get_controller()
        return unwrap(quiet(function()
            return UEHelpers.GetPlayerController()
        end, nil))
    end

    local function get_live_widget()
        if ui.native_entry == nil or type(native_ui_stack) ~= "table"
            or type(native_ui_stack.get_widget) ~= "function" then
            return nil
        end
        return unwrap(native_ui_stack.get_widget(ui.native_entry))
    end

    local function get_live_field(name)
        local widget = get_live_widget()
        if not is_valid_object(widget) then return nil end
        return unwrap(find_in_instance(widget, name))
    end

    local function owns_escape_context(context)
        local widget = get_live_widget()
        local context_address = safe_object_address(unwrap(context))
        local widget_address = safe_object_address(widget)
        return context_address ~= nil and widget_address ~= nil
            and tostring(context_address) == tostring(widget_address)
    end

    local function ensure_escape_hooks()
        if ui.escape_hooks_registered then return true, nil end
        if type(RegisterHook) ~= "function" then
            return false, "RegisterHook is unavailable"
        end

        local pressed = function(context)
            if not owns_escape_context(context) or not ui.is_open() then return end
            ui.escape_armed_generation = ui.generation
        end
        local released = function(context)
            if not owns_escape_context(context) then return end
            local generation = ui.escape_armed_generation
            ui.escape_armed_generation = nil
            if generation == nil or generation ~= ui.generation then return end
            BlueprintCallbackScheduler.game_thread(
                1, "blueprint-library-escape:" .. tostring(generation),
                function()
                    if generation ~= ui.generation or not ui.is_open() then
                        return
                    end
                    if ui.pending_name_action ~= nil then
                        cancel_name("library-escape")
                    elseif ui.pending_delete_id ~= nil then
                        cancel_confirm("library-escape")
                    else
                        ui.close("escape")
                    end
                end
            )
        end
        local retained_pressed = function(...)
            local ok, error_value = pcall(pressed, ...)
            if not ok then
                log("blueprint library ESC pressed hook isolated error="
                    .. tostring(error_value))
            end
        end
        local retained_released = function(...)
            local ok, error_value = pcall(released, ...)
            if not ok then
                log("blueprint library ESC released hook isolated error="
                    .. tostring(error_value))
            end
        end
        local press_ok, press_pre, press_post = pcall(
            RegisterHook, PANEL_ESCAPE_PRESSED_PATH, retained_pressed
        )
        if not press_ok then
            return false, "library ESC pressed hook unavailable: "
                .. tostring(press_pre)
        end
        local release_ok, release_pre, release_post = pcall(
            RegisterHook, PANEL_ESCAPE_RELEASED_PATH, retained_released
        )
        if not release_ok then
            return false, "library ESC released hook unavailable: "
                .. tostring(release_pre)
        end
        ui.escape_hook_callbacks.pressed = retained_pressed
        ui.escape_hook_callbacks.released = retained_released
        ui.escape_hooks_registered = true
        log("blueprint library CommonUI ESC hooks registered pressedPre="
            .. tostring(press_pre) .. " pressedPost=" .. tostring(press_post)
            .. " releasedPre=" .. tostring(release_pre)
            .. " releasedPost=" .. tostring(release_post))
        return true, nil
    end

    local function clear_handler_addresses(addresses)
        for _, address in ipairs(addresses) do
            ui.click_handlers[address] = nil
        end
        for index = #addresses, 1, -1 do
            addresses[index] = nil
        end
    end

    local function set_text(widget, text)
        widget = unwrap(widget)
        if not is_valid_object(widget) then return false end
        return quiet(function()
            widget:SetText(FText(tostring(text or "")))
            return true
        end, false)
    end

    local function set_hint(widget, text)
        widget = unwrap(widget)
        if not is_valid_object(widget) then return false end
        return quiet(function()
            widget:SetHintText(FText(tostring(text or "")))
            return true
        end, false)
    end

    local function read_text(widget)
        widget = unwrap(widget)
        if not is_valid_object(widget) then return "" end
        local value = quiet(function() return widget:GetText() end, nil)
        local text = value_to_string(value)
        if text == "<nil>" then return "" end
        return tostring(text or "")
    end

    local function restore_image_bindings(instance, bindings)
        for _, binding in ipairs(bindings) do
            local image = unwrap(find_in_instance(
                instance, binding.widget
            ))
            local asset = load_asset(binding.package, binding.path)
            if is_valid_object(image) and is_valid_object(asset) then
                local applied = quiet(function()
                    image:SetBrushResourceObject(asset)
                    return true
                end, false)
                if not applied then
                    log("blueprint library image bind failed widget="
                        .. tostring(binding.widget))
                end
            else
                log("blueprint library image asset unavailable widget="
                    .. tostring(binding.widget) .. " path="
                    .. tostring(binding.path))
            end
        end
    end

    local function restore_text_fonts(instance, specifications)
        local font_asset = load_asset(PAL_FONT_PACKAGE, PAL_FONT_PATH)
        local font_material = load_asset(
            WHITE_FONT_PACKAGE, WHITE_FONT_PATH
        )
        if not is_valid_object(font_asset) then
            log("blueprint library Pal font unavailable")
            return
        end
        for _, specification in ipairs(specifications) do
            local text_widget = unwrap(find_in_instance(
                instance, specification.name
            ))
            if is_valid_object(text_widget) then
                local applied = quiet(function()
                    text_widget:SetFont({
                        FontObject = font_asset,
                        FontMaterial = is_valid_object(font_material)
                            and font_material or nil,
                        TypefaceFontName = FName("Medium"),
                        Size = specification.size,
                        LetterSpacing = 0,
                        SkewAmount = 0.0,
                    })
                    return true
                end, false)
                if not applied then
                    log("blueprint library font bind failed widget="
                        .. tostring(specification.name))
                end
            end
        end
    end

    local function prepare_code_input_template(panel_class)
        local font_asset = load_asset(PAL_FONT_PACKAGE, PAL_FONT_PATH)
        local font_material = load_asset(
            WHITE_FONT_PACKAGE, WHITE_FONT_PATH
        )
        if not is_valid_object(font_asset) then
            return false, "Pal font unavailable"
        end

        local template = resolve(PANEL_CLASS .. ":WidgetTree.Library_CodeInput")
        if not is_valid_object(template) then
            local class_default = unwrap(quiet(function()
                return panel_class:GetDefaultObject()
            end, nil))
            template = unwrap(find_in_instance(
                class_default, "Library_CodeInput"
            ))
        end
        if not is_valid_object(template) then
            return false, "input template unavailable"
        end

        local applied = quiet(function()
            local style = template.WidgetStyle
            local text_style = style.TextStyle
            local input_font = text_style.Font
            input_font.FontObject = font_asset
            input_font.FontMaterial = is_valid_object(font_material)
                and font_material or nil
            input_font.TypefaceFontName = FName("Medium")
            input_font.Size = 18
            input_font.LetterSpacing = 0
            input_font.SkewAmount = 0.0
            text_style.Font = input_font
            style.TextStyle = text_style
            template.WidgetStyle = style
            template:SetForegroundColor({
                R = 0.94, G = 0.97, B = 1.0, A = 1.0,
            })
            return true
        end, false)
        return applied, applied and nil or "input template style assignment failed"
    end

    local function hide_library_for_native_name_dialog()
        if ui.name_modal_library_hidden then return true end
        local widget = get_live_widget()
        if not is_valid_object(widget) then return false end
        local hidden = quiet(function()
            -- Hidden retains the live widget tree and card instances while
            -- removing this independent viewport root from paint and hit-test.
            -- The stock CommonUI Modal container can then remain the real
            -- owner of the name editor and preserve its input lifecycle.
            widget:SetVisibility(2)
            return true
        end, false)
        if hidden then ui.name_modal_library_hidden = true end
        return hidden
    end

    local function restore_library_after_name_dialog()
        ui.pending_name_action = nil
        if not ui.is_open() then return end
        local widget = get_live_widget()
        local code_input = get_live_field("Library_CodeInput")
        quiet(function() widget:SetVisibility(0) end, nil)
        ui.name_modal_library_hidden = false
        if type(native_ui_stack) == "table" then
            native_ui_stack.focus(ui.native_entry, code_input)
        end
    end

    local function clear_references()
        ui.native_entry = nil
        ui.pending_delete_id = nil
        ui.pending_name_action = nil
        ui.name_modal_library_hidden = false
        ui.escape_armed_generation = nil
        ui.closing = false
        ui.panel_button_handles = {}
        ui.card_handler_addresses_by_entry = {}
        ui.card_handles_by_entry = {}
        ui.rendered_entry_ids = {}
        ui.layout_spacer_address = nil
        ui.reuse_eligible = false
    end

    local finalize_close

    function ui.is_open()
        if ui.closing then return false end
        local lifecycle_alive = ui.native_entry ~= nil
            and type(native_ui_stack) == "table"
            and type(native_ui_stack.is_alive) == "function"
            and native_ui_stack.is_alive(ui.native_entry)
        if lifecycle_alive then return true end

        local had_stale_state = ui.native_entry ~= nil
        if had_stale_state and finalize_close ~= nil then
            if ui.native_entry ~= nil and type(native_ui_stack) == "table"
                and type(native_ui_stack.abandon) == "function" then
                native_ui_stack.abandon(
                    ui.native_entry, "stale-library-lifecycle"
                )
            end
            finalize_close("stale-library-lifecycle")
        end
        return false
    end

    finalize_close = function(reason)
        ui.closing = true
        if string.find(tostring(reason), "stale", 1, true)
            or string.find(tostring(reason), "invalid-widget", 1, true) then
            ui.reuse_snapshot = nil
        end
        if ui.pending_name_action ~= nil then
            cancel_name("library-close:" .. tostring(reason))
        end
        if ui.pending_delete_id ~= nil then
            cancel_confirm("library-close:" .. tostring(reason))
        end
        clear_handler_addresses(ui.card_handler_addresses)
        clear_handler_addresses(ui.panel_handler_addresses)
        ui.generation = ui.generation + 1
        clear_references()
        log("blueprint library panel closed reason=" .. tostring(reason))
        return true
    end

    local function on_native_closed(reason)
        local generation = ui.generation
        ui.closing = true
        BlueprintCallbackScheduler.game_thread_now(
            "blueprint-library-native-close:" .. tostring(generation),
            function()
                if generation ~= ui.generation then return end
                finalize_close(reason)
            end
        )
    end

    function ui.close(reason)
        if ui.closing then return false end
        if not is_valid_object(get_live_widget()) then
            ui.reuse_snapshot = nil
            if ui.native_entry ~= nil and type(native_ui_stack) == "table" then
                native_ui_stack.abandon(ui.native_entry, reason)
            end
            return finalize_close("invalid-widget:" .. tostring(reason))
        end

        if ui.reuse_eligible
            and type(cards.capture_reuse_snapshot) == "function" then
            local captured, capture_error = cards.capture_reuse_snapshot()
            if not captured then
                ui.reuse_snapshot = nil
                log("blueprint library reuse snapshot unavailable error="
                    .. tostring(capture_error))
            end
        end
        ui.closing = true
        if ui.native_entry ~= nil
            and type(native_ui_stack) == "table" then
            local closed, close_error = native_ui_stack.close(
                ui.native_entry, reason
            )
            if not closed then
                log("blueprint library native close fallback reason="
                    .. tostring(reason) .. " error=" .. tostring(close_error))
            end
            return true
        end
        return finalize_close(reason)
    end

    local function create_original_input_button(
        owner, placeholder, route, presentation, widget_library, controller,
        address_list
    )
        presentation = type(presentation) == "table" and presentation or {}
        owner = unwrap(owner)
        placeholder = unwrap(placeholder)
        if not is_valid_object(owner) or not is_valid_object(placeholder) then
            return nil, "input owner or placeholder is unavailable"
        end
        local parent = unwrap(quiet(function()
            return placeholder:GetParent()
        end, nil))
        local presentation_kind = tostring(presentation.kind or "invisible")
        local presentation_class_path = ORIGINAL_BUTTON_CLASS
        if presentation_kind == "common" then
            presentation_class_path = ORIGINAL_COMMON_BUTTON_CLASS
        elseif presentation_kind == "close" then
            presentation_class_path = ORIGINAL_CLOSE_BUTTON_CLASS
        end
        local button_class, button_class_error = load_class(
            presentation_class_path:gsub("%.[^%.]+_C$", ""),
            presentation_class_path
        )
        if not is_valid_object(parent)
            or not is_usable_class_object(button_class)
            or not is_valid_object(widget_library)
            or not is_valid_object(controller) then
            return nil, "stock invisible button dependencies are unavailable class="
                .. tostring(button_class_error)
        end

        local presentation_widget = unwrap(quiet(function()
            return widget_library:Create(
                controller, button_class, controller
            )
        end, nil))
        if not is_valid_object(presentation_widget) then
            return nil, "stock button could not be created kind="
                .. presentation_kind
        end

        local input_button = presentation_widget
        if presentation_kind ~= "invisible" then
            input_button = unwrap(find_in_instance(
                presentation_widget, "WBP_PalInvisibleButton"
            ))
            if not is_valid_object(input_button) then
                quiet(function() presentation_widget:RemoveFromParent() end, nil)
                return nil, "stock button input layer is unavailable kind="
                    .. presentation_kind
            end
        end

        local configured = quiet(function()
            local placeholder_slot = unwrap(safe_property(placeholder, "Slot"))
            local layout = placeholder_slot:GetLayout()
            local z_order = tonumber(placeholder_slot:GetZOrder()) or 0
            local input_slot = parent:AddChildToCanvas(presentation_widget)
            input_slot:SetLayout(layout)
            input_slot:SetZOrder(z_order + 20)
            placeholder:SetVisibility(3)
            if presentation_kind == "common" then
                presentation_widget:Setup(false)
                presentation_widget:SetText(FText(tostring(
                    presentation.label or ""
                )))
            end
            input_button:SetIsInteractionEnabled(true)
            input_button:SetIsFocusable(false)
            presentation_widget:SetVisibility(0)
            return true
        end, false)
        if not configured then
            quiet(function() presentation_widget:RemoveFromParent() end, nil)
            return nil, "stock button setup failed kind=" .. presentation_kind
        end

        local address = safe_object_address(input_button)
        if type(route) ~= "table" or address == nil
            or type(address_list) ~= "table" then
            quiet(function() presentation_widget:RemoveFromParent() end, nil)
            return nil, "stock button input layer route is unavailable"
        end
        address = tostring(address)
        route.generation = ui.generation
        ui.click_handlers[address] = route
        table.insert(address_list, address)
        if address_list == ui.panel_handler_addresses then
            local input_handle = make_object_handle(input_button)
            local presentation_handle = make_object_handle(
                presentation_widget
            )
            if input_handle == nil or presentation_handle == nil then
                ui.click_handlers[address] = nil
                table.remove(address_list, #address_list)
                quiet(function() presentation_widget:RemoveFromParent() end, nil)
                return nil, "stock panel button reuse handle is unavailable"
            end
            ui.panel_button_handles[address] = {
                input = input_handle,
                presentation = presentation_handle,
            }
        end
        return presentation_widget, nil
    end

    local function configure_thumbnail(card, entry, controller)
        local image = unwrap(find_in_instance(card, "Card_Thumbnail"))
        local state_text = unwrap(find_in_instance(
            card, "Card_ThumbnailStateText"
        ))
        if not is_valid_object(image) then return end

        local thumbnail_loaded = false
        if entry.thumbnail_state == "ready" then
            local resource = resource_manager ~= nil
                and resource_manager.get_thumbnail(entry.id) or nil
            if not is_valid_object(resource) then
                local path = store.get_thumbnail_path(entry.id)
                local rendering_library = resolve(RENDERING_LIBRARY_PATH)
                if type(path) == "string"
                    and is_valid_object(rendering_library)
                    and is_valid_object(controller) then
                    resource = unwrap(quiet(function()
                        return rendering_library:ImportFileAsTexture2D(
                            controller, path
                        )
                    end, nil))
                    if is_valid_object(resource)
                        and resource_manager ~= nil then
                        resource_manager.put_thumbnail(entry.id, resource)
                    end
                end
            end
            if is_valid_object(resource) then
                thumbnail_loaded = quiet(function()
                    image:SetBrushResourceObject(resource)
                    return true
                end, false)
            end
        end
        if thumbnail_loaded then
            set_text(state_text, "")
        elseif entry.thumbnail_state == "pending" then
            set_text(state_text, localize("ui.library.thumbnail_pending"))
        else
            set_text(state_text, localize("ui.library.thumbnail_failed"))
        end
    end

    local function create_card(
        entry, card_index, widget_library, controller, card_wrap,
        address_list
    )
        local card_class, card_class_error = load_class(
            CARD_PACKAGE, CARD_CLASS
        )
        if not is_usable_class_object(card_class)
            or not is_valid_object(widget_library)
            or not is_valid_object(controller)
            or not is_valid_object(card_wrap) then
            return nil, "blueprint library card dependencies are unavailable class="
                .. tostring(card_class_error)
        end
        local card = unwrap(quiet(function()
            return widget_library:Create(
                controller, card_class, controller
            )
        end, nil))
        if not is_valid_object(card) then
            return nil, "blueprint library card could not be created"
        end
        local function fail(error_value)
            clear_handler_addresses(address_list)
            quiet(function() card:RemoveFromParent() end, nil)
            return nil, error_value
        end
        local attached = quiet(function()
            local zero_based_index = math.max(
                math.floor(tonumber(card_index) or 1) - 1, 0
            )
            local row = math.floor(zero_based_index / 3)
            local column = zero_based_index % 3
            local slot = card_wrap:AddChildToUniformGrid(
                card, row, column
            )
            quiet(function()
                -- Fill the padded 372x274 grid cell so the UserWidget's Slate
                -- geometry matches its full 372x258 visual tree.  Left/Top
                -- alignment keeps the seed widget's much smaller DesiredSize;
                -- Slate then culls the whole card while half of its visuals are
                -- still inside the ScrollBox, leaving an apparently empty row.
                slot:SetHorizontalAlignment(0)
                slot:SetVerticalAlignment(0)
            end, nil)
            return true
        end, false)
        if not attached then
            return fail("blueprint library card could not be attached")
        end

        restore_image_bindings(card, CARD_IMAGE_BINDINGS)
        restore_text_fonts(card, CARD_TEXT_WIDGETS)
        set_text(find_in_instance(card, "Card_NameText"), entry.name)
        configure_thumbnail(card, entry, controller)

        local place_placeholder = find_in_instance(card, "Card_PlaceButton")
        local rename_placeholder = find_in_instance(card, "Card_Rename_Button")
        local export_placeholder = find_in_instance(card, "Card_Export_Button")
        local delete_placeholder = find_in_instance(card, "Card_Delete_Button")
        local place_button, place_error = create_original_input_button(
            card, place_placeholder,
            { action = "place", entry_id = entry.id },
            nil, widget_library, controller, address_list
        )
        if not is_valid_object(place_button) then return fail(place_error) end
        local rename_button, rename_error = create_original_input_button(
            card, rename_placeholder,
            { action = "rename", entry_id = entry.id },
            { kind = "common", label = localize("ui.library.rename") },
            widget_library, controller, address_list
        )
        if not is_valid_object(rename_button) then return fail(rename_error) end
        local export_button, export_error = create_original_input_button(
            card, export_placeholder,
            { action = "export", entry_id = entry.id },
            { kind = "common", label = localize("ui.library.export") },
            widget_library, controller, address_list
        )
        if not is_valid_object(export_button) then return fail(export_error) end
        local delete_button, delete_error = create_original_input_button(
            card, delete_placeholder,
            { action = "delete", entry_id = entry.id },
            { kind = "common", label = localize("ui.library.delete") },
            widget_library, controller, address_list
        )
        if not is_valid_object(delete_button) then return fail(delete_error) end
        return card, nil
    end

    local function add_three_column_layout_spacer(
        entry_count, widget_library, controller, card_wrap
    )
        if entry_count <= 0 or entry_count >= 3 then return nil, nil end
        local card_class, card_class_error = load_class(
            CARD_PACKAGE, CARD_CLASS
        )
        if not is_usable_class_object(card_class) then
            return nil, card_class_error
        end
        local spacer = unwrap(quiet(function()
            return widget_library:Create(
                controller, card_class, controller
            )
        end, nil))
        if not is_valid_object(spacer) then
            return nil, "three-column layout spacer could not be created"
        end
        local attached = quiet(function()
            -- Hidden retains DesiredSize while drawing nothing and accepting
            -- no input.  Placing it in column 2 forces UniformGridPanel to
            -- retain three equal columns when the library has one or two
            -- records.
            spacer:SetVisibility(2)
            local slot = card_wrap:AddChildToUniformGrid(spacer, 0, 2)
            slot:SetHorizontalAlignment(1)
            slot:SetVerticalAlignment(1)
            return true
        end, false)
        if not attached then
            quiet(function() spacer:RemoveFromParent() end, nil)
            return nil, "three-column layout spacer could not be attached"
        end
        return spacer, nil
    end

    function cards.reset_registry()
        ui.card_handler_addresses_by_entry = {}
        ui.card_handles_by_entry = {}
        ui.rendered_entry_ids = {}
        ui.layout_spacer_address = nil
    end

    function cards.register(entry, card, address_list, insert_position)
        local entry_id = type(entry) == "table" and tostring(entry.id or "")
            or ""
        local address = safe_object_address(unwrap(card))
        if entry_id == "" or address == nil
            or type(address_list) ~= "table" then
            clear_handler_addresses(address_list or {})
            quiet(function() card:RemoveFromParent() end, nil)
            return false, "blueprint library card registry address is unavailable"
        end
        ui.card_handler_addresses_by_entry[entry_id] = address_list
        ui.card_handles_by_entry[entry_id] = {
            address = tostring(address),
            generation = ui.generation,
        }
        for _, route_address in ipairs(address_list) do
            ui.card_handler_addresses[#ui.card_handler_addresses + 1] =
                route_address
        end
        if insert_position ~= nil then
            table.insert(ui.rendered_entry_ids, insert_position, entry_id)
        else
            ui.rendered_entry_ids[#ui.rendered_entry_ids + 1] = entry_id
        end
        return true, nil
    end

    function cards.unregister(entry_id)
        entry_id = tostring(entry_id or "")
        local addresses = ui.card_handler_addresses_by_entry[entry_id] or {}
        local lookup = {}
        for _, address in ipairs(addresses) do
            lookup[tostring(address)] = true
        end
        for index = #ui.card_handler_addresses, 1, -1 do
            if lookup[tostring(ui.card_handler_addresses[index])] then
                table.remove(ui.card_handler_addresses, index)
            end
        end
        clear_handler_addresses(addresses)
        ui.card_handler_addresses_by_entry[entry_id] = nil
        ui.card_handles_by_entry[entry_id] = nil
        for index = #ui.rendered_entry_ids, 1, -1 do
            if ui.rendered_entry_ids[index] == entry_id then
                table.remove(ui.rendered_entry_ids, index)
                break
            end
        end
    end

    function cards.resolve(entry_id, card_wrap)
        local handle = ui.card_handles_by_entry[tostring(entry_id or "")]
        if type(handle) ~= "table" or handle.generation ~= ui.generation
            or not is_valid_object(card_wrap) then
            return nil
        end
        local child_count = tonumber(quiet(function()
            return card_wrap:GetChildrenCount()
        end, 0)) or 0
        for index = 0, child_count - 1 do
            local child = unwrap(quiet(function()
                return card_wrap:GetChildAt(index)
            end, nil))
            local address = safe_object_address(child)
            if address ~= nil and tostring(address) == handle.address then
                return child
            end
        end
        return nil
    end

    function cards.remove_spacer(card_wrap)
        local spacer_address = ui.layout_spacer_address
        ui.layout_spacer_address = nil
        if spacer_address == nil or not is_valid_object(card_wrap) then
            return
        end
        local child_count = tonumber(quiet(function()
            return card_wrap:GetChildrenCount()
        end, 0)) or 0
        for index = 0, child_count - 1 do
            local child = unwrap(quiet(function()
                return card_wrap:GetChildAt(index)
            end, nil))
            local address = safe_object_address(child)
            if address ~= nil and tostring(address) == spacer_address then
                quiet(function() child:RemoveFromParent() end, nil)
                return
            end
        end
    end

    function cards.ensure_spacer(card_wrap, widget_library, controller)
        if #ui.rendered_entry_ids <= 0
            or #ui.rendered_entry_ids >= 3 then
            return true, nil
        end
        local spacer, spacer_error = add_three_column_layout_spacer(
            #ui.rendered_entry_ids, widget_library, controller, card_wrap
        )
        if not is_valid_object(spacer) then
            return false, spacer_error or "three-column layout spacer is unavailable"
        end
        local address = safe_object_address(spacer)
        if address == nil then
            quiet(function() spacer:RemoveFromParent() end, nil)
            return false, "three-column layout spacer address is unavailable"
        end
        ui.layout_spacer_address = tostring(address)
        return true, nil
    end

    function cards.reflow(card_wrap, widget_library, controller)
        cards.remove_spacer(card_wrap)
        local children_by_address = {}
        local child_count = tonumber(quiet(function()
            return card_wrap:GetChildrenCount()
        end, 0)) or 0
        for index = 0, child_count - 1 do
            local child = unwrap(quiet(function()
                return card_wrap:GetChildAt(index)
            end, nil))
            local address = safe_object_address(child)
            if address ~= nil then
                children_by_address[tostring(address)] = child
            end
        end
        for index, entry_id in ipairs(ui.rendered_entry_ids) do
            local handle = ui.card_handles_by_entry[entry_id]
            local card = type(handle) == "table"
                and children_by_address[handle.address] or nil
            local moved = is_valid_object(card) and quiet(function()
                local slot = unwrap(safe_property(card, "Slot"))
                local zero_based_index = index - 1
                slot:SetRow(math.floor(zero_based_index / 3))
                slot:SetColumn(zero_based_index % 3)
                return true
            end, false)
            if not moved then
                return false, "blueprint library card reflow failed id="
                    .. tostring(entry_id)
            end
        end
        return cards.ensure_spacer(card_wrap, widget_library, controller)
    end

    function cards.update_summary(entry_count)
        local empty_text = get_live_field("Library_EmptyText")
        if is_valid_object(empty_text) then
            quiet(function()
                empty_text:SetVisibility(entry_count == 0 and 0 or 1)
            end, nil)
        end
        set_text(get_live_field("Library_StatusText"),
            localize("ui.library.status", entry_count))
    end

    function cards.add(entry)
        local card_wrap = get_live_field("Library_CardWrap")
        local widget_library = resolve(WIDGET_LIBRARY_PATH)
        local controller = get_controller()
        if not ui.is_open() or not is_valid_object(card_wrap)
            or not is_valid_object(widget_library)
            or not is_valid_object(controller) then
            return false, "blueprint library incremental add dependencies are unavailable"
        end
        cards.remove_spacer(card_wrap)
        local addresses = {}
        local card, card_error = create_card(
            entry, #ui.rendered_entry_ids + 1, widget_library, controller,
            card_wrap, addresses
        )
        if not is_valid_object(card) then return false, card_error end
        local registered, register_error = cards.register(
            entry, card, addresses, 1
        )
        if not registered then return false, register_error end
        local flowed, flow_error = cards.reflow(
            card_wrap, widget_library, controller
        )
        if not flowed then return false, flow_error end
        local entries = store.list() or ui.rendered_entry_ids
        cards.update_summary(#entries)
        return true, nil
    end

    function cards.remove(entry_id)
        local card_wrap = get_live_field("Library_CardWrap")
        local widget_library = resolve(WIDGET_LIBRARY_PATH)
        local controller = get_controller()
        if not ui.is_open() or not is_valid_object(card_wrap)
            or not is_valid_object(widget_library)
            or not is_valid_object(controller) then
            return false, "blueprint library incremental remove dependencies are unavailable"
        end
        local card = cards.resolve(entry_id, card_wrap)
        if not is_valid_object(card) then
            return false, "blueprint library incremental remove card is unavailable"
        end
        cards.remove_spacer(card_wrap)
        quiet(function() card:RemoveFromParent() end, nil)
        cards.unregister(entry_id)
        local flowed, flow_error = cards.reflow(
            card_wrap, widget_library, controller
        )
        if not flowed then return false, flow_error end
        local entries = store.list() or ui.rendered_entry_ids
        cards.update_summary(#entries)
        return true, nil
    end

    function cards.rename(entry_id, name)
        local card_wrap = get_live_field("Library_CardWrap")
        if not ui.is_open() or not is_valid_object(card_wrap) then
            return false, "blueprint library incremental rename dependencies are unavailable"
        end
        local card = cards.resolve(entry_id, card_wrap)
        if not is_valid_object(card)
            or not set_text(find_in_instance(card, "Card_NameText"), name) then
            return false, "blueprint library incremental rename card is unavailable"
        end
        return true, nil
    end

    function cards.copy_array(source)
        local copied = {}
        for index, value in ipairs(source or {}) do
            copied[index] = value
        end
        return copied
    end

    function cards.copy_address_groups(source)
        local copied = {}
        for entry_id, addresses in pairs(source or {}) do
            copied[entry_id] = cards.copy_array(addresses)
        end
        return copied
    end

    function cards.copy_card_handles(source)
        local copied = {}
        for entry_id, handle in pairs(source or {}) do
            copied[entry_id] = {
                address = tostring(handle.address),
            }
        end
        return copied
    end

    function cards.copy_panel_button_handles(source)
        local copied = {}
        for address, handles in pairs(source or {}) do
            copied[address] = {
                input = type(handles.input) == "table" and {
                    path = handles.input.path,
                    address = tostring(handles.input.address),
                } or nil,
                presentation = type(handles.presentation) == "table" and {
                    path = handles.presentation.path,
                    address = tostring(handles.presentation.address),
                } or nil,
            }
        end
        return copied
    end

    function cards.entry_signature(entries)
        local parts = {}
        for _, entry in ipairs(entries or {}) do
            for _, value in ipairs({
                entry.id,
                entry.name,
                entry.fingerprint,
                entry.thumbnail_file,
                entry.thumbnail_state,
            }) do
                value = tostring(value or "")
                parts[#parts + 1] = tostring(#value) .. ":" .. value
            end
        end
        return table.concat(parts, "|")
    end

    function cards.address_is_child(card_wrap, wanted_address)
        if not is_valid_object(card_wrap) or wanted_address == nil then
            return false
        end
        local child_count = tonumber(quiet(function()
            return card_wrap:GetChildrenCount()
        end, 0)) or 0
        for index = 0, child_count - 1 do
            local child = unwrap(quiet(function()
                return card_wrap:GetChildAt(index)
            end, nil))
            local address = safe_object_address(child)
            if address ~= nil
                and tostring(address) == tostring(wanted_address) then
                return true
            end
        end
        return false
    end

    function cards.capture_reuse_snapshot()
        local widget = get_live_widget()
        local card_wrap = get_live_field("Library_CardWrap")
        local entries, list_error = store.list()
        local panel_handle = make_object_handle(widget)
        if not is_valid_object(widget) or not is_valid_object(card_wrap)
            or entries == nil or panel_handle == nil then
            return false, list_error or "live library tree is unavailable"
        end
        if #ui.rendered_entry_ids ~= #entries then
            return false, "rendered card count disagrees with library index"
        end
        if #ui.panel_handler_addresses ~= 3 then
            return false, "panel button route count is incomplete"
        end
        for _, address in ipairs(ui.panel_handler_addresses) do
            if type(ui.panel_button_handles[address]) ~= "table" then
                return false, "panel button handle is incomplete"
            end
        end
        ui.reuse_snapshot = {
            panel_handle = panel_handle,
            card_wrap_address = safe_object_address(card_wrap),
            entry_signature = cards.entry_signature(entries),
            panel_handler_addresses = cards.copy_array(
                ui.panel_handler_addresses
            ),
            panel_button_handles = cards.copy_panel_button_handles(
                ui.panel_button_handles
            ),
            card_handler_addresses_by_entry = cards.copy_address_groups(
                ui.card_handler_addresses_by_entry
            ),
            card_handles_by_entry = cards.copy_card_handles(
                ui.card_handles_by_entry
            ),
            rendered_entry_ids = cards.copy_array(ui.rendered_entry_ids),
            layout_spacer_address = ui.layout_spacer_address,
        }
        return true, nil
    end

    function cards.snapshot_matches_panel(snapshot, widget)
        if type(snapshot) ~= "table" then return false end
        local live_handle = make_object_handle(widget)
        local cached_handle = snapshot.panel_handle
        return live_handle ~= nil and type(cached_handle) == "table"
            and live_handle.path == cached_handle.path
            and live_handle.address == tostring(cached_handle.address)
    end

    function cards.snapshot_matches_tree(snapshot, card_wrap)
        if type(snapshot) ~= "table" or not is_valid_object(card_wrap)
            or snapshot.card_wrap_address == nil then
            return false
        end
        local rendered_ids = snapshot.rendered_entry_ids or {}
        local expected_children = #rendered_ids
        if expected_children > 0 and expected_children < 3 then
            expected_children = expected_children + 1
        end
        local child_count = tonumber(quiet(function()
            return card_wrap:GetChildrenCount()
        end, -1)) or -1
        return safe_object_address(card_wrap)
                == tostring(snapshot.card_wrap_address)
            and child_count == expected_children
    end

    function cards.restore_panel_buttons(snapshot)
        local actions = { "close", "paste", "import" }
        clear_handler_addresses(ui.panel_handler_addresses)
        ui.panel_button_handles = {}
        for index, address in ipairs(
            snapshot.panel_handler_addresses or {}
        ) do
            local handles = snapshot.panel_button_handles
                and snapshot.panel_button_handles[address] or nil
            if actions[index] == nil or type(handles) ~= "table"
                or type(handles.input) ~= "table"
                or type(handles.presentation) ~= "table" then
                clear_handler_addresses(ui.panel_handler_addresses)
                ui.panel_button_handles = {}
                return false
            end
            address = tostring(address)
            ui.panel_handler_addresses[#ui.panel_handler_addresses + 1] =
                address
            ui.panel_button_handles[address] = handles
            ui.click_handlers[address] = {
                action = actions[index],
                generation = ui.generation,
            }
        end
        return #ui.panel_handler_addresses == #actions
    end

    function cards.remove_snapshot_panel_buttons(snapshot)
        for _, handles in pairs(
            snapshot.panel_button_handles or {}
        ) do
            local presentation = resolve_object_handle(
                handles.presentation
            )
            if is_valid_object(presentation) then
                quiet(function() presentation:RemoveFromParent() end, nil)
            end
        end
    end

    function cards.restore_card_tree(snapshot, card_wrap, entries)
        if cards.entry_signature(entries) ~= snapshot.entry_signature then
            return false, "library index changed while panel was closed"
        end
        local rendered_ids = snapshot.rendered_entry_ids or {}
        if not cards.snapshot_matches_tree(snapshot, card_wrap) then
            return false, "pooled card tree identity changed"
        end

        cards.reset_registry()
        ui.card_handler_addresses_by_entry = cards.copy_address_groups(
            snapshot.card_handler_addresses_by_entry
        )
        ui.card_handles_by_entry = cards.copy_card_handles(
            snapshot.card_handles_by_entry
        )
        ui.rendered_entry_ids = cards.copy_array(rendered_ids)
        ui.layout_spacer_address = snapshot.layout_spacer_address
        for _, handle in pairs(ui.card_handles_by_entry) do
            handle.generation = ui.generation
        end
        local actions = { "place", "rename", "export", "delete" }
        for _, entry_id in ipairs(ui.rendered_entry_ids) do
            local card_handle = ui.card_handles_by_entry[entry_id]
            if type(card_handle) ~= "table" or card_handle.address == nil then
                clear_handler_addresses(ui.card_handler_addresses)
                cards.reset_registry()
                return false, "pooled card handle is incomplete"
            end
            local addresses = ui.card_handler_addresses_by_entry[entry_id]
            if type(addresses) ~= "table" or #addresses ~= 4 then
                clear_handler_addresses(ui.card_handler_addresses)
                cards.reset_registry()
                return false, "pooled card button routes are incomplete"
            end
            for action_index, address in ipairs(addresses) do
                address = tostring(address)
                ui.card_handler_addresses[#ui.card_handler_addresses + 1] =
                    address
                ui.click_handlers[address] = {
                    action = actions[action_index],
                    entry_id = entry_id,
                    generation = ui.generation,
                }
            end
        end
        if #ui.rendered_entry_ids > 0 and #ui.rendered_entry_ids < 3
            and ui.layout_spacer_address == nil then
            clear_handler_addresses(ui.card_handler_addresses)
            cards.reset_registry()
            return false, "pooled layout spacer is no longer live"
        end
        cards.update_summary(#entries)
        return true, nil
    end

    function ui.refresh()
        local widget = get_live_widget()
        local card_wrap = is_valid_object(widget)
            and unwrap(find_in_instance(widget, "Library_CardWrap")) or nil
        local widget_library = resolve(WIDGET_LIBRARY_PATH)
        local controller = get_controller()
        if not ui.is_open() or not is_valid_object(card_wrap)
            or not is_valid_object(widget_library)
            or not is_valid_object(controller) then
            return false, "blueprint library panel is not open"
        end
        clear_handler_addresses(ui.card_handler_addresses)
        cards.reset_registry()
        quiet(function() card_wrap:ClearChildren() end, nil)
        local entries, list_error = store.list()
        if entries == nil then return false, list_error end

        local created = 0
        for _, entry in ipairs(entries) do
            local addresses = {}
            local card, card_error = create_card(
                entry, created + 1, widget_library, controller, card_wrap,
                addresses
            )
            if not is_valid_object(card) then
                log("blueprint library card skipped id=" .. tostring(entry.id)
                    .. " error=" .. tostring(card_error))
            else
                local registered, register_error = cards.register(
                    entry, card, addresses
                )
                if not registered then
                    log("blueprint library card registry skipped id="
                        .. tostring(entry.id) .. " error="
                        .. tostring(register_error))
                else
                    created = created + 1
                end
            end
        end
        local spacer_ok, spacer_error = cards.ensure_spacer(
            card_wrap, widget_library, controller
        )
        if not spacer_ok then
            log("blueprint library three-column spacer unavailable error="
                .. tostring(spacer_error))
        end
        cards.update_summary(#entries)
        log("blueprint library panel refreshed entries=" .. tostring(#entries)
            .. " cards=" .. tostring(created))
        return true, nil
    end

    local function handle_paste()
        local text, read_error = read_clipboard()
        if text == nil then
            send_message("message.library.clipboard_read_failed", read_error)
            return false
        end
        local code_input = get_live_field("Library_CodeInput")
        set_text(code_input, text)
        quiet(function()
            code_input:SetKeyboardFocus()
            code_input:SelectAllText()
        end, nil)
        return true
    end

    local function handle_import()
        local code_input = get_live_field("Library_CodeInput")
        local status_text = get_live_field("Library_StatusText")
        local code = read_text(code_input)
        local compact, decode_error = decode_blueprint(code)
        if compact == nil then
            log("blueprint library import decode rejected error="
                .. tostring(decode_error))
            set_text(status_text,
                localize("ui.library.import_invalid_status"))
            send_message(
                "message.library.import_failed",
                localize("ui.library.import_invalid_reason")
            )
            quiet(function()
                code_input:SetKeyboardFocus()
                code_input:SelectAllText()
            end, nil)
            return false
        end
        local entries = store.list() or {}
        local default_name = localize(
            "ui.library.imported_name", #entries + 1
        )
        if ui.pending_name_action ~= nil then return false end
        if not hide_library_for_native_name_dialog() then
            send_message("message.library.import_name_failed",
                "blueprint library could not be hidden for naming")
            return false
        end
        ui.pending_name_action = { action = "import" }
        local opened, open_error = request_name({
            default_name = default_name,
            heading_text = localize("ui.library.import_name_heading"),
            on_confirm = function(name)
                local entry, import_error = import_blueprint(
                    code, name, compact
                )
                if entry == nil then
                    log("blueprint library import runtime rejected error="
                        .. tostring(import_error))
                    set_text(get_live_field("Library_StatusText"),
                        localize("ui.library.import_runtime_status"))
                    local user_reason = localize(
                        "ui.library.import_runtime_reason"
                    )
                    send_message("message.library.import_failed", user_reason)
                    return false, user_reason
                end
                set_text(get_live_field("Library_CodeInput"), "")
                local updated, update_error = cards.add(entry)
                if not updated then
                    log("blueprint library incremental import fallback error="
                        .. tostring(update_error))
                    local refreshed, refresh_error = ui.refresh()
                    if not refreshed then
                        log("blueprint library refresh after import failed error="
                            .. tostring(refresh_error))
                    end
                end
                send_message("message.library.import_success", entry.name)
                return true, nil
            end,
            on_closed = function()
                restore_library_after_name_dialog()
            end,
        })
        if not opened then
            restore_library_after_name_dialog()
            send_message("message.library.import_name_failed", open_error)
            return false
        end
        return true
    end

    local function handle_export(entry_id)
        local record, load_error = store.load(entry_id)
        if record == nil then
            send_message("message.library.load_failed", load_error)
            return false
        end
        local copied, copy_error = copy_clipboard(record.blueprint_code)
        if not copied then
            send_message("message.library.export_failed", copy_error)
            return false
        end
        send_message("message.library.export_success", record.metadata.name)
        return true
    end

    local function handle_place(entry_id)
        local record, load_error = store.load(entry_id)
        if record == nil then
            send_message("message.library.load_failed", load_error)
            return false
        end
        local compact, stats_or_error =
            decode_blueprint(record.blueprint_code)
        if compact == nil then
            send_message("message.library.load_failed", stats_or_error)
            return false
        end
        local name = record.metadata.name
        ui.placement_request_sequence = ui.placement_request_sequence + 1
        local placement_request_sequence = ui.placement_request_sequence
        ui.close("place:" .. tostring(entry_id))
        BlueprintCallbackScheduler.game_thread_now(
            "blueprint-library-place:" .. tostring(entry_id), function()
                -- Native CommonUI closes asynchronously. Its normal close
                -- completion advances ui.generation before this continuation
                -- runs, so the panel generation cannot also be the placement
                -- request token.
                if placement_request_sequence
                    ~= ui.placement_request_sequence then
                    return
                end
                local accepted = on_place(
                    compact, stats_or_error,
                    "library:" .. tostring(name),
                    entry_id, record.type_templates
                )
                if accepted ~= true then
                    log("blueprint library placement was rejected id="
                        .. tostring(entry_id))
                end
            end
        )
        return true
    end
    ui.place_entry = handle_place

    local function handle_rename(entry_id)
        local record, load_error = store.load(entry_id)
        if record == nil then
            send_message("message.library.load_failed", load_error)
            return false
        end
        local entry_name = record.metadata.name
        if ui.pending_name_action ~= nil then return false end
        if not hide_library_for_native_name_dialog() then
            send_message("message.library.rename_failed",
                "blueprint library could not be hidden for naming")
            return false
        end
        ui.pending_name_action = {
            action = "rename",
            entry_id = entry_id,
        }
        local opened, open_error = request_name({
            default_name = entry_name,
            heading_text = localize("ui.library.rename_heading"),
            on_confirm = function(name)
                local renamed, rename_error = store.rename(entry_id, name)
                if renamed == nil then
                    send_message("message.library.rename_failed", rename_error)
                    return false, rename_error
                end
                local updated, update_error = cards.rename(
                    entry_id, renamed.name
                )
                if not updated then
                    log("blueprint library incremental rename fallback id="
                        .. tostring(entry_id) .. " error="
                        .. tostring(update_error))
                    local refreshed, refresh_error = ui.refresh()
                    if not refreshed then
                        log("blueprint library refresh after rename failed id="
                            .. tostring(entry_id) .. " error="
                            .. tostring(refresh_error))
                    end
                end
                send_message("message.library.rename_success", renamed.name)
                return true, nil
            end,
            on_closed = function()
                restore_library_after_name_dialog()
            end,
        })
        if not opened then
            restore_library_after_name_dialog()
            send_message("message.library.rename_failed", open_error)
            return false
        end
        return true
    end

    local function perform_delete(entry_id, entry_name)
        local removed, cleanup_warning = store.remove(entry_id)
        if removed == nil then
            send_message("message.library.delete_failed", cleanup_warning)
            return false
        end
        if cleanup_warning ~= nil then
            log("blueprint library delete cleanup warning id="
                .. tostring(entry_id) .. " error="
                .. tostring(cleanup_warning))
        end
        if resource_manager ~= nil then
            resource_manager.remove_thumbnail(entry_id)
        end
        if ui.is_open() then
            local updated, update_error = cards.remove(entry_id)
            if not updated then
                log("blueprint library incremental delete fallback error="
                    .. tostring(update_error))
                local refreshed, refresh_error = ui.refresh()
                if not refreshed then
                    log("blueprint library refresh after delete failed error="
                        .. tostring(refresh_error))
                end
            end
        end
        send_message("message.library.delete_success",
            removed.name or entry_name)
        return true
    end

    local function handle_delete(entry_id)
        local record, load_error = store.load(entry_id)
        if record == nil then
            send_message("message.library.load_failed", load_error)
            return false
        end
        local entry_name = record.metadata.name
        if ui.pending_delete_id ~= nil then return false end
        ui.pending_delete_id = entry_id
        local opened, open_error = request_confirm(
            localize("ui.library.delete_confirm", entry_name),
            function(confirmed)
                if ui.pending_delete_id ~= entry_id then return end
                ui.pending_delete_id = nil
                if confirmed == true then
                    perform_delete(entry_id, entry_name)
                end
            end,
            {
                -- PalUtility already inserts its dialog above an overlay that
                -- lives in the native HUD stack. Reparenting that stock dialog
                -- to the viewport is only required by the legacy fallback.
                promote = false,
            }
        )
        if not opened then
            ui.pending_delete_id = nil
            send_message("message.library.delete_confirm_failed", open_error)
            return false
        end
        return true
    end

    local function dispatch_route(route)
        if type(route) ~= "table" or not ui.is_open()
            or route.generation ~= ui.generation then
            return false
        end
        if route.action == "close" then
            return ui.close("close-button")
        elseif route.action == "paste" then
            return handle_paste()
        elseif route.action == "import" then
            return handle_import()
        elseif route.action == "rename" then
            return handle_rename(route.entry_id)
        elseif route.action == "export" then
            return handle_export(route.entry_id)
        elseif route.action == "delete" then
            return handle_delete(route.entry_id)
        elseif route.action == "place" then
            return handle_place(route.entry_id)
        end
        return false
    end

    local function ensure_common_button_hook()
        if ui.common_button_hook_registered then return true, nil end
        local callback = function(context)
            local address = safe_object_address(unwrap(context))
            local route = address ~= nil
                and ui.click_handlers[tostring(address)] or nil
            if route == nil then return end
            local generation = route.generation
            BlueprintCallbackScheduler.game_thread_now(
                "blueprint-library-click:" .. tostring(route.action),
                function()
                    if generation == ui.generation then
                        dispatch_route(route)
                    end
                end
            )
        end
        local retained = function(...)
            local ok, error_value = pcall(callback, ...)
            if not ok then
                log("blueprint library click hook isolated error="
                    .. tostring(error_value))
            end
        end
        local ok, pre_id, post_id = pcall(
            RegisterHook, COMMON_BUTTON_CLICK, retained
        )
        if not ok then
            return false, "CommonButton click hook unavailable: "
                .. tostring(pre_id)
        end
        ui.common_button_hook_callback = retained
        ui.common_button_hook_registered = true
        log("blueprint library click hook registered pre="
            .. tostring(pre_id) .. " post=" .. tostring(post_id))
        return true, nil
    end

    local function configure_labels(widget)
        set_text(find_in_instance(widget, "Library_TitleText"),
            localize("ui.library.title"))
        set_hint(find_in_instance(widget, "Library_CodeInput"),
            localize("ui.library.code_hint"))
        set_text(find_in_instance(widget, "Library_EmptyText"),
            localize("ui.library.empty"))
    end

    function ui.open()
        if ui.is_open() then return true, nil end
        local open_started_at = os.clock()
        local stage_started_at = open_started_at
        local open_timing = {}
        local initialized, initialize_error = store.initialize()
        if not initialized then return false, initialize_error end
        local hooks_ready, hook_error = ensure_common_button_hook()
        if not hooks_ready then return false, hook_error end

        local panel_class, panel_class_error = load_class(
            PANEL_PACKAGE, PANEL_CLASS
        )
        if not is_usable_class_object(panel_class) then
            return false, "blueprint library widget dependencies are unavailable"
                .. " panelClass="
                .. tostring(class_object_name(panel_class))
                .. " classDiagnostic=" .. tostring(panel_class_error)
        end
        if not ui.template_style_prepared then
            local input_style_ready, input_style_error =
                prepare_code_input_template(panel_class)
            if input_style_ready then
                ui.template_style_prepared = true
            else
                log("blueprint library code input stock font restore failed error="
                    .. tostring(input_style_error))
            end
        end
        local escape_ready, escape_error = ensure_escape_hooks()
        if not escape_ready then return false, escape_error end

        if type(native_ui_stack) ~= "table"
            or type(native_ui_stack.push) ~= "function"
            or type(native_ui_stack.get_widget) ~= "function" then
            return false, "blueprint library native UI stack is unavailable"
        end
        open_timing.bootstrap_ms = (os.clock() - stage_started_at) * 1000.0
        stage_started_at = os.clock()
        local native_entry, widget, native_error = native_ui_stack.push(
            panel_class, on_native_closed
        )
        widget = unwrap(widget)
        if not is_valid_object(widget) then
            return false, "blueprint library panel could not be created: "
                .. tostring(native_error)
        end
        open_timing.push_ms = (os.clock() - stage_started_at) * 1000.0
        stage_started_at = os.clock()

        ui.native_entry = native_entry
        ui.generation = ui.generation + 1
        ui.closing = false
        ui.reuse_eligible = false
        local code_input = unwrap(find_in_instance(
            widget, "Library_CodeInput"
        ))
        local card_wrap = unwrap(find_in_instance(
            widget, "Library_CardWrap"
        ))
        local empty_text = unwrap(find_in_instance(
            widget, "Library_EmptyText"
        ))
        local status_text = unwrap(find_in_instance(
            widget, "Library_StatusText"
        ))

        if not is_valid_object(code_input)
            or not is_valid_object(card_wrap)
            or not is_valid_object(empty_text)
            or not is_valid_object(status_text) then
            ui.close("required-fields-missing")
            return false, "blueprint library panel fields are unavailable"
        end
        quiet(function()
            card_wrap:SetSlotPadding({
                Left = 0.0, Top = 8.0, Right = 0.0, Bottom = 8.0,
            })
            card_wrap:SetMinDesiredSlotWidth(372.0)
            card_wrap:SetMinDesiredSlotHeight(274.0)
        end, nil)
        local reuse_snapshot = ui.reuse_snapshot
        ui.reuse_snapshot = nil
        local same_pooled_panel = cards.snapshot_matches_panel(
            reuse_snapshot, widget
        )
        local same_pooled_tree = same_pooled_panel
            and cards.snapshot_matches_tree(reuse_snapshot, card_wrap)
        configure_labels(widget)
        if not same_pooled_panel then
            restore_image_bindings(widget, PANEL_IMAGE_BINDINGS)
            restore_text_fonts(widget, PANEL_TEXT_WIDGETS)
        end
        open_timing.panel_setup_ms =
            (os.clock() - stage_started_at) * 1000.0
        stage_started_at = os.clock()
        local panel_reused = same_pooled_tree
            and cards.restore_panel_buttons(reuse_snapshot) or false
        if not panel_reused then
            if same_pooled_tree then
                cards.remove_snapshot_panel_buttons(reuse_snapshot)
            end
            local controller = get_controller()
            local library = resolve(WIDGET_LIBRARY_PATH)
            if not is_valid_object(controller)
                or not is_valid_object(library) then
                ui.close("panel-button-dependencies")
                return false,
                    "blueprint library button dependencies are unavailable"
            end
            local panel_buttons = {
                {
                    name = "Library_CloseButton", action = "close",
                    presentation = { kind = "close" },
                },
                {
                    name = "Library_Paste_Button", action = "paste",
                    presentation = {
                        kind = "common", label = localize("ui.library.paste"),
                    },
                },
                {
                    name = "Library_Import_Button", action = "import",
                    presentation = {
                        kind = "common", label = localize("ui.library.import"),
                    },
                },
            }
            for _, spec in ipairs(panel_buttons) do
                local placeholder = find_in_instance(widget, spec.name)
                local button, button_error = create_original_input_button(
                    widget, placeholder, { action = spec.action },
                    spec.presentation, library, controller,
                    ui.panel_handler_addresses
                )
                if not is_valid_object(button) then
                    ui.close("panel-button-failed:" .. spec.action)
                    return false, button_error
                end
            end
        end
        open_timing.panel_routes_ms =
            (os.clock() - stage_started_at) * 1000.0
        stage_started_at = os.clock()

        local attached = quiet(function()
            widget:SetVisibility(0)
            return true
        end, false)
        if not attached then
            ui.close("viewport-attach-failed")
            return false, "blueprint library panel could not be attached"
        end
        local guard_ready, guard_error = pcall(function()
            widget:ActivateWidget()
            widget:ClearCancelAction()
            widget:BR_SetupEscapeGuard()
        end)
        if not guard_ready then
            ui.close("escape-guard-failed")
            return false, "blueprint library CommonUI guard failed: "
                .. tostring(guard_error)
        end
        native_ui_stack.focus(ui.native_entry, code_input)
        open_timing.activation_ms =
            (os.clock() - stage_started_at) * 1000.0
        stage_started_at = os.clock()
        local entries, list_error = store.list()
        local cards_reused = entries ~= nil and same_pooled_tree
            and cards.restore_card_tree(
                reuse_snapshot, card_wrap, entries
            ) or false
        if not cards_reused then
            local refreshed, refresh_error = ui.refresh()
            if not refreshed then
                ui.close("initial-refresh-failed")
                return false, refresh_error or list_error
            end
        end
        open_timing.cards_ms = (os.clock() - stage_started_at) * 1000.0
        open_timing.total_ms = (os.clock() - open_started_at) * 1000.0
        ui.reuse_eligible = true
        log(string.format(
            "blueprint performance library-open totalMs=%.2f bootstrapMs=%.2f pushMs=%.2f panelSetupMs=%.2f panelRoutesMs=%.2f activationMs=%.2f cardsMs=%.2f pooledPanel=%s pooledCards=%s entries=%d",
            open_timing.total_ms,
            open_timing.bootstrap_ms,
            open_timing.push_ms,
            open_timing.panel_setup_ms,
            open_timing.panel_routes_ms,
            open_timing.activation_ms,
            open_timing.cards_ms,
            tostring(panel_reused),
            tostring(cards_reused),
            type(entries) == "table" and #entries or 0
        ))
        log("blueprint library panel opened mode=pal-native-stack"
            .. " pooledPanel=" .. tostring(panel_reused)
            .. " pooledCards=" .. tostring(cards_reused)
            .. " widget=" .. object_name(widget))
        return true, nil
    end

    function ui.reset_for_world_travel()
        ui.closing = true
        ui.placement_request_sequence = ui.placement_request_sequence + 1
        if ui.native_entry ~= nil and type(native_ui_stack) == "table" then
            native_ui_stack.abandon(ui.native_entry, "world-travel")
        end
        clear_handler_addresses(ui.card_handler_addresses)
        clear_handler_addresses(ui.panel_handler_addresses)
        ui.reuse_snapshot = nil
        ui.generation = ui.generation + 1
        clear_references()
    end

    return ui
end

return BlueprintLibraryUI

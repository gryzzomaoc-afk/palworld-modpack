local BlueprintPlacementHUDKeyGuides = {}

local ROW_PACKAGE_PATH =
    "/Game/Pal/Blueprint/UI/UserInterface/InGame/Construction/" ..
    "WBP_Ingameconstruction_KeyGuide"
local ROW_CLASS_PATH = ROW_PACKAGE_PATH ..
    ".WBP_Ingameconstruction_KeyGuide_C"
local KEY_ICON_PACKAGE_PATH =
    "/Game/Pal/Blueprint/UI/CommonWidget/ActionWidget/" ..
    "WBP_PalKeyGuideIcon"
local KEY_ICON_CLASS_PATH = KEY_ICON_PACKAGE_PATH ..
    ".WBP_PalKeyGuideIcon_C"
local CAMERA_ACTION = "BlueprintResearch_PlacementToggleFreeCamera"
local CAMERA_KEY = "CapsLock"
local WORLD_SNAP_ACTION = "BlueprintResearch_PlacementToggleWorldSnap"
local WORLD_SNAP_KEY = "V"
local GUIDE_ROWS = {
    {
        action = CAMERA_ACTION,
        key = CAMERA_KEY,
        text_key = "ui.guide.camera",
    },
    {
        action = WORLD_SNAP_ACTION,
        key = WORLD_SNAP_KEY,
        text_key = "ui.guide.world_snap",
    },
}

function BlueprintPlacementHUDKeyGuides.install(deps)
    assert(type(deps) == "table", "placement HUD key guides requires deps")

    local UEHelpers = assert(
        deps.UEHelpers, "placement HUD key guides UEHelpers is required"
    )
    local mode_ui = assert(
        deps.mode_ui, "placement HUD key guides mode_ui is required"
    )
    local log = assert(deps.log, "placement HUD key guides log is required")
    local unwrap = assert(
        deps.unwrap, "placement HUD key guides unwrap is required"
    )
    local object_name = assert(
        deps.object_name, "placement HUD key guides object_name is required"
    )
    local is_valid_object = assert(
        deps.is_valid_object,
        "placement HUD key guides is_valid_object is required"
    )
    local is_usable_class_object = assert(
        deps.is_usable_class_object,
        "placement HUD key guides is_usable_class_object is required"
    )
    local safe_object_address = assert(
        deps.safe_object_address,
        "placement HUD key guides safe_object_address is required"
    )
    local safe_property = assert(
        deps.safe_property,
        "placement HUD key guides safe_property is required"
    )
    local make_runtime_object_handle = assert(
        deps.make_runtime_object_handle,
        "placement HUD key guides make_runtime_object_handle is required"
    )
    local resolve_runtime_object_handle = assert(
        deps.resolve_runtime_object_handle,
        "placement HUD key guides resolve_runtime_object_handle is required"
    )
    local find_in_instance = assert(
        deps.find_in_instance,
        "placement HUD key guides find_in_instance is required"
    )
    local get_building_model = assert(
        deps.get_building_model,
        "placement HUD key guides get_building_model is required"
    )
    local get_local_player_controller = assert(
        deps.get_local_player_controller,
        "placement HUD key guides get_local_player_controller is required"
    )
    local is_placement_active = assert(
        deps.is_placement_active,
        "placement HUD key guides is_placement_active is required"
    )
    local localize = assert(
        deps.localize, "placement HUD key guides localize is required"
    )
    local schedule_cleanup = assert(
        deps.schedule_cleanup,
        "placement HUD key guides schedule_cleanup is required"
    )

    local runtime = {
        installed = false,
        action_row_ready = false,
        building_widget_handle = nil,
        row_handles = {},
        owner_handle = nil,
        row_class = nil,
        key_icon_class = nil,
        last_error = nil,
        retry_ticks = 0,
    }

    local function load_widget_class(package_path, class_path, cached_class)
        cached_class = unwrap(cached_class)
        if is_usable_class_object(cached_class) then return cached_class end

        local exact_class = unwrap(StaticFindObject(class_path))
        if is_usable_class_object(exact_class) then return exact_class end

        local package_result = nil
        pcall(function()
            package_result = unwrap(LoadAsset(package_path))
        end)
        exact_class = unwrap(StaticFindObject(class_path))
        if is_usable_class_object(exact_class) then return exact_class end
        if is_usable_class_object(package_result) then return package_result end

        local generated_class = unwrap(safe_property(
            package_result, "GeneratedClass"
        ))
        if is_usable_class_object(generated_class) then return generated_class end
        return nil
    end

    local function ensure_action_rows()
        if runtime.action_row_ready then return true, nil end
        local data_table = unwrap(mode_ui.load_input_action_table())
        if not is_valid_object(data_table) then
            return false, "DT_UIInputAction unavailable"
        end
        for _, guide in ipairs(GUIDE_ROWS) do
            local ok, error_value = mode_ui.install_input_action_row(
                data_table, guide.action, guide.key
            )
            if not ok then return false, tostring(error_value) end
        end
        runtime.action_row_ready = true
        return true, nil
    end

    local function create_widget(player_controller, widget_class, label)
        local widget_library = unwrap(StaticFindObject(
            "/Script/UMG.Default__WidgetBlueprintLibrary"
        ))
        if not is_usable_class_object(widget_class)
            or not is_valid_object(widget_library) then
            return nil, label .. " class or UMG library unavailable"
        end
        local ok, widget = pcall(function()
            return unwrap(widget_library:Create(
                player_controller, widget_class, player_controller
            ))
        end)
        widget = unwrap(widget)
        if not ok or not is_valid_object(widget) then
            return nil, label .. " CreateWidget failed: " .. tostring(widget)
        end
        return widget, nil
    end

    local function is_widget_visible(widget)
        local ok, visible = pcall(function() return widget:IsVisible() end)
        return not ok or visible == true
    end

    local function find_active_hud(building_model)
        local model_address = safe_object_address(building_model)
        if model_address == nil then return nil end
        -- SetupInputAction supplies the one WBP_PalBuilding instance that is
        -- being initialized for this placement session. Never enumerate every
        -- historical /Engine/Transient widget here: after LoadMap an old root
        -- can remain discoverable while its Model pointer already belongs to a
        -- destroyed world, and reflecting that pointer can crash natively.
        local root = unwrap(resolve_runtime_object_handle(
            runtime.building_widget_handle
        ))
        if not is_valid_object(root) or not is_widget_visible(root) then
            return nil
        end
        local root_model = unwrap(safe_property(root, "Model"))
        if not is_valid_object(root_model)
            or safe_object_address(root_model) ~= model_address then
            return nil
        end
        local hud = unwrap(safe_property(root, "WBP_IngameConstruction"))
        local vertical_box = unwrap(find_in_instance(hud, "VerticalBox_1"))
        local separator = unwrap(find_in_instance(hud, "Overlay_Line"))
        if is_valid_object(hud)
            and is_valid_object(vertical_box)
            and is_valid_object(separator) then
            return hud
        end
        return nil
    end

    local function set_vertical_padding(widget, padding)
        local slot = unwrap(safe_property(widget, "Slot"))
        if not is_valid_object(slot) then return end
        pcall(function() slot:SetPadding(padding) end)
    end

    local function append_above_separator(vertical_box, hud, row)
        local separator = unwrap(find_in_instance(hud, "Overlay_Line"))
        local cancel = unwrap(find_in_instance(
            hud, "WBP_Ingameconstruction_KeyGuide_Cancel"
        ))
        local finish = unwrap(find_in_instance(
            hud, "WBP_Ingameconstruction_KeyGuide_End"
        ))
        if not is_valid_object(separator)
            or not is_valid_object(cancel)
            or not is_valid_object(finish) then
            return false, "stock construction key-guide tail unavailable"
        end

        local added_ok, added_slot = pcall(function()
            return unwrap(vertical_box:AddChildToVerticalBox(row))
        end)
        if not added_ok or not is_valid_object(added_slot) then
            return false, "camera row could not be appended"
        end
        set_vertical_padding(row, { Bottom = 4.0 })

        -- AddChild is the reflected runtime-safe API. Move the stock separator
        -- and its two footer actions behind the new row by removing and adding
        -- those three live widgets back in the same order. Their original slot
        -- padding is restored explicitly.
        local tail = {
            {
                widget = separator,
                padding = {
                    Left = -10.0,
                    Top = 3.0,
                    Right = -10.0,
                    Bottom = 7.0,
                },
            },
            { widget = cancel, padding = { Bottom = 4.0 } },
            { widget = finish, padding = { Bottom = 4.0 } },
        }
        local ok = true
        local errors = {}
        for _, entry in ipairs(tail) do
            local remove_ok, removed = pcall(function()
                return vertical_box:RemoveChild(entry.widget)
            end)
            if not remove_ok or removed ~= true then
                ok = false
                errors[#errors + 1] = "remove-tail"
            end
        end
        for _, entry in ipairs(tail) do
            local parent = nil
            pcall(function() parent = unwrap(entry.widget:GetParent()) end)
            if not is_valid_object(parent) then
                local readd_ok, slot = pcall(function()
                    return unwrap(vertical_box:AddChildToVerticalBox(
                        entry.widget
                    ))
                end)
                if not readd_ok or not is_valid_object(slot) then
                    ok = false
                    errors[#errors + 1] = "readd-tail"
                else
                    set_vertical_padding(entry.widget, entry.padding)
                end
            end
        end
        if not ok then
            pcall(function() row:RemoveFromParent() end)
            return false, table.concat(errors, ",")
        end
        return true, nil
    end

    local function install_into_hud(hud)
        local action_ok, action_error = ensure_action_rows()
        if not action_ok then return false, action_error end

        local player_controller = unwrap(get_local_player_controller())
        if not is_valid_object(player_controller) then
            player_controller = unwrap(UEHelpers.GetPlayerController())
        end
        if not is_valid_object(player_controller) then
            return false, "local player controller unavailable"
        end

        runtime.row_class = load_widget_class(
            ROW_PACKAGE_PATH, ROW_CLASS_PATH, runtime.row_class
        )
        runtime.key_icon_class = load_widget_class(
            KEY_ICON_PACKAGE_PATH,
            KEY_ICON_CLASS_PATH,
            runtime.key_icon_class
        )
        local vertical_box = unwrap(find_in_instance(hud, "VerticalBox_1"))
        if not is_valid_object(vertical_box) then
            return false, "stock construction key-guide containers unavailable"
        end
        local created_rows = {}
        local created_handles = {}
        local function discard_created_rows()
            for _, created_row in ipairs(created_rows) do
                pcall(function() created_row:RemoveFromParent() end)
            end
        end
        for _, guide in ipairs(GUIDE_ROWS) do
            local row, row_error = create_widget(
                player_controller, runtime.row_class,
                "stock construction key-guide row"
            )
            if not is_valid_object(row) then
                discard_created_rows()
                return false, row_error
            end
            created_rows[#created_rows + 1] = row
            local horizontal_box = unwrap(find_in_instance(
                row, "HorizontalBox_46"
            ))
            if not is_valid_object(horizontal_box) then
                discard_created_rows()
                return false,
                    "stock construction key-guide containers unavailable"
            end
            local icon, icon_error = create_widget(
                player_controller, runtime.key_icon_class,
                "stock key-guide icon"
            )
            if not is_valid_object(icon) then
                discard_created_rows()
                return false, icon_error
            end
            local setup_ok, setup_error = pcall(function()
                row:Setup({}, FText(localize(guide.text_key)))
                horizontal_box:AddChildToHorizontalBox(icon)
                icon:SetInputAction(FName(guide.action))
                icon:SetVisibility(0)
                icon:OverrideInputType(0)
                local action_widget = unwrap(safe_property(
                    icon, "PalUIActionWidgetBase_24"
                ))
                if is_valid_object(action_widget) then
                    action_widget:SetVisibility(0)
                end
                row:SetVisibility(4)
            end)
            if not setup_ok then
                discard_created_rows()
                return false, "placement key-guide setup failed: "
                    .. tostring(setup_error)
            end
            local inserted, insert_error = append_above_separator(
                vertical_box, hud, row
            )
            if not inserted then
                discard_created_rows()
                return false, insert_error
            end
            local row_handle = make_runtime_object_handle(row)
            if row_handle == nil then
                discard_created_rows()
                return false, "placement key-guide runtime identity unavailable"
            end
            created_handles[#created_handles + 1] = row_handle
        end

        runtime.row_handles = created_handles
        runtime.owner_handle = make_runtime_object_handle(hud)
        if runtime.owner_handle == nil then
            discard_created_rows()
            runtime.row_handles = {}
            return false, "placement key-guide owner identity unavailable"
        end
        runtime.installed = true
        runtime.last_error = nil
        runtime.retry_ticks = 0
        log("blueprint placement stock key guides installed keys="
            .. CAMERA_KEY .. "," .. WORLD_SNAP_KEY
            .. " position=above-separator hud="
            .. object_name(hud))
        return true, nil
    end

    local function remove_row(row_handle, reason)
        if row_handle == nil then return true end
        local row = unwrap(resolve_runtime_object_handle(row_handle))
        if not is_valid_object(row) then return true end
        local ok = pcall(function() row:RemoveFromParent() end)
        if not ok then
            log("blueprint placement key guide cleanup failed reason="
                .. tostring(reason))
        end
        return ok
    end

    function runtime.cancel(reason, defer_native_cleanup)
        local row_handles = runtime.row_handles
        runtime.installed = false
        runtime.row_handles = {}
        runtime.owner_handle = nil
        runtime.last_error = nil
        runtime.retry_ticks = 0
        if type(row_handles) ~= "table" or #row_handles == 0 then
            return true
        end
        local function remove_rows()
            local ok = true
            for _, row_handle in ipairs(row_handles) do
                ok = remove_row(row_handle, reason) and ok
            end
            return ok
        end
        if defer_native_cleanup == true then
            schedule_cleanup(
                "placement-key-guide:" .. tostring(reason), function()
                    remove_rows()
                end
            )
            return true
        end
        return remove_rows()
    end

    function runtime.observe_building_widget(widget)
        local handle = make_runtime_object_handle(widget)
        if handle == nil then
            return false, "WBP_PalBuilding runtime identity unavailable"
        end
        local previous = runtime.building_widget_handle
        local changed = previous == nil
            or previous.path ~= handle.path
            or previous.address ~= handle.address
            or previous.world_generation ~= handle.world_generation
        runtime.building_widget_handle = handle
        if changed then
            runtime.installed = false
            runtime.row_handles = {}
            runtime.owner_handle = nil
            runtime.last_error = nil
            runtime.retry_ticks = 0
        end
        return true, nil
    end

    function runtime.abandon_world()
        runtime.installed = false
        runtime.building_widget_handle = nil
        runtime.row_handles = {}
        runtime.owner_handle = nil
        runtime.last_error = nil
        runtime.retry_ticks = 0
        return true
    end

    function runtime.refresh()
        if runtime.installed then return true, nil end
        if not is_placement_active() then
            return false, "blueprint placement is inactive"
        end
        if runtime.retry_ticks > 0 then
            runtime.retry_ticks = runtime.retry_ticks - 1
            return false, "camera key-guide retry pending"
        end
        local building_model = unwrap(get_building_model())
        if not is_valid_object(building_model) then
            return false, "placement building model unavailable"
        end
        if runtime.building_widget_handle == nil then
            return false, "current WBP_PalBuilding context not observed"
        end
        local hud = find_active_hud(building_model)
        if not is_valid_object(hud) then
            runtime.retry_ticks = 1
            return false, "active WBP_IngameConstruction_C not found"
        end
        local ok, error_value = install_into_hud(hud)
        if not ok and runtime.last_error ~= tostring(error_value) then
            runtime.last_error = tostring(error_value)
            log("blueprint placement camera key guide pending error="
                .. runtime.last_error)
        end
        if not ok then runtime.retry_ticks = 30 end
        return ok, error_value
    end

    function runtime.is_installed()
        return runtime.installed == true
    end

    return runtime
end

return BlueprintPlacementHUDKeyGuides

local BlueprintRuntimeBridge = {}

local CLASS_FULL_NAME =
    "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/"
        .. "ModActor.ModActor_C"
local FUNCTION_PATH_PREFIX =
    "/Game/Mods/BlueprintResearch/ModActor.ModActor_C:"
local HEALTHY_TICK_THRESHOLD = 180
local ACTIVATION_RETRY_INTERVAL = 30
local DEFAULT_HOOK_RETRY_DELAY_MS = 250
local DEFAULT_HOOK_RETRY_LIMIT = 40

function BlueprintRuntimeBridge.install(deps)
    assert(type(deps) == "table",
        "BlueprintRuntimeBridge dependencies are required")
    local log = assert(deps.log,
        "BlueprintRuntimeBridge log is required")
    local register_hook = assert(deps.register_hook,
        "BlueprintRuntimeBridge register_hook is required")
    local unwrap = assert(deps.unwrap,
        "BlueprintRuntimeBridge unwrap is required")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintRuntimeBridge is_valid_object is required")
    local safe_object_address = assert(deps.safe_object_address,
        "BlueprintRuntimeBridge safe_object_address is required")
    local object_name = assert(deps.object_name,
        "BlueprintRuntimeBridge object_name is required")
    local get_class_full_name = assert(deps.get_class_full_name,
        "BlueprintRuntimeBridge get_class_full_name is required")
    local get_player_controller = assert(deps.get_player_controller,
        "BlueprintRuntimeBridge get_player_controller is required")
    local read_property = assert(deps.read_property,
        "BlueprintRuntimeBridge read_property is required")
    local write_property = assert(deps.write_property,
        "BlueprintRuntimeBridge write_property is required")
    local set_tick_enabled = assert(deps.set_tick_enabled,
        "BlueprintRuntimeBridge set_tick_enabled is required")
    local schedule_retry = deps.schedule_retry
    local find_mod_actor_instances =
        deps.find_mod_actor_instances or function() return {} end
    local hook_retry_delay_ms = math.max(
        tonumber(deps.hook_retry_delay_ms)
            or DEFAULT_HOOK_RETRY_DELAY_MS,
        0
    )
    local hook_retry_limit = math.max(
        math.floor(
            tonumber(deps.hook_retry_limit)
                or DEFAULT_HOOK_RETRY_LIMIT
        ),
        1
    )

    -- This table intentionally contains scalar values only. In particular it
    -- never stores the ModActor, World, PlayerController or any UObject
    -- address. Every UObject below is local to one hook invocation.
    local controller = {
        generation_sequence = 0,
        active_generation = nil,
        active_tick_count = 0,
        begin_count = 0,
        end_count = 0,
        retry_tick_count = 0,
        healthy_reported = false,
        world_blocked = false,
        hook_begin_registered = false,
        hook_tick_registered = false,
        hook_end_registered = false,
        hook_install_attempts = 0,
        hook_install_pending = false,
        hook_install_terminal = false,
        bootstrap_count = 0,
    }

    local function write_runtime_property(context, name, value)
        local ok, result = pcall(
            write_property, context, name, value
        )
        return ok and result ~= false
    end

    local function read_runtime_property(context, name)
        local ok, result = pcall(read_property, context, name)
        if not ok then return nil end
        return result
    end

    local function get_context_world(context)
        context = unwrap(context)
        if not is_valid_object(context) then return nil end
        local ok, world = pcall(function()
            return unwrap(context:GetWorld())
        end)
        if not ok or not is_valid_object(world) then return nil end
        return world
    end

    local function context_is_eligible(context)
        context = unwrap(context)
        if not is_valid_object(context) then
            return false, "invalid-context"
        end
        if get_class_full_name(context) ~= CLASS_FULL_NAME then
            return false, "wrong-class"
        end

        local world = get_context_world(context)
        if not is_valid_object(world) then
            return false, "missing-world"
        end
        local world_name = tostring(object_name(world) or "")
        if not string.find(
                world_name, "/Game/Pal/Maps/MainWorld", 1, true) then
            return false, "not-main-world"
        end

        local player_controller = nil
        local player_ok = pcall(function()
            player_controller = unwrap(get_player_controller())
        end)
        if not player_ok or not is_valid_object(player_controller) then
            return false, "missing-local-player"
        end

        local player_world = nil
        local player_world_ok = pcall(function()
            player_world = unwrap(player_controller:GetWorld())
        end)
        if not player_world_ok or not is_valid_object(player_world)
            or safe_object_address(player_world)
                ~= safe_object_address(world) then
            return false, "local-player-world-mismatch"
        end
        return true, nil
    end

    local function try_activate(context, source)
        if controller.world_blocked then
            return false, "world-blocked"
        end

        local current_generation = tonumber(
            read_runtime_property(context, "SBB_RuntimeGeneration")
        )
        if controller.active_generation ~= nil then
            if current_generation == controller.active_generation then
                return true, nil
            end
            return false, "another-instance-is-authoritative"
        end

        local eligible, reason = context_is_eligible(context)
        if not eligible then return false, reason end

        controller.generation_sequence =
            controller.generation_sequence + 1
        local generation = controller.generation_sequence
        local writes_ok =
            write_runtime_property(
                context, "SBB_RuntimeGeneration", generation)
            and write_runtime_property(
                context, "SBB_RuntimeShadowMode", true)
            and write_runtime_property(
                context, "SBB_RuntimeAuthoritative", true)
            and write_runtime_property(
                context, "SBB_RuntimeActive", true)
        if not writes_ok then
            return false, "runtime-property-write-failed"
        end

        controller.active_generation = generation
        controller.active_tick_count = 0
        controller.retry_tick_count = 0
        controller.healthy_reported = false
        log("blueprint runtime bridge shadow begin generation="
            .. tostring(generation)
            .. " source=" .. tostring(source))
        return true, nil
    end

    local function on_runtime_begin(context)
        controller.begin_count = controller.begin_count + 1
        write_runtime_property(
            context, "SBB_RuntimeShadowMode", true)
        write_runtime_property(
            context, "SBB_RuntimeAuthoritative", false)
        write_runtime_property(
            context, "SBB_RuntimeActive", false)
        write_runtime_property(
            context, "SBB_RuntimeGeneration", 0)
        local _, reason = try_activate(context, "begin")
        if reason == "not-main-world" then
            pcall(set_tick_enabled, context, false)
        end
    end

    local function on_runtime_tick(context)
        if controller.world_blocked then return end

        local generation = tonumber(
            read_runtime_property(context, "SBB_RuntimeGeneration")
        )
        local active = read_runtime_property(
            context, "SBB_RuntimeActive")
        if controller.active_generation ~= nil
            and generation == controller.active_generation
            and active == true then
            controller.active_tick_count =
                controller.active_tick_count + 1
            if not controller.healthy_reported
                and controller.active_tick_count
                    >= HEALTHY_TICK_THRESHOLD then
                controller.healthy_reported = true
                log("blueprint runtime bridge shadow healthy generation="
                    .. tostring(generation)
                    .. " ticks="
                    .. tostring(controller.active_tick_count))
            end
            return
        end

        controller.retry_tick_count =
            controller.retry_tick_count + 1
        if controller.retry_tick_count
            < ACTIVATION_RETRY_INTERVAL then
            return
        end
        controller.retry_tick_count = 0
        local _, reason = try_activate(context, "tick-retry")
        if reason == "not-main-world" then
            pcall(set_tick_enabled, context, false)
        end
    end

    local function on_runtime_end(context)
        controller.end_count = controller.end_count + 1
        local generation = tonumber(
            read_runtime_property(context, "SBB_RuntimeGeneration")
        )
        if generation == nil
            or generation ~= controller.active_generation then
            return
        end

        log("blueprint runtime bridge shadow end generation="
            .. tostring(generation)
            .. " ticks="
            .. tostring(controller.active_tick_count))
        controller.active_generation = nil
        controller.active_tick_count = 0
        controller.retry_tick_count = 0
        controller.healthy_reported = false
    end

    function controller.abandon_world(reason)
        local previous_generation = controller.active_generation
        local previous_ticks = controller.active_tick_count
        controller.generation_sequence =
            controller.generation_sequence + 1
        controller.active_generation = nil
        controller.active_tick_count = 0
        controller.retry_tick_count = 0
        controller.healthy_reported = false
        controller.world_blocked = true
        if previous_generation ~= nil then
            log("blueprint runtime bridge shadow abandoned generation="
                .. tostring(previous_generation)
                .. " ticks=" .. tostring(previous_ticks)
                .. " reason=" .. tostring(reason))
        end
    end

    function controller.resume_world()
        controller.world_blocked = false
        controller.retry_tick_count =
            ACTIVATION_RETRY_INTERVAL - 1
    end

    function controller.get_diagnostics()
        return {
            generation_sequence = controller.generation_sequence,
            active_generation = controller.active_generation,
            active_tick_count = controller.active_tick_count,
            begin_count = controller.begin_count,
            end_count = controller.end_count,
            world_blocked = controller.world_blocked,
            healthy_reported = controller.healthy_reported,
            hook_begin_registered =
                controller.hook_begin_registered,
            hook_tick_registered =
                controller.hook_tick_registered,
            hook_end_registered =
                controller.hook_end_registered,
            hook_install_attempts =
                controller.hook_install_attempts,
            hook_install_pending =
                controller.hook_install_pending,
            hook_install_terminal =
                controller.hook_install_terminal,
            bootstrap_count = controller.bootstrap_count,
        }
    end

    local function hooks_are_ready()
        return controller.hook_begin_registered
            and controller.hook_tick_registered
            and controller.hook_end_registered
    end

    local function bootstrap_current_actor()
        local ok, candidates = pcall(find_mod_actor_instances)
        if not ok or type(candidates) ~= "table" then return false end
        for _, candidate_value in ipairs(candidates) do
            local candidate = unwrap(candidate_value)
            local eligible = context_is_eligible(candidate)
            if eligible then
                on_runtime_begin(candidate)
                controller.bootstrap_count =
                    controller.bootstrap_count + 1
                return true
            end
        end
        return false
    end

    local attempt_hook_install = nil
    local function schedule_hook_retry()
        if controller.hook_install_pending
            or controller.hook_install_terminal
            or hooks_are_ready() then
            return
        end
        if type(schedule_retry) ~= "function" then
            controller.hook_install_terminal = true
            log("blueprint runtime bridge hook installation failed: "
                .. "ModActor runtime functions are unavailable and "
                .. "no deferred installer was provided")
            return
        end

        controller.hook_install_pending = true
        local scheduled, schedule_error = schedule_retry(
            hook_retry_delay_ms,
            "runtime-bridge-hook-install",
            function()
                controller.hook_install_pending = false
                attempt_hook_install("deferred")
            end
        )
        if scheduled ~= true then
            controller.hook_install_pending = false
            controller.hook_install_terminal = true
            log("blueprint runtime bridge hook installation failed: "
                .. "deferred retry could not be scheduled error="
                .. tostring(schedule_error))
        end
    end

    attempt_hook_install = function(source)
        if controller.hook_install_terminal or hooks_are_ready() then
            return hooks_are_ready()
        end
        controller.hook_install_attempts =
            controller.hook_install_attempts + 1

        local quiet_options = { silent_failure = true }
        if not controller.hook_begin_registered then
            controller.hook_begin_registered = register_hook(
                FUNCTION_PATH_PREFIX .. "SBB_RuntimeBegin",
                on_runtime_begin,
                quiet_options
            ) == true
        end
        if not controller.hook_tick_registered then
            controller.hook_tick_registered = register_hook(
                FUNCTION_PATH_PREFIX .. "SBB_RuntimeTick",
                on_runtime_tick,
                quiet_options
            ) == true
        end
        if not controller.hook_end_registered then
            controller.hook_end_registered = register_hook(
                FUNCTION_PATH_PREFIX .. "SBB_RuntimeEnd",
                on_runtime_end,
                quiet_options
            ) == true
        end

        if hooks_are_ready() then
            if controller.hook_install_attempts > 1 then
                log("blueprint runtime bridge hooks ready after deferred "
                    .. "asset load attempts="
                    .. tostring(controller.hook_install_attempts)
                    .. " source=" .. tostring(source))
            end
            bootstrap_current_actor()
            return true
        end

        if controller.hook_install_attempts >= hook_retry_limit then
            controller.hook_install_terminal = true
            log("blueprint runtime bridge hook installation failed after "
                .. tostring(controller.hook_install_attempts)
                .. " attempts: BlueprintResearch LogicMod is missing, "
                .. "outdated, or could not be loaded")
            return false
        end
        schedule_hook_retry()
        return false
    end

    attempt_hook_install("initial")

    return controller
end

return BlueprintRuntimeBridge

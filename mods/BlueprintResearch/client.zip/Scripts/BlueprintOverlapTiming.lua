local BlueprintPerformance = require("BlueprintPerformance")

local BlueprintOverlapTiming = {}

local SAMPLE_LIMIT = 32768
local SLOW_MEMBER_LIMIT = 5

local function number(value)
    return tonumber(value) or 0.0
end

local function sample_bucket(probe, sample_name)
    if type(probe) ~= "table" then return nil end
    probe.samples = probe.samples or {}
    local bucket = probe.samples[sample_name]
    if bucket == nil then
        bucket = {
            count = 0,
            total_ms = 0.0,
            maximum_ms = 0.0,
            retained = {},
            dropped = 0,
        }
        probe.samples[sample_name] = bucket
    end
    return bucket
end

local function percentile(values, fraction)
    if type(values) ~= "table" or #values == 0 then return 0.0 end
    local ordered = {}
    for index, value in ipairs(values) do
        ordered[index] = number(value)
    end
    table.sort(ordered)
    local ordinal = math.ceil(#ordered * fraction)
    ordinal = math.max(1, math.min(ordinal, #ordered))
    return ordered[ordinal]
end

local function phase(probe, phase_name)
    if type(probe) ~= "table" then return 0.0 end
    return number((probe.phases or {})[phase_name])
end

local function counter(probe, counter_name)
    if type(probe) ~= "table" then return 0 end
    return math.floor(number((probe.counters or {})[counter_name]))
end

local function format_sample(probe, sample_name)
    local bucket = type(probe) == "table"
        and type(probe.samples) == "table"
        and probe.samples[sample_name] or nil
    if type(bucket) ~= "table" or bucket.count <= 0 then
        return {
            count = 0,
            total_ms = 0.0,
            average_ms = 0.0,
            p50_ms = 0.0,
            p95_ms = 0.0,
            maximum_ms = 0.0,
            dropped = 0,
        }
    end
    return {
        count = bucket.count,
        total_ms = bucket.total_ms,
        average_ms = bucket.total_ms / bucket.count,
        p50_ms = percentile(bucket.retained, 0.50),
        p95_ms = percentile(bucket.retained, 0.95),
        maximum_ms = bucket.maximum_ms,
        dropped = bucket.dropped,
    }
end

function BlueprintOverlapTiming.new(trigger, mode, building_count)
    return {
        started_at = BlueprintPerformance.now(),
        trigger = tostring(trigger or "unknown"),
        mode = tostring(mode or "unknown"),
        building_count = math.max(
            math.floor(number(building_count)), 0
        ),
        phases = {},
        counters = {},
        samples = {},
        members = {},
        context = {},
        finished = false,
    }
end

function BlueprintOverlapTiming.now(probe)
    if type(probe) ~= "table" then return nil end
    return BlueprintPerformance.now()
end

function BlueprintOverlapTiming.elapsed_ms(started_at)
    return BlueprintPerformance.elapsed_ms(started_at)
end

function BlueprintOverlapTiming.add_ms(probe, phase_name, elapsed_ms)
    if type(probe) ~= "table" or type(phase_name) ~= "string" then
        return 0.0
    end
    local elapsed = math.max(number(elapsed_ms), 0.0)
    probe.phases[phase_name] =
        number(probe.phases[phase_name]) + elapsed
    return elapsed
end

function BlueprintOverlapTiming.add_elapsed(
    probe, phase_name, started_at
)
    return BlueprintOverlapTiming.add_ms(
        probe, phase_name,
        BlueprintPerformance.elapsed_ms(started_at)
    )
end

function BlueprintOverlapTiming.phase_ms(probe, phase_name)
    return phase(probe, phase_name)
end

function BlueprintOverlapTiming.increment(probe, counter_name, amount)
    if type(probe) ~= "table" or type(counter_name) ~= "string" then
        return 0
    end
    local next_value = counter(probe, counter_name)
        + math.floor(number(amount == nil and 1 or amount))
    probe.counters[counter_name] = next_value
    return next_value
end

function BlueprintOverlapTiming.counter(probe, counter_name)
    return counter(probe, counter_name)
end

function BlueprintOverlapTiming.sample_ms(
    probe, sample_name, elapsed_ms
)
    local bucket = sample_bucket(probe, sample_name)
    if bucket == nil then return 0.0 end
    local elapsed = math.max(number(elapsed_ms), 0.0)
    bucket.count = bucket.count + 1
    bucket.total_ms = bucket.total_ms + elapsed
    bucket.maximum_ms = math.max(bucket.maximum_ms, elapsed)
    if #bucket.retained < SAMPLE_LIMIT then
        bucket.retained[#bucket.retained + 1] = elapsed
    else
        bucket.dropped = bucket.dropped + 1
    end
    return elapsed
end

function BlueprintOverlapTiming.sample_elapsed(
    probe, sample_name, started_at
)
    return BlueprintOverlapTiming.sample_ms(
        probe, sample_name,
        BlueprintPerformance.elapsed_ms(started_at)
    )
end

function BlueprintOverlapTiming.set_context(probe, key, value)
    if type(probe) ~= "table" or type(key) ~= "string" then return end
    probe.context[key] = value
end

function BlueprintOverlapTiming.record_member(probe, member)
    if type(probe) ~= "table" or type(member) ~= "table" then return end
    probe.members[#probe.members + 1] = {
        index = math.floor(number(member.index)),
        source_instance_id = tostring(
            member.source_instance_id or "<none>"
        ),
        build_object_id = tostring(
            member.build_object_id or "<unknown>"
        ),
        total_ms = math.max(number(member.total_ms), 0.0),
        classify_ms = math.max(number(member.classify_ms), 0.0),
        query_ms = math.max(number(member.query_ms), 0.0),
        candidate_count = math.max(
            math.floor(number(member.candidate_count)), 0
        ),
        pair_visits = math.max(
            math.floor(number(member.pair_visits)), 0
        ),
        blocked = member.blocked == true,
        preexisting = member.preexisting == true,
    }
    BlueprintOverlapTiming.sample_ms(
        probe, "member_total_ms", member.total_ms
    )
end

function BlueprintOverlapTiming.finish(probe, status, error_value)
    if type(probe) ~= "table" or probe.finished == true then return probe end
    probe.finished = true
    probe.status = tostring(status or "unknown")
    probe.error = error_value ~= nil and tostring(error_value) or nil
    probe.total_ms = BlueprintPerformance.elapsed_ms(probe.started_at)
    return probe
end

function BlueprintOverlapTiming.format_lines(probe)
    if type(probe) ~= "table" then return {} end
    local context = probe.context or {}
    local native_query = format_sample(probe, "native_query_ms")
    local snapshot = format_sample(probe, "snapshot_ms")
    local equivalence = format_sample(probe, "equivalence_ms")
    local member = format_sample(probe, "member_total_ms")
    local pair_visits = counter(probe, "component_pair_visits")
    local pair_scan_ms =
        phase(probe, "exact_scan_ms")
        + phase(probe, "blocker_scan_ms")
        + phase(probe, "surface_scan_ms")
    local pair_lua_ms = math.max(
        pair_scan_ms
            - phase(probe, "snapshot_ms")
            - phase(probe, "equivalence_ms"),
        0.0
    )
    local pair_average_ms = pair_visits > 0
        and pair_lua_ms / pair_visits or 0.0
    local preexisting_total_ms =
        phase(probe, "preexisting_expectations_ms")
        + phase(probe, "preexisting_query_ms")
        + phase(probe, "preexisting_snapshot_ms")
        + phase(probe, "preexisting_match_ms")
    local accounted_ms =
        phase(probe, "dependency_setup_ms")
        + preexisting_total_ms
        + phase(probe, "claim_index_ms")
        + phase(probe, "member_total_ms")
        + phase(probe, "tail_clear_ms")
        + phase(probe, "blocker_visual_clear_ms")
        + phase(probe, "finalize_ms")
    local unaccounted_ms = math.max(
        number(probe.total_ms) - accounted_ms, 0.0
    )

    local lines = {
        string.format(
            "blueprint overlap timing gate trigger=%s mode=%s status=%s totalMs=%.3f buildings=%d scanned=%d blockers=%d broadphaseCandidates=%d existingMatches=%d error=%s",
            tostring(probe.trigger), tostring(probe.mode),
            tostring(probe.status or "unfinished"),
            number(probe.total_ms), probe.building_count,
            math.floor(number(context.scanned_buildings)),
            math.floor(number(context.blocker_count)),
            math.floor(number(context.broadphase_candidates)),
            math.floor(number(context.existing_matches)),
            tostring(probe.error or "<none>")
        ),
        string.format(
            "blueprint overlap timing stages setup=%.3f preexisting=%.3f(expect=%.3f query=%.3f snapshot=%.3f match=%.3f actors=%d candidates=%d pairChecks=%d) claims=%.3f members=%.3f compose=%.3f classify=%.3f material=%.3f tail=%.3f blockerVisualClear=%.3f finalize=%.3f unaccounted=%.3f",
            phase(probe, "dependency_setup_ms"),
            preexisting_total_ms,
            phase(probe, "preexisting_expectations_ms"),
            phase(probe, "preexisting_query_ms"),
            phase(probe, "preexisting_snapshot_ms"),
            phase(probe, "preexisting_match_ms"),
            counter(probe, "preexisting_actor_count"),
            counter(probe, "preexisting_candidate_count"),
            counter(probe, "preexisting_pair_checks"),
            phase(probe, "claim_index_ms"),
            phase(probe, "member_total_ms"),
            phase(probe, "member_transform_ms"),
            phase(probe, "member_classify_ms"),
            phase(probe, "material_update_ms"),
            phase(probe, "tail_clear_ms"),
            phase(probe, "blocker_visual_clear_ms"),
            phase(probe, "finalize_ms"),
            unaccounted_ms
        ),
        string.format(
            "blueprint overlap timing nativeQueries count=%d totalMs=%.3f avgMs=%.4f p50Ms=%.3f p95Ms=%.3f maxMs=%.3f componentsReturned=%d sampleDropped=%d",
            native_query.count, native_query.total_ms,
            native_query.average_ms, native_query.p50_ms,
            native_query.p95_ms, native_query.maximum_ms,
            counter(probe, "native_query_components"),
            native_query.dropped
        ),
        string.format(
            "blueprint overlap timing candidatePairs visits=%d scanTotalMs=%.3f luaRemainderMs=%.3f derivedLuaAvgMs=%.5f snapshots=%d/%.3fms(avg=%.4f p95=%.3f max=%.3f) equivalence=%d/%.3fms(avg=%.4f p95=%.3f max=%.3f) blockerVisual=%.3fms",
            pair_visits, pair_scan_ms, pair_lua_ms,
            pair_average_ms,
            snapshot.count, snapshot.total_ms,
            snapshot.average_ms, snapshot.p95_ms,
            snapshot.maximum_ms,
            equivalence.count, equivalence.total_ms,
            equivalence.average_ms, equivalence.p95_ms,
            equivalence.maximum_ms,
            phase(probe, "blocker_visual_ms")
        ),
        string.format(
            "blueprint overlap timing memberDistribution count=%d totalMs=%.3f avgMs=%.4f p50Ms=%.3f p95Ms=%.3f maxMs=%.3f",
            member.count, member.total_ms, member.average_ms,
            member.p50_ms, member.p95_ms, member.maximum_ms
        ),
    }

    local ordered_members = {}
    for index, value in ipairs(probe.members or {}) do
        ordered_members[index] = value
    end
    table.sort(ordered_members, function(left, right)
        if left.total_ms ~= right.total_ms then
            return left.total_ms > right.total_ms
        end
        return left.index < right.index
    end)
    local slow = {}
    for index = 1, math.min(#ordered_members, SLOW_MEMBER_LIMIT) do
        local value = ordered_members[index]
        slow[#slow + 1] = string.format(
            "#%d:%s total=%.3f query=%.3f classify=%.3f candidates=%d visits=%d blocked=%s existing=%s",
            value.index, value.build_object_id,
            value.total_ms, value.query_ms, value.classify_ms,
            value.candidate_count, value.pair_visits,
            tostring(value.blocked), tostring(value.preexisting)
        )
    end
    lines[#lines + 1] =
        "blueprint overlap timing slowestMembers "
        .. (#slow > 0 and table.concat(slow, " | ") or "<none>")
    return lines
end

return BlueprintOverlapTiming

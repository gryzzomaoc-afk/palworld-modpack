local BlueprintSelectionHUD = {}

function BlueprintSelectionHUD.install(mode, deps)
    assert(type(mode) == "table", "BlueprintSelectionHUD requires a mode table")
    assert(type(deps) == "table", "BlueprintSelectionHUD requires dependencies")

    local UEHelpers = deps.UEHelpers
    local log = deps.log
    local unwrap = deps.unwrap
    local value_to_string = deps.value_to_string
    local object_name = deps.object_name
    local is_valid_object = deps.is_valid_object
    local is_usable_class_object = deps.is_usable_class_object
    local class_object_name = deps.class_object_name
    local safe_property = deps.safe_property
    local get_hud_widget = assert(
        deps.get_hud_widget,
        "BlueprintSelectionHUD requires get_hud_widget")
    local reticle_base_material_path =
        "/Game/Pal/Material/UI/Ingame/MI_UI_BaseSphereMask_02."
        .. "MI_UI_BaseSphereMask_02"

    local function find_hud_widget(instance, wanted_name)
        local direct = unwrap(safe_property(instance, wanted_name))
        if is_valid_object(direct) then return direct end

        local named_widget = nil
        pcall(function()
            named_widget = unwrap(instance:GetWidgetFromName(
                UEHelpers.FindOrAddFName(wanted_name)
            ))
        end)
        if is_valid_object(named_widget) then return named_widget end
        return nil
    end

    function mode.restore_hud_reticle_base(instance)
        local image = find_hud_widget(instance, "Mode_Image")
        if not is_valid_object(image) then
            return false, "Mode_Image unavailable"
        end

        -- PMK does not contain Palworld's original reticle material, so bind
        -- that one stock resource after this HUD instance is created.  The
        -- custom pencil texture itself is a cooked strong reference and needs
        -- no Lua lookup.  No reflected object is retained after this call.
        pcall(LoadAsset, reticle_base_material_path)
        local material = unwrap(StaticFindObject(reticle_base_material_path))
        if not is_valid_object(material) then
            return false, "original reticle base material unavailable"
        end
        local bind_ok, bind_error = pcall(function()
            image:SetBrushFromMaterial(material)
        end)
        if not bind_ok then
            return false, "reticle base material bind failed: "
                .. tostring(bind_error)
        end
        return true, nil
    end

    function mode.load_hud_class()
        -- Never retain a reflected class wrapper across selection sessions.
        -- Resolve the cooked class afresh, use it immediately in CreateWidget,
        -- and let the local reference go when show_hud returns.
        local package_ok, package_result = pcall(
            LoadAsset, mode.hud_package_path
        )

        -- AssetRegistryHelpers:GetAsset takes FAssetData and returns an
        -- ObjectProperty.  In a cooked game a Blueprint asset resolves here
        -- to the generated class used by SpawnActor/CreateWidget.  This exact
        -- package+asset lookup is the path that originally created this HUD
        -- successfully; unlike the old implementation, its result is not
        -- cached beyond the current show_hud call.
        local registry_ok, registry_result = pcall(function()
            local registry_helpers = unwrap(StaticFindObject(
                "/Script/AssetRegistry.Default__AssetRegistryHelpers"
            ))
            if not is_valid_object(registry_helpers) then return nil end
            return unwrap(registry_helpers:GetAsset({
                PackageName = UEHelpers.FindOrAddFName(mode.hud_package_path),
                AssetName = UEHelpers.FindOrAddFName(mode.hud_asset_name),
            }))
        end)
        local registry_class = unwrap(registry_result)
        if registry_ok and is_usable_class_object(registry_class) then
            return registry_class
        end

        local widget_class = unwrap(StaticFindObject(mode.hud_class_path))
        if is_usable_class_object(widget_class) then return widget_class end

        local returned_class = unwrap(package_result)
        if is_usable_class_object(returned_class) then
            local returned_name = tostring(class_object_name(returned_class))
            if string.find(
                returned_name, "BlueprintGeneratedClass", 1, true
            ) then
                return returned_class
            end
        end

        local generated_class = nil
        local asset = unwrap(package_result)
        if is_valid_object(asset) then
            generated_class = unwrap(safe_property(asset, "GeneratedClass"))
            if is_usable_class_object(generated_class) then
                return generated_class
            end
        end

        local find_ok, find_result = pcall(
            FindObject, "WidgetBlueprintGeneratedClass", mode.hud_class_name
        )
        local found_class = unwrap(find_result)
        if find_ok and is_usable_class_object(found_class) then
            return found_class
        end

        local class_find_ok, class_find_result = pcall(
            FindObject, "Class", mode.hud_class_name
        )
        found_class = unwrap(class_find_result)
        if class_find_ok and is_usable_class_object(found_class) then
            return found_class
        end

        if not mode.hud_load_diagnostic_emitted then
            mode.hud_load_diagnostic_emitted = true
            log("blueprint selection HUD asset load diagnostic package_ok="
                .. tostring(package_ok)
                .. " package_result="
                .. tostring(value_to_string(package_result))
                .. " exact_class=" .. tostring(class_object_name(widget_class))
                .. " generated_class="
                .. tostring(class_object_name(generated_class))
                .. " registry_ok=" .. tostring(registry_ok)
                .. " registry_result="
                .. tostring(class_object_name(registry_class))
                .. " find_ok=" .. tostring(find_ok)
                .. " find_result=" .. tostring(value_to_string(find_result))
                .. " class_find_ok=" .. tostring(class_find_ok)
                .. " class_find_result="
                .. tostring(value_to_string(class_find_result)))
        end
        return nil
    end

    function mode.hide_hud(reason, explicit_widget)
        local widget = unwrap(explicit_widget)
        if not is_valid_object(widget) then
            widget = unwrap(get_hud_widget())
        end
        if type(mode.clear_hud_target_name_handle) == "function" then
            mode.clear_hud_target_name_handle()
        end
        if type(mode.clear_hud_key_guide_cache) == "function" then
            mode.clear_hud_key_guide_cache()
        end
        if type(mode.clear_hud_material_cache) == "function" then
            mode.clear_hud_material_cache()
        end
        if not is_valid_object(widget) then return end

        local remove_ok, remove_error = pcall(function()
            widget:RemoveFromParent()
        end)
        if remove_ok then
            log("blueprint selection HUD removed reason=" .. tostring(reason))
        else
            log("blueprint selection HUD remove isolated error reason="
                .. tostring(reason) .. " error=" .. tostring(remove_error))
        end
    end

    function mode.show_hud(player_controller)
        player_controller = unwrap(player_controller)
        if not is_valid_object(player_controller) then
            return false, "local player controller unavailable"
        end

        mode.hide_hud("replace-before-show")
        local widget_class = mode.load_hud_class()
        local widget_library = unwrap(StaticFindObject(
            "/Script/UMG.Default__WidgetBlueprintLibrary"
        ))
        if not is_usable_class_object(widget_class) then
            return false, "cooked HUD class unavailable"
        end
        if not is_valid_object(widget_library) then
            return false, "UMG WidgetBlueprintLibrary unavailable"
        end

        local create_ok, instance = pcall(function()
            return unwrap(widget_library:Create(
                player_controller, widget_class, player_controller
            ))
        end)
        if not create_ok or not is_valid_object(instance) then
            return false, "CreateWidget failed: " .. tostring(instance)
        end

        -- The copied stock HUD contains Japanese culture-invariant placeholder
        -- text. Keep the complete tree hidden until the target name, key guides
        -- and material rows have been initialized so no untranslated frame can
        -- reach Slate.
        pcall(function() instance:SetVisibility(1) end)
        mode.update_hud_target_name(nil, "pre-show", instance)

        local attach_ok, attach_result = pcall(function()
            return instance:AddToPlayerScreen(50)
        end)
        local attach_method = "AddToPlayerScreen"
        if not attach_ok or attach_result == false then
            attach_method = "AddToViewport-fallback"
            attach_ok, attach_result = pcall(function()
                return instance:AddToViewport(50)
            end)
        end
        if not attach_ok or attach_result == false then
            pcall(function() instance:RemoveFromParent() end)
            return false,
                "viewport attachment failed: " .. tostring(attach_result)
        end

        local reticle_ok, reticle_error =
            mode.restore_hud_reticle_base(instance)
        if not reticle_ok then
            -- The mode remains usable if a game update moves this cosmetic
            -- stock material; report it without breaking selection input.
            log("selection HUD reticle base unavailable: "
                .. tostring(reticle_error))
        end
        if type(mode.setup_hud_escape_guard) == "function" then
            local guard_ok, guard_error = mode.setup_hud_escape_guard(instance)
            if not guard_ok then
                mode.hide_hud("escape-guard-unavailable", instance)
                return false, "CommonUI ESC guard unavailable: "
                    .. tostring(guard_error)
            end
        end
        if type(mode.setup_hud_key_guides) == "function" then
            local guide_ok, guide_error = mode.setup_hud_key_guides(
                instance, player_controller
            )
            if not guide_ok then
                -- The guide is supplemental.  Keep selection mode usable if
                -- a game update changes this stock UI class or placeholder.
                log("selection HUD stock key guide unavailable: "
                    .. tostring(guide_error))
            end
        end
        mode.update_hud_target_name(nil, "show", instance)
        pcall(function() instance:SetVisibility(0) end)
        log(string.format(
            "blueprint selection HUD shown method=%s widget=%s controller=%s",
            attach_method,
            object_name(instance),
            object_name(player_controller)
        ))
        return true, nil, instance
    end

    return mode
end

return BlueprintSelectionHUD

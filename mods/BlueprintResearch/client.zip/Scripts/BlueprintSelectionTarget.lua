local BlueprintSelectionTarget = {}

function BlueprintSelectionTarget.install(deps)
    assert(type(deps) == "table",
        "BlueprintSelectionTarget.install requires dependencies")

    local unwrap = assert(deps.unwrap,
        "BlueprintSelectionTarget requires unwrap")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintSelectionTarget requires is_valid_object")
    local safe_property = assert(deps.safe_property,
        "BlueprintSelectionTarget requires safe_property")
    local format_guid = assert(deps.format_guid,
        "BlueprintSelectionTarget requires format_guid")
    local find_valid_instance = assert(deps.find_valid_instance,
        "BlueprintSelectionTarget requires find_valid_instance")
    local get_selection_mode = assert(deps.get_selection_mode,
        "BlueprintSelectionTarget requires get_selection_mode")
    local get_independent_target = deps.get_independent_target

    local target = {}

    function target.get_dismantle_target(builder)
        builder = unwrap(builder)
        if not is_valid_object(builder) then return nil end
        local build_object = nil
        pcall(function()
            build_object = builder:GetDismantleTargetObject()
        end)
        build_object = unwrap(build_object)
        if not is_valid_object(build_object) then
            local checker = safe_property(builder, "DismantleChecker")
            pcall(function() build_object = checker:GetTargetObject() end)
            build_object = unwrap(build_object)
        end
        return build_object
    end

    function target.get_paint_target(builder)
        builder = unwrap(builder)
        if not is_valid_object(builder) then return nil end

        local build_object = nil
        pcall(function() build_object = builder:GetPaintTargetObject() end)
        build_object = unwrap(build_object)
        if not is_valid_object(build_object) then
            build_object = unwrap(safe_property(builder, "CurrentPaintTarget"))
        end
        if not is_valid_object(build_object) then
            local paint_model = nil
            pcall(function() paint_model = unwrap(builder:GetPaintModel()) end)
            build_object = unwrap(safe_property(paint_model, "TargetBuildObject"))
        end
        return build_object
    end

    function target.get_instance_id(build_object)
        build_object = unwrap(build_object)
        if not is_valid_object(build_object) then return nil end
        local model = nil
        pcall(function() model = build_object:GetModel() end)
        model = unwrap(model)
        if not is_valid_object(model) then return nil end
        local instance_id = format_guid(safe_property(model, "InstanceId"))
        if instance_id == "<nil>" or instance_id == "None"
            or instance_id == "00000000-00000000-00000000-00000000" then
            return nil
        end
        return instance_id
    end

    function target.is_dismantle_active(builder)
        builder = unwrap(builder)
        if not is_valid_object(builder) then return false end
        local ok, result = pcall(function() return builder:IsDismantling() end)
        return ok and result == true
    end

    function target.is_paint_active(builder)
        builder = unwrap(builder)
        if not is_valid_object(builder) then return false end
        local ok, result = pcall(function() return builder:IsInPaintingMode() end)
        return ok and result == true
    end

    function target.get_host_mode(builder)
        if target.is_paint_active(builder) then return "painting" end
        if target.is_dismantle_active(builder) then return "dismantle" end
        return nil
    end

    function target.is_host_mode_active(builder)
        return target.get_host_mode(builder) ~= nil
    end

    function target.get_current()
        local selection_mode = get_selection_mode()
        if type(selection_mode) == "table" and selection_mode.active then
            if type(get_independent_target) ~= "function" then
                return nil, nil
            end
            return nil, unwrap(get_independent_target())
        end

        local builder = find_valid_instance(
            "PalBuilderComponent", "/Game/Pal/Maps/"
        )
        if builder == nil then return nil, nil end

        local build_object = nil
        if target.is_paint_active(builder) then
            build_object = target.get_paint_target(builder)
        else
            build_object = target.get_dismantle_target(builder)
        end
        return builder, build_object
    end

    return target
end

return BlueprintSelectionTarget

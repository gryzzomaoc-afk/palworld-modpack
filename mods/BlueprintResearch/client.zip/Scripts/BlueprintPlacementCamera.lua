local BlueprintPlacementCamera = {}

function BlueprintPlacementCamera.install(deps)
    assert(type(deps) == "table",
        "BlueprintPlacementCamera dependencies are required")

    local UEHelpers = assert(
        deps.UEHelpers, "BlueprintPlacementCamera UEHelpers is required")
    local log = assert(
        deps.log, "BlueprintPlacementCamera log is required")
    local unwrap = assert(
        deps.unwrap, "BlueprintPlacementCamera unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object,
        "BlueprintPlacementCamera is_valid_object is required")
    local is_usable_class_object = assert(
        deps.is_usable_class_object,
        "BlueprintPlacementCamera is_usable_class_object is required")
    local safe_property = assert(
        deps.safe_property,
        "BlueprintPlacementCamera safe_property is required")
    local get_local_player_controller = assert(
        deps.get_local_player_controller,
        "BlueprintPlacementCamera get_local_player_controller is required")
    local runtime_backend = assert(
        deps.runtime_backend,
        "BlueprintPlacementCamera runtime_backend is required")
    local send_message = deps.send_message
    local on_restored = deps.on_restored
    local property_names = deps.property_names or {}
    local camera_property = property_names.camera
        or "SBB_PlacementCamera"
    local camera_active_property = property_names.camera_active
        or "SBB_PlacementCameraActive"
    local camera_class_property = property_names.camera_class
        or "SBB_PlacementCameraClass"
    local frozen_anchor_property = property_names.frozen_anchor
        or "SBB_PlacementAnchor"
    local runtime_label = tostring(
        deps.runtime_label or "blueprint placement"
    )
    local get_frozen_anchor = deps.get_frozen_anchor

    local controller = {}

    local function number_value(value)
        return tonumber(unwrap(value))
    end

    local function bool_value(value)
        return unwrap(value) == true
    end

    local function copy_ue_vector(value)
        value = unwrap(value)
        if value == nil then return nil end
        local x = number_value(safe_property(value, "X"))
        local y = number_value(safe_property(value, "Y"))
        local z = number_value(safe_property(value, "Z"))
        if x == nil or y == nil or z == nil then return nil end
        return { X = x, Y = y, Z = z }
    end

    local function copy_ue_quaternion(value)
        value = unwrap(value)
        if value == nil then return nil end
        local x = number_value(safe_property(value, "X"))
        local y = number_value(safe_property(value, "Y"))
        local z = number_value(safe_property(value, "Z"))
        local w = number_value(safe_property(value, "W"))
        if x == nil or y == nil or z == nil or w == nil then return nil end
        return { X = x, Y = y, Z = z, W = w }
    end

    local function copy_ue_rotator(value)
        value = unwrap(value)
        if value == nil then return nil end
        local pitch = number_value(safe_property(value, "Pitch"))
        local yaw = number_value(safe_property(value, "Yaw"))
        local roll = number_value(safe_property(value, "Roll"))
        if pitch == nil or yaw == nil or roll == nil then return nil end
        return { Pitch = pitch, Yaw = yaw, Roll = roll }
    end

    local function copy_ue_transform(value)
        value = unwrap(value)
        if value == nil then return nil end
        local translation = copy_ue_vector(
            safe_property(value, "Translation")
        )
        local rotation = copy_ue_quaternion(
            safe_property(value, "Rotation")
        )
        local scale = copy_ue_vector(safe_property(value, "Scale3D"))
        if translation == nil or rotation == nil or scale == nil then
            return nil
        end
        return {
            Translation = translation,
            Rotation = rotation,
            Scale3D = scale,
        }
    end

    local function notify(message_key)
        if type(send_message) == "function" then
            pcall(send_message, message_key)
        end
    end

    local function is_inside_base_camp(player_pawn)
        local component = unwrap(safe_property(
            player_pawn, "InsideBaseCampCheckComponent"
        ))
        if not is_valid_object(component) then return false end
        local ok, result = pcall(function()
            return component:IsInsideBaseCamp()
        end)
        return ok and bool_value(result)
    end

    local function write(value, property_name, property_value)
        value = unwrap(value)
        if not is_valid_object(value) then return false end
        local ok = pcall(function()
            value[property_name] = property_value
        end)
        return ok
    end

    local function get_camera(session)
        session = unwrap(session)
        if not is_valid_object(session) then return nil end
        local camera = unwrap(safe_property(
            session, camera_property
        ))
        if not is_valid_object(camera) then return nil end
        return camera
    end

    function controller.is_active(session)
        session = unwrap(session)
        return is_valid_object(session)
            and safe_property(
                session, camera_active_property
            ) == true
            and get_camera(session) ~= nil
    end

    function controller.matches_camera(session, camera)
        local active_camera = get_camera(session)
        camera = unwrap(camera)
        if not is_valid_object(active_camera)
            or not is_valid_object(camera) then
            return false
        end
        local left, right = nil, nil
        pcall(function() left = active_camera:GetAddress() end)
        pcall(function() right = camera:GetAddress() end)
        return left ~= nil and left == right
    end

    local function fallback_restore(camera)
        local player_controller = unwrap(safe_property(
            camera, "SBB_CameraController"
        ))
        local player_pawn = unwrap(safe_property(
            camera, "SBB_CameraPawn"
        ))
        local movement = unwrap(safe_property(
            camera, "SBB_CameraMovement"
        ))
        local view_target = unwrap(safe_property(
            camera, "SBB_OriginalViewTarget"
        ))
        local control_rotation = safe_property(
            camera, "SBB_OriginalControlRotation"
        )
        local pawn_transform = safe_property(
            camera, "SBB_OriginalPawnTransform"
        )
        local movement_mode = number_value(safe_property(
            camera, "SBB_OriginalMovementMode"
        ))
        local custom_mode = number_value(safe_property(
            camera, "SBB_OriginalCustomMovementMode"
        )) or 0

        if is_valid_object(player_controller)
            and is_valid_object(view_target) then
            pcall(function()
                player_controller:SetViewTargetWithBlend(
                    view_target, 0.0, 0, 0.0, false
                )
            end)
        end
        if is_valid_object(player_controller)
            and control_rotation ~= nil then
            pcall(function()
                player_controller:SetControlRotation(control_rotation)
            end)
        end
        if is_valid_object(player_pawn)
            and pawn_transform ~= nil then
            pcall(function()
                player_pawn:K2_SetActorTransform(
                    pawn_transform, false, {}, true
                )
            end)
        end
        if is_valid_object(movement) and movement_mode ~= nil then
            pcall(function()
                movement:SetMovementMode(movement_mode, custom_mode)
            end)
        end
        if is_valid_object(player_controller) then
            pcall(function()
                player_controller:SetIgnoreMoveInput(false)
            end)
        end
        if is_valid_object(player_pawn)
            and is_valid_object(player_controller) then
            pcall(function()
                player_pawn:EnableInput(player_controller)
            end)
        end
    end

    function controller.exit(session, input_actor, reason)
        session = unwrap(session)
        input_actor = unwrap(input_actor)
        if not is_valid_object(session) then return true end

        local camera = get_camera(session)
        write(session, camera_active_property, false)
        if is_valid_object(camera) then
            local restore_ok, restore_error = pcall(function()
                camera:SBB_RestorePlacementCamera()
            end)
            if not restore_ok then
                log(runtime_label .. " native camera restore failed; "
                    .. "using one-shot fallback error="
                    .. tostring(restore_error))
                fallback_restore(camera)
            end

            local player_controller = unwrap(safe_property(
                camera, "SBB_CameraController"
            ))
            pcall(function()
                if is_valid_object(player_controller) then
                    camera:DisableInput(player_controller)
                end
            end)
            pcall(function() camera:K2_DestroyActor() end)

            -- EnableInput on the pawn pushes it back onto the legacy input
            -- stack. Re-push the placement session once so LMB/CapsLock keep
            -- their established priority for the remainder of placement.
            if is_valid_object(input_actor)
                and is_valid_object(player_controller) then
                pcall(function()
                    input_actor:DisableInput(player_controller)
                    input_actor:EnableInput(player_controller)
                end)
            end
        end
        write(session, camera_property, nil)
        local resumed, resume_error =
            runtime_backend.set_tick_paused(session, false)
        if not resumed then
            log(runtime_label .. " session Tick resume failed error="
                .. tostring(resume_error))
        end
        if type(on_restored) == "function" then
            pcall(on_restored, tostring(reason))
        end
        log(runtime_label .. " native camera restored reason="
            .. tostring(reason))
        return true
    end

    function controller.enter(session, input_actor)
        session = unwrap(session)
        input_actor = unwrap(input_actor)
        if not is_valid_object(session)
            or not runtime_backend.is_current_session(session) then
            return false, runtime_label .. " session is unavailable"
        end
        if controller.is_active(session) then return true end

        local player_controller = unwrap(
            get_local_player_controller()
        )
        local player_pawn = unwrap(safe_property(
            player_controller, "Pawn"
        ))
        local camera_manager = unwrap(safe_property(
            player_controller, "PlayerCameraManager"
        ))
        local movement = unwrap(safe_property(
            player_pawn, "CharacterMovement"
        ))
        local anchor = nil
        if type(get_frozen_anchor) == "function" then
            local anchor_ok, anchor_value = pcall(
                get_frozen_anchor, session
            )
            if anchor_ok then anchor = unwrap(anchor_value) end
        else
            anchor = unwrap(safe_property(
                session, frozen_anchor_property
            ))
        end
        local world = unwrap(UEHelpers.GetWorld())
        local camera_class = unwrap(safe_property(
            session, camera_class_property
        ))
        if not is_valid_object(player_controller)
            or not is_valid_object(player_pawn)
            or not is_valid_object(camera_manager)
            or not is_valid_object(movement)
            or not is_valid_object(anchor)
            or not is_valid_object(world)
            or not is_usable_class_object(camera_class) then
            notify("message.camera.start_failed")
            return false, runtime_label
                .. " camera runtime context is unavailable"
        end
        if not is_inside_base_camp(player_pawn) then
            notify("message.camera.base_only")
            return false, runtime_label .. " camera is base-only"
        end

        local camera_location, camera_rotation = nil, nil
        local pawn_transform, anchor_transform = nil, nil
        local original_view_target, original_control_rotation = nil, nil
        local movement_mode, custom_mode, fov = nil, nil, nil
        local snapshot_ok, snapshot_error = pcall(function()
            camera_location = copy_ue_vector(
                camera_manager:GetCameraLocation()
            )
            camera_rotation = copy_ue_rotator(
                camera_manager:GetCameraRotation()
            )
            pawn_transform = copy_ue_transform(
                player_pawn:GetTransform()
            )
            anchor_transform = copy_ue_transform(anchor:GetTransform())
            original_view_target = unwrap(
                player_controller:GetViewTarget()
            )
            original_control_rotation = copy_ue_rotator(
                player_controller:GetControlRotation()
            )
            movement_mode = number_value(safe_property(
                movement, "MovementMode"
            ))
            custom_mode = number_value(safe_property(
                movement, "CustomMovementMode"
            )) or 0
            fov = number_value(camera_manager:GetFOVAngle())
        end)
        if not snapshot_ok or camera_location == nil
            or camera_rotation == nil or pawn_transform == nil
            or anchor_transform == nil
            or not is_valid_object(original_view_target)
            or original_control_rotation == nil
            or movement_mode == nil then
            notify("message.camera.start_failed")
            return false, runtime_label .. " camera snapshot failed: "
                .. tostring(snapshot_error)
        end

        local camera = nil
        local spawn_ok, spawn_error = pcall(function()
            camera = unwrap(world:SpawnActor(camera_class, {}, {}))
        end)
        if not spawn_ok or not is_valid_object(camera) then
            notify("message.camera.start_failed")
            return false, runtime_label .. " camera spawn failed: "
                .. tostring(spawn_error)
        end

        local configured = false
        local configure_ok, configure_error = pcall(function()
            camera:K2_SetActorLocationAndRotation(
                camera_location, camera_rotation, false, {}, true
            )
            local component = unwrap(safe_property(
                camera, "CameraComponent"
            ))
            if is_valid_object(component) and fov ~= nil then
                component.FieldOfView = fov
            end

            camera.SBB_CameraController = player_controller
            camera.SBB_CameraPawn = player_pawn
            camera.SBB_CameraMovement = movement
            camera.SBB_OriginalViewTarget = original_view_target
            camera.SBB_FrozenAnchor = anchor
            camera.SBB_CameraOrigin = pawn_transform.Translation
            camera.SBB_OriginalPawnTransform = pawn_transform
            camera.SBB_FrozenAnchorTransform = anchor_transform
            camera.SBB_OriginalControlRotation =
                original_control_rotation
            camera.SBB_OriginalMovementMode = movement_mode
            camera.SBB_OriginalCustomMovementMode = custom_mode
            camera.SBB_CurrentMoveSpeed = 1200.0

            session[camera_property] = camera
            session[camera_active_property] = true
            local paused, pause_error =
                runtime_backend.set_tick_paused(session, true)
            if not paused then
                error(runtime_label .. " session Tick pause failed: "
                    .. tostring(pause_error))
            end

            player_pawn:DisableInput(player_controller)
            player_controller:SetIgnoreMoveInput(true)
            movement:SetMovementMode(0, 0)
            player_controller:SetControlRotation(camera_rotation)
            camera:EnableInput(player_controller)
            player_controller:SetViewTargetWithBlend(
                camera, 0.0, 0, 0.0, false
            )
            configured = true
        end)
        if not configure_ok or not configured then
            log(runtime_label .. " native camera activation failed error="
                .. tostring(configure_error))
            controller.exit(session, input_actor, "activation-failed")
            notify("message.camera.start_failed")
            return false, tostring(configure_error)
        end

        log(runtime_label .. " native camera entered backend="
            .. "ue-blueprint-actor-tick maxDistance=5000")
        return true
    end

    function controller.abandon_world()
        -- No Lua-side UObject survives a call. The placement session and
        -- camera Actor are both destroyed with their World.
        return true
    end

    return controller
end

return BlueprintPlacementCamera

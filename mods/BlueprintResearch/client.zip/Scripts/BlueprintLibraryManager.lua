local Json = require("BlueprintCodeCodec")

local BlueprintLibraryManager = {}

local MANAGER_CLASS_PATH =
    "/Game/Mods/BlueprintResearch/BP_SBBBlueprintLibraryManager."
        .. "BP_SBBBlueprintLibraryManager_C"
local MANAGER_OBJECT_NAME = "SBB_BlueprintLibraryManager"
local RENDERING_LIBRARY_PATH =
    "/Script/Engine.Default__KismetRenderingLibrary"
-- RF_Transient | RF_MarkAsRootSet. The GameInstance is the semantic owner;
-- the root flag makes the dynamically constructed UObject an explicit GC
-- root because UObject Outer relationships alone are not strong references.
local MANAGER_OBJECT_FLAGS = 0x40 | 0x80
local PREWARM_INTERVAL_MS = 16

function BlueprintLibraryManager.install(deps)
    assert(type(deps) == "table",
        "BlueprintLibraryManager dependencies are required")
    local UEHelpers = assert(
        deps.UEHelpers, "BlueprintLibraryManager UEHelpers is required"
    )
    local log = assert(deps.log,
        "BlueprintLibraryManager log is required")
    local unwrap = assert(deps.unwrap,
        "BlueprintLibraryManager unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object,
        "BlueprintLibraryManager is_valid_object is required"
    )
    local is_usable_class_object = assert(
        deps.is_usable_class_object,
        "BlueprintLibraryManager is_usable_class_object is required"
    )
    local value_to_string = assert(
        deps.value_to_string,
        "BlueprintLibraryManager value_to_string is required"
    )
    local scheduler = assert(
        deps.scheduler, "BlueprintLibraryManager scheduler is required"
    )
    local find_object = deps.find_object or StaticFindObject
    local construct_object = deps.construct_object or StaticConstructObject
    local make_name = deps.make_name or FName

    local manager = {
        borrowed_instance = nil,
        prewarm_generation = 0,
        prewarm_pending = 0,
        ready_address = nil,
    }

    local function current_game_instance()
        local instance = unwrap(UEHelpers.GetGameInstance())
        if not is_valid_object(instance) then
            return nil, "GameInstance is unavailable"
        end
        return instance, nil
    end

    local function instance_outer_matches(instance, game_instance)
        if not is_valid_object(instance)
            or not is_valid_object(game_instance) then
            return false
        end
        local outer = nil
        local ok = pcall(function()
            outer = unwrap(instance:GetOuter())
        end)
        if not ok or not is_valid_object(outer) then return false end
        local outer_address = nil
        local game_instance_address = nil
        pcall(function() outer_address = tostring(outer:GetAddress()) end)
        pcall(function()
            game_instance_address = tostring(game_instance:GetAddress())
        end)
        return outer_address ~= nil
            and outer_address == game_instance_address
    end

    local function resolve_class()
        local class = unwrap(find_object(MANAGER_CLASS_PATH))
        if not is_usable_class_object(class) then
            return nil, "Blueprint Library Manager class is unavailable"
        end
        return class, nil
    end

    local function find_existing(class, game_instance)
        local existing = unwrap(find_object(
            class, game_instance, MANAGER_OBJECT_NAME, true
        ))
        if is_valid_object(existing)
            and instance_outer_matches(existing, game_instance) then
            return existing
        end
        return nil
    end

    function manager.ensure_instance()
        local game_instance, game_instance_error = current_game_instance()
        if game_instance == nil then return nil, game_instance_error end
        if instance_outer_matches(
                manager.borrowed_instance, game_instance
            ) then
            return manager.borrowed_instance, nil
        end

        local class, class_error = resolve_class()
        if class == nil then return nil, class_error end
        local existing = find_existing(class, game_instance)
        if existing == nil then
            local constructed = nil
            local construct_ok, construct_error = pcall(function()
                constructed = unwrap(construct_object(
                    class,
                    game_instance,
                    make_name(MANAGER_OBJECT_NAME),
                    MANAGER_OBJECT_FLAGS,
                    0,
                    nil,
                    false,
                    false,
                    nil
                ))
            end)
            if not construct_ok or not is_valid_object(constructed) then
                return nil, "Blueprint Library Manager construction failed: "
                    .. tostring(construct_error)
            end
            existing = constructed
        end
        if not instance_outer_matches(existing, game_instance) then
            return nil, "Blueprint Library Manager has the wrong Outer"
        end
        manager.borrowed_instance = existing
        return existing, nil
    end

    function manager.initialize()
        local instance, error_value = manager.ensure_instance()
        if instance == nil then
            log("blueprint library UE manager unavailable; using Lua/file "
                .. "fallback error=" .. tostring(error_value))
            return false, error_value
        end
        local address = tostring(instance)
        pcall(function() address = tostring(instance:GetAddress()) end)
        if manager.ready_address ~= address then
            manager.ready_address = address
            log("blueprint library UE manager initialized "
                .. "ownership=game-instance textureCache=ue-tmap")
        end
        return true, nil
    end

    function manager.publish_index(index)
        local instance, instance_error = manager.ensure_instance()
        if instance == nil then return false, instance_error end
        local json, encode_error = Json.encode_json(index)
        if json == nil then return false, encode_error end
        local published, publish_error = pcall(function()
            local revision = tonumber(instance.SBB_LibraryRevision) or 0
            instance.SBB_LibraryIndexJson = json
            instance.SBB_LibraryRevision = revision + 1
            instance.SBB_LibraryInitialized = true
        end)
        if not published then return false, tostring(publish_error) end
        return true, nil
    end

    function manager.read_index()
        local instance, instance_error = manager.ensure_instance()
        if instance == nil then return nil, instance_error end
        local json = value_to_string(instance.SBB_LibraryIndexJson)
        if type(json) ~= "string" or json == "" or json == "<nil>" then
            return nil, "Blueprint Library Manager index is empty"
        end
        return Json.decode_json(json)
    end

    local function get_thumbnail_map(instance)
        local cache = nil
        local ok, error_value = pcall(function()
            cache = instance.SBB_ThumbnailCache
        end)
        if not ok or cache == nil then
            return nil, tostring(error_value or "thumbnail cache is unavailable")
        end
        return cache, nil
    end

    function manager.get_thumbnail(entry_id)
        entry_id = tostring(entry_id or "")
        if entry_id == "" then return nil end
        local instance = manager.ensure_instance()
        if instance == nil then return nil end
        local cache = get_thumbnail_map(instance)
        if cache == nil then return nil end
        local contains = false
        local contains_ok = pcall(function()
            contains = cache:Contains(entry_id) == true
        end)
        if not contains_ok or not contains then return nil end
        local resource = nil
        local found = pcall(function()
            resource = unwrap(cache:Find(entry_id))
        end)
        if found and is_valid_object(resource) then return resource end
        pcall(function() cache:Remove(entry_id) end)
        return nil
    end

    function manager.put_thumbnail(entry_id, resource)
        entry_id = tostring(entry_id or "")
        resource = unwrap(resource)
        if entry_id == "" or not is_valid_object(resource) then
            return false, "thumbnail cache input is invalid"
        end
        local instance, instance_error = manager.ensure_instance()
        if instance == nil then return false, instance_error end
        local cache, cache_error = get_thumbnail_map(instance)
        if cache == nil then return false, cache_error end
        local added, add_error = pcall(function()
            cache:Add(entry_id, resource)
        end)
        if not added then return false, tostring(add_error) end
        return true, nil
    end

    function manager.remove_thumbnail(entry_id)
        entry_id = tostring(entry_id or "")
        if entry_id == "" then return false end
        local instance = manager.ensure_instance()
        if instance == nil then return false end
        local cache = get_thumbnail_map(instance)
        if cache == nil then return false end
        return pcall(function() cache:Remove(entry_id) end)
    end

    local function import_thumbnail(path)
        local instance = manager.ensure_instance()
        if instance == nil then return nil end
        local rendering_library = unwrap(find_object(RENDERING_LIBRARY_PATH))
        if not is_valid_object(rendering_library) then return nil end
        local texture = nil
        local imported = pcall(function()
            texture = unwrap(rendering_library:ImportFileAsTexture2D(
                instance, path
            ))
        end)
        if imported and is_valid_object(texture) then return texture end
        return nil
    end

    function manager.prewarm(entries, get_thumbnail_path)
        if type(entries) ~= "table"
            or type(get_thumbnail_path) ~= "function" then
            return false, "thumbnail prewarm input is invalid"
        end
        if manager.ensure_instance() == nil then
            return false, "Blueprint Library Manager is unavailable"
        end

        manager.prewarm_generation = manager.prewarm_generation + 1
        local generation = manager.prewarm_generation
        local queue = {}
        for _, entry in ipairs(entries) do
            if type(entry) == "table"
                and entry.thumbnail_state == "ready"
                and manager.get_thumbnail(entry.id) == nil then
                local path = get_thumbnail_path(entry.id)
                if type(path) == "string" and path ~= "" then
                    queue[#queue + 1] = {
                        id = tostring(entry.id),
                        path = path,
                    }
                end
            end
        end
        manager.prewarm_pending = #queue
        if #queue == 0 then return true, nil end

        local next_index = 1
        local schedule_next = nil
        schedule_next = function()
            if generation ~= manager.prewarm_generation then return end
            if next_index > #queue then
                manager.prewarm_pending = 0
                log("blueprint library thumbnail cache warmed entries="
                    .. tostring(#queue))
                return
            end
            local queued = queue[next_index]
            next_index = next_index + 1
            scheduler.game_thread(
                PREWARM_INTERVAL_MS,
                "blueprint-library-thumbnail-prewarm",
                function()
                    if generation ~= manager.prewarm_generation then return end
                    if manager.get_thumbnail(queued.id) == nil then
                        local texture = import_thumbnail(queued.path)
                        if texture ~= nil then
                            manager.put_thumbnail(queued.id, texture)
                        end
                    end
                    manager.prewarm_pending = math.max(
                        #queue - next_index + 1, 0
                    )
                    schedule_next()
                end,
                { survive_world = true }
            )
        end
        schedule_next()
        return true, nil
    end

    function manager.get_state()
        return {
            available = manager.ensure_instance() ~= nil,
            prewarm_generation = manager.prewarm_generation,
            prewarm_pending = manager.prewarm_pending,
        }
    end

    return manager
end

return BlueprintLibraryManager

local BlueprintJsonSchema = require("BlueprintJsonSchema")
local BlueprintTransport = require("BlueprintTransport")
local BlueprintPerformance = require("BlueprintPerformance")

local BlueprintClipboard = {}

function BlueprintClipboard.install(deps)
    assert(type(deps) == "table", "BlueprintClipboard dependencies are required")
    local unwrap = assert(deps.unwrap, "BlueprintClipboard unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object, "BlueprintClipboard is_valid_object is required"
    )

    local function get_pal_utility()
        return unwrap(StaticFindObject("/Script/Pal.Default__PalUtility"))
    end

    function BlueprintClipboard.encode(compact_blueprint)
        local total_started_at = BlueprintPerformance.now()
        local phase_started_at = BlueprintPerformance.now()
        local json, stats_or_error = BlueprintJsonSchema.encode(compact_blueprint)
        if json == nil then
            return nil, "blueprint JSON encode failed: " .. tostring(stats_or_error)
        end
        local json_encode_ms = BlueprintPerformance.elapsed_ms(phase_started_at)
        phase_started_at = BlueprintPerformance.now()
        local code, transport_stats_or_error = BlueprintTransport.encode_json(json)
        if code == nil then
            return nil, "blueprint PWB9D encode failed: "
                .. tostring(transport_stats_or_error)
        end
        local transport_encode_ms = BlueprintPerformance.elapsed_ms(phase_started_at)
        transport_stats_or_error.performance = {
            json_encode_ms = json_encode_ms,
            transport_encode_ms = transport_encode_ms,
            total_ms = BlueprintPerformance.elapsed_ms(total_started_at),
        }
        return code, transport_stats_or_error
    end

    function BlueprintClipboard.copy_text(text)
        if type(text) ~= "string" or text == "" then
            return false, "clipboard text is empty"
        end
        local utility = get_pal_utility()
        if not is_valid_object(utility) then
            return false, "PalUtility clipboard writer is unavailable"
        end
        local phase_started_at = BlueprintPerformance.now()
        local call_ok, copy_result = pcall(function()
            return utility:ClipboardCopy(text)
        end)
        if not call_ok then
            return false, "PalUtility.ClipboardCopy failed: " .. tostring(copy_result)
        end
        if copy_result ~= true then
            return false, "PalUtility.ClipboardCopy returned false"
        end
        return true, {
            clipboard_copy_ms = BlueprintPerformance.elapsed_ms(phase_started_at),
        }
    end

    function BlueprintClipboard.export(compact_blueprint)
        local total_started_at = BlueprintPerformance.now()
        local code, stats_or_error = BlueprintClipboard.encode(compact_blueprint)
        if code == nil then return false, stats_or_error end
        local copied, copy_stats_or_error = BlueprintClipboard.copy_text(code)
        if not copied then return false, copy_stats_or_error end
        stats_or_error.performance = stats_or_error.performance or {}
        stats_or_error.performance.clipboard_copy_ms =
            copy_stats_or_error.clipboard_copy_ms
        stats_or_error.performance.total_ms =
            BlueprintPerformance.elapsed_ms(total_started_at)
        return true, stats_or_error
    end

    function BlueprintClipboard.read_text()
        local utility = get_pal_utility()
        if not is_valid_object(utility) then
            return nil, "PalUtility clipboard reader is unavailable"
        end
        -- UE4SS non-struct out parameters are supplied as Lua tables. The call
        -- writes the FString to a field with the reflected parameter name.
        local out_string = {}
        local call_ok, read_result = pcall(function()
            return utility:GetClipboard(out_string)
        end)
        if not call_ok then
            return nil, "PalUtility.GetClipboard failed: " .. tostring(read_result)
        end
        if read_result ~= true then
            return nil, "PalUtility.GetClipboard returned false"
        end
        local text_value = out_string.String
        if type(text_value) == "string" then return text_value, nil end
        if text_value ~= nil then
            local convert_ok, converted = pcall(function()
                return text_value:ToString()
            end)
            if convert_ok and type(converted) == "string" then
                return converted, nil
            end
        end
        return nil, "PalUtility.GetClipboard returned no FString output"
    end

    function BlueprintClipboard.decode_text(clipboard_text)
        local total_started_at = BlueprintPerformance.now()
        local phase_started_at = BlueprintPerformance.now()
        if type(clipboard_text) ~= "string" or clipboard_text == "" then
            return nil, "blueprint text is empty"
        end
        local json = clipboard_text
        local transport_stats = {
            transport = "raw-json-compat",
            json_bytes = #clipboard_text,
            compressed_bytes = 0,
            frame_bytes = 0,
            code_chars = #clipboard_text,
        }
        if BlueprintTransport.is_code(clipboard_text) then
            phase_started_at = BlueprintPerformance.now()
            local decoded_json, decode_stats_or_error =
                BlueprintTransport.decode_code(clipboard_text)
            if decoded_json == nil then
                return nil, "blueprint PWB9D decode failed: "
                    .. tostring(decode_stats_or_error)
            end
            json = decoded_json
            transport_stats = decode_stats_or_error
            transport_stats.performance = transport_stats.performance or {}
            transport_stats.performance.transport_decode_ms =
                BlueprintPerformance.elapsed_ms(phase_started_at)
        end
        phase_started_at = BlueprintPerformance.now()
        local compact_blueprint, stats_or_error = BlueprintJsonSchema.decode(json)
        if compact_blueprint == nil then
            return nil, "blueprint JSON decode failed: " .. tostring(stats_or_error)
        end
        transport_stats.json_bytes = stats_or_error.json_bytes
        transport_stats.performance = transport_stats.performance or {}
        transport_stats.performance.json_decode_ms =
            BlueprintPerformance.elapsed_ms(phase_started_at)
        transport_stats.performance.total_ms =
            BlueprintPerformance.elapsed_ms(total_started_at)
        return compact_blueprint, transport_stats
    end

    function BlueprintClipboard.import()
        local total_started_at = BlueprintPerformance.now()
        local phase_started_at = BlueprintPerformance.now()
        local clipboard_text, read_error = BlueprintClipboard.read_text()
        if clipboard_text == nil then return nil, read_error end
        local clipboard_read_ms = BlueprintPerformance.elapsed_ms(phase_started_at)
        local compact_blueprint, stats_or_error =
            BlueprintClipboard.decode_text(clipboard_text)
        if compact_blueprint == nil then return nil, stats_or_error end
        stats_or_error.performance = stats_or_error.performance or {}
        stats_or_error.performance.clipboard_read_ms = clipboard_read_ms
        stats_or_error.performance.total_ms =
            BlueprintPerformance.elapsed_ms(total_started_at)
        return compact_blueprint, stats_or_error
    end

    return BlueprintClipboard
end

return BlueprintClipboard

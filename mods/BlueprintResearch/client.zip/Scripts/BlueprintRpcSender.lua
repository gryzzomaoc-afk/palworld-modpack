local BlueprintRpcSender = {}

local function assert_state(state)
    assert(type(state) == "table", "sender state is required")
    assert(type(state.queue) == "table", "sender queue is required")
end

local function compact_queue(state)
    local head = tonumber(state.queue_head) or 1
    if head <= 32 or head <= (#state.queue / 2) then return end

    local compacted = {}
    for index = head, #state.queue do
        compacted[#compacted + 1] = state.queue[index]
    end
    state.queue = compacted
    state.queue_head = 1
end

function BlueprintRpcSender.new(options)
    options = options or {}
    return {
        world_generation = tonumber(options.world_generation) or 0,
        queue = {},
        queue_head = 1,
        current = nil,
        next_token = 0,
        closed = false,
    }
end

function BlueprintRpcSender.enqueue(state, envelope)
    assert_state(state)
    if state.closed == true then return nil, "sender is closed" end
    if type(envelope) ~= "table" then
        return nil, "request envelope is required"
    end
    if type(envelope.on_complete) ~= "function" then
        return nil, "request completion callback is required"
    end

    state.next_token = (tonumber(state.next_token) or 0) + 1
    local queued = {
        token = state.next_token,
        world_generation = state.world_generation,
        payload = envelope.payload,
        on_complete = envelope.on_complete,
        diagnostic_id = envelope.diagnostic_id,
    }
    state.queue[#state.queue + 1] = queued
    return queued.token, nil
end

function BlueprintRpcSender.begin_next(state)
    assert_state(state)
    if state.closed == true then return nil, "sender is closed" end
    if state.current ~= nil then return nil, "sender is busy" end

    local head = tonumber(state.queue_head) or 1
    local envelope = state.queue[head]
    if envelope == nil then return nil, nil end

    state.queue[head] = false
    state.queue_head = head + 1
    state.current = envelope
    compact_queue(state)
    return envelope, nil
end

function BlueprintRpcSender.peek_next(state)
    assert_state(state)
    if state.closed == true or state.current ~= nil then return nil end
    return state.queue[tonumber(state.queue_head) or 1]
end

function BlueprintRpcSender.current(state)
    assert_state(state)
    return state.current
end

function BlueprintRpcSender.complete(state, token, outcome)
    assert_state(state)
    local current = state.current
    if current == nil then return false, "sender is idle" end
    if current.token ~= token then return false, "request token is stale" end
    if current.world_generation ~= state.world_generation then
        return false, "request generation is stale"
    end

    -- Release the single slot before invoking business code. A completion
    -- callback may enqueue its session's next request; any requests that were
    -- already waiting remain ahead of it in the FIFO.
    state.current = nil
    local ok, callback_result = pcall(current.on_complete, outcome)
    if not ok then return true, callback_result end
    return true, nil, callback_result
end

function BlueprintRpcSender.queued_count(state)
    assert_state(state)
    local count = #state.queue - (tonumber(state.queue_head) or 1) + 1
    return math.max(count, 0)
end

function BlueprintRpcSender.is_idle(state)
    assert_state(state)
    return state.current == nil
        and BlueprintRpcSender.queued_count(state) == 0
end

function BlueprintRpcSender.reset(state, world_generation)
    assert_state(state)
    state.world_generation = tonumber(world_generation)
        or ((tonumber(state.world_generation) or 0) + 1)
    state.queue = {}
    state.queue_head = 1
    state.current = nil
    state.closed = false
end

function BlueprintRpcSender.close(state)
    assert_state(state)
    state.queue = {}
    state.queue_head = 1
    state.current = nil
    state.closed = true
end

return BlueprintRpcSender

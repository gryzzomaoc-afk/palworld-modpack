-- Compact JSON clipboard schema for BlueprintResearch.
--
-- The clipboard contains only semantic blueprint data.  Runtime-only class,
-- mesh, collision and install-strategy metadata is hydrated from a per-type
-- cache keyed by BuildObjectId.

local Json = require("BlueprintCodeCodec")
local BlueprintPreviewMesh = require("BlueprintPreviewMesh")

local Schema = {}

Schema.VERSION = 9
Schema.CONNECTION_VERSION = 1
Schema.POSITION_DECIMALS = 3
Schema.ROTATION_DECIMALS = 7
Schema.SCALE_DECIMALS = 7

Schema.CONNECT_PROPERTIES = {
    "ConnectInfoAnyPlace",
    "FrontConnectInfo",
    "BackConnectInfo",
    "LeftConnectInfo",
    "RightConnectInfo",
    "UpConnectInfo",
    "DownConnectInfo",
    "DiagonalUpConnectInfo",
    "DiagonalDownConnectInfo",
    "DiagonalLeftConnectInfo",
    "DiagonalRightConnectInfo",
    "DiagonalBackConnectInfo",
    "DiagonalConnectInfo",
    "CornerFrontLeftConnectInfo",
    "CornerFrontRightConnectInfo",
    "CornerBackLeftConnectInfo",
    "CornerBackRightConnectInfo",
}

local property_index = {}
for index, name in ipairs(Schema.CONNECT_PROPERTIES) do
    property_index[name] = index
end

local function normalize_connect_index(value)
    if value == nil then return "<nil>" end
    local text = tostring(value)
    local normalized = string.lower(text)
    if normalized == "" or normalized == "nil" or normalized == "<nil>"
        or normalized == "none" or normalized == "null" then
        return "<nil>"
    end
    return text
end

local function deep_copy(value, active)
    if type(value) ~= "table" then return value end
    active = active or {}
    if active[value] then error("cannot copy a cyclic runtime template") end
    active[value] = true
    local result = {}
    for key, child in pairs(value) do
        result[deep_copy(key, active)] = deep_copy(child, active)
    end
    active[value] = nil
    return result
end

local function finite(value)
    return type(value) == "number" and value == value
        and value ~= math.huge and value ~= -math.huge
end

local function component(value, lower, upper, default)
    if type(value) ~= "table" then return default end
    local result = value[lower]
    if result == nil then result = value[upper] end
    if result == nil then return default end
    return tonumber(result)
end

local function quantize(value, decimal_places)
    if not finite(value) then return value end
    local factor = 10 ^ decimal_places
    local scaled = value * factor
    local rounded
    if scaled >= 0 then
        rounded = math.floor(scaled + 0.5)
    else
        rounded = math.ceil(scaled - 0.5)
    end
    local result = rounded / factor
    if math.abs(result) < 0.5 / factor then return 0 end
    local nearest_integer
    if result >= 0 then
        nearest_integer = math.floor(result + 0.5)
    else
        nearest_integer = math.ceil(result - 0.5)
    end
    if math.abs(result - nearest_integer) < 0.5 / factor then
        return nearest_integer
    end
    return result
end

local function normalized_quaternion(rotation)
    local x = component(rotation, "x", "X")
    local y = component(rotation, "y", "Y")
    local z = component(rotation, "z", "Z")
    local w = component(rotation, "w", "W")
    if not finite(x) or not finite(y) or not finite(z) or not finite(w) then
        return nil, "rotation contains a non-finite value"
    end
    local magnitude = math.sqrt(x * x + y * y + z * z + w * w)
    if magnitude < 0.000000000001 then
        return nil, "rotation quaternion has zero length"
    end
    return {
        quantize(x / magnitude, Schema.ROTATION_DECIMALS),
        quantize(y / magnitude, Schema.ROTATION_DECIMALS),
        quantize(z / magnitude, Schema.ROTATION_DECIMALS),
        quantize(w / magnitude, Schema.ROTATION_DECIMALS),
    }, nil
end

local function encode_transform(transform)
    if type(transform) ~= "table" then return nil, "transform is missing" end
    local translation = transform.translation or transform.Translation
    local rotation = transform.rotation or transform.Rotation
    local scale = transform.scale or transform.Scale3D
    local quaternion, quaternion_error = normalized_quaternion(rotation)
    if quaternion == nil then return nil, quaternion_error end
    local values = {
        quantize(component(translation, "x", "X"), Schema.POSITION_DECIMALS),
        quantize(component(translation, "y", "Y"), Schema.POSITION_DECIMALS),
        quantize(component(translation, "z", "Z"), Schema.POSITION_DECIMALS),
        quaternion[1], quaternion[2], quaternion[3], quaternion[4],
    }
    for _, value in ipairs(values) do
        if not finite(value) then return nil, "transform contains a non-finite value" end
    end
    local sx = quantize(
        component(scale, "x", "X", 1.0), Schema.SCALE_DECIMALS
    )
    local sy = quantize(
        component(scale, "y", "Y", 1.0), Schema.SCALE_DECIMALS
    )
    local sz = quantize(
        component(scale, "z", "Z", 1.0), Schema.SCALE_DECIMALS
    )
    if not finite(sx) or not finite(sy) or not finite(sz) then
        return nil, "transform scale contains a non-finite value"
    end
    if math.abs(sx - 1.0) > 0.000001
        or math.abs(sy - 1.0) > 0.000001
        or math.abs(sz - 1.0) > 0.000001 then
        values[8] = sx
        values[9] = sy
        values[10] = sz
    end
    return values, nil
end

local function decode_transform(record, offset)
    offset = offset or 1
    local rotation = {
        x = record[offset + 3], y = record[offset + 4],
        z = record[offset + 5], w = record[offset + 6],
    }
    local magnitude = math.sqrt(
        rotation.x * rotation.x + rotation.y * rotation.y
        + rotation.z * rotation.z + rotation.w * rotation.w
    )
    if magnitude > 0.000000000001 then
        rotation.x = rotation.x / magnitude
        rotation.y = rotation.y / magnitude
        rotation.z = rotation.z / magnitude
        rotation.w = rotation.w / magnitude
    end
    local result = {
        translation = {
            x = record[offset], y = record[offset + 1], z = record[offset + 2],
        },
        rotation = rotation,
        scale = { x = 1.0, y = 1.0, z = 1.0 },
    }
    if record[offset + 7] ~= nil then
        result.scale.x = record[offset + 7]
        result.scale.y = record[offset + 8]
        result.scale.z = record[offset + 9]
    end
    return result
end

local function valid_integer(value, minimum, maximum)
    return type(value) == "number" and value % 1 == 0
        and value >= minimum and value <= maximum
end

local function validate_transform_record(record, offset, allow_scale)
    if type(record) ~= "table" then return false end
    offset = offset or 1
    for index = offset, offset + 6 do
        if not finite(record[index]) then return false end
    end
    local first_scale = record[offset + 7]
    if first_scale ~= nil then
        if not allow_scale then return false end
        for index = offset + 7, offset + 9 do
            if not finite(record[index]) then return false end
        end
    end
    return true
end

function Schema.validate(compact)
    if type(compact) ~= "table" then return false, "blueprint JSON root is not an object" end
    if compact.v ~= Schema.VERSION then
        return false, "unsupported blueprint JSON schema=" .. tostring(compact.v)
    end
    if type(compact.t) ~= "table" or #compact.t == 0 then
        return false, "type dictionary is missing"
    end
    for index, build_object_id in ipairs(compact.t) do
        if type(build_object_id) ~= "string" or build_object_id == "" then
            return false, "invalid BuildObjectId at type index=" .. tostring(index)
        end
    end
    if type(compact.b) ~= "table" or #compact.b == 0 then
        return false, "building array is missing"
    end
    if not valid_integer(compact.a, 1, #compact.b) then
        return false, "anchor building index is invalid"
    end
    for index, building in ipairs(compact.b) do
        if type(building) ~= "table"
            or not valid_integer(building[1], 1, #compact.t)
            or not validate_transform_record(building, 2, true) then
            return false, "invalid building record index=" .. tostring(index)
        end
    end
    if compact.c ~= nil and type(compact.c) ~= "table" then
        return false, "connection array is invalid"
    end
    for index, edge in ipairs(compact.c or {}) do
        if type(edge) ~= "table"
            or not valid_integer(edge[1], 1, #compact.b)
            or not valid_integer(edge[2], 1, #compact.b)
            or not valid_integer(edge[3], 1, #Schema.CONNECT_PROPERTIES)
            or edge[4] == nil or edge[5] == nil then
            return false, "invalid internal connection index=" .. tostring(index)
        end
    end
    if compact.x ~= nil and type(compact.x) ~= "table" then
        return false, "external support array is invalid"
    end
    for index, edge in ipairs(compact.x or {}) do
        if type(edge) ~= "table"
            or not valid_integer(edge[1], 1, #compact.b)
            or not valid_integer(edge[2], 1, #compact.t)
            or not valid_integer(edge[3], 1, #Schema.CONNECT_PROPERTIES)
            or edge[4] == nil or edge[5] == nil
            or not validate_transform_record(edge, 6, false) then
            return false, "invalid external support index=" .. tostring(index)
        end
    end
    if compact.g ~= nil then
        return false, "legacy terrain-anchor blueprints are unsupported"
    end
    if compact.w ~= nil
        and not validate_transform_record(compact.w, 1, true) then
        return false, "anchor world transform record is invalid"
    end
    return true, nil
end

function Schema.from_runtime(runtime)
    if type(runtime) ~= "table" or type(runtime.buildings) ~= "table"
        or #runtime.buildings == 0 then
        return nil, "runtime blueprint has no buildings"
    end
    local compact = { v = Schema.VERSION, t = {}, b = {}, c = {} }
    local type_index_by_id = {}
    local building_index_by_id = {}
    local function ensure_type(build_object_id)
        if type(build_object_id) ~= "string" or build_object_id == "" then
            return nil
        end
        local index = type_index_by_id[build_object_id]
        if index == nil then
            index = #compact.t + 1
            compact.t[index] = build_object_id
            type_index_by_id[build_object_id] = index
        end
        return index
    end

    for index, building in ipairs(runtime.buildings) do
        local type_index = ensure_type(building.build_object_id)
        local transform, transform_error = encode_transform(
            building.relative_transform
        )
        if type_index == nil or transform == nil then
            return nil, "building encode failed index=" .. tostring(index)
                .. " error=" .. tostring(transform_error)
        end
        local record = { type_index }
        for _, value in ipairs(transform) do record[#record + 1] = value end
        compact.b[index] = record
        building_index_by_id[building.source_instance_id] = index
        if building.source_instance_id == runtime.anchor_instance_id
            and building.is_anchor == true then
            compact.a = index
        end
    end
    if compact.a == nil then return nil, "runtime anchor record is missing" end

    local external = {}
    for source_index, building in ipairs(runtime.buildings) do
        for _, connection in ipairs(building.connections or {}) do
            local target_index = building_index_by_id[
                connection.target_source_instance_id
            ]
            local connect_property = property_index[connection.source_property]
            if target_index == nil or connect_property == nil then
                return nil, "internal connection encode failed source="
                    .. tostring(source_index)
            end
            compact.c[#compact.c + 1] = {
                source_index, target_index, connect_property,
                normalize_connect_index(connection.source_connect_index),
                normalize_connect_index(connection.target_connect_index),
            }
        end
        for _, connection in ipairs(building.external_connections or {}) do
            local target_type = ensure_type(connection.target_build_object_id)
            local connect_property = property_index[connection.source_property]
            local transform, transform_error = encode_transform(
                connection.target_relative_to_anchor
            )
            if target_type == nil or connect_property == nil or transform == nil then
                return nil, "external connection encode failed source="
                    .. tostring(source_index) .. " error="
                    .. tostring(transform_error)
            end
            local record = {
                source_index, target_type, connect_property,
                normalize_connect_index(connection.source_connect_index),
                normalize_connect_index(connection.target_connect_index),
            }
            for _, value in ipairs(transform) do
                if #record >= 12 then break end
                record[#record + 1] = value
            end
            external[#external + 1] = record
        end
    end
    if #compact.c == 0 then compact.c = nil end
    if #external > 0 then compact.x = external end
    if runtime.anchor_world_transform ~= nil then
        local anchor_world_transform, anchor_world_error = encode_transform(
            runtime.anchor_world_transform
        )
        if anchor_world_transform == nil then
            return nil, "anchor world transform encode failed: "
                .. tostring(anchor_world_error)
        end
        compact.w = anchor_world_transform
    end
    local valid, validation_error = Schema.validate(compact)
    if not valid then return nil, validation_error end
    return compact, {
        buildings = #compact.b,
        types = #compact.t,
        connections = #(compact.c or {}),
        external_supports = #(compact.x or {}),
    }
end

function Schema.to_runtime(compact, templates)
    local valid, validation_error = Schema.validate(compact)
    if not valid then return nil, validation_error end
    templates = templates or {}
    local runtime = {
        schema_version = Schema.VERSION,
        connection_schema_version = Schema.CONNECTION_VERSION,
        anchor_was_user_selected = true,
        anchor_world_transform = compact.w ~= nil
            and decode_transform(compact.w, 1) or nil,
        buildings = {},
        saved_connections = {},
    }
    for index, record in ipairs(compact.b) do
        local build_object_id = compact.t[record[1]]
        local template = templates[build_object_id]
        if type(template) ~= "table" then
            return nil, "runtime type template is missing for " .. build_object_id
        end
        local building = Schema.copy_type_template(template)
        building.source = "schema-9-json"
        building.build_object_id = build_object_id
        building.source_instance_id = "bp:" .. tostring(index)
        building.relative_transform = decode_transform(record, 2)
        building.world_transform = nil
        building.selection_index = index
        building.is_anchor = index == compact.a
        building.connections = {}
        building.external_connections = {}
        runtime.buildings[index] = building
        if building.is_anchor then
            runtime.anchor_instance_id = building.source_instance_id
            runtime.anchor_build_object_id = build_object_id
        end
    end
    for _, edge in ipairs(compact.c or {}) do
        local source = runtime.buildings[edge[1]]
        local target = runtime.buildings[edge[2]]
        local connection = {
            target_source_instance_id = target.source_instance_id,
            target_build_object_id = target.build_object_id,
            target_connector_class = target.connector_class,
            source_property = Schema.CONNECT_PROPERTIES[edge[3]],
            source_connect_index = normalize_connect_index(edge[4]),
            target_connect_index = normalize_connect_index(edge[5]),
            source_selection_index = edge[1],
            target_selection_index = edge[2],
        }
        source.connections[#source.connections + 1] = connection
        runtime.saved_connections[#runtime.saved_connections + 1] = connection
    end
    for _, edge in ipairs(compact.x or {}) do
        local source = runtime.buildings[edge[1]]
        source.external_connections[#source.external_connections + 1] = {
            target_source_instance_id = nil,
            target_build_object_id = compact.t[edge[2]],
            source_property = Schema.CONNECT_PROPERTIES[edge[3]],
            source_connect_index = normalize_connect_index(edge[4]),
            target_connect_index = normalize_connect_index(edge[5]),
            source_selection_index = edge[1],
            target_relative_to_anchor = decode_transform(edge, 6),
        }
    end
    return runtime, {
        buildings = #runtime.buildings,
        types = #compact.t,
        connections = #(compact.c or {}),
        external_supports = #(compact.x or {}),
    }
end

function Schema.encode(compact)
    local valid, validation_error = Schema.validate(compact)
    if not valid then return nil, validation_error end
    return Json.encode_json(compact, {
        decimal_places = math.max(
            Schema.POSITION_DECIMALS,
            Schema.ROTATION_DECIMALS,
            Schema.SCALE_DECIMALS
        ),
    })
end

function Schema.decode(text)
    local compact, stats_or_error = Json.decode_json(text)
    if compact == nil then return nil, stats_or_error end
    local valid, validation_error = Schema.validate(compact)
    if not valid then return nil, validation_error end
    return compact, stats_or_error
end

function Schema.copy_type_template(value)
    local copy = deep_copy(value)
    if type(copy) == "table" then
        copy.preview_meshes = BlueprintPreviewMesh.filter_descriptors(
            copy.build_object_id, copy.preview_meshes
        )
    end
    return copy
end

return Schema

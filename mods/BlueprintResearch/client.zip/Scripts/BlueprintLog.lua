local BlueprintRuntimeUtils = require("BlueprintRuntimeUtils")

local BlueprintLog = {}

BlueprintLog.CATEGORY_REQUIRED = "required"
BlueprintLog.CATEGORY_DIAGNOSTIC = "diagnostic"
BlueprintLog.CATEGORY_PROBE = "probe"
BlueprintLog.CATEGORY_TRACE = "trace"

local REQUIRED_PREFIXES = {
    "Simple Building Blueprints runtime loaded",
    "blueprint mode UI injected ",
    "blueprint mode UI construction-menu listener registered",
    "selection session entered ",
    "selection session exited ",
    "blueprint placement mode entered ",
    "blueprint placement mode exited ",
    "blueprint placement runtime session began ",
    "blueprint placement runtime session ended ",
    "blueprint library panel opened ",
    "blueprint library panel closed ",
    "blueprint library initialized ",
    "blueprint library using legacy write storage ",
    "blueprint wave transaction completed ",
    "blueprint wave transaction terminal ",
    "blueprint runtime world references abandoned ",
    "blueprint runtime bridge hooks ready ",
}

local REQUIRED_MARKERS = {
    "error=",
    "isolated error",
    "failed",
    "failure",
    "aborted",
    "timeout",
    "exception",
    "warning",
    "crash",
    "critical",
}

local PROBE_PREFIXES = {
    "blueprint performance ",
    "blueprint overlap timing ",
    "blueprint build queue timing ",
}

local function starts_with_any(text, prefixes)
    for _, prefix in ipairs(prefixes) do
        if string.sub(text, 1, #prefix) == prefix then
            return true
        end
    end
    return false
end

local function contains_any(text, markers)
    local lowered = string.lower(text)
    for _, marker in ipairs(markers) do
        if string.find(lowered, marker, 1, true) then
            return true
        end
    end
    return false
end

local function normalize_category(category)
    category = string.lower(tostring(category or ""))
    if category == BlueprintLog.CATEGORY_REQUIRED
        or category == BlueprintLog.CATEGORY_DIAGNOSTIC
        or category == BlueprintLog.CATEGORY_PROBE
        or category == BlueprintLog.CATEGORY_TRACE then
        return category
    end
    return nil
end

function BlueprintLog.classify(message)
    local text = tostring(message or "")
    if contains_any(text, REQUIRED_MARKERS)
        or starts_with_any(text, REQUIRED_PREFIXES) then
        return BlueprintLog.CATEGORY_REQUIRED
    end
    if starts_with_any(text, PROBE_PREFIXES) then
        return BlueprintLog.CATEGORY_PROBE
    end
    return BlueprintLog.CATEGORY_DIAGNOSTIC
end

function BlueprintLog.install(options)
    options = options or {}
    local settings = assert(
        options.settings, "BlueprintLog settings are required"
    )
    local sink = options.sink
        or BlueprintRuntimeUtils.make_logger(
            options.tag or "[BlueprintResearch]"
        )

    local logger = {}

    function logger.is_enabled(category)
        category = normalize_category(category)
            or BlueprintLog.CATEGORY_DIAGNOSTIC
        if category == BlueprintLog.CATEGORY_REQUIRED then
            return true
        end
        if category == BlueprintLog.CATEGORY_DIAGNOSTIC then
            return settings.get_log_diagnostics() == true
        end
        if category == BlueprintLog.CATEGORY_PROBE then
            return settings.get_log_probes() == true
        end
        if category == BlueprintLog.CATEGORY_TRACE then
            return settings.get_log_trace() == true
        end
        return false
    end

    function logger.emit(category, message)
        local text = tostring(message or "")
        -- Errors and lifecycle-critical records cannot be accidentally hidden
        -- by a caller assigning the wrong category.
        local classified = BlueprintLog.classify(text)
        if classified == BlueprintLog.CATEGORY_REQUIRED then
            category = classified
        else
            category = normalize_category(category) or classified
        end
        if not logger.is_enabled(category) then return false end
        sink(string.format("[%s] %s", category, text))
        return true
    end

    function logger.log(message, category)
        return logger.emit(category, message)
    end

    function logger.required(message)
        return logger.emit(BlueprintLog.CATEGORY_REQUIRED, message)
    end

    function logger.diagnostic(message)
        return logger.emit(BlueprintLog.CATEGORY_DIAGNOSTIC, message)
    end

    function logger.probe(message)
        return logger.emit(BlueprintLog.CATEGORY_PROBE, message)
    end

    function logger.trace(message)
        return logger.emit(BlueprintLog.CATEGORY_TRACE, message)
    end

    return logger
end

return BlueprintLog

local BlueprintPerformance = require("BlueprintPerformance")

local BlueprintStockVisualProbe = {}

local SCALAR_PARAMETERS = {
    "Progress",
    "Opacity",
}

local VECTOR_PARAMETERS = {
    "RimInitialColor",
    "RimCompleteColor",
    "RimBorderColor",
}

local function numeric_component(value, lower, upper)
    if value == nil then return nil end
    return tonumber(value[lower]) or tonumber(value[upper])
end

local function snapshot_vector(value)
    if value == nil then return nil end
    local result = {
        r = numeric_component(value, "r", "R"),
        g = numeric_component(value, "g", "G"),
        b = numeric_component(value, "b", "B"),
        a = numeric_component(value, "a", "A"),
    }
    if result.r == nil or result.g == nil
        or result.b == nil or result.a == nil then
        return nil
    end
    return result
end

local function format_vector(value)
    if value == nil then return "<nil>" end
    return string.format(
        "(%.4f,%.4f,%.4f,%.4f)",
        tonumber(value.r) or 0.0,
        tonumber(value.g) or 0.0,
        tonumber(value.b) or 0.0,
        tonumber(value.a) or 0.0
    )
end

function BlueprintStockVisualProbe.install(deps)
    deps = type(deps) == "table" and deps or {}
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object dependency is required")
    local safe_property = assert(
        deps.safe_property, "safe_property dependency is required")
    local safe_object_address = assert(
        deps.safe_object_address, "safe_object_address dependency is required")
    local object_name = assert(
        deps.object_name, "object_name dependency is required")
    local log_probe = deps.log_probe or deps.log or function() end
    local enabled = deps.enabled == true

    local controller = {
        enabled = enabled,
        hook_ready = false,
        last_target_address = nil,
        sample_count = 0,
    }

    local function object_identity(value)
        value = unwrap(value)
        if not is_valid_object(value) then
            return {
                address = nil,
                name = "<invalid>",
            }
        end
        return {
            address = safe_object_address(value),
            name = tostring(object_name(value)),
        }
    end

    local function snapshot_parameters(material)
        local parts = {}
        material = unwrap(material)
        if not is_valid_object(material) then return "<unavailable>" end
        for _, parameter_name in ipairs(SCALAR_PARAMETERS) do
            local value = nil
            pcall(function()
                value = unwrap(material:K2_GetScalarParameterValue(
                    FName(parameter_name)
                ))
            end)
            if tonumber(value) ~= nil then
                parts[#parts + 1] = parameter_name .. "="
                    .. string.format("%.6f", tonumber(value))
            end
        end
        for _, parameter_name in ipairs(VECTOR_PARAMETERS) do
            local value = nil
            pcall(function()
                value = snapshot_vector(unwrap(
                    material:K2_GetVectorParameterValue(
                        FName(parameter_name)
                    )
                ))
            end)
            if value ~= nil then
                parts[#parts + 1] = parameter_name .. "="
                    .. format_vector(value)
            end
        end
        return #parts > 0 and table.concat(parts, ",")
            or "<none-readable>"
    end

    local function snapshot_target(actor)
        local started_at = BlueprintPerformance.now()
        actor = unwrap(actor)
        local actor_identity = object_identity(actor)
        local visual_ctrl = unwrap(safe_property(actor, "VisualCtrl"))
        local visual_ctrl_identity = object_identity(visual_ctrl)
        local meshes = safe_property(actor, "AllMeshes")
        local mesh_count = 0
        pcall(function() mesh_count = #meshes end)

        local slot_count = 0
        local current_equals_normal = 0
        local current_differs_from_normal = 0
        local normal_unavailable = 0
        local overlay_present = 0
        local details = {}

        for mesh_index = 1, mesh_count do
            local mesh = nil
            pcall(function() mesh = unwrap(meshes[mesh_index]) end)
            if is_valid_object(mesh) then
                local materials = nil
                local material_count = 0
                pcall(function()
                    materials = mesh:GetMaterials()
                    material_count = #materials
                end)
                local overlay = nil
                pcall(function()
                    overlay = unwrap(mesh:GetOverlayMaterial())
                end)
                local overlay_identity = object_identity(overlay)
                if overlay_identity.address ~= nil then
                    overlay_present = overlay_present + 1
                end

                for material_index = 1, material_count do
                    local slot_index = material_index - 1
                    local current_material = nil
                    pcall(function()
                        current_material = unwrap(
                            materials[material_index]
                        )
                    end)
                    local normal_material = nil
                    if is_valid_object(visual_ctrl) then
                        pcall(function()
                            normal_material = unwrap(
                                visual_ctrl:GetMaterialInstanceNormal(
                                    mesh, slot_index
                                )
                            )
                        end)
                    end
                    local current_identity =
                        object_identity(current_material)
                    local normal_identity =
                        object_identity(normal_material)
                    local relation = "normal-unavailable"
                    if normal_identity.address == nil then
                        normal_unavailable = normal_unavailable + 1
                    elseif current_identity.address
                        == normal_identity.address then
                        relation = "same-as-normal"
                        current_equals_normal =
                            current_equals_normal + 1
                    else
                        relation = "different-from-normal"
                        current_differs_from_normal =
                            current_differs_from_normal + 1
                    end
                    slot_count = slot_count + 1
                    if #details < 12 then
                        details[#details + 1] = string.format(
                            "%s[%d] relation=%s current=%s normal=%s overlay=%s currentParams={%s}",
                            tostring(object_name(mesh)),
                            slot_index,
                            relation,
                            tostring(current_identity.name),
                            tostring(normal_identity.name),
                            tostring(overlay_identity.name),
                            snapshot_parameters(current_material)
                        )
                    end
                end
            end
        end

        return {
            actor = actor_identity,
            visual_ctrl = visual_ctrl_identity,
            dismantle_flag =
                safe_property(actor, "bDismantleTargetInLocal") == true,
            mesh_count = mesh_count,
            slot_count = slot_count,
            current_equals_normal = current_equals_normal,
            current_differs_from_normal =
                current_differs_from_normal,
            normal_unavailable = normal_unavailable,
            overlay_present = overlay_present,
            details = details,
            elapsed_ms = BlueprintPerformance.elapsed_ms(started_at),
        }
    end

    function controller.observe_target(actor, source)
        if not enabled then return false end
        actor = unwrap(actor)
        if not is_valid_object(actor) then
            controller.last_target_address = nil
            return false
        end
        local actor_address = safe_object_address(actor)
        if actor_address == nil
            or actor_address == controller.last_target_address then
            return false
        end
        controller.last_target_address = actor_address
        controller.sample_count = controller.sample_count + 1

        local snapshot = snapshot_target(actor)
        log_probe(string.format(
            "blueprint performance stock-dismantle-visual-target sample=%d source=%s actor=%s flag=%s visualCtrl=%s meshes=%d slots=%d sameAsNormal=%d differentFromNormal=%d normalUnavailable=%d overlayPresent=%d elapsedMs=%.3f details=%s",
            controller.sample_count,
            tostring(source or "observed-target"),
            tostring(snapshot.actor.name),
            tostring(snapshot.dismantle_flag),
            tostring(snapshot.visual_ctrl.name),
            tonumber(snapshot.mesh_count) or 0,
            tonumber(snapshot.slot_count) or 0,
            tonumber(snapshot.current_equals_normal) or 0,
            tonumber(snapshot.current_differs_from_normal) or 0,
            tonumber(snapshot.normal_unavailable) or 0,
            tonumber(snapshot.overlay_present) or 0,
            tonumber(snapshot.elapsed_ms) or 0.0,
            #snapshot.details > 0
                and table.concat(snapshot.details, "|") or "<none>"
        ))
        return true
    end

    function controller.reset_target()
        controller.last_target_address = nil
    end

    if enabled then
        controller.hook_ready = true
        log_probe(
            "blueprint performance stock-dismantle-visual-target-probe-ready"
        )
    end
    return controller
end

return BlueprintStockVisualProbe

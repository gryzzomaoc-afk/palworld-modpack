local BlueprintBuildSessionRuntime = {}
local BlueprintPerformance = require("BlueprintPerformance")

local SESSION_PACKAGE =
    "/Game/Mods/BlueprintResearch/BP_SBBBuildSessionActor"
local SESSION_CLASS_PATH = SESSION_PACKAGE
    .. ".BP_SBBBuildSessionActor_C"
local SESSION_CLASS_NAME = "BP_SBBBuildSessionActor_C"
local SESSION_CLASS_FULL_NAME =
    "BlueprintGeneratedClass " .. SESSION_CLASS_PATH
local MOD_ACTOR_CLASS_NAME = "ModActor_C"
local MOD_ACTOR_CLASS_FULL_NAME =
    "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/"
        .. "ModActor.ModActor_C"
local SESSION_CLASS_REFERENCE_PROPERTY = "SBB_BuildSessionClass"
local WAKE_FUNCTION = "SBB_BuildSessionWake"
local VISUAL_WAKE_FUNCTION = "SBB_BuildSessionVisualWake"
local WAKE_FUNCTION_PATH = SESSION_CLASS_PATH .. ":" .. WAKE_FUNCTION
local VISUAL_WAKE_FUNCTION_PATH =
    SESSION_CLASS_PATH .. ":" .. VISUAL_WAKE_FUNCTION
local DEFAULT_PULSE_INTERVAL_SECONDS = 0.05

local PROPERTIES = {
    id = "SBB_BuildSessionId",
    generation = "SBB_BuildSessionGeneration",
    active = "SBB_BuildSessionActive",
    waiting = "SBB_BuildSessionWaitingForResult",
    wave = "SBB_BuildSessionWaveNumber",
    member = "SBB_BuildSessionMemberNumber",
    wake_token = "SBB_BuildSessionWakeToken",
    wake_kind = "SBB_BuildSessionWakeKind",
    network = "SBB_BuildSessionNetworkComponent",
}

function BlueprintBuildSessionRuntime.install(deps)
    assert(type(deps) == "table",
        "BlueprintBuildSessionRuntime dependencies are required")

    local UEHelpers = assert(
        deps.UEHelpers, "Build Session UEHelpers is required")
    local log = assert(deps.log, "Build Session log is required")
    local unwrap = assert(deps.unwrap, "Build Session unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object, "Build Session is_valid_object is required")
    local is_usable_class_object = assert(
        deps.is_usable_class_object,
        "Build Session is_usable_class_object is required")
    local safe_property = assert(
        deps.safe_property, "Build Session safe_property is required")
    local safe_object_address = assert(
        deps.safe_object_address,
        "Build Session safe_object_address is required")
    local get_asset_path = assert(
        deps.get_asset_path, "Build Session get_asset_path is required")
    local object_name = assert(
        deps.object_name, "Build Session object_name is required")
    local get_world_generation = assert(
        deps.get_world_generation,
        "Build Session get_world_generation is required")
    local find_all_of = deps.find_all_of or FindAllOf
    local static_find_object = deps.static_find_object or StaticFindObject
    local register_hook = deps.register_hook or RegisterHook
    local record_performance = type(deps.record_performance) == "function"
        and deps.record_performance or function() end
    local pulse_interval_seconds = math.max(
        tonumber(deps.pulse_interval_seconds)
            or DEFAULT_PULSE_INTERVAL_SECONDS,
        0.01
    )

    local function report_performance(
        session_id, phase_name, started_at, context
    )
        -- Diagnostics must never be able to change timer/session behavior.
        pcall(record_performance,
            tonumber(session_id), phase_name,
            BlueprintPerformance.elapsed_ms(started_at), context
        )
    end

    local controller = {
        entries = {},
        hook_callbacks = {},
        hooks_ready = false,
    }

    local function get_class_full_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return "<invalid>" end
        local ok, result = pcall(function()
            return unwrap(value:GetClass()):GetFullName()
        end)
        return ok and tostring(result) or "<unavailable>"
    end

    local function belongs_to_current_world(value)
        value = unwrap(value)
        local world = unwrap(UEHelpers.GetWorld())
        if not is_valid_object(value) or not is_valid_object(world) then
            return false
        end
        local value_world = nil
        pcall(function() value_world = unwrap(value:GetWorld()) end)
        return is_valid_object(value_world)
            and safe_object_address(value_world)
                == safe_object_address(world)
    end

    local function make_handle(value, generation)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local path = get_asset_path(value)
        local address = safe_object_address(value)
        if type(path) ~= "string" or path == "" or address == nil then
            return nil
        end
        return {
            path = path,
            address = address,
            world_generation = generation,
        }
    end

    local function resolve_handle(handle)
        if type(handle) ~= "table"
            or type(handle.path) ~= "string"
            or handle.address == nil
            or handle.world_generation ~= get_world_generation() then
            return nil
        end
        local ok, value = pcall(static_find_object, handle.path)
        value = ok and unwrap(value) or nil
        if not is_valid_object(value)
            or safe_object_address(value) ~= handle.address
            or get_class_full_name(value) ~= SESSION_CLASS_FULL_NAME
            or not belongs_to_current_world(value) then
            return nil
        end
        return value
    end

    local function matching_entry_actor(entry, actor)
        actor = unwrap(actor)
        return type(entry) == "table"
            and entry.generation == get_world_generation()
            and is_valid_object(actor)
            and safe_object_address(actor) == entry.handle.address
    end

    local function get_entry_from_context(context)
        local actor = unwrap(context)
        if not is_valid_object(actor) then return nil, nil end
        local session_id = tonumber(safe_property(actor, PROPERTIES.id))
        local generation = tonumber(
            safe_property(actor, PROPERTIES.generation))
        local entry = session_id ~= nil
            and controller.entries[session_id] or nil
        if type(entry) ~= "table"
            or entry.generation ~= generation
            or not matching_entry_actor(entry, actor) then
            return nil, actor
        end
        return entry, actor
    end

    local function invoke_hook(context, endpoint)
        local entry, actor = get_entry_from_context(context)
        if entry == nil then return end
        local expected_token = endpoint == "visual"
            and entry.visual_token or entry.main_token
        if expected_token == nil then return end
        local observed_token = tonumber(
            safe_property(actor, PROPERTIES.wake_token))
        -- Both timer endpoints intentionally share the reflected diagnostic
        -- token. The visual timer is armed once before the first main timeout,
        -- so the main arm overwrites that field without affecting UE's
        -- independent function timer. Main wakes still validate the field;
        -- visual wakes are authorized by endpoint, Actor identity and World
        -- generation, and the visual timer is always cleared when cancelled.
        if endpoint == "main" and observed_token ~= expected_token then
            return
        end
        local callback = endpoint == "visual"
            and entry.on_visual_wake or entry.on_wake
        if type(callback) ~= "function" then return end
        local callback_started_at = BlueprintPerformance.now()
        local wake = {
            session_id = entry.session_id,
            generation = entry.generation,
            token = expected_token,
            kind = endpoint == "visual"
                and (tonumber(entry.visual_kind) or 0)
                or (tonumber(entry.main_kind) or 0),
            endpoint = endpoint,
        }
        local ok, callback_error = pcall(callback, actor, wake)
        report_performance(
            entry.session_id,
            endpoint == "main"
                and "session_pulse_callback"
                or "session_visual_callback",
            callback_started_at, endpoint)
        if not ok then
            log("Build Session " .. endpoint
                .. " wake isolated error session="
                .. tostring(entry.session_id) .. " error="
                .. tostring(callback_error))
        end
    end

    local function ensure_hooks()
        if controller.hooks_ready then return true, nil end
        local main_callback = function(context)
            invoke_hook(context, "main")
        end
        local visual_callback = function(context)
            invoke_hook(context, "visual")
        end
        local main_ok, main_pre, main_post = pcall(
            register_hook, WAKE_FUNCTION_PATH, main_callback)
        if not main_ok then return false, tostring(main_pre) end
        local visual_ok, visual_pre, visual_post = pcall(
            register_hook, VISUAL_WAKE_FUNCTION_PATH, visual_callback)
        if not visual_ok then return false, tostring(visual_pre) end
        controller.hook_callbacks.main = main_callback
        controller.hook_callbacks.visual = visual_callback
        controller.hooks_ready = true
        log("Build Session hooks registered main=" .. tostring(main_pre)
            .. "/" .. tostring(main_post) .. " visual="
            .. tostring(visual_pre) .. "/" .. tostring(visual_post))
        return true, nil
    end

    local function load_session_class()
        for _, candidate_value in ipairs(
            find_all_of(MOD_ACTOR_CLASS_NAME) or {}
        ) do
            local candidate = unwrap(candidate_value)
            if is_valid_object(candidate)
                and get_class_full_name(candidate)
                    == MOD_ACTOR_CLASS_FULL_NAME
                and belongs_to_current_world(candidate) then
                local referenced_class = unwrap(safe_property(
                    candidate, SESSION_CLASS_REFERENCE_PROPERTY))
                if is_usable_class_object(referenced_class) then
                    return referenced_class
                end
            end
        end
        local actor_class = unwrap(static_find_object(SESSION_CLASS_PATH))
        if is_usable_class_object(actor_class) then return actor_class end
        return nil
    end

    local function timer_library(session_id, operation)
        local started_at = BlueprintPerformance.now()
        local value = nil
        pcall(function()
            value = unwrap(UEHelpers.GetKismetSystemLibrary())
        end)
        report_performance(
            session_id, "session_timer_library", started_at, operation)
        return is_valid_object(value) and value or nil
    end

    local function clear_actor_timer(
        actor, function_name, session_id, operation
    )
        local system = timer_library(session_id, operation)
        if not is_valid_object(system) or not is_valid_object(actor) then
            return false, "timer dependencies are unavailable"
        end
        local clear_started_at = BlueprintPerformance.now()
        local ok, error_value = pcall(function()
            system:K2_ClearTimer(actor, function_name)
        end)
        report_performance(
            session_id, "session_timer_clear",
            clear_started_at, operation)
        return ok, ok and nil or tostring(error_value)
    end

    local function arm_actor_timer(
        actor, function_name, delay_ms, session_id, operation, looping
    )
        local system = timer_library(session_id, operation)
        if not is_valid_object(system) or not is_valid_object(actor) then
            return false, "timer dependencies are unavailable"
        end
        local delay_seconds = math.max(
            tonumber(delay_ms) or 0, 1) / 1000.0
        local clear_started_at = BlueprintPerformance.now()
        local clear_ok, clear_error = pcall(function()
            system:K2_ClearTimer(actor, function_name)
        end)
        report_performance(
            session_id, "session_timer_clear",
            clear_started_at, operation)
        if not clear_ok then
            return false, tostring(clear_error)
        end
        local set_started_at = BlueprintPerformance.now()
        local set_ok, set_error = pcall(function()
            system:K2_SetTimer(
                actor, function_name, delay_seconds,
                looping == true, 0.0, 0.0)
        end)
        report_performance(
            session_id, "session_timer_set", set_started_at, operation)
        return set_ok, set_ok and nil or tostring(set_error)
    end

    function controller.begin(options)
        options = type(options) == "table" and options or {}
        local session_id = tonumber(options.session_id)
        local generation = tonumber(options.generation)
            or get_world_generation()
        if session_id == nil then
            return nil, "Build Session id is required"
        end
        if generation ~= get_world_generation() then
            return nil, "Build Session generation is stale"
        end
        if controller.entries[session_id] ~= nil then
            return nil, "Build Session id is already active"
        end
        local hooks_ok, hooks_error = ensure_hooks()
        if not hooks_ok then
            return nil, "Build Session hook registration failed: "
                .. tostring(hooks_error)
        end
        local session_class = load_session_class()
        if not is_usable_class_object(session_class) then
            return nil, "Build Session class is unavailable"
        end
        local world = unwrap(UEHelpers.GetWorld())
        if not is_valid_object(world) then
            return nil, "Build Session World is unavailable"
        end
        local network_component = unwrap(options.network_component)
        if not is_valid_object(network_component)
            or not belongs_to_current_world(network_component) then
            return nil, "Build Session network component is unavailable"
        end
        local actor = nil
        local spawn_ok, spawn_error = pcall(function()
            actor = unwrap(world:SpawnActor(session_class, {}, {}))
        end)
        if not spawn_ok or not is_valid_object(actor) then
            return nil, "Build Session spawn failed: "
                .. tostring(spawn_error)
        end
        local handle = make_handle(actor, generation)
        if handle == nil then
            pcall(function() actor:K2_DestroyActor() end)
            return nil, "Build Session identity is unavailable"
        end
        local configure_ok, configure_error = pcall(function()
            actor[PROPERTIES.id] = session_id
            actor[PROPERTIES.generation] = generation
            actor[PROPERTIES.active] = true
            actor[PROPERTIES.waiting] = false
            actor[PROPERTIES.wave] = 0
            actor[PROPERTIES.member] = 0
            actor[PROPERTIES.wake_token] = 0
            actor[PROPERTIES.wake_kind] = 0
            actor[PROPERTIES.network] = network_component
        end)
        if not configure_ok then
            pcall(function() actor:K2_DestroyActor() end)
            return nil, "Build Session configuration failed: "
                .. tostring(configure_error)
        end
        controller.entries[session_id] = {
            session_id = session_id,
            generation = generation,
            handle = handle,
            main_token = 0,
            visual_token = 0,
            on_wake = options.on_wake,
            on_visual_wake = options.on_visual_wake,
        }
        local pulse_started_at = BlueprintPerformance.now()
        local pulse_ok, pulse_error = arm_actor_timer(
            actor, WAKE_FUNCTION, pulse_interval_seconds * 1000.0,
            session_id, "pulse-start", true)
        report_performance(
            session_id, "session_pulse_start",
            pulse_started_at, "interval="
                .. tostring(pulse_interval_seconds))
        if not pulse_ok then
            controller.entries[session_id] = nil
            pcall(function() actor:K2_DestroyActor() end)
            return nil, "Build Session pulse start failed: "
                .. tostring(pulse_error)
        end
        -- Do not retain the Actor wrapper. The returned handle contains only
        -- scalar identity data and every later call resolves it temporarily.
        return {
            path = handle.path,
            address = handle.address,
            world_generation = handle.world_generation,
        }, nil
    end

    local function resolve_entry_actor(entry, actor_hint)
        local started_at = BlueprintPerformance.now()
        local actor = unwrap(actor_hint)
        if matching_entry_actor(entry, actor) then
            report_performance(
                entry.session_id, "session_actor_hint",
                started_at, "accepted")
            return actor
        end
        actor = resolve_handle(entry.handle)
        report_performance(
            entry.session_id, "session_actor_resolve",
            started_at, is_valid_object(actor) and "resolved" or "failed")
        return actor
    end

    local function arm(
        session_id, endpoint, kind, delay_ms, actor_hint, status
    )
        local entry = controller.entries[tonumber(session_id)]
        if type(entry) ~= "table"
            or entry.generation ~= get_world_generation() then
            return false, "Build Session is inactive"
        end
        -- A wake hook already supplies the current live Actor wrapper. Use
        -- that synchronous context directly instead of resolving the same
        -- Actor again through StaticFindObject. Never retain the hint.
        local actor = resolve_entry_actor(entry, actor_hint)
        if not is_valid_object(actor) then
            return false, "Build Session Actor is unavailable"
        end
        local token_key = endpoint == "visual"
            and "visual_token" or "main_token"
        local kind_key = endpoint == "visual"
            and "visual_kind" or "main_kind"
        entry[token_key] = (tonumber(entry[token_key]) or 0) + 1
        entry[kind_key] = tonumber(kind) or 0
        local token = entry[token_key]
        status = type(status) == "table" and status or {}
        local status_write_started_at = BlueprintPerformance.now()
        local write_ok, write_error = pcall(function()
            actor[PROPERTIES.wake_token] = token
            actor[PROPERTIES.wake_kind] = tonumber(kind) or 0
            if status.active ~= nil then
                actor[PROPERTIES.active] = status.active == true
            end
            if status.waiting ~= nil then
                actor[PROPERTIES.waiting] = status.waiting == true
            end
            if status.wave ~= nil then
                actor[PROPERTIES.wave] = tonumber(status.wave) or 0
            end
            if status.member ~= nil then
                actor[PROPERTIES.member] =
                    tonumber(status.member) or 0
            end
        end)
        report_performance(
            session_id, "session_status_write",
            status_write_started_at, endpoint)
        if not write_ok then return false, tostring(write_error) end
        local function_name = endpoint == "visual"
            and VISUAL_WAKE_FUNCTION or WAKE_FUNCTION
        local armed, arm_error = arm_actor_timer(
            actor, function_name, delay_ms, session_id, "arm-" .. endpoint)
        if not armed then return false, arm_error end
        return true, nil, token
    end

    function controller.arm_main(
        session_id, kind, delay_ms, actor_hint, status
    )
        return arm(
            session_id, "main", kind, delay_ms, actor_hint, status
        )
    end

    function controller.arm_visual(
        session_id, kind, delay_ms, actor_hint, status
    )
        return arm(
            session_id, "visual", kind, delay_ms, actor_hint, status
        )
    end

    local function cancel(session_id, endpoint, actor_hint)
        local entry = controller.entries[tonumber(session_id)]
        if type(entry) ~= "table" then return true, nil end
        local token_key = endpoint == "visual"
            and "visual_token" or "main_token"
        entry[token_key] = (tonumber(entry[token_key]) or 0) + 1
        local actor = resolve_entry_actor(entry, actor_hint)
        if not is_valid_object(actor) then
            return false, "Build Session Actor is unavailable"
        end
        local function_name = endpoint == "visual"
            and VISUAL_WAKE_FUNCTION or WAKE_FUNCTION
        return clear_actor_timer(
            actor, function_name, session_id, "cancel-" .. endpoint)
    end

    function controller.cancel_main(session_id, actor_hint)
        return cancel(session_id, "main", actor_hint)
    end

    function controller.cancel_visual(session_id, actor_hint)
        return cancel(session_id, "visual", actor_hint)
    end

    function controller.update_status(
        session_id, status, actor_hint
    )
        local entry = controller.entries[tonumber(session_id)]
        if type(entry) ~= "table" then
            return false, "Build Session is inactive"
        end
        local actor = resolve_entry_actor(entry, actor_hint)
        if not is_valid_object(actor) then
            return false, "Build Session Actor is unavailable"
        end
        status = type(status) == "table" and status or {}
        local status_write_started_at = BlueprintPerformance.now()
        local ok, error_value = pcall(function()
            if status.active ~= nil then
                actor[PROPERTIES.active] = status.active == true
            end
            if status.waiting ~= nil then
                actor[PROPERTIES.waiting] = status.waiting == true
            end
            if status.wave ~= nil then
                actor[PROPERTIES.wave] = tonumber(status.wave) or 0
            end
            if status.member ~= nil then
                actor[PROPERTIES.member] = tonumber(status.member) or 0
            end
        end)
        report_performance(
            session_id, "session_status_write",
            status_write_started_at, "update")
        return ok, ok and nil or tostring(error_value)
    end

    function controller.get_network_component(session_id, actor_hint)
        local entry = controller.entries[tonumber(session_id)]
        local actor = unwrap(actor_hint)
        -- Network dispatch is legal only from the owning Session's live pulse
        -- context. Never resolve an Actor handle here: doing so once per
        -- request was the dominant repeated hitch, and accepting another
        -- Session's pulse would break FIFO ownership.
        if type(entry) ~= "table"
            or entry.generation ~= get_world_generation()
            or not matching_entry_actor(entry, actor) then
            return nil, "Build Session live Actor context is unavailable"
        end
        local network_component = unwrap(safe_property(
            actor, PROPERTIES.network
        ))
        if not is_valid_object(network_component) then
            return nil, "Build Session network component is unavailable"
        end
        return network_component, nil
    end

    function controller.destroy(session_id, reason, actor_hint)
        session_id = tonumber(session_id)
        local entry = controller.entries[session_id]
        if type(entry) ~= "table" then return true, nil end
        controller.entries[session_id] = nil
        entry.on_wake = nil
        entry.on_visual_wake = nil
        local actor = unwrap(actor_hint)
        if not matching_entry_actor(entry, actor) then
            actor = resolve_handle(entry.handle)
        end
        if not is_valid_object(actor) then
            return false, "Build Session Actor already unavailable"
        end
        local destroy_started_at = BlueprintPerformance.now()
        local ok, error_value = pcall(function()
            local system = timer_library(session_id, "destroy")
            if is_valid_object(system) then
                system:K2_ClearTimer(actor, WAKE_FUNCTION)
                system:K2_ClearTimer(actor, VISUAL_WAKE_FUNCTION)
            end
            actor[PROPERTIES.active] = false
            actor[PROPERTIES.waiting] = false
            actor[PROPERTIES.network] = nil
            actor:K2_DestroyActor()
        end)
        report_performance(
            session_id, "session_destroy_call",
            destroy_started_at, tostring(reason))
        if not ok then
            log("Build Session destroy error session="
                .. tostring(session_id) .. " reason=" .. tostring(reason)
                .. " error=" .. tostring(error_value))
        end
        return ok, ok and nil or tostring(error_value)
    end

    function controller.abandon_world(reason)
        local count = 0
        for session_id, entry in pairs(controller.entries) do
            entry.on_wake = nil
            entry.on_visual_wake = nil
            controller.entries[session_id] = nil
            count = count + 1
        end
        if count > 0 then
            log("Build Session Lua handles abandoned without UObject access "
                .. "count=" .. tostring(count) .. " reason="
                .. tostring(reason))
        end
        return count
    end

    function controller.is_active(session_id)
        local entry = controller.entries[tonumber(session_id)]
        return type(entry) == "table"
            and entry.generation == get_world_generation()
    end

    function controller.get_handle(session_id)
        local entry = controller.entries[tonumber(session_id)]
        if type(entry) ~= "table" then return nil end
        return {
            path = entry.handle.path,
            address = entry.handle.address,
            world_generation = entry.handle.world_generation,
        }
    end

    controller.class_name = SESSION_CLASS_NAME
    controller.class_path = SESSION_CLASS_PATH
    controller.properties = PROPERTIES
    controller.pulse_interval_seconds = pulse_interval_seconds
    return controller
end

return BlueprintBuildSessionRuntime

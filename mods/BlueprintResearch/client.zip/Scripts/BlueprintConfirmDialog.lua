local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local BlueprintConfirmDialog = {}

local PAL_UTILITY_PATH = "/Script/Pal.Default__PalUtility"
local PARAMETER_CLASS_PATH = "/Script/Pal.PalDialogParameterDialog"
local INVOKE_CALLBACK_PATH =
    "/Script/Pal.PalDialogParameterBase:InvokeCallback"
local DIALOG_TYPE_YES_NO = 1
local TEXT_JUSTIFY_CENTER = 1
local PARAMETER_ROUTE_PREFIX = "SBB_Confirm_"

function BlueprintConfirmDialog.install(deps)
    assert(type(deps) == "table",
        "BlueprintConfirmDialog dependencies are required")
    local UEHelpers = assert(deps.UEHelpers,
        "BlueprintConfirmDialog UEHelpers is required")
    local log = assert(deps.log,
        "BlueprintConfirmDialog log is required")
    local unwrap = assert(deps.unwrap,
        "BlueprintConfirmDialog unwrap is required")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintConfirmDialog is_valid_object is required")
    local copy_native_widget_id = deps.copy_native_widget_id
    local close_native_widget_id = deps.close_native_widget_id

    local dialog = {
        pending = nil,
        generation = 0,
        hook_registered = false,
        hook_callback = nil,
    }

    local function resolve(path)
        if type(StaticFindObject) ~= "function" then return nil end
        local ok, result = pcall(StaticFindObject, path)
        if not ok then return nil end
        return unwrap(result)
    end

    local function decode_bool(value)
        value = unwrap(value)
        if value == true then return true end
        if value == false or value == nil then return false end
        local numeric = tonumber(value)
        if numeric ~= nil then return numeric ~= 0 end
        return string.lower(tostring(value)) == "true"
    end

    local function dispatch_result(pending, confirmed)
        if pending.widget_id ~= nil
            and type(close_native_widget_id) == "function" then
            local call_ok, closed, close_error = pcall(
                close_native_widget_id, pending.widget_id
            )
            pending.widget_id = nil
            if not call_ok or closed ~= true then
                log("blueprint confirm dialog native close failed error="
                    .. tostring(call_ok and close_error or closed))
            end
        end
        BlueprintCallbackScheduler.game_thread_now(
            "blueprint-confirm-dialog-result:"
                .. tostring(pending.generation),
            function()
                if pending.generation ~= dialog.generation then return end
                local ok, error_value = pcall(
                    pending.on_result, confirmed == true
                )
                if not ok then
                    log("blueprint confirm dialog callback isolated error="
                        .. tostring(error_value))
                end
            end
        )
    end

    local function parameter_route(generation)
        return PARAMETER_ROUTE_PREFIX .. tostring(generation)
    end

    local function object_short_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local ok, name = pcall(function() return value:GetName() end)
        if ok and name ~= nil then return tostring(name) end
        ok, name = pcall(function() return value:GetFullName() end)
        if not ok or name == nil then return nil end
        return string.match(tostring(name), "([^%.%s]+)$")
    end

    local function ensure_hook()
        if dialog.hook_registered then return true, nil end
        local callback = function(context, result)
            local pending = dialog.pending
            if pending == nil then return end
            if object_short_name(context)
                ~= parameter_route(pending.generation) then
                return
            end
            dialog.pending = nil
            dispatch_result(pending, decode_bool(result))
        end
        local retained = function(...)
            local ok, error_value = pcall(callback, ...)
            if not ok then
                log("blueprint confirm dialog hook isolated error="
                    .. tostring(error_value))
            end
        end
        local ok, pre_id, post_id = pcall(
            RegisterHook, INVOKE_CALLBACK_PATH, retained
        )
        if not ok then
            return false, "original confirmation callback hook unavailable: "
                .. tostring(pre_id)
        end
        dialog.hook_callback = retained
        dialog.hook_registered = true
        log("blueprint confirm dialog hook registered pre="
            .. tostring(pre_id) .. " post=" .. tostring(post_id))
        return true, nil
    end

    function dialog.request(message, on_result, _options)
        if type(on_result) ~= "function" then
            return false, "confirmation result callback is missing"
        end
        if dialog.pending ~= nil then
            return false, "another blueprint confirmation is already open"
        end
        if type(StaticConstructObject) ~= "function" then
            return false, "StaticConstructObject is unavailable"
        end
        if type(copy_native_widget_id) ~= "function"
            or type(close_native_widget_id) ~= "function" then
            return false, "native confirmation lifecycle is unavailable"
        end
        local hook_ready, hook_error = ensure_hook()
        if not hook_ready then return false, hook_error end

        local utility = resolve(PAL_UTILITY_PATH)
        local parameter_class = resolve(PARAMETER_CLASS_PATH)
        local world = unwrap(select(2, pcall(UEHelpers.GetWorld)))
        local controller = unwrap(select(2, pcall(
            UEHelpers.GetPlayerController
        )))
        if not is_valid_object(utility)
            or not is_valid_object(parameter_class)
            or not is_valid_object(world)
            or not is_valid_object(controller) then
            return false, "original confirmation dialog dependencies are unavailable"
        end

        dialog.generation = dialog.generation + 1
        local generation = dialog.generation
        local route = parameter_route(generation)
        local construct_ok, construct_result = pcall(
            StaticConstructObject, parameter_class, controller, FName(route)
        )
        local parameter = construct_ok and unwrap(construct_result) or nil
        if not is_valid_object(parameter) then
            return false, "original confirmation parameter could not be created: "
                .. tostring(construct_ok and "invalid object" or construct_result)
        end
        local configured, configure_error = pcall(function()
            parameter:SetParameters(
                FText(tostring(message or "")),
                DIALOG_TYPE_YES_NO,
                true,
                TEXT_JUSTIFY_CENTER
            )
        end)
        if not configured then
            return false, "original confirmation parameter setup failed: "
                .. tostring(configure_error)
        end
        if object_short_name(parameter) ~= route then
            return false, "original confirmation parameter route is unavailable"
        end

        local pending = {
            generation = generation,
            on_result = on_result,
        }
        dialog.pending = pending
        local opened, open_result = pcall(function()
            return utility:DialogWithParameter(world, parameter)
        end)
        if not opened then
            dialog.pending = nil
            return false, "original confirmation dialog open failed: "
                .. tostring(open_result)
        end
        pending.widget_id = copy_native_widget_id(open_result)
        if pending.widget_id == nil then
            dialog.pending = nil
            pcall(close_native_widget_id, open_result)
            return false, "original confirmation dialog returned an unreadable widget ID"
        end
        log("blueprint confirm dialog opened generation="
            .. tostring(pending.generation))
        return true, nil
    end

    function dialog.is_open()
        return dialog.pending ~= nil
    end

    function dialog.cancel(reason)
        local pending = dialog.pending
        if pending == nil then return false end
        dialog.pending = nil
        dispatch_result(pending, false)
        log("blueprint confirm dialog cancelled reason=" .. tostring(reason))
        return true
    end

    function dialog.reset_for_world_travel()
        -- The parameter and widget ID belong to the old world/HUD stack. Do
        -- not invoke callbacks or attempt to close that old ID during travel.
        dialog.generation = dialog.generation + 1
        dialog.pending = nil
    end

    return dialog
end

return BlueprintConfirmDialog

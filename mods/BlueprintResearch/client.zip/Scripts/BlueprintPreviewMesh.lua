local BlueprintPreviewMesh = {}

BlueprintPreviewMesh.STATIC = "static"
BlueprintPreviewMesh.SKELETAL = "skeletal"

local PALBOX_BUILD_OBJECT_ID = "PalBoxV2"
local BASE_RANGE_CYLINDER_PATH = "/Engine/BasicShapes/Cylinder.Cylinder"

local function non_empty_string(value)
    return type(value) == "string" and value ~= ""
end

function BlueprintPreviewMesh.kind(descriptor)
    if type(descriptor) ~= "table" then return nil end
    if non_empty_string(descriptor.skeletal_mesh_path)
        or descriptor.mesh_kind == BlueprintPreviewMesh.SKELETAL then
        return BlueprintPreviewMesh.SKELETAL
    end
    if non_empty_string(descriptor.static_mesh_path)
        or descriptor.mesh_kind == BlueprintPreviewMesh.STATIC then
        return BlueprintPreviewMesh.STATIC
    end
    return nil
end

function BlueprintPreviewMesh.asset_path(descriptor)
    local kind = BlueprintPreviewMesh.kind(descriptor)
    if kind == BlueprintPreviewMesh.SKELETAL then
        return descriptor.skeletal_mesh_path, kind
    elseif kind == BlueprintPreviewMesh.STATIC then
        return descriptor.static_mesh_path, kind
    end
    return nil, nil
end

function BlueprintPreviewMesh.cache_key(descriptor)
    local path, kind = BlueprintPreviewMesh.asset_path(descriptor)
    if path == nil or kind == nil then return nil end
    return kind .. "|" .. path
end

function BlueprintPreviewMesh.is_auxiliary(build_object_id, descriptor)
    if tostring(build_object_id or "") ~= PALBOX_BUILD_OBJECT_ID then
        return false
    end
    local path, kind = BlueprintPreviewMesh.asset_path(descriptor)
    return kind == BlueprintPreviewMesh.STATIC
        and type(path) == "string"
        and string.find(path, BASE_RANGE_CYLINDER_PATH, 1, true) ~= nil
end

function BlueprintPreviewMesh.filter_descriptors(build_object_id, descriptors)
    local filtered = {}
    local removed = 0
    if type(descriptors) ~= "table" then return filtered, removed end
    for _, descriptor in ipairs(descriptors) do
        if BlueprintPreviewMesh.is_auxiliary(build_object_id, descriptor) then
            removed = removed + 1
        else
            filtered[#filtered + 1] = descriptor
        end
    end
    return filtered, removed
end

function BlueprintPreviewMesh.copy_descriptor(descriptor, copy_transform)
    if type(descriptor) ~= "table"
        or type(copy_transform) ~= "function" then
        return nil, "preview descriptor copy dependencies are unavailable"
    end
    local path, kind = BlueprintPreviewMesh.asset_path(descriptor)
    if not non_empty_string(path) or kind == nil then
        return nil, "preview descriptor mesh identity is unavailable"
    end
    local relative_transform = copy_transform(descriptor.relative_transform)
    if relative_transform == nil then
        return nil, "preview descriptor transform is invalid"
    end
    local copy = {
        relative_transform = relative_transform,
        material_slot_count = math.max(
            tonumber(descriptor.material_slot_count) or 1, 1
        ),
    }
    if kind == BlueprintPreviewMesh.SKELETAL then
        copy.mesh_kind = BlueprintPreviewMesh.SKELETAL
        copy.skeletal_mesh_path = path
    else
        -- Preserve the original v9 static descriptor shape. Older local
        -- records have no mesh_kind field and remain valid without migration.
        copy.static_mesh_path = path
    end
    return copy, nil
end

return BlueprintPreviewMesh

local RuntimeUtils = {}

function RuntimeUtils.make_logger(tag)
    tag = tostring(tag or "[BlueprintResearch]")
    return function(message)
        print(string.format("%s %s\n", tag, message))
    end
end

local function unwrap(value)
    if value == nil then return nil end
    local ok, result = pcall(function() return value:get() end)
    if ok then return result end
    return value
end

local function value_to_string(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end

    local ok, result = pcall(function() return value:ToString() end)
    if ok and result ~= nil then return tostring(result) end

    ok, result = pcall(function() return value:GetFullName() end)
    if ok and result ~= nil then return tostring(result) end

    return tostring(value)
end

local function object_name(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end

    local ok, valid = pcall(function() return value:IsValid() end)
    if not ok or not valid then return "<invalid>" end

    ok, valid = pcall(function() return value:GetFullName() end)
    if ok then return valid end
    return tostring(value)
end

local function is_valid_object(value)
    value = unwrap(value)
    if value == nil then return false end
    local ok, valid = pcall(function() return value:IsValid() end)
    return ok and valid == true
end

-- Some UE4SS Palworld builds expose freshly loaded UClass objects whose
-- UObject:IsValid() wrapper returns false even though reflection can safely
-- resolve the class.  Keep the normal instance guard strict and use this only
-- where a UClass is required (for example CreateWidget's class argument).
local function is_usable_class_object(value)
    value = unwrap(value)
    if value == nil then return false end
    if is_valid_object(value) then return true end

    local ok, full_name = pcall(function() return value:GetFullName() end)
    if not ok or type(full_name) ~= "string" then return false end
    return string.find(full_name, "Class", 1, true) ~= nil
end

local function class_object_name(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end
    local ok, full_name = pcall(function() return value:GetFullName() end)
    if ok and full_name ~= nil then return tostring(full_name) end
    return object_name(value)
end

local function safe_object_address(value)
    value = unwrap(value)
    if not is_valid_object(value) then return nil end
    local ok, address = pcall(function() return value:GetAddress() end)
    if not ok or address == nil then return nil end
    return tostring(address)
end

local function find_valid_instance(class_name, required_name_fragment)
    local objects = FindAllOf(class_name) or {}
    for _, object in ipairs(objects) do
        object = unwrap(object)
        if is_valid_object(object) then
            local full_name = object_name(object)
            if required_name_fragment == nil
                or string.find(full_name, required_name_fragment, 1, true) then
                return object
            end
        end
    end
    return nil
end

local function find_valid_instance_by_address(class_name, expected_address)
    if expected_address == nil then return nil end
    local objects = FindAllOf(class_name) or {}
    for _, object in ipairs(objects) do
        object = unwrap(object)
        if is_valid_object(object)
            and safe_object_address(object) == expected_address then
            return object
        end
    end
    return nil
end

local function safe_property(value, property_name)
    value = unwrap(value)
    if value == nil then return nil end
    local ok, result = pcall(function() return value[property_name] end)
    if ok then return result end
    return nil
end

local function format_number(value)
    local number = tonumber(value)
    if number == nil then return "?" end
    return string.format("%.6f", number)
end

local function format_vector(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end
    return string.format(
        "(%s,%s,%s)",
        format_number(safe_property(value, "X")),
        format_number(safe_property(value, "Y")),
        format_number(safe_property(value, "Z"))
    )
end

local function format_quaternion(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end
    return string.format(
        "(%s,%s,%s,%s)",
        format_number(safe_property(value, "X")),
        format_number(safe_property(value, "Y")),
        format_number(safe_property(value, "Z")),
        format_number(safe_property(value, "W"))
    )
end

local function format_transform(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end
    return string.format(
        "T%s R%s S%s",
        format_vector(safe_property(value, "Translation")),
        format_quaternion(safe_property(value, "Rotation")),
        format_vector(safe_property(value, "Scale3D"))
    )
end

local function copy_vector(value)
    value = unwrap(value)
    if value == nil then return nil end
    return {
        x = tonumber(safe_property(value, "X")),
        y = tonumber(safe_property(value, "Y")),
        z = tonumber(safe_property(value, "Z")),
    }
end

local function copy_quaternion(value)
    value = unwrap(value)
    if value == nil then return nil end
    return {
        x = tonumber(safe_property(value, "X")),
        y = tonumber(safe_property(value, "Y")),
        z = tonumber(safe_property(value, "Z")),
        w = tonumber(safe_property(value, "W")),
    }
end

local function copy_transform(value)
    value = unwrap(value)
    if value == nil then return nil end
    return {
        translation = copy_vector(safe_property(value, "Translation")),
        rotation = copy_quaternion(safe_property(value, "Rotation")),
        scale = copy_vector(safe_property(value, "Scale3D")),
    }
end

local function restore_transform(value)
    if value == nil or value.translation == nil
        or value.rotation == nil or value.scale == nil then
        return nil
    end
    return {
        Translation = {
            X = tonumber(value.translation.x),
            Y = tonumber(value.translation.y),
            Z = tonumber(value.translation.z),
        },
        Rotation = {
            X = tonumber(value.rotation.x),
            Y = tonumber(value.rotation.y),
            Z = tonumber(value.rotation.z),
            W = tonumber(value.rotation.w),
        },
        Scale3D = {
            X = tonumber(value.scale.x),
            Y = tonumber(value.scale.y),
            Z = tonumber(value.scale.z),
        },
    }
end

local function get_asset_path(value)
    value = unwrap(value)
    if not is_valid_object(value) then return nil end
    local full_name = object_name(value)
    local path = string.match(full_name, "^%S+%s+(.+)$") or full_name
    if string.sub(path, 1, 1) ~= "/" then return nil end
    return path
end

local function copy_rotator(value)
    value = unwrap(value)
    if value == nil then return nil end
    local pitch = tonumber(safe_property(value, "Pitch"))
    local yaw = tonumber(safe_property(value, "Yaw"))
    local roll = tonumber(safe_property(value, "Roll"))
    if pitch == nil or yaw == nil or roll == nil then return nil end
    return { Pitch = pitch, Yaw = yaw, Roll = roll }
end

local function format_guid(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end
    local a = tonumber(safe_property(value, "A"))
    local b = tonumber(safe_property(value, "B"))
    local c = tonumber(safe_property(value, "C"))
    local d = tonumber(safe_property(value, "D"))
    if a == nil or b == nil or c == nil or d == nil then return value_to_string(value) end
    local modulus = 4294967296
    return string.format(
        "%08X-%08X-%08X-%08X",
        a % modulus,
        b % modulus,
        c % modulus,
        d % modulus
    )
end

local function get_actor_from_hit_result(hit_result)
    if UnrealVersion:IsBelow(5, 0) then
        return hit_result.Actor:Get()
    elseif UnrealVersion:IsBelow(5, 4) then
        return hit_result.HitObjectHandle.Actor:Get()
    end
    return hit_result.HitObjectHandle.ReferenceObject:Get()
end

RuntimeUtils.unwrap = unwrap
RuntimeUtils.value_to_string = value_to_string
RuntimeUtils.object_name = object_name
RuntimeUtils.is_valid_object = is_valid_object
RuntimeUtils.is_usable_class_object = is_usable_class_object
RuntimeUtils.class_object_name = class_object_name
RuntimeUtils.safe_object_address = safe_object_address
RuntimeUtils.find_valid_instance = find_valid_instance
RuntimeUtils.find_valid_instance_by_address = find_valid_instance_by_address
RuntimeUtils.safe_property = safe_property
RuntimeUtils.format_number = format_number
RuntimeUtils.format_vector = format_vector
RuntimeUtils.format_quaternion = format_quaternion
RuntimeUtils.format_transform = format_transform
RuntimeUtils.copy_vector = copy_vector
RuntimeUtils.copy_quaternion = copy_quaternion
RuntimeUtils.copy_transform = copy_transform
RuntimeUtils.restore_transform = restore_transform
RuntimeUtils.get_asset_path = get_asset_path
RuntimeUtils.copy_rotator = copy_rotator
RuntimeUtils.format_guid = format_guid
RuntimeUtils.get_actor_from_hit_result = get_actor_from_hit_result

return RuntimeUtils


local Json = require("BlueprintCodeCodec")
local DefaultFileSystem = require("BlueprintLibraryFileSystem")

local BlueprintLibraryStore = {}

BlueprintLibraryStore.INDEX_SCHEMA_VERSION = 1
BlueprintLibraryStore.RECORD_SCHEMA_VERSION = 1
BlueprintLibraryStore.INDEX_FILE_NAME =
    "SimpleBuildingBlueprints.library.json"

local function trim(value)
    return (value:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function copy_table(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, child in pairs(value) do
        result[key] = copy_table(child)
    end
    return result
end

local function code_fingerprint(code)
    -- DJB2 stays below Lua's exact-integer boundary on every iteration.
    local hash = 5381
    for index = 1, #code do
        hash = (hash * 33 + string.byte(code, index)) % 4294967296
    end
    return string.format("%08x", hash)
end

local function utc_now()
    return os.date("!%Y-%m-%dT%H:%M:%SZ")
end

local function compact_utc_now()
    return os.date("!%Y%m%dT%H%M%SZ")
end

local function validate_name(value)
    if type(value) ~= "string" then
        return nil, "blueprint name must be a string"
    end
    local normalized = trim(value)
    if normalized == "" then return nil, "blueprint name is empty" end
    if normalized:find("[%z\1-\31\127]") ~= nil then
        return nil, "blueprint name contains control characters"
    end
    local character_count = utf8 ~= nil and utf8.len(normalized) or #normalized
    if character_count == nil then return nil, "blueprint name is not valid UTF-8" end
    if character_count > 64 then
        return nil, "blueprint name exceeds 64 characters"
    end
    if #normalized > 256 then
        return nil, "blueprint name exceeds the byte limit"
    end
    return normalized, nil
end

local function validate_entry(entry)
    if type(entry) ~= "table" then return false, "entry is not an object" end
    if type(entry.id) ~= "string"
        or entry.id:match("^[A-Za-z0-9_-]+$") == nil then
        return false, "entry id is invalid"
    end
    local name, name_error = validate_name(entry.name)
    if name == nil or name ~= entry.name then
        return false, name_error or "entry name is not normalized"
    end
    if type(entry.created_at_utc) ~= "string" then
        return false, "entry creation time is missing"
    end
    if type(entry.record_file) ~= "string"
        or entry.record_file ~= "SBB_Blueprint_" .. entry.id .. ".json" then
        return false, "entry record file is invalid"
    end
    if type(entry.thumbnail_file) ~= "string"
        or entry.thumbnail_file ~= "SBB_Thumbnail_" .. entry.id .. ".png" then
        return false, "entry thumbnail file is invalid"
    end
    if entry.thumbnail_state ~= "pending"
        and entry.thumbnail_state ~= "ready"
        and entry.thumbnail_state ~= "failed" then
        return false, "entry thumbnail state is invalid"
    end
    if type(entry.fingerprint) ~= "string"
        or entry.fingerprint:match("^[0-9a-f]+$") == nil then
        return false, "entry fingerprint is invalid"
    end
    if type(entry.building_count) ~= "number"
        or entry.building_count < 1
        or entry.building_count % 1 ~= 0 then
        return false, "entry building count is invalid"
    end
    return true, nil
end

local function validate_index(index)
    if type(index) ~= "table" then return false, "index is not an object" end
    if index.schema_version ~= BlueprintLibraryStore.INDEX_SCHEMA_VERSION then
        return false, "unsupported library index schema="
            .. tostring(index.schema_version)
    end
    if type(index.entries) ~= "table" then
        return false, "library entries are missing"
    end
    local seen = {}
    for position, entry in ipairs(index.entries) do
        local valid, error_value = validate_entry(entry)
        if not valid then
            return false, "invalid library entry position=" .. tostring(position)
                .. " error=" .. tostring(error_value)
        end
        if seen[entry.id] then
            return false, "duplicate library entry id=" .. entry.id
        end
        seen[entry.id] = true
    end
    return true, nil
end

local function validate_record(record)
    if type(record) ~= "table" then return false, "record is not an object" end
    if record.schema_version
        ~= BlueprintLibraryStore.RECORD_SCHEMA_VERSION then
        return false, "unsupported library record schema="
            .. tostring(record.schema_version)
    end
    local valid_entry, entry_error = validate_entry(record.metadata)
    if not valid_entry then return false, entry_error end
    if record.id ~= record.metadata.id then
        return false, "record id disagrees with metadata"
    end
    if type(record.blueprint_code) ~= "string"
        or record.blueprint_code == "" then
        return false, "record blueprint code is missing"
    end
    if code_fingerprint(record.blueprint_code)
        ~= record.metadata.fingerprint then
        return false, "record blueprint fingerprint mismatch"
    end
    if record.type_templates ~= nil
        and type(record.type_templates) ~= "table" then
        return false, "record type templates are invalid"
    end
    return true, nil
end

local function new_index()
    return {
        schema_version = BlueprintLibraryStore.INDEX_SCHEMA_VERSION,
        entries = {},
    }
end

function BlueprintLibraryStore.install(deps)
    assert(type(deps) == "table",
        "BlueprintLibraryStore dependencies are required")
    local get_storage_directories = assert(
        deps.get_storage_directories,
        "BlueprintLibraryStore get_storage_directories is required"
    )
    local create_primary_directory = deps.create_primary_directory
    local create_legacy_directory = deps.create_legacy_directory
    local file_system = deps.filesystem or DefaultFileSystem
    local normalize_directory = assert(file_system.normalize_directory)
    local join_path = assert(file_system.join_path)
    local read_file = assert(file_system.read_file)
    local file_exists = assert(file_system.file_exists)
    local safe_remove = assert(file_system.safe_remove)
    local atomic_write = assert(file_system.atomic_write)
    local ensure_writable_directory =
        assert(file_system.ensure_writable_directory)
    local log = deps.log or function() end
    local decode_blueprint_code = deps.decode_blueprint_code
    local on_index_changed = deps.on_index_changed
    local store = {
        directory = nil,
        primary_directory = nil,
        legacy_directory = nil,
        storage_kind = nil,
        write_kind = nil,
        index_path = nil,
        index = nil,
        primary_index = nil,
        legacy_index = nil,
        entry_sources = {},
        loaded_from_backup = false,
        primary_loaded_from_backup = false,
        legacy_loaded_from_backup = false,
        legacy_load_error = nil,
    }

    local function decode_index(content)
        local index, decode_error = Json.decode_json(content)
        if index == nil then return nil, decode_error end
        local valid, validation_error = validate_index(index)
        if not valid then return nil, validation_error end
        return index, nil
    end

    local function encode_validated(value, validator)
        local valid, validation_error = validator(value)
        if not valid then return nil, validation_error end
        local content, encode_error = Json.encode_json(value)
        if content == nil then return nil, encode_error end
        local decoded, decode_error = Json.decode_json(content)
        if decoded == nil then return nil, decode_error end
        local decoded_valid, decoded_validation_error = validator(decoded)
        if not decoded_valid then return nil, decoded_validation_error end
        return content, nil
    end

    local function index_path_for(directory)
        return join_path(
            directory, BlueprintLibraryStore.INDEX_FILE_NAME
        )
    end

    local function index_exists(directory)
        if directory == nil then return false end
        local path = index_path_for(directory)
        return file_exists(path) or file_exists(path .. ".bak")
    end

    local function load_index_from_directory(directory)
        local path = index_path_for(directory)
        local primary_content, primary_read_error = read_file(path)
        if primary_content ~= nil then
            local primary_index, primary_decode_error =
                decode_index(primary_content)
            if primary_index ~= nil then
                return primary_index, path, nil
            end
            primary_read_error = primary_decode_error
        end

        local backup_path = path .. ".bak"
        local backup_content, backup_read_error = read_file(backup_path)
        if backup_content ~= nil then
            local backup_index, backup_decode_error =
                decode_index(backup_content)
            if backup_index ~= nil then
                return backup_index, backup_path, nil
            end
            backup_read_error = backup_decode_error
        end
        return nil, nil, "library index and backup are invalid primary="
            .. tostring(primary_read_error) .. " backup="
            .. tostring(backup_read_error)
    end

    local function same_directory(left, right)
        if left == nil or right == nil then return false end
        return string.lower(left) == string.lower(right)
    end

    local function directory_for_kind(kind)
        if kind == "primary" then return store.primary_directory end
        if kind == "legacy" then return store.legacy_directory end
        return nil
    end

    local function index_for_kind(kind)
        if kind == "primary" then return store.primary_index end
        if kind == "legacy" then return store.legacy_index end
        return nil
    end

    local function set_index_for_kind(kind, index)
        if kind == "primary" then
            store.primary_index = index
        elseif kind == "legacy" then
            store.legacy_index = index
        end
    end

    local function entry_in_index(index, id)
        if type(index) ~= "table" then return nil, nil end
        for position, entry in ipairs(index.entries) do
            if entry.id == id then return entry, position end
        end
        return nil, nil
    end

    local function rebuild_merged_index()
        local entries = {}
        local sources = {}
        local merge_order = {}
        local function include(index, kind)
            if type(index) ~= "table" then return end
            for _, entry in ipairs(index.entries) do
                local source = sources[entry.id]
                if source == nil then
                    source = {
                        active = kind,
                        primary = false,
                        legacy = false,
                    }
                    sources[entry.id] = source
                    entries[#entries + 1] = copy_table(entry)
                    merge_order[entry.id] = #entries
                end
                source[kind] = true
                if kind == "primary" then source.active = "primary" end
            end
        end
        include(store.primary_index, "primary")
        include(store.legacy_index, "legacy")
        table.sort(entries, function(left, right)
            if left.created_at_utc ~= right.created_at_utc then
                return left.created_at_utc > right.created_at_utc
            end
            return merge_order[left.id] < merge_order[right.id]
        end)
        store.index = {
            schema_version = BlueprintLibraryStore.INDEX_SCHEMA_VERSION,
            entries = entries,
        }
        store.entry_sources = sources
        if type(on_index_changed) == "function" then
            local published, publish_error = pcall(
                on_index_changed, copy_table(store.index)
            )
            if not published then
                log("blueprint library index publication isolated error="
                    .. tostring(publish_error))
            end
        end
    end

    local function ensure_kind_writable(kind)
        local directory = directory_for_kind(kind)
        if directory == nil then
            return false, tostring(kind) .. " directory is unavailable"
        end
        local creator = kind == "primary"
            and create_primary_directory or create_legacy_directory
        return ensure_writable_directory(directory, creator)
    end

    local function resolve_directories()
        if store.directory ~= nil then return store.directory, nil end
        local directories, directory_error = get_storage_directories()
        if type(directories) ~= "table" then
            return nil, "storage directories unavailable: "
                .. tostring(directory_error)
        end
        store.primary_directory =
            normalize_directory(directories.primary_directory)
        store.legacy_directory =
            normalize_directory(directories.legacy_directory)

        local primary_error = nil
        if store.primary_directory ~= nil then
            local primary_ready, ready_error =
                ensure_kind_writable("primary")
            if primary_ready then
                store.directory = store.primary_directory
                store.write_kind = "primary"
                store.storage_kind = "primary"
                store.index_path = index_path_for(store.directory)
                return store.directory, nil
            end
            primary_error = ready_error
        else
            primary_error = tostring(directory_error
                or "primary directory is unavailable")
        end

        if store.legacy_directory ~= nil then
            local legacy_ready, legacy_error =
                ensure_kind_writable("legacy")
            if legacy_ready then
                store.directory = store.legacy_directory
                store.write_kind = "legacy"
                store.storage_kind = "legacy-directory-fallback"
                store.index_path = index_path_for(store.directory)
                log("blueprint library using legacy write storage "
                    .. "primaryError=" .. tostring(primary_error))
                return store.directory, nil
            end
            return nil, "no writable blueprint library directory primary="
                .. tostring(primary_error) .. " legacy="
                .. tostring(legacy_error)
        end
        return nil, "no writable blueprint library directory primary="
            .. tostring(primary_error)
            .. " legacy=legacy directory is unavailable"
    end

    local function load_or_create_index(kind, create_when_missing)
        local directory = directory_for_kind(kind)
        if directory == nil then return nil, false, nil end
        local path = index_path_for(directory)
        if not index_exists(directory) then
            if not create_when_missing then return nil, false, nil end
            local content, encode_error =
                encode_validated(new_index(), validate_index)
            if content == nil then return nil, false, encode_error end
            local written, write_error = atomic_write(path, content)
            if not written then return nil, false, write_error end
            log("blueprint library index created path=" .. path)
        end
        local index, source_path, load_error =
            load_index_from_directory(directory)
        if index == nil then return nil, false, load_error end
        local from_backup = source_path == path .. ".bak"
        if from_backup then
            log("blueprint library recovered from backup path="
                .. source_path)
        end
        return index, from_backup, nil
    end

    local function persist_kind_index(kind, index)
        local writable, writable_error = ensure_kind_writable(kind)
        if not writable then return false, writable_error end
        local content, encode_error =
            encode_validated(index, validate_index)
        if content == nil then return false, encode_error end
        local directory = directory_for_kind(kind)
        local written, write_error =
            atomic_write(index_path_for(directory), content)
        if not written then return false, write_error end
        set_index_for_kind(kind, index)
        if kind == "primary" then
            store.primary_loaded_from_backup = false
        else
            store.legacy_loaded_from_backup = false
        end
        store.loaded_from_backup = store.write_kind == "primary"
            and store.primary_loaded_from_backup
            or store.legacy_loaded_from_backup
        rebuild_merged_index()
        return true, nil
    end

    function store.initialize()
        if store.index ~= nil then return true, nil end
        local _, directory_error = resolve_directories()
        if store.directory == nil then return false, directory_error end

        if store.write_kind == "primary" then
            local primary_index, primary_backup, primary_error =
                load_or_create_index("primary", true)
            if primary_index == nil then return false, primary_error end
            store.primary_index = primary_index
            store.primary_loaded_from_backup = primary_backup

            if store.legacy_directory ~= nil
                and not same_directory(
                    store.primary_directory, store.legacy_directory
                )
                and index_exists(store.legacy_directory) then
                local legacy_index, legacy_backup, legacy_error =
                    load_or_create_index("legacy", false)
                if legacy_index ~= nil then
                    store.legacy_index = legacy_index
                    store.legacy_loaded_from_backup = legacy_backup
                    store.storage_kind = "dual-directory"
                else
                    store.legacy_load_error = legacy_error
                    log("blueprint legacy library ignored error="
                        .. tostring(legacy_error))
                end
            end
        else
            local legacy_index, legacy_backup, legacy_error =
                load_or_create_index("legacy", true)
            if legacy_index == nil then return false, legacy_error end
            store.legacy_index = legacy_index
            store.legacy_loaded_from_backup = legacy_backup
        end

        store.loaded_from_backup = store.write_kind == "primary"
            and store.primary_loaded_from_backup
            or store.legacy_loaded_from_backup
        rebuild_merged_index()
        return true, nil
    end

    local function ensure_initialized()
        if store.index ~= nil then return true, nil end
        return store.initialize()
    end

    local function entry_by_id(id)
        for position, entry in ipairs(store.index.entries) do
            if entry.id == id then return entry, position end
        end
        return nil, nil
    end

    local function active_kind_for_id(id)
        local source = store.entry_sources[id]
        return source ~= nil and source.active or nil
    end

    local function active_directory_for_id(id)
        return directory_for_kind(active_kind_for_id(id))
    end

    local function load_record_from_kind(kind, entry)
        local directory = directory_for_kind(kind)
        if directory == nil then
            return nil, tostring(kind) .. " directory is unavailable"
        end
        local record_path = join_path(directory, entry.record_file)
        local content, read_error = read_file(record_path)
        if content == nil then return nil, read_error end
        local record, decode_error = Json.decode_json(content)
        if record == nil then return nil, decode_error end
        local valid, validation_error = validate_record(record)
        if not valid then return nil, validation_error end
        if record.id ~= entry.id
            or record.metadata.fingerprint ~= entry.fingerprint then
            return nil, "record metadata disagrees with library index"
        end
        return record, nil
    end

    local function next_id(code)
        local base = tostring(compact_utc_now() or os.time())
            .. "_" .. code_fingerprint(code)
        for sequence = 0, 999 do
            local id = base .. "_" .. string.format("%03d", sequence)
            local record_file = "SBB_Blueprint_" .. id .. ".json"
            if entry_by_id(id) == nil
                and not file_exists(join_path(store.directory, record_file)) then
                return id
            end
        end
        return nil
    end

    function store.create(name, blueprint_code, metadata)
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return nil, initialize_error end
        local normalized_name, name_error = validate_name(name)
        if normalized_name == nil then return nil, name_error end
        if type(blueprint_code) ~= "string" or blueprint_code == "" then
            return nil, "blueprint code is empty"
        end
        local decoded_blueprint = nil
        if type(decode_blueprint_code) == "function" then
            local decode_error
            decoded_blueprint, decode_error =
                decode_blueprint_code(blueprint_code)
            if decoded_blueprint == nil then
                return nil, "blueprint code validation failed: "
                    .. tostring(decode_error)
            end
        end
        metadata = metadata or {}
        local building_count = tonumber(metadata.building_count)
        if building_count == nil and type(decoded_blueprint) == "table" then
            building_count = type(decoded_blueprint.b) == "table"
                and #decoded_blueprint.b
                or type(decoded_blueprint.buildings) == "table"
                    and #decoded_blueprint.buildings or nil
        end
        building_count = math.floor(tonumber(building_count) or 0)
        if building_count < 1 then return nil, "building count is invalid" end

        local id = next_id(blueprint_code)
        if id == nil then return nil, "unable to allocate a unique blueprint id" end
        local created_at = tostring(metadata.created_at_utc or utc_now())
        local entry = {
            id = id,
            name = normalized_name,
            created_at_utc = created_at,
            building_count = building_count,
            blueprint_schema_version = tonumber(
                metadata.blueprint_schema_version
            ) or 0,
            code_chars = #blueprint_code,
            fingerprint = code_fingerprint(blueprint_code),
            record_file = "SBB_Blueprint_" .. id .. ".json",
            thumbnail_file = "SBB_Thumbnail_" .. id .. ".png",
            thumbnail_state = "pending",
        }
        local record = {
            schema_version = BlueprintLibraryStore.RECORD_SCHEMA_VERSION,
            id = id,
            metadata = copy_table(entry),
            blueprint_code = blueprint_code,
            type_templates = type(metadata.type_templates) == "table"
                and copy_table(metadata.type_templates) or nil,
        }
        local record_content, record_encode_error = encode_validated(
            record, validate_record
        )
        if record_content == nil then return nil, record_encode_error end
        local record_path = join_path(store.directory, entry.record_file)
        local record_written, record_write_error =
            atomic_write(record_path, record_content)
        if not record_written then return nil, record_write_error end

        local next_index = copy_table(index_for_kind(store.write_kind))
        table.insert(next_index.entries, 1, copy_table(entry))
        local index_written, index_write_error =
            persist_kind_index(store.write_kind, next_index)
        if not index_written then
            safe_remove(record_path)
            safe_remove(record_path .. ".bak")
            return nil, index_write_error
        end
        return copy_table(entry), nil
    end

    function store.validate_name(value)
        return validate_name(value)
    end

    function store.list()
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return nil, initialize_error end
        return copy_table(store.index.entries), nil
    end

    function store.load(id)
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return nil, initialize_error end
        local entry = entry_by_id(id)
        if entry == nil then return nil, "blueprint entry was not found" end
        local source = store.entry_sources[id]
        local active_kind = source ~= nil and source.active or nil
        local record, load_error =
            load_record_from_kind(active_kind, entry)
        if record == nil and source ~= nil
            and active_kind == "primary" and source.legacy then
            record, load_error = load_record_from_kind("legacy", entry)
        end
        if record == nil then return nil, load_error end
        return copy_table(record), nil
    end

    function store.rename(id, name)
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return nil, initialize_error end
        local normalized_name, name_error = validate_name(name)
        if normalized_name == nil then return nil, name_error end

        local entry = entry_by_id(id)
        if entry == nil then return nil, "blueprint entry was not found" end
        if entry.name == normalized_name then
            return copy_table(entry), nil
        end
        local kind = active_kind_for_id(id)
        local source_entry, source_position =
            entry_in_index(index_for_kind(kind), id)
        if source_entry == nil then
            return nil, "blueprint entry source was not found"
        end
        local directory = directory_for_kind(kind)

        local record_path = join_path(directory, source_entry.record_file)
        local original_record_content, read_error = read_file(record_path)
        if original_record_content == nil then return nil, read_error end
        local record, decode_error = Json.decode_json(original_record_content)
        if record == nil then return nil, decode_error end
        local valid, validation_error = validate_record(record)
        if not valid then return nil, validation_error end
        if record.id ~= source_entry.id
            or record.metadata.fingerprint ~= source_entry.fingerprint then
            return nil, "record metadata disagrees with library index"
        end

        record.metadata.name = normalized_name
        local renamed_record_content, encode_error = encode_validated(
            record, validate_record
        )
        if renamed_record_content == nil then return nil, encode_error end

        local record_written, record_write_error = atomic_write(
            record_path, renamed_record_content
        )
        if not record_written then return nil, record_write_error end

        local next_index = copy_table(index_for_kind(kind))
        next_index.entries[source_position].name = normalized_name
        local index_written, index_write_error =
            persist_kind_index(kind, next_index)
        if not index_written then
            local rolled_back, rollback_error = atomic_write(
                record_path, original_record_content
            )
            return nil, tostring(index_write_error)
                .. (rolled_back and "" or "; record rollback failed: "
                    .. tostring(rollback_error))
        end
        local renamed_entry = entry_by_id(id)
        return copy_table(renamed_entry), nil
    end

    function store.remove(id)
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return nil, initialize_error end
        local entry = entry_by_id(id)
        if entry == nil then return nil, "blueprint entry was not found" end

        local source = store.entry_sources[id] or {}
        local operations = {}
        -- Remove the legacy copy first and the primary copy second. If either
        -- index write fails, all completed index writes are rolled back so a
        -- duplicate cannot reappear from the other directory.
        for _, kind in ipairs({ "legacy", "primary" }) do
            if source[kind] then
                local writable, writable_error =
                    ensure_kind_writable(kind)
                if not writable then return nil, writable_error end
                local source_index = index_for_kind(kind)
                local source_entry, position =
                    entry_in_index(source_index, id)
                if source_entry ~= nil then
                    local next_index = copy_table(source_index)
                    table.remove(next_index.entries, position)
                    local original_content, original_encode_error =
                        encode_validated(source_index, validate_index)
                    if original_content == nil then
                        return nil, original_encode_error
                    end
                    local next_content, next_encode_error =
                        encode_validated(next_index, validate_index)
                    if next_content == nil then
                        return nil, next_encode_error
                    end
                    operations[#operations + 1] = {
                        kind = kind,
                        directory = directory_for_kind(kind),
                        entry = copy_table(source_entry),
                        index_path = index_path_for(
                            directory_for_kind(kind)
                        ),
                        next_index = next_index,
                        original_content = original_content,
                        next_content = next_content,
                    }
                end
            end
        end

        local applied = {}
        for _, operation in ipairs(operations) do
            local written, write_error = atomic_write(
                operation.index_path, operation.next_content
            )
            if not written then
                local rollback_errors = {}
                for position = #applied, 1, -1 do
                    local previous = applied[position]
                    local rolled_back, rollback_error = atomic_write(
                        previous.index_path, previous.original_content
                    )
                    if not rolled_back then
                        rollback_errors[#rollback_errors + 1] =
                            tostring(previous.kind) .. ": "
                            .. tostring(rollback_error)
                    end
                end
                return nil, tostring(write_error)
                    .. (#rollback_errors > 0
                        and "; index rollback failed: "
                            .. table.concat(rollback_errors, "; ")
                        or "")
            end
            applied[#applied + 1] = operation
        end

        for _, operation in ipairs(operations) do
            set_index_for_kind(operation.kind, operation.next_index)
            if operation.kind == "primary" then
                store.primary_loaded_from_backup = false
            else
                store.legacy_loaded_from_backup = false
            end
        end
        store.loaded_from_backup = store.write_kind == "primary"
            and store.primary_loaded_from_backup
            or store.legacy_loaded_from_backup
        rebuild_merged_index()
        local cleanup_errors = {}
        for _, operation in ipairs(operations) do
            -- Synchronize the recovery index after deletion so loading a
            -- backup cannot resurrect a deleted entry from either directory.
            local primary_content, primary_read_error =
                read_file(operation.index_path)
            if primary_content ~= nil then
                local backup_written, backup_write_error = atomic_write(
                    operation.index_path .. ".bak", primary_content
                )
                if not backup_written then
                    cleanup_errors[#cleanup_errors + 1] =
                        tostring(operation.kind)
                        .. " index backup sync failed: "
                        .. tostring(backup_write_error)
                else
                    safe_remove(operation.index_path .. ".bak.bak")
                end
            else
                cleanup_errors[#cleanup_errors + 1] =
                    tostring(operation.kind)
                    .. " index backup sync read failed: "
                    .. tostring(primary_read_error)
            end

            local cleanup_paths = {
                join_path(
                    operation.directory, operation.entry.record_file
                ),
                join_path(
                    operation.directory, operation.entry.record_file
                ) .. ".bak",
                join_path(
                    operation.directory, operation.entry.thumbnail_file
                ),
            }
            for _, path in ipairs(cleanup_paths) do
                local removed, remove_error = safe_remove(path)
                if not removed then
                    cleanup_errors[#cleanup_errors + 1] =
                        path .. ": " .. tostring(remove_error)
                end
            end
        end

        local cleanup_warning = #cleanup_errors > 0
            and table.concat(cleanup_errors, "; ") or nil
        return copy_table(entry), cleanup_warning
    end

    function store.set_type_templates(id, type_templates)
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return false, initialize_error end
        if type(type_templates) ~= "table" then
            return false, "type templates are invalid"
        end
        local record, load_error = store.load(id)
        if record == nil then return false, load_error end
        record.type_templates = copy_table(type_templates)
        local content, encode_error = encode_validated(record, validate_record)
        if content == nil then return false, encode_error end
        local entry = entry_by_id(id)
        if entry == nil then return false, "blueprint entry was not found" end
        local kind = active_kind_for_id(id)
        local writable, writable_error = ensure_kind_writable(kind)
        if not writable then return false, writable_error end
        return atomic_write(
            join_path(directory_for_kind(kind), entry.record_file), content
        )
    end

    function store.set_thumbnail_state(id, state)
        if state ~= "pending" and state ~= "ready" and state ~= "failed" then
            return false, "thumbnail state is invalid"
        end
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return false, initialize_error end
        local entry = entry_by_id(id)
        if entry == nil then return false, "blueprint entry was not found" end
        if entry.thumbnail_state == state then return true, nil end
        local kind = active_kind_for_id(id)
        local _, position = entry_in_index(index_for_kind(kind), id)
        if position == nil then
            return false, "blueprint entry source was not found"
        end
        local next_index = copy_table(index_for_kind(kind))
        next_index.entries[position].thumbnail_state = state
        local written, write_error =
            persist_kind_index(kind, next_index)
        if not written then return false, write_error end
        return true, nil
    end

    function store.get_thumbnail_path(id)
        local initialized, initialize_error = ensure_initialized()
        if not initialized then return nil, initialize_error end
        local entry = entry_by_id(id)
        if entry == nil then return nil, "blueprint entry was not found" end
        local directory = active_directory_for_id(id)
        if directory == nil then
            return nil, "blueprint entry source directory was not found"
        end
        return join_path(directory, entry.thumbnail_file), nil
    end

    function store.get_directory()
        local directory, directory_error = resolve_directories()
        return directory, directory_error
    end

    function store.get_index_path()
        local _, directory_error = resolve_directories()
        if store.index_path == nil then return nil, directory_error end
        return store.index_path, nil
    end

    function store.get_state()
        return {
            directory = store.directory,
            primary_directory = store.primary_directory,
            legacy_directory = store.legacy_directory,
            storage_kind = store.storage_kind,
            index_path = store.index_path,
            loaded = store.index ~= nil,
            loaded_from_backup = store.loaded_from_backup,
            primary_loaded_from_backup =
                store.primary_loaded_from_backup,
            legacy_loaded_from_backup =
                store.legacy_loaded_from_backup,
            legacy_load_error = store.legacy_load_error,
            primary_entry_count = store.primary_index ~= nil
                and #store.primary_index.entries or 0,
            legacy_entry_count = store.legacy_index ~= nil
                and #store.legacy_index.entries or 0,
            entry_count = store.index ~= nil and #store.index.entries or 0,
        }
    end

    return store
end

return BlueprintLibraryStore

local BlueprintPlacementHUDMaterials = {}

local HUD_CLASS_NAME = "WBP_IngameConstruction_C"
local SET_MATERIAL_FUNCTION_PATH =
    "/Game/Pal/Blueprint/UI/UserInterface/InGame/Construction/" ..
    "WBP_IngameConstruction.WBP_IngameConstruction_C:SetMaterial"
local CELL_NAMES = {
    "Item_0",
    "Item_1",
    "Item_2",
    "Item_3",
}
local MAX_VISIBLE_MATERIALS = #CELL_NAMES

local function integer(value)
    value = tonumber(value) or 0
    return math.max(0, math.floor(value + 0.5))
end

function BlueprintPlacementHUDMaterials.install(deps)
    assert(type(deps) == "table", "placement HUD materials requires deps")

    local material_gate = assert(
        deps.material_gate, "placement HUD material_gate is required"
    )
    local log = assert(deps.log, "placement HUD log is required")
    local unwrap = assert(deps.unwrap, "placement HUD unwrap is required")
    local value_to_string = assert(
        deps.value_to_string, "placement HUD value_to_string is required"
    )
    local object_name = assert(
        deps.object_name, "placement HUD object_name is required"
    )
    local is_valid_object = assert(
        deps.is_valid_object, "placement HUD is_valid_object is required"
    )
    local safe_object_address = assert(
        deps.safe_object_address,
        "placement HUD safe_object_address is required"
    )
    local find_in_instance = assert(
        deps.find_in_instance, "placement HUD find_in_instance is required"
    )
    local get_blueprint = assert(
        deps.get_blueprint, "placement HUD get_blueprint is required"
    )
    local get_builder = assert(
        deps.get_builder, "placement HUD get_builder is required"
    )
    local is_placement_active = assert(
        deps.is_placement_active,
        "placement HUD is_placement_active is required"
    )

    local runtime = {
        applying = false,
        bound_widget = nil,
        bound_cells = nil,
        cached_materials = nil,
        applied = false,
        set_material_hook_registered = false,
        set_material_hook_callback = nil,
        hook_reapply_error_logged = false,
    }

    local function get_visibility_label(widget)
        local ok, visibility = pcall(function()
            return widget:GetVisibility()
        end)
        if not ok then return nil end
        return value_to_string(visibility)
    end

    local function is_widget_visible(widget)
        local label = get_visibility_label(widget)
        if label == nil then return true end
        local lowered = string.lower(tostring(label))
        return lowered ~= "1"
            and lowered ~= "2"
            and not string.find(lowered, "collapsed", 1, true)
            and not string.find(lowered, "hidden", 1, true)
    end

    local function get_world(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local world = nil
        pcall(function() world = unwrap(value:GetWorld()) end)
        return world
    end

    local function is_same_world(left, right)
        local left_world = get_world(left)
        local right_world = get_world(right)
        if not is_valid_object(left_world) or not is_valid_object(right_world) then
            return true
        end
        return safe_object_address(left_world)
            == safe_object_address(right_world)
    end

    local function resolve_cells(widget)
        local cells = {}
        for index, cell_name in ipairs(CELL_NAMES) do
            cells[index] = unwrap(find_in_instance(widget, cell_name))
            if not is_valid_object(cells[index]) then
                return nil, "original material cell unavailable: " .. cell_name
            end
        end
        return cells, nil
    end

    local function are_cells_valid(cells)
        if type(cells) ~= "table" then return false end
        for index = 1, MAX_VISIBLE_MATERIALS do
            if not is_valid_object(unwrap(cells[index])) then return false end
        end
        return true
    end

    local function clear_bound_hud()
        runtime.bound_widget = nil
        runtime.bound_cells = nil
    end

    local function find_active_hud(builder)
        local best_widget = nil
        local best_cells = nil
        local best_score = -1
        local widgets = FindAllOf(HUD_CLASS_NAME) or {}
        for _, widget_value in ipairs(widgets) do
            local widget = unwrap(widget_value)
            if is_valid_object(widget)
                and is_widget_visible(widget)
                and is_same_world(widget, builder) then
                local cells = resolve_cells(widget)
                if cells ~= nil then
                    local score = 10
                    local full_name = object_name(widget)
                    if string.find(full_name, "/Engine/Transient", 1, true) then
                        score = score + 5
                    end
                    if score > best_score then
                        best_score = score
                        best_widget = widget
                        best_cells = cells
                    end
                end
            end
        end
        return best_widget, best_cells
    end

    local function get_bound_hud(builder)
        local widget = unwrap(runtime.bound_widget)
        local cells = runtime.bound_cells
        if not is_valid_object(widget)
            or not is_widget_visible(widget)
            or not is_same_world(widget, builder)
            or not are_cells_valid(cells) then
            return nil, nil
        end
        return widget, cells
    end

    local function bind_active_hud(builder)
        local widget, cells = get_bound_hud(builder)
        if widget ~= nil then return widget, cells, nil end

        -- A placement HUD is created by the original StartBuildObject call,
        -- which happens after our placement session starts. Discover it once
        -- when ready and retain only the live widget/cell references. No
        -- original UObject ownership or widget-tree pointer is modified.
        clear_bound_hud()
        widget, cells = find_active_hud(builder)
        if not is_valid_object(widget) then
            return nil, nil, "active WBP_IngameConstruction_C not found"
        end
        if not are_cells_valid(cells) then
            return nil, nil, "original material cells unavailable"
        end

        runtime.bound_widget = widget
        runtime.bound_cells = cells
        return widget, cells, nil
    end

    local function collect_materials(blueprint, builder)
        local requirement, requirement_error =
            material_gate.collect_required_materials(blueprint)
        if requirement == nil then return nil, requirement_error end

        local available, available_error =
            material_gate.collect_available_materials(
                builder, requirement.material_order
            )
        local availability_known = available ~= nil
        if not availability_known then
            available = {}
            log("blueprint placement HUD availability unavailable; "
                .. "original SetMaterial will still query inventory error="
                .. tostring(available_error))
        end

        local materials = {}
        for _, item_id in ipairs(requirement.material_order) do
            local required = integer(requirement.required[item_id])
            local have = integer(available[item_id])
            local shortage = availability_known
                and math.max(required - have, 0) or 0
            materials[#materials + 1] = {
                item_id = tostring(item_id),
                required = required,
                available = have,
                missing = availability_known and shortage > 0,
                shortage = shortage,
            }
        end

        table.sort(materials, function(left, right)
            if left.missing ~= right.missing then return left.missing end
            if left.shortage ~= right.shortage then
                return left.shortage > right.shortage
            end
            if left.required ~= right.required then
                return left.required > right.required
            end
            return left.item_id < right.item_id
        end)
        return materials, nil
    end

    local function set_cell_visibility(cell, visible)
        cell = unwrap(cell)
        if not is_valid_object(cell) then return end
        pcall(function() cell:SetVisibility(visible and 0 or 1) end)
    end

    local function get_cached_materials(blueprint, builder)
        if type(runtime.cached_materials) == "table" then
            return runtime.cached_materials, nil
        end
        local materials, material_error = collect_materials(blueprint, builder)
        if materials == nil then return nil, material_error end
        runtime.cached_materials = materials
        return materials, nil
    end

    local function apply_to_hud(widget, cells, materials, reason)
        if runtime.applying then
            return false, "aggregate material override is already applying"
        end

        runtime.applying = true
        local apply_ok, apply_error = pcall(function()
            for index = 1, MAX_VISIBLE_MATERIALS do
                local material = materials[index]
                if material == nil then
                    set_cell_visibility(cells[index], false)
                else
                    -- Keep the original widget's own item icon, inventory
                    -- query, number formatting and shortage color.  Only its
                    -- required item/count inputs are replaced with blueprint
                    -- aggregate values after the anchor Setup has completed.
                    set_cell_visibility(cells[index], true)
                    widget:SetMaterial(
                        index - 1,
                        FName(material.item_id),
                        material.required
                    )
                    set_cell_visibility(cells[index], true)
                end
            end
        end)
        runtime.applying = false
        if not apply_ok then
            return false, "original SetMaterial failed: "
                .. tostring(apply_error)
        end

        runtime.applied = true
        return true, nil
    end

    local function ensure_set_material_hook()
        if runtime.set_material_hook_registered then return true end

        local function apply_stock_material_override(context, index)
            if not is_placement_active()
                or type(runtime.cached_materials) ~= "table"
                or runtime.applying then
                return
            end

            -- UE4SS invokes the callback for a /Game/ Blueprint function only
            -- after the function has executed. Mutating RemoteUnrealParam here
            -- is therefore too late. Reapply the aggregate value through the
            -- live context after the stock anchor value has rendered. The
            -- applying guard makes the nested SetMaterial hook a no-op.
            local slot_index = tonumber(unwrap(index))
                or tonumber(value_to_string(index))
            if slot_index == nil then return end
            slot_index = math.floor(slot_index) + 1
            if slot_index < 1 or slot_index > MAX_VISIBLE_MATERIALS then
                return
            end

            local material = runtime.cached_materials[slot_index]
            local replacement_id = material ~= nil
                and FName(material.item_id) or FName("None")
            local replacement_count = material ~= nil
                and material.required or 0
            local widget = unwrap(context)
            if not is_valid_object(widget) then return end

            runtime.applying = true
            local reapply_ok, reapply_error = pcall(function()
                widget:SetMaterial(
                    slot_index - 1, replacement_id, replacement_count
                )
            end)
            runtime.applying = false
            if not reapply_ok and not runtime.hook_reapply_error_logged then
                runtime.hook_reapply_error_logged = true
                log("blueprint placement HUD SetMaterial post-reapply failed error="
                    .. tostring(reapply_error))
            end
        end

        local callback = function(...)
            local callback_ok, callback_error = pcall(
                apply_stock_material_override, ...
            )
            if not callback_ok then
                runtime.applying = false
                log("blueprint placement HUD SetMaterial hook isolated error="
                    .. tostring(callback_error))
            end
        end

        runtime.set_material_hook_callback = callback
        local ok, pre_id, post_id = pcall(
            RegisterHook, SET_MATERIAL_FUNCTION_PATH, callback
        )
        if not ok then
            runtime.set_material_hook_callback = nil
            log("blueprint placement HUD SetMaterial hook registration failed path="
                .. SET_MATERIAL_FUNCTION_PATH .. " error=" .. tostring(pre_id))
            return false
        end
        runtime.set_material_hook_registered = true
        return true
    end

    function runtime.cancel(reason)
        runtime.applying = false
        runtime.applied = false
        runtime.cached_materials = nil
        runtime.hook_reapply_error_logged = false
        clear_bound_hud()
    end

    function runtime.refresh(reason)
        if not is_placement_active() then
            return false, "blueprint placement is inactive"
        end

        -- Register lazily after the stock construction HUD exists. Registering
        -- this Blueprint function during mod startup can race package loading.
        if not ensure_set_material_hook() then
            return false, "SetMaterial hook is unavailable"
        end

        -- Once applied, stock Setup continues to call SetMaterial for all four
        -- slots. UE4SS delivers the /Game/ Blueprint hook after SetMaterial;
        -- the callback immediately reapplies the aggregate to that same live
        -- context, including replacement widgets, without an UObject lookup.
        if runtime.applied
            and type(runtime.cached_materials) == "table" then
            return true, nil
        end

        local blueprint = get_blueprint()
        local builder = unwrap(get_builder())
        if type(blueprint) ~= "table"
            or type(blueprint.buildings) ~= "table"
            or not is_valid_object(builder) then
            return false, "blueprint or builder unavailable"
        end

        local widget, cells, bind_error = bind_active_hud(builder)
        if not is_valid_object(widget) then return false, bind_error end

        local materials, material_error = get_cached_materials(
            blueprint, builder
        )
        if materials == nil then return false, material_error end

        local applied, apply_error = apply_to_hud(
            widget, cells, materials, reason
        )
        -- The widget tree belongs to the stock construction UI. Retain its
        -- wrappers only for this synchronous first apply; the persistent hook
        -- receives the current live widget as context on every later refresh.
        clear_bound_hud()
        return applied, apply_error
    end

    return runtime
end

return BlueprintPlacementHUDMaterials

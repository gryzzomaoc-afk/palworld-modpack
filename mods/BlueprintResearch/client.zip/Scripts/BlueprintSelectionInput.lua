local BlueprintSelectionInput = {}
local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

function BlueprintSelectionInput.install(bridge, deps)
    assert(type(bridge) == "table", "BlueprintSelectionInput bridge is required")
    assert(type(deps) == "table", "BlueprintSelectionInput dependencies are required")

    local mode = assert(deps.mode, "BlueprintSelectionInput mode is required")
    local log = assert(deps.log, "BlueprintSelectionInput log is required")
    local unwrap = assert(deps.unwrap, "BlueprintSelectionInput unwrap is required")
    local value_to_string = assert(
        deps.value_to_string, "BlueprintSelectionInput value_to_string is required"
    )
    local object_name = assert(
        deps.object_name, "BlueprintSelectionInput object_name is required"
    )
    local is_valid_object = assert(
        deps.is_valid_object, "BlueprintSelectionInput is_valid_object is required"
    )
    local class_object_name = assert(
        deps.class_object_name,
        "BlueprintSelectionInput class_object_name is required"
    )
    local safe_object_address = assert(
        deps.safe_object_address,
        "BlueprintSelectionInput safe_object_address is required"
    )
    local safe_property = assert(
        deps.safe_property, "BlueprintSelectionInput safe_property is required"
    )
    local get_session_player_controller = assert(
        deps.get_session_player_controller,
        "BlueprintSelectionInput get_session_player_controller is required")
    local runtime_diagnostics_enabled =
        deps.runtime_diagnostics_enabled == true
    local begin_camera_hold = assert(
        deps.begin_camera_hold,
        "BlueprintSelectionInput begin_camera_hold is required"
    )
    local end_camera_hold = assert(
        deps.end_camera_hold,
        "BlueprintSelectionInput end_camera_hold is required"
    )
    local abandon_camera_hold = deps.abandon_camera_hold
    local is_camera_hold_active = assert(
        deps.is_camera_hold_active,
        "BlueprintSelectionInput is_camera_hold_active is required"
    )
    local is_modal_active = deps.is_modal_active or function() return false end
    local cancel_modal = deps.cancel_modal or function() return false end

    -- Never hook a compiler-generated InpActEvt_* name here. Adding an input
    -- node renumbers those UFunctions (adding the camera binding moved Escape's
    -- release event from _13 to _15). Every consumed key release already
    -- routes through this stable Blueprint UFunction, while the pending flag
    -- below ensures that only an armed Escape exit does any work.
    bridge.escape_release_function_name = bridge.escape_release_function_name
        or "ConsumeBlueprintModeInput"
    bridge.hud_escape_function_path_prefix =
        bridge.hud_escape_function_path_prefix
        or "/Game/Mods/BlueprintResearch/UI/WBP_BlueprintSelectionHUD."
            .. "WBP_BlueprintSelectionHUD_C:"
    bridge.hud_escape_hooks = bridge.hud_escape_hooks or {}
    bridge.hud_escape_hook_callbacks =
        bridge.hud_escape_hook_callbacks or {}
    bridge.escape_exit_pending = false
    bridge.escape_exit_release_scheduled = false
    bridge.escape_exit_generation = tonumber(bridge.escape_exit_generation) or 0
    function bridge.clear_pending_escape_exit(reason)
        local was_pending = bridge.escape_exit_pending == true
        bridge.escape_exit_generation = bridge.escape_exit_generation + 1
        bridge.escape_exit_pending = false
        bridge.escape_exit_release_scheduled = false
        if was_pending then
            log("blueprint selection ESC exit cleared reason=" .. tostring(reason))
        end
    end

    function bridge.arm_escape_exit()
        if is_modal_active() then
            bridge.clear_pending_escape_exit("modal-cancel")
            cancel_modal("selection-escape")
            return
        end
        if not mode.active then
            log("blueprint selection ESC exit ignored: mode inactive")
            return
        end
        if bridge.escape_exit_pending then
            log("blueprint selection ESC exit ignored: already waiting for release")
            return
        end
        bridge.escape_exit_generation = bridge.escape_exit_generation + 1
        bridge.escape_exit_pending = true
        bridge.escape_exit_release_scheduled = false
        log("blueprint selection ESC exit armed; waiting for consumed release")
    end

    function bridge.finish_escape_exit_after_release()
        if is_modal_active() then
            bridge.clear_pending_escape_exit("modal-release")
            return
        end
        if not bridge.escape_exit_pending then
            return
        end
        if bridge.escape_exit_release_scheduled then
            return
        end
        bridge.escape_exit_release_scheduled = true
        local generation = bridge.escape_exit_generation
        log("blueprint selection ESC release consumed; scheduling mode exit")
        BlueprintCallbackScheduler.game_thread(
            1, "selection-escape-release", function()
            if not bridge.escape_exit_pending
                or bridge.escape_exit_generation ~= generation then
                return
            end
            bridge.escape_exit_pending = false
            bridge.escape_exit_release_scheduled = false
            if mode.active then
                mode.finish("input-cancel", false)
            end
            end
        )
    end

    function bridge.get_local_player_controller()
        local controllers = FindAllOf("PlayerController")
            or FindAllOf("Controller") or {}
        for _, controller_value in ipairs(controllers) do
            local controller = unwrap(controller_value)
            if bridge.is_local_player_controller(controller) then
                return controller
            end
        end
        return nil
    end

    function bridge.is_local_player_controller(controller)
        controller = unwrap(controller)
        if not is_valid_object(controller) then return false end
        local check_ok, is_local = pcall(function()
            return controller:IsLocalPlayerController()
        end)
        return check_ok and is_local == true
    end

    function bridge.get_world(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local world = nil
        pcall(function() world = unwrap(value:GetWorld()) end)
        return world
    end

    function bridge.is_same_world(left, right)
        local left_world = bridge.get_world(left)
        local right_world = bridge.get_world(right)
        if not is_valid_object(left_world) or not is_valid_object(right_world) then
            return false
        end
        return safe_object_address(left_world) == safe_object_address(right_world)
    end

    function bridge.find_owned_component(class_name, owner)
        owner = unwrap(owner)
        if not is_valid_object(owner) then return nil end
        local owner_address = safe_object_address(owner)
        local components = FindAllOf(class_name) or {}
        for _, component_value in ipairs(components) do
            local component = unwrap(component_value)
            if is_valid_object(component) then
                local component_owner = nil
                pcall(function() component_owner = unwrap(component:GetOwner()) end)
                if is_valid_object(component_owner)
                    and safe_object_address(component_owner) == owner_address then
                    return component
                end
            end
        end
        return nil
    end

    function bridge.get_object_class_full_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return "<invalid>" end
        local ok, full_name = pcall(function()
            local object_class = unwrap(value:GetClass())
            return object_class:GetFullName()
        end)
        if not ok or full_name == nil then return "<unavailable>" end
        return tostring(full_name)
    end

    function bridge.find_actor(player_controller, expected_address)
        player_controller = unwrap(player_controller)
        if not is_valid_object(player_controller) then return nil end
        local objects = FindAllOf(bridge.actor_class_name) or {}
        local candidate_diagnostics = {}
        for _, object_value in ipairs(objects) do
            local object = unwrap(object_value)
            if is_valid_object(object) then
                local class_full_name = bridge.get_object_class_full_name(object)
                local address = safe_object_address(object)
                local class_matches = class_full_name
                    == bridge.actor_class_full_name
                local world_matches = bridge.is_same_world(
                    object, player_controller
                )
                local address_matches = expected_address == nil
                    or address == expected_address
                candidate_diagnostics[#candidate_diagnostics + 1] = string.format(
                    "instance=%s class=%s address=%s classMatch=%s worldMatch=%s addressMatch=%s",
                    object_name(object), class_full_name, tostring(address),
                    tostring(class_matches), tostring(world_matches),
                    tostring(address_matches)
                )
                if class_matches and world_matches and address_matches then
                    log("blueprint selection input ModActor selected "
                        .. candidate_diagnostics[#candidate_diagnostics])
                    return object
                end
            else
                candidate_diagnostics[#candidate_diagnostics + 1] =
                    "instance=" .. object_name(object)
                        .. " class=<invalid> address=<nil>"
            end
        end
        log("blueprint selection input ModActor lookup failed expectedClass="
            .. tostring(bridge.actor_class_full_name)
            .. " expectedAddress=" .. tostring(expected_address)
            .. " candidates=["
            .. table.concat(candidate_diagnostics, " | ") .. "]")
        return nil
    end

    function bridge.ensure_request_hook(function_name, action)
        if bridge.request_hooks[function_name] == true then
            return true
        end
        local path = bridge.function_path_prefix .. function_name
        local callback = function(context)
            if runtime_diagnostics_enabled then
                log("blueprint selection input request="
                    .. tostring(function_name)
                    .. " context=" .. object_name(context))
            end
            local action_ok, action_error = pcall(action, unwrap(context))
            if not action_ok then
                log("blueprint selection input hook isolated error function="
                    .. tostring(function_name) .. " error="
                    .. tostring(action_error))
            end
        end
        bridge.request_hook_callbacks[function_name] = callback
        local ok, pre_id, post_id = pcall(RegisterHook, path, callback)
        if not ok then
            bridge.request_hook_callbacks[function_name] = nil
            log("blueprint selection input hook unavailable function="
                .. tostring(function_name) .. " path=" .. tostring(path)
                .. " error=" .. tostring(pre_id))
            return false
        end
        bridge.request_hooks[function_name] = true
        log("blueprint selection input hook registered function="
            .. tostring(function_name) .. " pre=" .. tostring(pre_id)
            .. " post=" .. tostring(post_id))
        return true
    end

    function bridge.ensure_escape_release_hook()
        local function_name = bridge.escape_release_function_name
        if bridge.request_hooks[function_name] == true then
            return true
        end
        local path = bridge.function_path_prefix .. function_name
        local callback = function(context)
            log("blueprint selection input ESC release event context="
                .. object_name(context))
            local action_ok, action_error = pcall(
                bridge.finish_escape_exit_after_release
            )
            if not action_ok then
                log("blueprint selection ESC release hook isolated error="
                    .. tostring(action_error))
            end
        end
        bridge.request_hook_callbacks[function_name] = callback
        local ok, pre_id, post_id = pcall(RegisterHook, path, callback)
        if not ok then
            bridge.request_hook_callbacks[function_name] = nil
            log("blueprint selection input ESC release hook unavailable function="
                .. tostring(function_name) .. " path=" .. tostring(path)
                .. " error=" .. tostring(pre_id))
            return false
        end
        bridge.request_hooks[function_name] = true
        log("blueprint selection input ESC release hook registered function="
            .. tostring(function_name) .. " pre=" .. tostring(pre_id)
            .. " post=" .. tostring(post_id))
        return true
    end

    function bridge.ensure_hud_escape_hook(function_name, action)
        if bridge.hud_escape_hooks[function_name] == true then
            return true
        end
        local path = bridge.hud_escape_function_path_prefix .. function_name
        local callback = function(context)
            log("blueprint selection CommonUI ESC callback="
                .. tostring(function_name)
                .. " context=" .. object_name(context))
            local action_ok, action_error = pcall(action)
            if not action_ok then
                log("blueprint selection CommonUI ESC hook isolated error function="
                    .. tostring(function_name) .. " error="
                    .. tostring(action_error))
            end
        end
        bridge.hud_escape_hook_callbacks[function_name] = callback
        local ok, pre_id, post_id = pcall(RegisterHook, path, callback)
        if not ok then
            bridge.hud_escape_hook_callbacks[function_name] = nil
            log("blueprint selection CommonUI ESC hook unavailable function="
                .. tostring(function_name) .. " path=" .. tostring(path)
                .. " error=" .. tostring(pre_id))
            return false
        end
        bridge.hud_escape_hooks[function_name] = true
        log("blueprint selection CommonUI ESC hook registered function="
            .. tostring(function_name) .. " pre=" .. tostring(pre_id)
            .. " post=" .. tostring(post_id))
        return true
    end

    function bridge.ensure_hud_escape_hooks()
        local pressed_ready = bridge.ensure_hud_escape_hook(
            "BR_OnEscapePressed", bridge.arm_escape_exit
        )
        local released_ready = bridge.ensure_hud_escape_hook(
            "BR_OnEscapeReleased", bridge.finish_escape_exit_after_release
        )
        return pressed_ready and released_ready
    end

    function mode.setup_hud_escape_guard(widget)
        widget = unwrap(widget)
        if not is_valid_object(widget) then
            return false, "selection HUD unavailable"
        end
        if not bridge.ensure_hud_escape_hooks() then
            return false, "CommonUI ESC callback hooks unavailable"
        end
        local activate_ok, activate_error = pcall(function()
            widget:ActivateWidget()
        end)
        if not activate_ok then
            return false, "selection HUD activation failed: "
                .. tostring(activate_error)
        end
        local setup_ok, setup_error = pcall(function()
            widget:BR_SetupEscapeGuard()
        end)
        if not setup_ok then
            return false, "BR_SetupEscapeGuard failed: "
                .. tostring(setup_error)
        end
        log("blueprint selection CommonUI UIEscape guard active widget="
            .. object_name(widget))
        return true
    end

    function bridge.ensure_request_hooks()
        local all_ready = true
        -- LMB selection, RMB anchor assignment, and MMB box selection are
        -- authored directly in ModActor/SelectionSession. Keeping Lua hooks
        -- for these paths would execute the same action twice and reintroduce
        -- the ExecuteInGameThread scheduling boundary that this Session owns.
        all_ready = bridge.ensure_request_hook(
            "RequestSaveBlueprintSelection",
            function()
                if not is_camera_hold_active()
                    and not is_modal_active() then
                    mode.save()
                end
            end
        ) and all_ready
        all_ready = bridge.ensure_request_hook(
            "RequestExitBlueprintSelection",
            function()
                if is_modal_active() then
                    bridge.clear_pending_escape_exit("modal-request-exit")
                    cancel_modal("selection-escape")
                    return
                end
                end_camera_hold("selection-escape")
                bridge.arm_escape_exit()
            end
        ) and all_ready
        all_ready = bridge.ensure_request_hook(
            "RequestBlueprintCameraHold",
            function(input_actor)
                if mode.active and not is_modal_active() then
                    if is_camera_hold_active() then
                        end_camera_hold("selection-camera-toggle")
                    else
                        begin_camera_hold("selection", input_actor)
                    end
                end
            end
        ) and all_ready
        all_ready = bridge.ensure_request_hook(
            "ReleaseBlueprintCameraHold",
            -- Caps Lock is a toggle. The release event is intentionally
            -- consumed by the Actor without changing camera state.
            function() end
        ) and all_ready
        all_ready = bridge.ensure_escape_release_hook() and all_ready
        return all_ready
    end

    function bridge.get_input_component(actor)
        local input_component = nil
        if is_valid_object(actor) then
            pcall(function()
                input_component = unwrap(actor.InputComponent)
            end)
        end
        return input_component
    end

    function bridge.ensure_native_input(actor, player_controller)
        local input_component = bridge.get_input_component(actor)
        local component_existed = is_valid_object(input_component)

        player_controller = unwrap(player_controller)
        if not bridge.is_local_player_controller(player_controller) then
            log("blueprint selection native EnableInput skipped: controller is not local")
            return false, "controller-not-local", nil
        end
        if not bridge.is_same_world(actor, player_controller) then
            log("blueprint selection native EnableInput skipped: actor/controller world mismatch")
            return false, "world-mismatch", nil
        end

        local enable_ok, enable_error = pcall(function()
            actor:EnableInput(player_controller)
        end)
        input_component = bridge.get_input_component(actor)
        local component_ready = is_valid_object(input_component)
        log("blueprint selection native EnableInput fallback callOk="
            .. tostring(enable_ok)
            .. " componentReady=" .. tostring(component_ready)
            .. " controller=" .. object_name(player_controller)
            .. " component=" .. object_name(input_component)
            .. (enable_ok and "" or " error=" .. tostring(enable_error)))
        return enable_ok and component_ready,
            enable_ok and (component_ready
                and (component_existed and "reused" or "created")
                or "component-missing")
                or tostring(enable_error),
            input_component
    end

    function bridge.disable_native_input(actor, player_controller, reason)
        player_controller = unwrap(player_controller)
        if not is_valid_object(player_controller) then
            log("blueprint selection native DisableInput skipped: player controller unavailable reason="
                .. tostring(reason))
            return false
        end
        local disable_ok, disable_error = pcall(function()
            actor:DisableInput(player_controller)
        end)
        log("blueprint selection native DisableInput fallback callOk="
            .. tostring(disable_ok)
            .. " reason=" .. tostring(reason)
            .. (disable_ok and "" or " error=" .. tostring(disable_error)))
        return disable_ok
    end

    function bridge.enter(player_controller, actor_hint)
        bridge.clear_pending_escape_exit("input-enter")
        if not bridge.ensure_request_hooks() then
            return false
        end
        player_controller = unwrap(player_controller)
        if not is_valid_object(player_controller)
            or not bridge.is_local_player_controller(player_controller) then
            log("blueprint selection input enter failed: controller is not local controller="
                .. object_name(player_controller))
            return false
        end
        local actor = unwrap(actor_hint)
        if not is_valid_object(actor)
            or bridge.get_object_class_full_name(actor)
                ~= bridge.actor_class_full_name
            or not bridge.is_same_world(actor, player_controller) then
            actor = bridge.find_actor(player_controller)
        end
        if not is_valid_object(actor) then
            log("blueprint selection input enter failed: exact current-world ModActor_C not found expectedClass="
                .. tostring(bridge.actor_class_full_name)
                .. " controller=" .. object_name(player_controller))
            return false
        end
        local ok, error_value = pcall(function()
            actor:EnterBlueprintSelectionInput()
        end)
        if not ok then
            log("blueprint selection input enter failed actor=" .. object_name(actor)
                .. " class=" .. bridge.get_object_class_full_name(actor)
                .. " error=" .. tostring(error_value))
            return false
        end
        local input_ok, input_reason = bridge.ensure_native_input(
            actor, player_controller
        )
        if not input_ok then
            pcall(function() actor:ExitBlueprintSelectionInput() end)
            log("blueprint selection input enter failed: native input unavailable reason="
                .. tostring(input_reason))
            return false
        end
        local function log_runtime_state(stage)
            local active_value = "<unreadable>"
            local input_component = nil
            local input_component_class = nil
            local active_player_controller = player_controller
            local player_input = nil
            local player_input_class = nil
            pcall(function()
                active_value = tostring(actor.BlueprintSelectionInputActive)
            end)
            pcall(function() input_component = unwrap(actor.InputComponent) end)
            if is_valid_object(input_component) then
                pcall(function()
                    input_component_class = unwrap(input_component:GetClass())
                end)
            end
            if is_valid_object(active_player_controller) then
                pcall(function()
                    player_input = unwrap(safe_property(
                        active_player_controller, "PlayerInput"
                    ))
                end)
            end
            if is_valid_object(player_input) then
                pcall(function()
                    player_input_class = unwrap(player_input:GetClass())
                end)
            end
            log("blueprint selection input runtime stage=" .. tostring(stage)
                .. " active=" .. tostring(active_value)
                .. " component=" .. object_name(input_component)
                .. " componentClass=" .. class_object_name(input_component_class)
                .. " controller=" .. object_name(active_player_controller)
                .. " playerInput=" .. object_name(player_input)
                .. " playerInputClass=" .. class_object_name(player_input_class))

            local subsystem_objects = FindAllOf(
                "EnhancedInputLocalPlayerSubsystem"
            ) or {}
            local action_names = {
                "IA_BP_Select",
                "IA_BP_Anchor",
                "IA_BP_Region",
                "IA_BP_Cancel",
                "IA_BP_Save",
                "IA_BP_Block",
            }
            for subsystem_index, subsystem_value in ipairs(subsystem_objects) do
                local subsystem = unwrap(subsystem_value)
                if is_valid_object(subsystem) then
                    local action_summaries = {}
                    for _, action_name in ipairs(action_names) do
                        local action_path = "/Game/Mods/BlueprintResearch/Input/"
                            .. action_name .. "." .. action_name
                        local action = unwrap(StaticFindObject(action_path))
                        if not is_valid_object(action) then
                            pcall(function()
                                action = unwrap(LoadAsset(action_path))
                            end)
                        end
                        local keys = nil
                        local query_ok, query_error = pcall(function()
                            keys = subsystem:QueryKeysMappedToAction(action)
                        end)
                        local key_labels = {}
                        if query_ok and keys ~= nil then
                            pcall(function()
                                for _, key in ipairs(keys) do
                                    local key_label = value_to_string(key)
                                    pcall(function()
                                        key_label = value_to_string(key.KeyName)
                                    end)
                                    table.insert(key_labels, key_label)
                                end
                            end)
                        end
                        table.insert(
                            action_summaries,
                            action_name .. "=[" .. table.concat(key_labels, ",")
                                .. "]" .. (query_ok and ""
                                or " error=" .. tostring(query_error))
                        )
                    end
                    log("blueprint selection input mappings stage=" .. tostring(stage)
                        .. " subsystemIndex=" .. tostring(subsystem_index)
                        .. " subsystem=" .. object_name(subsystem)
                        .. " " .. table.concat(action_summaries, " "))
                end
            end
        end

        log("blueprint selection input context entered localOnly=true actor="
            .. object_name(actor)
            .. " controller=" .. object_name(player_controller)
            .. " world=" .. object_name(bridge.get_world(player_controller)))
        if runtime_diagnostics_enabled then
            log_runtime_state("immediate")
        end
        return true
    end

    function bridge.exit(reason)
        end_camera_hold("selection-input-exit:" .. tostring(reason))
        bridge.clear_pending_escape_exit("input-exit:" .. tostring(reason))
        local player_controller = unwrap(
            get_session_player_controller()
        )
        local actor = bridge.find_actor(player_controller)
        if not is_valid_object(actor) then
            log("blueprint selection input exit skipped: exact ModActor_C unavailable reason="
                .. tostring(reason) .. " expectedClass="
                .. tostring(bridge.actor_class_full_name))
            return false
        end
        local ok, error_value = pcall(function()
            actor:ExitBlueprintSelectionInput()
        end)
        local input_disabled = bridge.disable_native_input(
            actor, player_controller, reason
        )
        if not ok then
            log("blueprint selection input exit failed actor=" .. object_name(actor)
                .. " reason=" .. tostring(reason)
                .. " inputDisabled=" .. tostring(input_disabled)
                .. " error=" .. tostring(error_value))
            return false
        end
        log("blueprint selection input context exited reason=" .. tostring(reason))
        return true
    end

    function bridge.abandon_world(reason)
        if type(abandon_camera_hold) == "function" then
            pcall(abandon_camera_hold,
                "selection-input-world-travel:" .. tostring(reason))
        end
        bridge.clear_pending_escape_exit(
            "world-travel:" .. tostring(reason)
        )
        return true
    end
end

return BlueprintSelectionInput

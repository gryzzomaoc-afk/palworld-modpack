local BlueprintWorldLifecycle = {}

function BlueprintWorldLifecycle.install(deps)
    assert(type(deps) == "table",
        "BlueprintWorldLifecycle dependencies are required")
    local log = assert(deps.log, "BlueprintWorldLifecycle log is required")
    local on_load_map_pre = assert(
        deps.on_load_map_pre,
        "BlueprintWorldLifecycle on_load_map_pre is required"
    )
    local on_load_map_post = assert(
        deps.on_load_map_post,
        "BlueprintWorldLifecycle on_load_map_post is required"
    )

    local controller = {
        transition_sequence = 0,
        pre_callback = nil,
        post_callback = nil,
        pre_registered = false,
        post_registered = false,
    }

    controller.pre_callback = function(...)
        controller.transition_sequence =
            controller.transition_sequence + 1
        local reason = "load-map-pre#"
            .. tostring(controller.transition_sequence)
        local ok, error_value = pcall(on_load_map_pre, reason, ...)
        if not ok then
            log("blueprint world pre-load cleanup isolated error="
                .. tostring(error_value))
        end
    end

    controller.post_callback = function(_, world, ...)
        local reason = "load-map-post#"
            .. tostring(controller.transition_sequence)
        local ok, error_value = pcall(
            on_load_map_post, world, reason, ...
        )
        if not ok then
            log("blueprint world post-load registration isolated error="
                .. tostring(error_value))
        end
    end

    local pre_ok, pre_error = pcall(
        RegisterLoadMapPreHook, controller.pre_callback
    )
    controller.pre_registered = pre_ok == true
    if not controller.pre_registered then
        log("blueprint world LoadMap pre-hook registration failed error="
            .. tostring(pre_error))
    end

    local post_ok, post_error = pcall(
        RegisterLoadMapPostHook, controller.post_callback
    )
    controller.post_registered = post_ok == true
    if not controller.post_registered then
        log("blueprint world LoadMap post-hook registration failed error="
            .. tostring(post_error))
    end

    log("blueprint world lifecycle hooks registered pre="
        .. tostring(controller.pre_registered) .. " post="
        .. tostring(controller.post_registered))
    return controller
end

return BlueprintWorldLifecycle

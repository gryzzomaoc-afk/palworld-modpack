local BlueprintCallbackScheduler = {
    callbacks = {},
    actions = {},
    sequence = 0,
    world_generation = 0,
    log = nil,
}

local function report_error(label, error_value)
    local logger = BlueprintCallbackScheduler.log
    if type(logger) ~= "function" then return end
    logger("deferred callback isolated error label="
        .. tostring(label or "<unnamed>")
        .. " error=" .. tostring(error_value))
end

local function schedule(executor, label, work, options)
    if type(executor) ~= "function" or type(work) ~= "function" then
        return false, "callback scheduler received an invalid executor or work"
    end
    options = type(options) == "table" and options or {}

    BlueprintCallbackScheduler.sequence =
        BlueprintCallbackScheduler.sequence + 1
    local callback_id = BlueprintCallbackScheduler.sequence
    local scheduled_generation = BlueprintCallbackScheduler.world_generation
    local survive_world = options.survive_world == true
    local callback = nil
    callback = function(...)
        -- Remove the retained reference only after UE4SS has entered the Lua
        -- callback. The active Lua stack then owns it for the rest of the call.
        BlueprintCallbackScheduler.callbacks[callback_id] = nil
        BlueprintCallbackScheduler.actions[callback_id] = nil
        if not survive_world
            and scheduled_generation
                ~= BlueprintCallbackScheduler.world_generation then
            return
        end
        local ok, error_value = pcall(work, ...)
        if not ok then report_error(label, error_value) end
    end

    -- UE4SS stores scheduled functions in its Lua registry, but this Palworld
    -- build can garbage-collect an otherwise unreferenced closure before the
    -- EngineTick scheduler invokes it. Keep a Lua-side strong reference for
    -- the complete waiting period.
    BlueprintCallbackScheduler.callbacks[callback_id] = callback
    BlueprintCallbackScheduler.actions[callback_id] = {
        callback = callback,
        survive_world = survive_world,
        handle = nil,
    }
    local ok, handle_or_error = pcall(executor, callback)
    if not ok then
        BlueprintCallbackScheduler.callbacks[callback_id] = nil
        BlueprintCallbackScheduler.actions[callback_id] = nil
        report_error(tostring(label) .. ":schedule", handle_or_error)
        return false, tostring(handle_or_error)
    end
    BlueprintCallbackScheduler.actions[callback_id].handle = handle_or_error
    return true, callback_id
end

function BlueprintCallbackScheduler.configure(options)
    options = options or {}
    if type(options.log) == "function" then
        BlueprintCallbackScheduler.log = options.log
    end
    return BlueprintCallbackScheduler
end

function BlueprintCallbackScheduler.game_thread(delay_ms, label, work, options)
    local delay = math.max(tonumber(delay_ms) or 0, 0)
    return schedule(function(callback)
        return ExecuteInGameThreadWithDelay(delay, callback)
    end, label, work, options)
end

function BlueprintCallbackScheduler.game_thread_now(label, work, options)
    return schedule(function(callback)
        return ExecuteInGameThread(callback)
    end, label, work, options)
end

function BlueprintCallbackScheduler.async(delay_ms, label, work, options)
    local delay = math.max(tonumber(delay_ms) or 0, 0)
    return schedule(function(callback)
        return ExecuteWithDelay(delay, callback)
    end, label, work, options)
end

function BlueprintCallbackScheduler.invalidate_world(reason)
    BlueprintCallbackScheduler.world_generation =
        BlueprintCallbackScheduler.world_generation + 1
    local logger = BlueprintCallbackScheduler.log
    if type(logger) == "function" then
        logger("deferred callback world generation invalidated generation="
            .. tostring(BlueprintCallbackScheduler.world_generation)
            .. " reason=" .. tostring(reason))
    end
    return BlueprintCallbackScheduler.world_generation
end

function BlueprintCallbackScheduler.cancel_all_world_actions(reason)
    local pending_before = BlueprintCallbackScheduler.pending_count()
    local survivor_count = 0
    local individually_cancelled = 0
    for callback_id, action in pairs(BlueprintCallbackScheduler.actions) do
        if action.survive_world == true then
            survivor_count = survivor_count + 1
        else
            if action.handle ~= nil
                and type(CancelDelayedAction) == "function" then
                local cancelled = false
                pcall(function()
                    cancelled = CancelDelayedAction(action.handle) == true
                end)
                if cancelled then
                    individually_cancelled = individually_cancelled + 1
                end
            end
            BlueprintCallbackScheduler.callbacks[callback_id] = nil
            BlueprintCallbackScheduler.actions[callback_id] = nil
        end
    end

    local cancel_available = type(ClearAllDelayedActions) == "function"
    local cancel_ok = true
    local cancel_error = nil
    local cleared_count = 0
    -- ClearAllDelayedActions is the final net for loops registered directly by
    -- a subsystem rather than through this scheduler. Never use it while an
    -- explicitly process-lifetime callback is pending.
    if cancel_available and survivor_count == 0 then
        local clear_result = nil
        cancel_ok, clear_result = pcall(ClearAllDelayedActions)
        if cancel_ok then
            cleared_count = tonumber(clear_result) or 0
        else
            cancel_error = clear_result
        end
    end

    local logger = BlueprintCallbackScheduler.log
    if type(logger) == "function" then
        logger("deferred callback world actions cancelled reason="
            .. tostring(reason)
            .. " pending=" .. tostring(pending_before)
            .. " survivors=" .. tostring(survivor_count)
            .. " individuallyCancelled="
            .. tostring(individually_cancelled)
            .. " apiAvailable=" .. tostring(cancel_available)
            .. " ok=" .. tostring(cancel_ok)
            .. " clearedCount=" .. tostring(cleared_count)
            .. (cancel_ok and "" or " error=" .. tostring(cancel_error)))
    end
    return cancel_ok, cancel_error, cancel_available, pending_before,
        survivor_count, individually_cancelled, cleared_count
end

function BlueprintCallbackScheduler.get_world_generation()
    return BlueprintCallbackScheduler.world_generation
end

function BlueprintCallbackScheduler.pending_count()
    local count = 0
    for _ in pairs(BlueprintCallbackScheduler.callbacks) do
        count = count + 1
    end
    return count
end

return BlueprintCallbackScheduler

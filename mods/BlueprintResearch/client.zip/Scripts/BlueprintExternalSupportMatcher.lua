local BlueprintExternalSupportMatcher = {}

local function number_value(value)
    return tonumber(value) or 0.0
end

local function vector_component(value, lower, upper)
    if type(value) ~= "table" then return 0.0 end
    return number_value(value[lower] or value[upper])
end

local function quaternion_abs_dot(left, right)
    if left == nil or right == nil then return 0.0 end
    local dot =
        vector_component(left, "x", "X")
            * vector_component(right, "x", "X")
        + vector_component(left, "y", "Y")
            * vector_component(right, "y", "Y")
        + vector_component(left, "z", "Z")
            * vector_component(right, "z", "Z")
        + vector_component(left, "w", "W")
            * vector_component(right, "w", "W")
    return math.abs(dot)
end

local function connector_index_is_optional(value)
    local normalized = string.lower(tostring(value or ""))
    return normalized == "" or normalized == "nil"
        or normalized == "<nil>" or normalized == "none"
        or normalized == "null"
end

local function stable_number_key(value)
    return string.format("%.17g", number_value(value))
end

local function expectation_key(expectation)
    local location = expectation.expected_location or {}
    local rotation = expectation.expected_rotation or {}
    return table.concat({
        tostring(expectation.request_id or ""),
        tostring(expectation.target_build_object_id or ""),
        stable_number_key(location.x or location.X),
        stable_number_key(location.y or location.Y),
        stable_number_key(location.z or location.Z),
        stable_number_key(rotation.x or rotation.X),
        stable_number_key(rotation.y or rotation.Y),
        stable_number_key(rotation.z or rotation.Z),
        stable_number_key(rotation.w or rotation.W),
        expectation.connector_class_required == true and "1" or "0",
        tostring(expectation.target_connector_class_token or ""),
        tostring(expectation.target_connect_index or ""),
        tostring(expectation.source_connect_index or ""),
    }, "\31")
end

function BlueprintExternalSupportMatcher.dedupe_expectations(expectations)
    local unique = {}
    local seen = {}
    for _, expectation in ipairs(expectations or {}) do
        if type(expectation) == "table" then
            local key = expectation_key(expectation)
            if not seen[key] then
                seen[key] = true
                unique[#unique + 1] = expectation
            end
        end
    end
    return unique
end

local function grid_coordinate(value, grid_size)
    return math.floor(number_value(value) / grid_size)
end

local function grid_key(x, y, z)
    return tostring(x) .. "|" .. tostring(y) .. "|" .. tostring(z)
end

local function build_candidate_index(
    candidates, grid_size, relevant_build_object_ids
)
    local by_build_object_id = {}
    local indexed_count = 0
    for ordinal, candidate in ipairs(candidates or {}) do
        if type(candidate) == "table"
            and candidate.build_object_id ~= nil
            and type(candidate.location) == "table"
            and relevant_build_object_ids[
                tostring(candidate.build_object_id)
            ] == true then
            candidate.ordinal = tonumber(candidate.ordinal) or ordinal
            local build_id = tostring(candidate.build_object_id)
            local build_index = by_build_object_id[build_id]
            if build_index == nil then
                build_index = {}
                by_build_object_id[build_id] = build_index
            end
            local x = grid_coordinate(
                candidate.location.x or candidate.location.X, grid_size
            )
            local y = grid_coordinate(
                candidate.location.y or candidate.location.Y, grid_size
            )
            local z = grid_coordinate(
                candidate.location.z or candidate.location.Z, grid_size
            )
            local key = grid_key(x, y, z)
            local bucket = build_index[key]
            if bucket == nil then
                bucket = {}
                build_index[key] = bucket
            end
            bucket[#bucket + 1] = candidate
            indexed_count = indexed_count + 1
        end
    end
    return by_build_object_id, indexed_count
end

local function candidate_matches(
    candidate, expectation, location_tolerance_squared, rotation_dot_min
)
    local expected = expectation.expected_location or {}
    local dx = vector_component(candidate.location, "x", "X")
        - vector_component(expected, "x", "X")
    local dy = vector_component(candidate.location, "y", "Y")
        - vector_component(expected, "y", "Y")
    local dz = vector_component(candidate.location, "z", "Z")
        - vector_component(expected, "z", "Z")
    if dx * dx + dy * dy + dz * dz
        > location_tolerance_squared then
        return false
    end
    if quaternion_abs_dot(
        candidate.rotation, expectation.expected_rotation
    ) < rotation_dot_min then
        return false
    end
    if expectation.connector_class_required == true
        and candidate.connector_class_token
            ~= expectation.target_connector_class_token then
        return false
    end
    if connector_index_is_optional(
        expectation.target_connect_index
    ) then
        return true
    end
    local connector_indexes = candidate.connector_indexes
    return type(connector_indexes) == "table"
        and connector_indexes[
            tostring(expectation.target_connect_index)
        ] == true
end

function BlueprintExternalSupportMatcher.match(
    expectations, candidates, options
)
    options = options or {}
    local location_tolerance = math.max(
        tonumber(options.location_tolerance) or 0.0, 0.0
    )
    local rotation_dot_min =
        tonumber(options.rotation_dot_min) or 0.0
    local grid_size = location_tolerance > 0.0
        and location_tolerance or 1.0
    local search_radius = location_tolerance > 0.0 and 1 or 0
    local unique_expectations =
        BlueprintExternalSupportMatcher.dedupe_expectations(expectations)
    local relevant_build_object_ids = {}
    for _, expectation in ipairs(unique_expectations) do
        relevant_build_object_ids[
            tostring(expectation.target_build_object_id or "")
        ] = true
    end
    local candidate_index, indexed_candidate_count =
        build_candidate_index(
            candidates, grid_size, relevant_build_object_ids
        )
    local matches_by_request_id = {}
    local candidate_checks = 0
    local bucket_visits = 0
    local location_tolerance_squared =
        location_tolerance * location_tolerance

    for _, expectation in ipairs(unique_expectations) do
        local request_id = expectation.request_id
        if request_id ~= nil
            and matches_by_request_id[request_id] == nil then
            local build_index = candidate_index[
                tostring(expectation.target_build_object_id or "")
            ]
            if build_index ~= nil then
                local expected = expectation.expected_location or {}
                local center_x = grid_coordinate(
                    expected.x or expected.X, grid_size
                )
                local center_y = grid_coordinate(
                    expected.y or expected.Y, grid_size
                )
                local center_z = grid_coordinate(
                    expected.z or expected.Z, grid_size
                )
                local best_candidate = nil
                for x = center_x - search_radius,
                    center_x + search_radius do
                    for y = center_y - search_radius,
                        center_y + search_radius do
                        for z = center_z - search_radius,
                            center_z + search_radius do
                            bucket_visits = bucket_visits + 1
                            local bucket = build_index[grid_key(x, y, z)]
                            for _, candidate in ipairs(bucket or {}) do
                                candidate_checks = candidate_checks + 1
                                if candidate_matches(
                                    candidate, expectation,
                                    location_tolerance_squared,
                                    rotation_dot_min
                                ) and (
                                    best_candidate == nil
                                    or candidate.ordinal
                                        < best_candidate.ordinal
                                ) then
                                    best_candidate = candidate
                                end
                            end
                        end
                    end
                end
                if best_candidate ~= nil then
                    matches_by_request_id[request_id] = {
                        candidate = best_candidate,
                        expectation = expectation,
                    }
                end
            end
        end
    end

    return {
        matches_by_request_id = matches_by_request_id,
        raw_expectation_count = #(expectations or {}),
        unique_expectation_count = #unique_expectations,
        indexed_candidate_count = indexed_candidate_count,
        candidate_checks = candidate_checks,
        bucket_visits = bucket_visits,
    }
end

BlueprintExternalSupportMatcher.quaternion_abs_dot =
    quaternion_abs_dot
BlueprintExternalSupportMatcher.connector_index_is_optional =
    connector_index_is_optional

return BlueprintExternalSupportMatcher

local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local BlueprintSelectionVisual = {}

local SELECTED_OPACITY = 0.55

function BlueprintSelectionVisual.install(deps)
    assert(type(deps) == "table", "BlueprintSelectionVisual.install requires deps")

    local log = assert(deps.log, "BlueprintSelectionVisual requires log")
    local unwrap = assert(deps.unwrap, "BlueprintSelectionVisual requires unwrap")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintSelectionVisual requires is_valid_object")
    local safe_property = assert(deps.safe_property,
        "BlueprintSelectionVisual requires safe_property")
    local safe_object_address = assert(deps.safe_object_address,
        "BlueprintSelectionVisual requires safe_object_address")
    local object_name = assert(deps.object_name,
        "BlueprintSelectionVisual requires object_name")
    local find_valid_instance = assert(deps.find_valid_instance,
        "BlueprintSelectionVisual requires find_valid_instance")
    local get_asset_path = assert(deps.get_asset_path,
        "BlueprintSelectionVisual requires get_asset_path")
    local collect_build_object_meshes = assert(deps.collect_build_object_meshes,
        "BlueprintSelectionVisual requires collect_build_object_meshes")
    local get_build_object_instance_id = assert(deps.get_build_object_instance_id,
        "BlueprintSelectionVisual requires get_build_object_instance_id")
    local get_selected_entry = assert(deps.get_selected_entry,
        "BlueprintSelectionVisual requires get_selected_entry")
    local get_selected_anchor_instance_id = assert(deps.get_selected_anchor_instance_id,
        "BlueprintSelectionVisual requires get_selected_anchor_instance_id")
    local is_selection_active = deps.is_selection_active
        or function() return true end
    local get_selection_session = deps.get_selection_session
        or function() return nil end

    local SHARED_ROLE_MATERIAL_PROPERTIES = {
        hover = "SBB_SelectionHoverMID",
        selected = "SBB_SelectionSelectedMID",
        anchor = "SBB_SelectionAnchorMID",
        ["serialization-error"] = "SBB_SelectionErrorMID",
    }

    local cached_dismantle_material = nil
    local cached_anchor_material = nil
    local last_observed_dismantle_target_address = nil
    local last_observed_dismantle_target_instance_id = nil
    local dismantle_target_observer_logged = false
    local dismantle_target_repair_logged = false
    local hover_dynamic_failure_logged = false
    local selected_dynamic_failure_logged = false
    local error_dynamic_failure_logged = false
    local error_flash_generation = 0
    local error_flash_instance_ids = {}

    local function get_shared_role_material(role)
        local property_name = SHARED_ROLE_MATERIAL_PROPERTIES[role]
        if property_name == nil then return nil end
        local session = unwrap(get_selection_session())
        if not is_valid_object(session) then return nil end
        local material = unwrap(safe_property(session, property_name))
        return is_valid_object(material) and material or nil
    end

    local function get_original_dismantle_material()
        if is_valid_object(cached_dismantle_material) then
            return cached_dismantle_material
        end
        local manager = find_valid_instance("PalMapObjectManager", "/Game/Pal/Maps/")
        local material_set = safe_property(manager, "BuildingSurfaceMaterialSet")
        local material = unwrap(safe_property(material_set, "Dismantle"))
        if is_valid_object(material) then
            cached_dismantle_material = material
            return material
        end
        material = StaticFindObject(
            "/Game/Pal/Material/MapObject/BuildObject/BuildingProcess/" ..
            "MI_LooksPredicatorDismantle.MI_LooksPredicatorDismantle"
        )
        material = unwrap(material)
        if is_valid_object(material) then
            cached_dismantle_material = material
        end
        return material
    end

    local function get_original_anchor_material()
        if is_valid_object(cached_anchor_material) then
            return cached_anchor_material
        end
        local manager = find_valid_instance("PalMapObjectManager", "/Game/Pal/Maps/")
        local material_set = safe_property(manager, "BuildingSurfaceMaterialSet")
        local material = unwrap(safe_property(material_set, "Highlight"))
        if is_valid_object(material) then
            cached_anchor_material = material
            return material
        end
        material = StaticFindObject(
            "/Game/Pal/Material/MapObject/BuildObject/BuildingProcess/" ..
            "MI_LooksPredicatorNormal.MI_LooksPredicatorNormal"
        )
        material = unwrap(material)
        if is_valid_object(material) then
            cached_anchor_material = material
        end
        return material
    end

    local function is_same_material(left, right)
        left = unwrap(left)
        right = unwrap(right)
        if not is_valid_object(left) or not is_valid_object(right) then return false end
        local left_address = safe_object_address(left)
        local right_address = safe_object_address(right)
        if left_address ~= nil and right_address ~= nil then
            return left_address == right_address
        end
        local left_name = tostring(object_name(left))
        local right_name = tostring(object_name(right))
        if left_name == "<invalid>" or right_name == "<invalid>" then return false end
        return left_name == right_name
    end

    local function create_hover_material(state, highlight_material)
        local dynamic_material = nil
        local create_ok, create_error = pcall(function()
            dynamic_material = unwrap(
                state.mesh:CreateAndSetMaterialInstanceDynamicFromMaterial(
                    state.slot_index, highlight_material
                )
            )
        end)
        if not create_ok or not is_valid_object(dynamic_material) then
            return nil, create_error or "CreateAndSetMaterialInstanceDynamicFromMaterial returned nil"
        end

        -- Highlight is the already-proven translucent/pulsing anchor material.
        -- Keep its Progress=0 presentation and change only the three rim colors
        -- to orange so hover remains visually distinct from the blue anchor.
        local style_ok, style_error = pcall(function()
            local orange = { R = 1.0, G = 0.3, B = 0.0, A = 1.0 }
            dynamic_material:SetScalarParameterValue(FName("Progress"), 0.0)
            dynamic_material:SetVectorParameterValue(
                FName("RimInitialColor"), orange
            )
            dynamic_material:SetVectorParameterValue(
                FName("RimCompleteColor"), orange
            )
            dynamic_material:SetVectorParameterValue(
                FName("RimBorderColor"), orange
            )
        end)
        if not style_ok and not hover_dynamic_failure_logged then
            hover_dynamic_failure_logged = true
            log("hover highlight MID color setup failed error="
                .. tostring(style_error))
        end
        state.hover_material = dynamic_material
        return dynamic_material, nil
    end

    local function create_selected_material(state, dismantle_material)
        local dynamic_material = nil
        local create_ok, create_error = pcall(function()
            dynamic_material = unwrap(
                state.mesh:CreateAndSetMaterialInstanceDynamicFromMaterial(
                    state.slot_index, dismantle_material
                )
            )
        end)
        if not create_ok or not is_valid_object(dynamic_material) then
            return nil, create_error
                or "CreateAndSetMaterialInstanceDynamicFromMaterial returned nil"
        end

        -- Progress=1 preserves the stock completed/dismantle color phase.
        -- Opacity is the actual alpha multiplier; lower only that value so a
        -- selected upper structure remains readable through adjacent selected
        -- foundations without becoming as faint as the ray-hover material.
        local style_ok, style_error = pcall(function()
            dynamic_material:SetScalarParameterValue(
                FName("Progress"), 1.0
            )
            dynamic_material:SetScalarParameterValue(
                FName("Opacity"), SELECTED_OPACITY
            )
        end)
        if not style_ok and not selected_dynamic_failure_logged then
            selected_dynamic_failure_logged = true
            log("selected highlight MID opacity setup failed error="
                .. tostring(style_error))
        end
        state.selected_material = dynamic_material
        return dynamic_material, nil
    end

    local function create_error_material(state, highlight_material)
        local dynamic_material = nil
        local create_ok, create_error = pcall(function()
            dynamic_material = unwrap(
                state.mesh:CreateAndSetMaterialInstanceDynamicFromMaterial(
                    state.slot_index, highlight_material
                )
            )
        end)
        if not create_ok or not is_valid_object(dynamic_material) then
            return nil, create_error
                or "CreateAndSetMaterialInstanceDynamicFromMaterial returned nil"
        end

        local style_ok, style_error = pcall(function()
            local red = { R = 1.0, G = 0.02, B = 0.0, A = 1.0 }
            dynamic_material:SetScalarParameterValue(FName("Progress"), 0.0)
            dynamic_material:SetVectorParameterValue(
                FName("RimInitialColor"), red
            )
            dynamic_material:SetVectorParameterValue(
                FName("RimCompleteColor"), red
            )
            dynamic_material:SetVectorParameterValue(
                FName("RimBorderColor"), red
            )
        end)
        if not style_ok and not error_dynamic_failure_logged then
            error_dynamic_failure_logged = true
            log("serialization error highlight MID setup failed error="
                .. tostring(style_error))
        end
        state.serialization_error_material = dynamic_material
        return dynamic_material, nil
    end

    local function set_selection_visual(entry, enabled, requested_role)
        if entry == nil or not is_valid_object(entry.actor) then
            return 0, "<invalid actor>"
        end
        local role = requested_role
        if role == nil then
            local instance_id = entry.record ~= nil and entry.record.source_instance_id or nil
            if entry.serialization_error_flash_active == true then
                role = "serialization-error"
            elseif instance_id ~= nil
                and instance_id == get_selected_anchor_instance_id() then
                role = "anchor"
            else
                role = "selected"
            end
        end
        local visual_material = nil
        if role == "anchor" or role == "hover"
            or role == "serialization-error" then
            visual_material = get_original_anchor_material()
        else
            visual_material = get_original_dismantle_material()
        end
        if enabled and not is_valid_object(visual_material) then
            return 0, "<" .. tostring(role) .. " material unavailable>"
        end

        local shared_role_material = nil
        if enabled and is_selection_active() then
            shared_role_material = get_shared_role_material(role)
            if not is_valid_object(shared_role_material) then
                error("Selection Session material is unavailable for role "
                    .. tostring(role))
            end
        end

        if enabled and entry.visual_material_states == nil then
            entry.visual_material_states = {}
            local visual_ctrl = unwrap(safe_property(entry.actor, "VisualCtrl"))
            for _, mesh in ipairs(collect_build_object_meshes(entry.actor)) do
                local materials = nil
                pcall(function() materials = mesh:GetMaterials() end)
                local count = 0
                pcall(function() count = #materials end)
                for index = 1, count do
                    local slot_index = index - 1
                    local normal_material = nil
                    if is_valid_object(visual_ctrl) then
                        pcall(function()
                            normal_material = visual_ctrl:GetMaterialInstanceNormal(mesh, slot_index)
                        end)
                    end
                    normal_material = unwrap(normal_material)
                    if not is_valid_object(normal_material) then
                        pcall(function() normal_material = unwrap(materials[index]) end)
                    end
                    table.insert(entry.visual_material_states, {
                        mesh = mesh,
                        mesh_address = safe_object_address(mesh),
                        mesh_name = object_name(mesh),
                        slot_index = slot_index,
                        normal_material = normal_material,
                        normal_material_path = get_asset_path(normal_material),
                    })
                end
            end
        end

        local changed = 0
        local states = entry.visual_material_states or {}
        for _, state in ipairs(states) do
            if is_valid_object(state.mesh) then
                local ok_material = false
                if enabled then
                    local current_material = nil
                    pcall(function()
                        current_material = state.mesh:GetMaterial(state.slot_index)
                    end)
                    local already_correct = false
                    if is_valid_object(shared_role_material) then
                        already_correct = is_same_material(
                            current_material, shared_role_material
                        )
                    elseif role == "hover" then
                        already_correct = is_same_material(
                            current_material, state.hover_material
                        )
                    elseif role == "serialization-error" then
                        already_correct = is_same_material(
                            current_material,
                            state.serialization_error_material
                        )
                    elseif role == "selected" then
                        already_correct = is_same_material(
                            current_material, state.selected_material
                        )
                    else
                        already_correct = is_same_material(current_material, visual_material)
                    end
                    if not already_correct then
                        if is_valid_object(shared_role_material) then
                            ok_material = pcall(function()
                                state.mesh:SetMaterial(
                                    state.slot_index, shared_role_material
                                )
                            end)
                        elseif role == "serialization-error" then
                            if is_valid_object(
                                state.serialization_error_material
                            ) then
                                ok_material = pcall(function()
                                    state.mesh:SetMaterial(
                                        state.slot_index,
                                        state.serialization_error_material
                                    )
                                end)
                            else
                                local error_material, error_value =
                                    create_error_material(
                                        state, visual_material
                                    )
                                ok_material = is_valid_object(error_material)
                                if not ok_material then
                                    ok_material = pcall(function()
                                        state.mesh:SetMaterial(
                                            state.slot_index, visual_material
                                        )
                                    end)
                                    if not error_dynamic_failure_logged then
                                        error_dynamic_failure_logged = true
                                        log("serialization error highlight MID unavailable; direct material fallback error="
                                            .. tostring(error_value))
                                    end
                                end
                            end
                        elseif role == "hover" then
                            if is_valid_object(state.hover_material) then
                                ok_material = pcall(function()
                                    state.mesh:SetMaterial(
                                        state.slot_index, state.hover_material
                                    )
                                end)
                            else
                                local hover_material, hover_error =
                                    create_hover_material(
                                        state, visual_material
                                    )
                                ok_material = is_valid_object(hover_material)
                                if not ok_material then
                                    ok_material = pcall(function()
                                        state.mesh:SetMaterial(
                                            state.slot_index, visual_material
                                        )
                                    end)
                                    if not hover_dynamic_failure_logged then
                                        hover_dynamic_failure_logged = true
                                        log("hover highlight MID unavailable; direct material fallback error="
                                            .. tostring(hover_error))
                                    end
                                end
                            end
                        elseif role == "selected" then
                            if is_valid_object(state.selected_material) then
                                ok_material = pcall(function()
                                    state.mesh:SetMaterial(
                                        state.slot_index,
                                        state.selected_material
                                    )
                                end)
                            else
                                local selected_material, selected_error =
                                    create_selected_material(
                                        state, visual_material
                                    )
                                ok_material = is_valid_object(
                                    selected_material
                                )
                                if not ok_material then
                                    ok_material = pcall(function()
                                        state.mesh:SetMaterial(
                                            state.slot_index, visual_material
                                        )
                                    end)
                                    if not selected_dynamic_failure_logged then
                                        selected_dynamic_failure_logged = true
                                        log("selected highlight MID unavailable; direct material fallback error="
                                            .. tostring(selected_error))
                                    end
                                end
                            end
                        else
                            ok_material = pcall(function()
                                state.mesh:SetMaterial(state.slot_index, visual_material)
                            end)
                        end
                    end
                elseif is_valid_object(state.normal_material) then
                    local current_material = nil
                    pcall(function()
                        current_material = state.mesh:GetMaterial(state.slot_index)
                    end)
                    if not is_same_material(current_material, state.normal_material) then
                        ok_material = pcall(function()
                            state.mesh:SetMaterial(state.slot_index, state.normal_material)
                        end)
                    end
                end
                if ok_material then changed = changed + 1 end
            end
        end
        return changed, object_name(
            is_valid_object(shared_role_material)
                and shared_role_material or visual_material
        )
    end

    local function try_set_selection_visual(entry, enabled, requested_role)
        local ok, changed, material = pcall(function()
            return set_selection_visual(entry, enabled, requested_role)
        end)
        if not ok then
            return 0, "<visual error: " .. tostring(changed) .. ">", false
        end
        return changed, material, true
    end

    local function repair_selected_entry_visual(entry, source)
        if entry == nil or entry.visual_repair_active then return end
        if not is_valid_object(entry.actor) then return end
        entry.visual_repair_active = true
        local _, visual_error, visual_ok = try_set_selection_visual(entry, true)
        entry.visual_repair_active = nil
        if not visual_ok and not entry.visual_event_error_logged then
            entry.visual_event_error_logged = true
            log("selection visual event repair failed source=" .. tostring(source)
                .. " instance=" .. tostring(entry.record and entry.record.source_instance_id)
                .. " error=" .. tostring(visual_error))
        elseif visual_ok then
            entry.visual_event_error_logged = nil
        end
    end

    local function set_error_flash_phase(instance_ids, enabled)
        if not is_selection_active() then return end
        for _, instance_id in ipairs(instance_ids or {}) do
            local entry = get_selected_entry(instance_id)
            if entry ~= nil then
                entry.serialization_error_flash_active = enabled == true
                try_set_selection_visual(entry, true)
            end
        end
    end

    local function cancel_error_flash(restore_visuals)
        error_flash_generation = error_flash_generation + 1
        local previous_ids = error_flash_instance_ids
        error_flash_instance_ids = {}
        for _, instance_id in ipairs(previous_ids or {}) do
            local entry = get_selected_entry(instance_id)
            if entry ~= nil then
                entry.serialization_error_flash_active = nil
                if restore_visuals == true and is_selection_active() then
                    try_set_selection_visual(entry, true)
                end
            end
        end
    end

    local function flash_serialization_errors(instance_ids)
        cancel_error_flash(true)
        local unique = {}
        local copied_ids = {}
        for _, instance_id in ipairs(instance_ids or {}) do
            local key = tostring(instance_id)
            if not unique[key] and get_selected_entry(instance_id) ~= nil then
                unique[key] = true
                table.insert(copied_ids, instance_id)
            end
        end
        if #copied_ids == 0 or not is_selection_active() then return false end

        error_flash_generation = error_flash_generation + 1
        local generation = error_flash_generation
        error_flash_instance_ids = copied_ids
        set_error_flash_phase(copied_ids, true)
        local phases = {
            { delay_ms = 450, enabled = false },
            { delay_ms = 900, enabled = true },
            { delay_ms = 1350, enabled = false },
            { delay_ms = 1800, enabled = true },
            { delay_ms = 2250, enabled = false },
            { delay_ms = 2700, enabled = true },
            { delay_ms = 3600, enabled = false, final = true },
        }
        for _, phase in ipairs(phases) do
            local delay_ms = phase.delay_ms
            local enabled = phase.enabled
            local final = phase.final == true
            BlueprintCallbackScheduler.game_thread(
                delay_ms,
                "selection-serialization-error-flash",
                function()
                    if error_flash_generation ~= generation then return end
                    set_error_flash_phase(copied_ids, enabled)
                    if final then
                        error_flash_instance_ids = {}
                    end
                end
            )
        end
        log("selection serialization error highlight started buildings="
            .. tostring(#copied_ids))
        return true
    end

    local function observe_dismantle_target_transition(target, source)
        target = unwrap(target)
        local target_address = safe_object_address(target)
        if target_address == last_observed_dismantle_target_address then return end

        local previous_instance_id = last_observed_dismantle_target_instance_id
        local current_instance_id = get_build_object_instance_id(target)
        last_observed_dismantle_target_address = target_address
        last_observed_dismantle_target_instance_id = current_instance_id
        if not dismantle_target_observer_logged then
            dismantle_target_observer_logged = true
            log("dismantle target observer active source=" .. tostring(source))
        end

        local previous_entry = previous_instance_id ~= nil
            and get_selected_entry(previous_instance_id) or nil
        if previous_entry ~= nil then
            repair_selected_entry_visual(previous_entry,
                tostring(source) .. ":previous-target")
            if not dismantle_target_repair_logged then
                dismantle_target_repair_logged = true
                log("dismantle target observer repaired first selected previous target instance="
                    .. tostring(previous_instance_id))
            end
        end

        if current_instance_id ~= nil
            and current_instance_id == get_selected_anchor_instance_id() then
            local current_entry = get_selected_entry(current_instance_id)
            if current_entry ~= nil then
                repair_selected_entry_visual(current_entry,
                    tostring(source) .. ":current-anchor")
            end
        end

    end

    local function reset_observer(reset_log_state)
        cancel_error_flash(false)
        last_observed_dismantle_target_address = nil
        last_observed_dismantle_target_instance_id = nil
        if reset_log_state then
            dismantle_target_observer_logged = false
            dismantle_target_repair_logged = false
            -- These are active-mode acceleration references.  Reacquire them
            -- from the next World's material set instead of retaining UObjects
            -- after the selection set has been torn down.
            cached_dismantle_material = nil
            cached_anchor_material = nil
        end
    end

    local function abandon_world()
        error_flash_generation = error_flash_generation + 1
        error_flash_instance_ids = {}
        last_observed_dismantle_target_address = nil
        last_observed_dismantle_target_instance_id = nil
        dismantle_target_observer_logged = false
        dismantle_target_repair_logged = false
        cached_dismantle_material = nil
        cached_anchor_material = nil
        hover_dynamic_failure_logged = false
        selected_dynamic_failure_logged = false
        error_dynamic_failure_logged = false
        return true
    end

    return {
        get_anchor_material = get_original_anchor_material,
        try_set = try_set_selection_visual,
        repair = repair_selected_entry_visual,
        flash_serialization_errors = flash_serialization_errors,
        cancel_serialization_errors = cancel_error_flash,
        observe_dismantle_target = observe_dismantle_target_transition,
        reset_observer = reset_observer,
        abandon_world = abandon_world,
    }
end

return BlueprintSelectionVisual

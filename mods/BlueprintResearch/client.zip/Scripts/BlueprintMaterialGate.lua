local UEHelpers = require("UEHelpers")
local M = {}

local AVAILABLE_MATERIALS_FUNCTION =
    "/Script/Pal.PalBuilderComponent:CollectItemInfoEnableToUseMaterial"
local availability_hook_attempted = false
local availability_hook_error = nil
local availability_capture = nil
local availability_hook_pre_callback = nil
local availability_hook_post_callback = nil
-- Pure Lua cache only. Never retain UDataTable rows or any other UObject here;
-- build recipes are stable for the lifetime of the loaded game process.
local unit_material_requirements_by_build_id = {}

local function unwrap(value)
    if value == nil then return nil end
    local ok, result = pcall(function() return value:get() end)
    if ok then return result end
    return value
end

local function safe_property(value, property_name)
    value = unwrap(value)
    if value == nil then return nil end
    local ok, result = pcall(function() return value[property_name] end)
    if ok then return result end
    return nil
end

local function value_to_string(value)
    value = unwrap(value)
    if value == nil then return "<nil>" end
    local ok, result = pcall(function() return value:ToString() end)
    if ok then return tostring(result) end
    return tostring(value)
end

local function value_to_number(value)
    value = unwrap(value)
    return tonumber(value)
end

local function is_material_id(item_id)
    return item_id ~= nil and item_id ~= "" and item_id ~= "None"
        and item_id ~= "<nil>"
end

local function get_build_data_table()
    local utility = unwrap(StaticFindObject(
        "/Script/Pal.Default__PalMasterDataTablesUtility"
    ))
    if utility == nil then
        return nil, "PalMasterDataTablesUtility is unavailable"
    end
    local world = UEHelpers.GetWorld()
    if world == nil then
        return nil, "world is unavailable"
    end
    local ok, data_table = pcall(function()
        return utility:GetBuildObjectDataTable(world)
    end)
    data_table = unwrap(data_table)
    if not ok or data_table == nil then
        return nil, "build object data table is unavailable: " .. tostring(data_table)
    end
    return data_table, nil
end

local function read_unit_material_requirement(data_table, build_object_id)
    local cached = unit_material_requirements_by_build_id[build_object_id]
    if cached ~= nil then return cached, true, nil end

    local row_ok, row = pcall(function()
        -- UE4SS's UDataTable Lua wrapper accepts a plain row-name string.
        -- Passing an FName wrapper reaches Lua::get_string with a non-string
        -- value and can crash natively before Lua pcall can recover.
        return data_table:FindRow(build_object_id)
    end)
    row = unwrap(row)
    if not row_ok or row == nil then
        return nil, false,
            "build data row is unavailable for " .. build_object_id
    end

    local required_build_work_amount = value_to_number(safe_property(
        row, "RequiredBuildWorkAmount"
    ))

    local unit = {
        required = {},
        material_order = {},
        required_build_work_amount = required_build_work_amount,
    }
    for material_index = 1, 4 do
        local item_id = value_to_string(safe_property(
            row, "Material" .. material_index .. "_Id"
        ))
        local unit_count = value_to_number(safe_property(
            row, "Material" .. material_index .. "_Count"
        )) or 0
        if is_material_id(item_id) and unit_count > 0 then
            if unit.required[item_id] == nil then
                unit.required[item_id] = 0
                table.insert(unit.material_order, item_id)
            end
            unit.required[item_id] = unit.required[item_id] + unit_count
        end
    end
    unit_material_requirements_by_build_id[build_object_id] = unit
    return unit, false, nil
end

local function collect_required_materials(blueprint)
    if blueprint == nil or type(blueprint.buildings) ~= "table"
        or #blueprint.buildings == 0 then
        return nil, "blueprint has no buildings"
    end

    local build_counts = {}
    local build_order = {}
    for _, building in ipairs(blueprint.buildings) do
        local build_object_id = tostring(building.build_object_id or "")
        if build_object_id == "" then
            return nil, "blueprint building has no BuildObjectId"
        end
        if build_counts[build_object_id] == nil then
            build_counts[build_object_id] = 0
            table.insert(build_order, build_object_id)
        end
        build_counts[build_object_id] = build_counts[build_object_id] + 1
    end

    local required = {}
    local material_order = {}
    local data_table = nil
    local cache_hits = 0
    local cache_misses = 0
    for _, build_object_id in ipairs(build_order) do
        local unit = unit_material_requirements_by_build_id[build_object_id]
        local was_cached = unit ~= nil
        local unit_error = nil
        if unit == nil then
            if data_table == nil then
                local table_error = nil
                data_table, table_error = get_build_data_table()
                if data_table == nil then return nil, table_error end
            end
            unit, was_cached, unit_error = read_unit_material_requirement(
                data_table, build_object_id
            )
            if unit == nil then return nil, unit_error end
        end
        if was_cached then
            cache_hits = cache_hits + 1
        else
            cache_misses = cache_misses + 1
        end
        local multiplier = build_counts[build_object_id]
        for _, item_id in ipairs(unit.material_order) do
            if required[item_id] == nil then
                required[item_id] = 0
                table.insert(material_order, item_id)
            end
            required[item_id] = required[item_id]
                + unit.required[item_id] * multiplier
        end
    end

    return {
        required = required,
        material_order = material_order,
        building_count = #blueprint.buildings,
        build_type_count = #build_order,
        requirement_cache_hits = cache_hits,
        requirement_cache_misses = cache_misses,
    }, nil
end

local function consume_item_info(available, value)
    local info = unwrap(value)
    if info == nil then return end
    local item_id = value_to_string(safe_property(info, "StaticItemId"))
    local count = value_to_number(safe_property(info, "Num")) or 0
    if is_material_id(item_id) then
        available[item_id] = count
    end
end

local function consume_item_infos(available, item_infos)
    item_infos = unwrap(item_infos)
    if item_infos == nil then return false, "item info array is nil" end

    if type(item_infos) == "table" then
        local found = false
        for _, item_info in ipairs(item_infos) do
            consume_item_info(available, item_info)
            found = true
        end
        return found or next(available) ~= nil, nil
    end

    local found = false
    local foreach_ok = pcall(function()
        item_infos:ForEach(function(_, item_info)
            consume_item_info(available, item_info)
            found = true
        end)
    end)
    if foreach_ok then return found or next(available) ~= nil, nil end

    local index_ok, index_error = pcall(function()
        for index = 1, #item_infos do
            consume_item_info(available, item_infos[index])
            found = true
        end
    end)
    if not index_ok then
        return false, "failed to read item info array: " .. tostring(index_error)
    end
    return found or next(available) ~= nil, nil
end

local function ensure_availability_capture_hook()
    if availability_hook_attempted then
        return availability_hook_error == nil, availability_hook_error
    end
    availability_hook_attempted = true

    availability_hook_pre_callback = function() end
    availability_hook_post_callback = function(_, _, out_item_infos)
            local capture = availability_capture
            if capture == nil then return end
            local callback_ok, callback_error = pcall(function()
                local captured = {}
                local read_ok, read_error = consume_item_infos(
                    captured, out_item_infos
                )
                capture.seen = true
                capture.read_ok = read_ok
                capture.read_error = read_error
                capture.available = captured
            end)
            if not callback_ok then
                capture.seen = true
                capture.read_ok = false
                capture.read_error = "availability post-hook failed: "
                    .. tostring(callback_error)
                capture.available = nil
            end
        end
    local ok, pre_id, post_id = pcall(
        RegisterHook,
        AVAILABLE_MATERIALS_FUNCTION,
        availability_hook_pre_callback,
        availability_hook_post_callback
    )
    if not ok then
        availability_hook_error = "availability post-hook registration failed: "
            .. tostring(pre_id)
        return false, availability_hook_error
    end
    return true, nil
end

local function collect_available_materials_fallback(material_order)
    local utility = unwrap(StaticFindObject(
        "/Script/Pal.Default__PalItemUtility"
    ))
    local world = UEHelpers.GetWorld()
    if utility == nil or world == nil then
        return nil, "PalItemUtility fallback is unavailable"
    end

    local available = {}
    for _, item_id in ipairs(material_order) do
        local inventory_ok, inventory_count = pcall(function()
            return utility:CountLocalPlayerInventoryItemNum64(
                world, FName(item_id)
            )
        end)
        local base_ok, base_count = pcall(function()
            return utility:CountLocalPlayerInsideBaseCampItemNum64(
                world, FName(item_id)
            )
        end)
        if not inventory_ok or not base_ok then
            return nil, "PalItemUtility fallback failed for " .. item_id
        end
        available[item_id] = math.max(0,
            (value_to_number(inventory_count) or 0)
            + (value_to_number(base_count) or 0)
        )
    end
    return available, nil
end

local function collect_available_materials(builder, material_order)
    if builder == nil then return nil, "builder is unavailable" end
    if #material_order == 0 then return {}, nil end

    local item_ids = {}
    for _, item_id in ipairs(material_order) do
        table.insert(item_ids, FName(item_id))
    end

    ensure_availability_capture_hook()
    local capture = { seen = false, available = nil }
    availability_capture = capture
    local output = {}
    local call_ok, call_result = pcall(function()
        return builder:CollectItemInfoEnableToUseMaterial(item_ids, output)
    end)
    availability_capture = nil
    if not call_ok then
        local fallback, fallback_error = collect_available_materials_fallback(
            material_order
        )
        if fallback ~= nil then return fallback, nil end
        return nil, "CollectItemInfoEnableToUseMaterial failed: "
            .. tostring(call_result) .. "; fallback: " .. tostring(fallback_error)
    end

    local available = {}
    local item_infos = output.OutItemInfos or output[1]
    if item_infos == nil and type(call_result) == "table" then
        item_infos = call_result.OutItemInfos or call_result[1]
    end
    if item_infos ~= nil then
        local read_ok = consume_item_infos(available, item_infos)
        if read_ok then return available, nil end
    end

    -- UE4SS 3.0.1 does not reliably copy TArray<struct> out parameters into
    -- the Lua table supplied by the caller.  The synchronous post-hook above
    -- observes the real native out parameter before its wrapper expires.
    if capture.seen and capture.read_ok and capture.available ~= nil then
        return capture.available, nil
    end

    local fallback, fallback_error = collect_available_materials_fallback(
        material_order
    )
    if fallback ~= nil then return fallback, nil end
    return nil, "CollectItemInfoEnableToUseMaterial returned no readable "
        .. "OutItemInfos; hook=" .. tostring(availability_hook_error)
        .. "; capture=" .. tostring(capture.read_error)
        .. "; fallback=" .. tostring(fallback_error)
end

-- Shared by the selection HUD.  Keep requirement and availability collection
-- identical to the placement gate so both surfaces use the same game data and
-- the same "inventory + enabled base storage" builder query.
M.collect_required_materials = collect_required_materials
M.collect_available_materials = collect_available_materials

-- Annotate the pure-data build requests with the game's static construction
-- work requirement. Reuse the material recipe cache so each build-object row
-- is reflected at most once per process and no UDataTable row survives this
-- call.
function M.annotate_build_requests(anchor_request, member_requests)
    if type(anchor_request) ~= "table" then
        return nil, "anchor request is unavailable"
    end

    local requests = { anchor_request }
    for _, request in ipairs(member_requests or {}) do
        requests[#requests + 1] = request
    end

    local data_table = nil
    local instant_count = 0
    local manual_count = 0
    local cache_hits = 0
    local cache_misses = 0
    for _, request in ipairs(requests) do
        local build_object_id = tostring(request.build_object_id or "")
        if build_object_id == "" then
            return nil, "build request has no BuildObjectId"
        end

        local unit = unit_material_requirements_by_build_id[build_object_id]
        local was_cached = unit ~= nil
        local unit_error = nil
        if unit == nil then
            if data_table == nil then
                local table_error = nil
                data_table, table_error = get_build_data_table()
                if data_table == nil then return nil, table_error end
            end
            unit, was_cached, unit_error = read_unit_material_requirement(
                data_table, build_object_id
            )
            if unit == nil then return nil, unit_error end
        end

        local work_amount = tonumber(unit.required_build_work_amount)
        if work_amount == nil then
            return nil, "cached build work amount is unavailable for "
                .. build_object_id
        end
        request.required_build_work_amount = work_amount
        if work_amount > 0 then
            request.construction_mode = "manual"
            manual_count = manual_count + 1
        else
            request.construction_mode = "instant"
            instant_count = instant_count + 1
        end
        if was_cached then
            cache_hits = cache_hits + 1
        else
            cache_misses = cache_misses + 1
        end
    end

    return {
        request_count = #requests,
        instant_count = instant_count,
        manual_count = manual_count,
        cache_hits = cache_hits,
        cache_misses = cache_misses,
    }, nil
end

local function format_counts(material_order, required, available, only_missing)
    local parts = {}
    for _, item_id in ipairs(material_order) do
        local need = required[item_id] or 0
        local have = available[item_id] or 0
        if not only_missing or have < need then
            table.insert(parts, string.format("%s %d/%d", item_id, have, need))
        end
    end
    return table.concat(parts, ", ")
end

local function format_shortages(material_order, required, available)
    local parts = {}
    for _, item_id in ipairs(material_order) do
        local need = required[item_id] or 0
        local have = available[item_id] or 0
        local shortage = math.max(need - have, 0)
        if shortage > 0 then
            table.insert(parts, string.format("%s ×%d", item_id, shortage))
        end
    end
    return table.concat(parts, ", ")
end

function M.check(blueprint, builder)
    local requirement, requirement_error = collect_required_materials(blueprint)
    if requirement == nil then
        return true, {
            kind = "unavailable",
            message = requirement_error,
            user_message = nil,
        }
    end

    local available, available_error = collect_available_materials(
        builder, requirement.material_order
    )
    if available == nil then
        return true, {
            kind = "unavailable",
            message = available_error,
            user_message = nil,
        }
    end

    local missing_count = 0
    for _, item_id in ipairs(requirement.material_order) do
        if (available[item_id] or 0) < (requirement.required[item_id] or 0) then
            missing_count = missing_count + 1
        end
    end

    local report = {
        kind = missing_count == 0 and "sufficient" or "insufficient",
        building_count = requirement.building_count,
        build_type_count = requirement.build_type_count,
        material_type_count = #requirement.material_order,
        material_order = requirement.material_order,
        missing_count = missing_count,
        required = requirement.required,
        available = available,
        summary = format_counts(
            requirement.material_order, requirement.required, available, false
        ),
        missing_summary = format_counts(
            requirement.material_order, requirement.required, available, true
        ),
        shortage_summary = format_shortages(
            requirement.material_order, requirement.required, available
        ),
    }
    if missing_count > 0 then
        report.message = "insufficient aggregate blueprint materials: "
            .. report.missing_summary .. " shortage=["
            .. report.shortage_summary .. "]"
        return false, report
    end
    report.message = "aggregate blueprint materials are sufficient"
    return true, report
end

return M

local BlueprintPerformance = {}

function BlueprintPerformance.now()
    return os.clock()
end

function BlueprintPerformance.elapsed_ms(started_at)
    local started = tonumber(started_at)
    if started == nil then return 0.0 end
    local elapsed = (os.clock() - started) * 1000.0
    if elapsed < 0.0 then return 0.0 end
    return elapsed
end

function BlueprintPerformance.add_elapsed(stats, field, started_at)
    if type(stats) ~= "table" or type(field) ~= "string" then
        return 0.0
    end
    local elapsed = BlueprintPerformance.elapsed_ms(started_at)
    stats[field] = (tonumber(stats[field]) or 0.0) + elapsed
    return elapsed
end

return BlueprintPerformance

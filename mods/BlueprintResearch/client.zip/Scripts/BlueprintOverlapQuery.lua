local BlueprintBuildEquivalence = require("BlueprintBuildEquivalence")
local BlueprintOverlapTiming = require("BlueprintOverlapTiming")

local BlueprintOverlapQuery = {}

-- These profiles describe sensors, interaction ranges or other query-only
-- helpers. Palworld's stock BuildingOverlap profile does not treat them as
-- construction geometry. Profile-name filtering is deliberately used instead
-- of reflected collision-response calls: invoking those methods on arbitrary
-- live-world components can crash UE4SS outside Lua's pcall protection.
local NON_PHYSICAL_QUERY_PROFILES = {
    InteractiveObject = true,
    Volume_PlayerOnly = true,
    Volume_PawnOnly = true,
    InteractOnly = true,
    DungeonAreaVolume = true,
    Volume_Temperature = true,
    WazaTargetSensor = true,
    Volume_WorldDynamic = true,
    OverlapPlayer_BlockAISight = true,
    AimTarget = true,
    WorkableBounds = true,
    FoliageThroughPawn = true,
    Temperature = true,
    MapObjectSpawnerLocation = true,
    BlockForPawn = true,
    SnapBuildObject = true,
    RagdollInteractiveSphereDeactive = true,
    RagdollInteractiveSphereActive = true,
    FishingSpot = true,
    ClimbSupportBlock = true,
    RideableCheck = true,
    FishingSpotAttackBlock = true,
}

function BlueprintOverlapQuery.install(deps)
    assert(type(deps) == "table", "BlueprintOverlapQuery.install requires deps")

    local unwrap = assert(deps.unwrap, "BlueprintOverlapQuery requires unwrap")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintOverlapQuery requires is_valid_object")
    local value_to_string = assert(deps.value_to_string,
        "BlueprintOverlapQuery requires value_to_string")
    local safe_property = assert(deps.safe_property,
        "BlueprintOverlapQuery requires safe_property")
    local object_name = assert(deps.object_name,
        "BlueprintOverlapQuery requires object_name")
    local get_query_component = assert(
        deps.get_query_component,
        "BlueprintOverlapQuery requires get_query_component"
    )
    local snapshot_build_object = assert(
        deps.snapshot_build_object,
        "BlueprintOverlapQuery requires snapshot_build_object"
    )
    local apply_blocker_visual = deps.apply_blocker_visual
    local pal_monster_class = deps.pal_monster_class

    local function get_object_types()
        local object_types = {}
        -- EObjectTypeQuery has 32 slots. Querying all slots is intentional:
        -- PalMapObjectManager.SearchObjectTypes omits WorldStatic terrain and
        -- some dynamic pickup channels.
        for object_type = 0, 31 do
            table.insert(object_types, object_type)
        end
        return object_types
    end

    local function object_is_a(object, class_object)
        object = unwrap(object)
        class_object = unwrap(class_object)
        if not is_valid_object(object) or not is_valid_object(class_object) then
            return false
        end
        local ok, result = pcall(function() return object:IsA(class_object) end)
        return ok and result == true
    end

    local function get_component_profile(component)
        local profile = "<unavailable>"
        pcall(function()
            profile = value_to_string(component:GetCollisionProfileName())
        end)
        return profile
    end

    local function get_component_object_type(component)
        local object_type = nil
        pcall(function()
            object_type = tonumber(value_to_string(
                component:GetCollisionObjectType()
            ))
        end)
        return object_type
    end

    local function get_object_class_label(object)
        local class_label = "<unavailable>"
        pcall(function()
            local class_object = unwrap(object:GetClass())
            if is_valid_object(class_object) then
                class_label = object_name(class_object)
            end
        end)
        return class_label
    end

    local function contains_any(value, tokens)
        for _, token in ipairs(tokens) do
            if string.find(value, token, 1, true) ~= nil then return true end
        end
        return false
    end

    local function is_surface_component(component, owner)
        if get_component_object_type(component) == 0 then return true end
        local component_label = object_name(component)
        local owner_label = object_name(owner)
        return string.find(component_label, "LandscapeHeightfield", 1, true) ~= nil
            or string.find(owner_label, "Landscape", 1, true) ~= nil
    end

    local function is_water_surface_component(component, owner)
        if not is_valid_object(component) or not is_valid_object(owner) then
            return false
        end
        local labels = {
            string.lower(object_name(component)),
            string.lower(object_name(owner)),
            string.lower(get_component_profile(component)),
        }
        pcall(function()
            table.insert(labels, string.lower(object_name(owner:GetClass())))
        end)
        for _, label in ipairs(labels) do
            if contains_any(label, { "water", "ocean", "river", "lake" }) then
                return true
            end
        end
        return false
    end

    local function is_ignored_overlap(component, owner)
        if not is_valid_object(component) or not is_valid_object(owner) then
            return false
        end
        local owner_label = object_name(owner)
        -- PalCharacterMaterialVolume only selects footstep/character materials.
        -- Its query-only Custom box is not a physical construction obstruction.
        local owner_class_label = "<unavailable>"
        pcall(function() owner_class_label = object_name(owner:GetClass()) end)
        -- Pals are moving actors rather than persistent construction
        -- obstructions.  Besides producing a poor placement experience, using
        -- their skeletal components as blocker diagnostics is unsafe while the
        -- character can be despawned or have its mesh rebuilt.  Leave the
        -- authoritative construction request to handle any transient contact.
        if object_is_a(owner, pal_monster_class) then return true end
        local profile = get_component_profile(component)
        if NON_PHYSICAL_QUERY_PROFILES[profile] == true then return true end
        -- Functional build objects such as Pal beds expose a large
        -- SnapBoxCollision using the generic Custom profile. It describes
        -- snapping/query space rather than occupied mesh volume. Filtering
        -- every Custom component would hide real blockers, so match the
        -- authored helper component name only.
        local component_label = object_name(component)
        if string.find(
            component_label, "SnapBoxCollision", 1, true
        ) ~= nil then
            return true
        end
        if string.find(owner_label, "CharacterMaterialVolume", 1, true) ~= nil
            or string.find(
                owner_class_label, "CharacterMaterialVolume", 1, true
            ) ~= nil then
            return true
        end
        return false
    end

    local function get_build_object_id(owner)
        return string.lower(value_to_string(
            safe_property(owner, "BuildObjectId")
        ))
    end

    local function is_support_build_object(building_state, owner)
        local candidate_id = string.lower(tostring(
            building_state.build_object_id or ""
        ))
        local owner_id = get_build_object_id(owner)
        return contains_any(candidate_id, { "pillar", "column" })
            or contains_any(owner_id, { "pillar", "column" })
    end

    local function can_sink_into_surface(building_state)
        local strategy = tostring(building_state.install_strategy)
        if strategy == "4" or strategy == "13" then return true end
        local build_object_id = string.lower(tostring(
            building_state.build_object_id or ""
        ))
        return contains_any(
            build_object_id, { "stair", "pillar", "column" }
        )
    end

    local function set_query_shape(component, descriptor, box_scale_xy,
        box_half_height)
        if not is_valid_object(component) or descriptor == nil then
            return false, "query shape or descriptor unavailable"
        end
        local ok, shape_error = pcall(function()
            if descriptor.shape_type == "box" then
                local scale_xy = tonumber(box_scale_xy) or 1.0
                component:SetBoxExtent({
                    X = descriptor.box_extent.x * scale_xy,
                    Y = descriptor.box_extent.y * scale_xy,
                    Z = tonumber(box_half_height) or descriptor.box_extent.z,
                }, false)
            elseif descriptor.shape_type == "sphere" then
                component:SetSphereRadius(descriptor.radius, false)
            elseif descriptor.shape_type == "capsule" then
                component:SetCapsuleSize(
                    descriptor.radius, descriptor.half_height, false
                )
            else
                error("unsupported query shape=" .. tostring(descriptor.shape_type))
            end
        end)
        if not ok then return false, tostring(shape_error) end
        return true, nil
    end

    local function query_components(
        session, system_library, building_state, collision_transform,
        object_types, ignored_actors, component_class, timing_probe
    )
        local query_component =
            get_query_component(session, building_state)
        if not is_valid_object(query_component) then
            return nil, 0, "Session query component unavailable shape="
                .. tostring(building_state.query_shape) .. " index="
                .. tostring(building_state.query_index)
        end
        local out_components = {}
        local query_started_at = BlueprintOverlapTiming.now(timing_probe)
        local query_ok, query_result = pcall(function()
            return system_library:ComponentOverlapComponents(
                query_component,
                collision_transform,
                object_types,
                component_class,
                ignored_actors,
                out_components
            )
        end)
        local query_ms = BlueprintOverlapTiming.elapsed_ms(query_started_at)
        BlueprintOverlapTiming.add_ms(
            timing_probe, "native_query_ms", query_ms
        )
        BlueprintOverlapTiming.sample_ms(
            timing_probe, "native_query_ms", query_ms
        )
        BlueprintOverlapTiming.increment(
            timing_probe, "native_query_calls", 1
        )
        if not query_ok then return nil, 0, tostring(query_result) end
        local components = safe_property(out_components, "OutComponents")
            or out_components
        local component_count = 0
        pcall(function() component_count = #components end)
        BlueprintOverlapTiming.increment(
            timing_probe, "native_query_components", component_count
        )
        return components, component_count, nil
    end

    local function query_surface_intrusion(
        session, system_library, math_library, building_state,
        collision_transform, object_types, ignored_actors,
        component_class, build_object_class, timing_probe
    )
        local descriptor = building_state.overlap_descriptor
        if not can_sink_into_surface(building_state)
            or descriptor == nil or descriptor.shape_type ~= "box" then
            return nil, nil, 0, nil
        end

        local sink_rate = tonumber(
            building_state.install_capacity_sink_rate_by_height
        )
        -- -1 means unspecified/use the strategy default. Do not treat it as
        -- zero, which makes ordinary ground contact look like intrusion.
        if sink_rate ~= nil and sink_rate < 0.0 then
            return nil, nil, 0, nil
        end
        if sink_rate == nil then sink_rate = 0.50 end
        if sink_rate > 1.0 and sink_rate <= 100.0 then
            sink_rate = sink_rate / 100.0
        end
        sink_rate = math.max(0.0, math.min(sink_rate, 0.90))

        local full_half_height = tonumber(descriptor.box_extent.z)
        if full_half_height == nil or full_half_height <= 0.0 then
            return nil, nil, 0, "foundation overlap height unavailable"
        end
        local full_height = full_half_height * 2.0
        local numeric_margin = math.max(2.0, full_height * 0.01)
        local allowed_bottom_depth = math.min(
            full_height * sink_rate + numeric_margin,
            full_height - 2.0
        )
        local inner_half_height = (full_height - allowed_bottom_depth) * 0.5
        local local_center_shift = allowed_bottom_depth * 0.5
        if inner_half_height <= 0.0 then return nil, nil, 0, nil end

        local inner_transform = math_library:ComposeTransforms({
            Rotation = { X = 0.0, Y = 0.0, Z = 0.0, W = 1.0 },
            Translation = { X = 0.0, Y = 0.0, Z = local_center_shift },
            Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
        }, collision_transform)
        local query_component =
            get_query_component(session, building_state)
        local shape_ok, shape_error = set_query_shape(
            query_component, descriptor, 0.98, inner_half_height
        )
        if not shape_ok then return nil, nil, 0, shape_error end

        local components, component_count, query_error = query_components(
            session, system_library, building_state, inner_transform,
            object_types, ignored_actors, component_class, timing_probe
        )
        local restore_ok, restore_error = set_query_shape(
            query_component, descriptor, 1.0, nil
        )
        if not restore_ok then
            return nil, nil, component_count,
                "failed to restore full overlap shape: " .. tostring(restore_error)
        end
        if query_error ~= nil then
            return nil, nil, component_count, query_error
        end

        local surface_scan_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        for index = 1, component_count do
            BlueprintOverlapTiming.increment(
                timing_probe, "component_pair_visits", 1
            )
            local component = nil
            pcall(function() component = unwrap(components[index]) end)
            if is_valid_object(component) then
                local owner = nil
                pcall(function() owner = unwrap(component:GetOwner()) end)
                if is_valid_object(owner)
                    and not object_is_a(owner, build_object_class)
                    and is_surface_component(component, owner)
                    and not is_water_surface_component(component, owner) then
                    BlueprintOverlapTiming.add_elapsed(
                        timing_probe, "surface_scan_ms",
                        surface_scan_started_at
                    )
                    return owner, component, component_count, nil
                end
            end
        end
        BlueprintOverlapTiming.add_elapsed(
            timing_probe, "surface_scan_ms", surface_scan_started_at
        )
        return nil, nil, component_count, nil
    end

    local function make_blocker_result(
        session, owner, component, reason, visualize,
        equivalence_rejection, timing_probe
    )
        local category = string.sub(reason, 1, 13) == "build-object:"
            and "build_object" or "world_object"
        local build_object_id = category == "build_object"
            and value_to_string(safe_property(owner, "BuildObjectId"))
            or nil
        local location = nil
        pcall(function()
            local value = component:K2_GetComponentLocation()
            location = {
                X = tonumber(safe_property(value, "X")) or 0.0,
                Y = tonumber(safe_property(value, "Y")) or 0.0,
                Z = tonumber(safe_property(value, "Z")) or 0.0,
            }
        end)
        local visual_applied = false
        if visualize == true and category == "build_object"
            and type(apply_blocker_visual) == "function" then
            local visual_started_at =
                BlueprintOverlapTiming.now(timing_probe)
            local ok, applied = pcall(
                apply_blocker_visual, session, owner, component
            )
            BlueprintOverlapTiming.add_elapsed(
                timing_probe, "blocker_visual_ms", visual_started_at
            )
            visual_applied = ok and applied == true
        end
        return {
            blocked = true,
            reason = tostring(reason),
            profile = string.match(tostring(reason), "^[^:]+:(.+)$")
                or "<unavailable>",
            category = category,
            build_object_id = build_object_id,
            actor_label = object_name(owner),
            actor_class_label = get_object_class_label(owner),
            component_label = object_name(component),
            component_class_label = get_object_class_label(component),
            object_type = get_component_object_type(component),
            location = location,
            visual_applied = visual_applied,
            equivalence_rejection = equivalence_rejection,
        }
    end

    local function snapshot_is_surface(pair)
        if tonumber(pair and pair.object_type) == 0 then return true end
        local world_object = pair and pair.world_object or {}
        local component_name = tostring(
            pair and pair.component_name or ""
        )
        local owner_name = tostring(world_object.object_name or "")
        return string.find(
            component_name, "LandscapeHeightfield", 1, true
        ) ~= nil
            or string.find(owner_name, "Landscape", 1, true) ~= nil
    end

    local function snapshot_is_water(pair)
        local world_object = pair and pair.world_object or {}
        local labels = {
            string.lower(tostring(
                pair and pair.component_name or ""
            )),
            string.lower(tostring(world_object.object_name or "")),
            string.lower(tostring(pair and pair.profile or "")),
        }
        for _, label in ipairs(labels) do
            if contains_any(
                label, { "water", "ocean", "river", "lake" }
            ) then
                return true
            end
        end
        return false
    end

    local function snapshot_is_ignored(pair)
        local world_object = pair and pair.world_object or {}
        if world_object.is_pal == true then return true end
        local profile = tostring(pair and pair.profile or "")
        if NON_PHYSICAL_QUERY_PROFILES[profile] == true then
            return true
        end
        local component_name = tostring(
            pair and pair.component_name or ""
        )
        if string.find(
            component_name, "SnapBoxCollision", 1, true
        ) ~= nil then
            return true
        end
        local owner_name = tostring(world_object.object_name or "")
        return string.find(
            owner_name, "CharacterMaterialVolume", 1, true
        ) ~= nil
    end

    local function snapshot_is_support_build_object(
        building_state, world_object
    )
        local candidate_id = string.lower(tostring(
            building_state.build_object_id or ""
        ))
        local owner_id = string.lower(tostring(
            world_object and world_object.build_object_id or ""
        ))
        return contains_any(candidate_id, { "pillar", "column" })
            or contains_any(owner_id, { "pillar", "column" })
    end

    local function make_snapshot_blocker(
        pair, reason, equivalence_rejection
    )
        local world_object = pair.world_object or {}
        local category = world_object.is_build_object == true
            and "build_object" or "world_object"
        return {
            blocked = true,
            reason = tostring(reason),
            profile = tostring(pair.profile or "<unavailable>"),
            category = category,
            build_object_id = category == "build_object"
                and world_object.build_object_id or nil,
            actor_label =
                tostring(world_object.object_name or "<unavailable>"),
            actor_class_label = "<session-snapshot>",
            component_label =
                tostring(pair.component_name or "<unavailable>"),
            component_class_label = "<session-snapshot>",
            object_type = tonumber(pair.object_type),
            location = pair.location,
            visual_applied = false,
            visual_pair_index = pair.pair_index,
            equivalence_rejection = equivalence_rejection,
        }
    end

    local function classify_snapshot(
        building_state, pairs, existing_match_claims
    )
        building_state.water_surface_overlap = false
        building_state.existing_world_match = nil
        pairs = type(pairs) == "table" and pairs or {}
        if building_state.skip_overlap_validation == true then
            return nil, #pairs, nil, {
                has_surface_overlap = false,
                water_surface_overlap = false,
            }
        end

        local best_world_object = nil
        local best_object_key = nil
        local best_details = nil
        local rejection_by_object_key = {}
        local seen = {}
        for _, pair in ipairs(pairs) do
            local world_object = pair.world_object or {}
            local object_key = world_object.object_index
            if world_object.is_build_object == true
                and object_key ~= nil and not seen[object_key] then
                seen[object_key] = true
                local expected_transform =
                    building_state.world_transform
                local equivalent, details = false, nil
                if expected_transform ~= nil then
                    equivalent, details =
                        BlueprintBuildEquivalence.compare({
                            build_object_id =
                                building_state.build_object_id,
                            install_strategy =
                                building_state.install_strategy,
                            model_location = safe_property(
                                expected_transform, "Translation"
                            ),
                            model_rotation = safe_property(
                                expected_transform, "Rotation"
                            ),
                        }, world_object)
                end
                local same_id = string.lower(tostring(
                    world_object.build_object_id or ""
                )) == string.lower(tostring(
                    building_state.build_object_id or ""
                ))
                if same_id then
                    rejection_by_object_key[object_key] = details
                end
                local source_id = building_state.source_instance_id
                local claimed_by = existing_match_claims ~= nil
                    and existing_match_claims[object_key] or nil
                if equivalent
                    and (
                        claimed_by == nil
                        or claimed_by == source_id
                    ) then
                    if best_details == nil
                        or details.position_error
                            < best_details.position_error
                        or (
                            details.position_error
                                == best_details.position_error
                            and details.angle_error_degrees
                                < best_details.angle_error_degrees
                        ) then
                        best_world_object = world_object
                        best_object_key = object_key
                        best_details = details
                    end
                end
            end
        end

        if best_world_object ~= nil then
            if existing_match_claims ~= nil then
                existing_match_claims[best_object_key] =
                    building_state.source_instance_id
            end
            building_state.existing_world_match = {
                instance_id =
                    "session-overlap:" .. tostring(best_object_key),
                actor_address = nil,
                build_object_id =
                    best_world_object.build_object_id,
                position_error = best_details.position_error,
                angle_error_degrees =
                    best_details.angle_error_degrees,
                matched_equivalent_yaw =
                    best_details.matched_equivalent_yaw,
            }
            return nil, #pairs, nil, {
                has_surface_overlap = false,
                water_surface_overlap = false,
            }
        end

        local has_surface_overlap = false
        for _, pair in ipairs(pairs) do
            local world_object = pair.world_object or {}
            if not snapshot_is_ignored(pair) then
                local profile = tostring(
                    pair.profile or "<unavailable>"
                )
                local is_foundation_water =
                    tostring(building_state.install_strategy) == "4"
                    and world_object.is_build_object ~= true
                    and snapshot_is_water(pair)
                if is_foundation_water then
                    building_state.water_surface_overlap = true
                end
                if building_state.allowed_profiles[profile] ~= true then
                    if world_object.is_build_object == true then
                        if not snapshot_is_support_build_object(
                            building_state, world_object
                        ) then
                            return make_snapshot_blocker(
                                pair,
                                "build-object:" .. profile,
                                rejection_by_object_key[
                                    world_object.object_index
                                ]
                            ), #pairs, nil, {
                                has_surface_overlap =
                                    has_surface_overlap,
                                water_surface_overlap =
                                    building_state.
                                        water_surface_overlap,
                            }
                        end
                    else
                        local permitted_surface =
                            is_foundation_water
                            or (
                                can_sink_into_surface(building_state)
                                and snapshot_is_surface(pair)
                            )
                        if permitted_surface then
                            if not is_foundation_water then
                                has_surface_overlap = true
                            end
                        else
                            return make_snapshot_blocker(
                                pair, "other:" .. profile, nil
                            ), #pairs, nil, {
                                has_surface_overlap =
                                    has_surface_overlap,
                                water_surface_overlap =
                                    building_state.
                                        water_surface_overlap,
                            }
                        end
                    end
                end
            end
        end
        return nil, #pairs, nil, {
            has_surface_overlap = has_surface_overlap,
            water_surface_overlap =
                building_state.water_surface_overlap,
        }
    end

    local function classify(
        session, system_library, math_library, building_state,
        collision_transform, object_types, ignored_actors,
        component_class, build_object_class, visualize,
        existing_match_claims, timing_probe
    )
        building_state.water_surface_overlap = false
        building_state.existing_world_match = nil
        if building_state.skip_overlap_validation == true then
            return nil, 0, nil
        end
        local components, component_count, query_error = query_components(
            session, system_library, building_state, collision_transform,
            object_types, ignored_actors, component_class, timing_probe
        )
        if query_error ~= nil then
            return nil, component_count, query_error
        end

        -- Exact-state recognition must precede obstruction classification.
        -- Dense snapped structures often return an adjacent build object's
        -- blocking mesh before the actor which actually occupies this exact
        -- blueprint state. Returning on that first neighbour makes a perfect
        -- overlay order-dependent. Once an equivalent one-to-one world match
        -- exists, this blueprint member is already built, so every other
        -- overlap for this member is irrelevant.
        local seen_build_objects = {}
        local best_world_building = nil
        local best_match_key = nil
        local best_equivalence_details = nil
        local exact_scan_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        for index = 1, component_count do
            BlueprintOverlapTiming.increment(
                timing_probe, "component_pair_visits", 1
            )
            local component = nil
            pcall(function() component = unwrap(components[index]) end)
            if is_valid_object(component) then
                local owner = nil
                pcall(function() owner = unwrap(component:GetOwner()) end)
                if is_valid_object(owner)
                    and object_is_a(owner, build_object_class) then
                    local snapshot_started_at =
                        BlueprintOverlapTiming.now(timing_probe)
                    local world_building = snapshot_build_object(owner)
                    local snapshot_ms = BlueprintOverlapTiming.elapsed_ms(
                        snapshot_started_at
                    )
                    BlueprintOverlapTiming.add_ms(
                        timing_probe, "snapshot_ms", snapshot_ms
                    )
                    BlueprintOverlapTiming.sample_ms(
                        timing_probe, "snapshot_ms", snapshot_ms
                    )
                    local match_key = world_building ~= nil and (
                        world_building.instance_id
                            or world_building.actor_address
                    ) or nil
                    if match_key ~= nil
                        and not seen_build_objects[match_key] then
                        seen_build_objects[match_key] = true
                        local expected_transform =
                            building_state.world_transform
                        local equivalent = false
                        local equivalence_details = nil
                        if expected_transform ~= nil then
                            local equivalence_started_at =
                                BlueprintOverlapTiming.now(timing_probe)
                            equivalent, equivalence_details =
                                BlueprintBuildEquivalence.compare({
                                    build_object_id =
                                        building_state.build_object_id,
                                    install_strategy =
                                        building_state.install_strategy,
                                    model_location = safe_property(
                                        expected_transform, "Translation"
                                    ),
                                    model_rotation = safe_property(
                                        expected_transform, "Rotation"
                                    ),
                                }, world_building)
                            local equivalence_ms =
                                BlueprintOverlapTiming.elapsed_ms(
                                    equivalence_started_at
                                )
                            BlueprintOverlapTiming.add_ms(
                                timing_probe, "equivalence_ms",
                                equivalence_ms
                            )
                            BlueprintOverlapTiming.sample_ms(
                                timing_probe, "equivalence_ms",
                                equivalence_ms
                            )
                        end
                        local source_id =
                            building_state.source_instance_id
                        local claimed_by =
                            existing_match_claims ~= nil
                            and existing_match_claims[match_key] or nil
                        if equivalent
                            and (
                                claimed_by == nil
                                or claimed_by == source_id
                            ) then
                            if best_equivalence_details == nil
                                or equivalence_details.position_error
                                    < best_equivalence_details.
                                        position_error
                                or (
                                    equivalence_details.position_error
                                        == best_equivalence_details.
                                            position_error
                                    and equivalence_details.
                                        angle_error_degrees
                                        < best_equivalence_details.
                                            angle_error_degrees
                                ) then
                                best_world_building = world_building
                                best_match_key = match_key
                                best_equivalence_details =
                                    equivalence_details
                            end
                        end
                    end
                end
            end
        end
        BlueprintOverlapTiming.add_elapsed(
            timing_probe, "exact_scan_ms", exact_scan_started_at
        )
        if best_world_building ~= nil then
            if existing_match_claims ~= nil then
                existing_match_claims[best_match_key] =
                    building_state.source_instance_id
            end
            building_state.existing_world_match = {
                instance_id = best_world_building.instance_id,
                actor_address = best_world_building.actor_address,
                build_object_id = best_world_building.build_object_id,
                position_error =
                    best_equivalence_details.position_error,
                angle_error_degrees =
                    best_equivalence_details.angle_error_degrees,
                matched_equivalent_yaw =
                    best_equivalence_details.matched_equivalent_yaw,
            }
            return nil, component_count, nil
        end

        local has_surface_overlap = false
        local blocker_scan_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        local blocker_scan_recorded = false
        local function finish_blocker_scan()
            if blocker_scan_recorded then return end
            blocker_scan_recorded = true
            BlueprintOverlapTiming.add_elapsed(
                timing_probe, "blocker_scan_ms",
                blocker_scan_started_at
            )
        end
        for index = 1, component_count do
            BlueprintOverlapTiming.increment(
                timing_probe, "component_pair_visits", 1
            )
            local component = nil
            pcall(function() component = unwrap(components[index]) end)
            if is_valid_object(component) then
                local owner = nil
                pcall(function() owner = unwrap(component:GetOwner()) end)
                if is_valid_object(owner)
                    and not is_ignored_overlap(component, owner) then
                    -- PalBuildObjectOverlapChecker::OnOverlapBegin checks the
                    -- overlapped component's collision profile before it
                    -- classifies the owning actor as a build object. Legal snap
                    -- combinations can therefore overlap an allowed auxiliary
                    -- component on another PalBuildObject. Keep that ordering:
                    -- an unsnapped physical intersection still reports one of
                    -- the other actor's non-allowed blocking components.
                    local profile = get_component_profile(component)
                    local is_foundation_water_surface =
                        tostring(building_state.install_strategy) == "4"
                        and not object_is_a(owner, build_object_class)
                        and is_water_surface_component(component, owner)
                    if is_foundation_water_surface then
                        building_state.water_surface_overlap = true
                    end
                    if building_state.allowed_profiles[profile] ~= true then
                        if object_is_a(owner, build_object_class) then
                            local snapshot_started_at =
                                BlueprintOverlapTiming.now(timing_probe)
                            local world_building =
                                snapshot_build_object(owner)
                            local snapshot_ms =
                                BlueprintOverlapTiming.elapsed_ms(
                                    snapshot_started_at
                                )
                            BlueprintOverlapTiming.add_ms(
                                timing_probe, "snapshot_ms", snapshot_ms
                            )
                            BlueprintOverlapTiming.sample_ms(
                                timing_probe, "snapshot_ms", snapshot_ms
                            )
                            local expected_transform =
                                building_state.world_transform
                            local equivalent = false
                            local equivalence_details = nil
                            if world_building ~= nil
                                and expected_transform ~= nil then
                                local equivalence_started_at =
                                    BlueprintOverlapTiming.now(timing_probe)
                                equivalent, equivalence_details =
                                    BlueprintBuildEquivalence.compare({
                                        build_object_id =
                                            building_state.build_object_id,
                                        install_strategy =
                                            building_state.install_strategy,
                                        model_location = safe_property(
                                            expected_transform,
                                            "Translation"
                                        ),
                                    model_rotation = safe_property(
                                            expected_transform,
                                            "Rotation"
                                        ),
                                    }, world_building)
                                local equivalence_ms =
                                    BlueprintOverlapTiming.elapsed_ms(
                                        equivalence_started_at
                                    )
                                BlueprintOverlapTiming.add_ms(
                                    timing_probe, "equivalence_ms",
                                    equivalence_ms
                                )
                                BlueprintOverlapTiming.sample_ms(
                                    timing_probe, "equivalence_ms",
                                    equivalence_ms
                                )
                            end
                            local same_build_object_id = world_building ~= nil
                                and string.lower(tostring(
                                    world_building.build_object_id or ""
                                )) == string.lower(tostring(
                                    building_state.build_object_id or ""
                                ))
                            local rejection = same_build_object_id
                                and equivalence_details or nil
                            -- Pillar/column contacts are intentionally outside
                            -- this custom overlap gate. Stock snap contacts are
                            -- extremely strict and their legal contact volume
                            -- cannot be reconstructed safely from component
                            -- bounds. The original construction request remains
                            -- the final authority for these combinations.
                            if not is_support_build_object(
                                building_state, owner
                            ) then
                                finish_blocker_scan()
                                return make_blocker_result(
                                    session, owner, component,
                                    "build-object:" .. tostring(profile),
                                    visualize, rejection, timing_probe
                                ), component_count, nil
                            end
                        else
                            local is_permitted_surface =
                                is_foundation_water_surface
                                or (
                                    can_sink_into_surface(building_state)
                                    and is_surface_component(component, owner)
                                )
                            if is_permitted_surface then
                                -- Water bodies legitimately intersect the
                                -- placement volume of foundations supported by
                                -- Palworld's water-building rules.  Treating
                                -- the water plane like terrain intrusion makes
                                -- every non-anchor foundation fail our custom
                                -- blueprint gate even though the stock build
                                -- path accepts the same placement.
                                if not is_foundation_water_surface then
                                    has_surface_overlap = true
                                end
                            else
                                finish_blocker_scan()
                                return make_blocker_result(
                                    session, owner, component,
                                    "other:" .. tostring(profile), false,
                                    nil, timing_probe
                                ), component_count, nil
                            end
                        end
                    end
                end
            end
        end
        finish_blocker_scan()

        if has_surface_overlap then
            local owner, component, inner_count, inner_error =
                query_surface_intrusion(
                    session, system_library, math_library, building_state,
                    collision_transform, object_types, ignored_actors,
                    component_class, build_object_class, timing_probe
                )
            component_count = component_count + (inner_count or 0)
            if inner_error ~= nil then
                return nil, component_count, inner_error
            end
            if is_valid_object(owner) then
                return make_blocker_result(
                    session, owner, component,
                    "surface-intrusion", false, nil, timing_probe
                ), component_count, nil
            end
        end
        return nil, component_count, nil
    end

    local function classify_surface_intrusion(
        session, system_library, math_library, building_state,
        collision_transform, object_types, ignored_actors,
        component_class, build_object_class, timing_probe
    )
        local owner, component, component_count, query_error =
            query_surface_intrusion(
                session, system_library, math_library,
                building_state, collision_transform, object_types,
                ignored_actors, component_class, build_object_class,
                timing_probe
            )
        if query_error ~= nil then
            return nil, component_count, query_error
        end
        if is_valid_object(owner) then
            return make_blocker_result(
                session, owner, component,
                "surface-intrusion", false, nil, timing_probe
            ), component_count, nil
        end
        return nil, component_count, nil
    end

    return {
        get_object_types = get_object_types,
        classify = classify,
        classify_snapshot = classify_snapshot,
        classify_surface_intrusion = classify_surface_intrusion,
    }
end

return BlueprintOverlapQuery

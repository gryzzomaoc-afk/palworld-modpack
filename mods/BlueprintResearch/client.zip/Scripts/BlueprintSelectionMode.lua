local UEHelpers = require("UEHelpers")
local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local BlueprintSelectionModeRuntime = {}

local function merge_visual_probe(target, probe)
    if type(target) ~= "table" or type(probe) ~= "table"
        or probe.skipped == true then
        return
    end
    target.role_calls = (tonumber(target.role_calls) or 0) + 1
    target.role_total_ms = (tonumber(target.role_total_ms) or 0.0)
        + (tonumber(probe.total_ms) or 0.0)
    target.role_session_resolve_ms =
        (tonumber(target.role_session_resolve_ms) or 0.0)
        + (tonumber(probe.session_resolve_ms) or 0.0)
    target.role_ue_call_ms =
        (tonumber(target.role_ue_call_ms) or 0.0)
        + (tonumber(probe.ue_call_ms) or 0.0)
    target.role_acknowledgement_ms =
        (tonumber(target.role_acknowledgement_ms) or 0.0)
        + (tonumber(probe.acknowledgement_ms) or 0.0)
end

local function append_selection_probe(mode, message)
    if type(mode) ~= "table" or type(message) ~= "string" then return end
    local records = mode.selection_probe_records
    if type(records) ~= "table" then
        records = {}
        mode.selection_probe_records = records
        mode.selection_probe_records_dropped = 0
    end
    if #records >= 256 then
        mode.selection_probe_records_dropped =
            (tonumber(mode.selection_probe_records_dropped) or 0) + 1
        return
    end
    records[#records + 1] = message
end

function BlueprintSelectionModeRuntime.install(BlueprintSelectionMode, deps)
    assert(type(BlueprintSelectionMode) == "table", "BlueprintSelectionMode table is required")
    assert(type(deps) == "table", "BlueprintSelectionMode dependencies are required")

    local log = assert(deps.log, "log dependency is required")
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(deps.is_valid_object, "is_valid_object dependency is required")
    local safe_property = assert(deps.safe_property, "safe_property dependency is required")
    local safe_object_address = assert(deps.safe_object_address,
        "safe_object_address dependency is required")
    local object_name = assert(deps.object_name, "object_name dependency is required")
    local get_actor_from_hit_result = assert(deps.get_actor_from_hit_result,
        "get_actor_from_hit_result dependency is required")
    local find_valid_instance = assert(deps.find_valid_instance, "find_valid_instance dependency is required")
    local get_build_object_instance_id = assert(deps.get_build_object_instance_id, "get_build_object_instance_id dependency is required")
    local get_build_object_identity = assert(
        deps.get_build_object_identity,
        "get_build_object_identity dependency is required")
    local get_selected_building = assert(deps.get_selected_building,
        "get_selected_building dependency is required")
    local try_set_selection_visual = assert(deps.try_set_selection_visual,
        "try_set_selection_visual dependency is required")
    local try_set_native_hover_visual =
        deps.try_set_native_hover_visual
    local prepare_region_preview = deps.prepare_region_preview
    local is_placement_active = assert(deps.is_placement_active, "is_placement_active dependency is required")
    local get_blueprint_clipboard = assert(deps.get_blueprint_clipboard, "get_blueprint_clipboard dependency is required")
    local clear_pending_selection = assert(deps.clear_pending_selection, "clear_pending_selection dependency is required")
    local has_pending_selection_state = assert(deps.has_pending_selection_state, "has_pending_selection_state dependency is required")
    local validate_selection_state = assert(deps.validate_selection_state, "validate_selection_state dependency is required")
    local can_save_selection = assert(deps.can_save_selection,
        "can_save_selection dependency is required")
    local sync_selection_state = assert(
        deps.sync_selection_state,
        "sync_selection_state dependency is required")
    local commit_selection_to_clipboard = assert(deps.commit_selection_to_clipboard, "commit_selection_to_clipboard dependency is required")
    local open_name_dialog = assert(deps.open_name_dialog,
        "open_name_dialog dependency is required")
    local is_name_dialog_open = assert(deps.is_name_dialog_open,
        "is_name_dialog_open dependency is required")
    local cancel_name_dialog = assert(deps.cancel_name_dialog,
        "cancel_name_dialog dependency is required")
    local send_blueprint_message = assert(deps.send_blueprint_message,
        "send_blueprint_message dependency is required")
    local schedule_cleanup = assert(deps.schedule_cleanup,
        "schedule_cleanup dependency is required")
    local BlueprintSelectionInputBridge = assert(deps.input_bridge, "input_bridge dependency is required")
    local selection_session = assert(
        deps.selection_session, "selection_session dependency is required")
    local performance_now = assert(
        deps.performance_now, "performance_now dependency is required")
    local performance_elapsed_ms = assert(
        deps.performance_elapsed_ms,
        "performance_elapsed_ms dependency is required")
    local is_probe_logging_enabled =
        deps.is_probe_logging_enabled or function() return false end
    local HOVER_VISUAL_CACHE_LIMIT = 64

    function BlueprintSelectionMode.flush_selection_probe_records(reason)
        local records = BlueprintSelectionMode.selection_probe_records
        local dropped = tonumber(
            BlueprintSelectionMode.selection_probe_records_dropped
        ) or 0
        BlueprintSelectionMode.selection_probe_records = nil
        BlueprintSelectionMode.selection_probe_records_dropped = nil
        if type(records) ~= "table" or #records == 0 then return 0 end
        local writer = deps.log_probe or log
        writer(string.format(
            "blueprint performance selection-probe-flush reason=%s records=%d dropped=%d",
            tostring(reason), #records, dropped
        ))
        for _, message in ipairs(records) do writer(message) end
        return #records
    end

    local function clear_hover_visual_cache()
        BlueprintSelectionMode.hover_visual_cache = nil
        BlueprintSelectionMode.hover_visual_cache_order = nil
    end

    local function get_cached_hover_entry(instance_id, actor, identity)
        if instance_id == nil or not is_valid_object(actor) then return nil end
        local cache = BlueprintSelectionMode.hover_visual_cache
        if type(cache) ~= "table" then
            cache = {}
            BlueprintSelectionMode.hover_visual_cache = cache
            BlueprintSelectionMode.hover_visual_cache_order = {}
        end
        local actor_address = safe_object_address(actor)
        local cached = cache[instance_id]
        if type(cached) == "table"
            and cached.actor_address == actor_address
            and is_valid_object(cached.entry and cached.entry.actor) then
            return cached.entry, true
        end
        if cached ~= nil then cache[instance_id] = nil end

        local entry = {
            actor = actor,
            record = {
                source_instance_id = identity.source_instance_id,
                build_object_id = identity.build_object_id,
                map_object_master_data_id =
                    identity.map_object_master_data_id,
            },
            retain_hover_visual_state = true,
        }
        cache[instance_id] = {
            actor_address = actor_address,
            entry = entry,
        }
        local order = BlueprintSelectionMode.hover_visual_cache_order
        order[#order + 1] = instance_id
        while #order > HOVER_VISUAL_CACHE_LIMIT do
            local evicted_id = table.remove(order, 1)
            if evicted_id ~= instance_id then
                cache[evicted_id] = nil
            end
        end
        return entry, false
    end

    function BlueprintSelectionMode.resolve_build_object(actor)
        actor = unwrap(actor)
        for _ = 1, 5 do
            if not is_valid_object(actor) then return nil end
            if get_build_object_instance_id(actor) ~= nil then return actor end

            local owner = nil
            pcall(function() owner = unwrap(actor:GetOwner()) end)
            if not is_valid_object(owner) or owner == actor then
                pcall(function() owner = unwrap(actor:GetAttachParentActor()) end)
            end
            if not is_valid_object(owner) or owner == actor then return nil end
            actor = owner
        end
        return nil
    end

    function BlueprintSelectionMode.trace_target()
        local player_pawn = unwrap(BlueprintSelectionMode.player_pawn)
        local camera_manager = unwrap(BlueprintSelectionMode.camera_manager)
        if not is_valid_object(player_pawn)
            or not is_valid_object(camera_manager) then
            return nil
        end

        local system = UEHelpers.GetKismetSystemLibrary()
        local math_library = UEHelpers.GetKismetMathLibrary()
        if not is_valid_object(system)
            or not is_valid_object(math_library) then
            return nil
        end

        local start_vector = camera_manager:GetCameraLocation()
        local forward = math_library:GetForwardVector(
            camera_manager:GetCameraRotation()
        )
        local end_vector = math_library:Add_VectorVector(
            start_vector,
            math_library:Multiply_VectorInt(
                forward, BlueprintSelectionMode.effective_trace_range
            )
        )
        local hit_result = {}
        local transparent = { R = 0, G = 0, B = 0, A = 0 }
        local was_hit = system:LineTraceSingle(
            player_pawn, start_vector, end_vector, 0, false, {}, 0,
            hit_result, true, transparent, transparent, 0.0
        )
        if not was_hit then return nil end
        local hit_actor = nil
        pcall(function()
            hit_actor = get_actor_from_hit_result(hit_result)
        end)
        return BlueprintSelectionMode.resolve_build_object(hit_actor)
    end

    function BlueprintSelectionMode.restore_hover()
        local probe_enabled = is_probe_logging_enabled() == true
        local total_started_at = probe_enabled
            and performance_now() or nil
        local stats = probe_enabled and {
            selected = false,
            native_restore_ms = 0.0,
            persistent_reapply_ms = 0.0,
            fallback_restore_ms = 0.0,
            role_calls = 0,
            role_total_ms = 0.0,
            role_session_resolve_ms = 0.0,
            role_ue_call_ms = 0.0,
            role_acknowledgement_ms = 0.0,
        } or nil
        local entry = BlueprintSelectionMode.hover_entry
        BlueprintSelectionMode.hover_entry = nil
        if entry == nil then
            if stats ~= nil then stats.total_ms = 0.0 end
            return stats
        end

        local instance_id = entry.record ~= nil
            and entry.record.source_instance_id or nil
        local selected_entry = instance_id ~= nil
            and get_selected_building(instance_id) or nil
        if stats ~= nil then stats.selected = selected_entry ~= nil end
        local native_restored = false
        if entry.native_dismantle_hover == true
            and type(try_set_native_hover_visual) == "function" then
            local started_at = probe_enabled and performance_now() or nil
            local visual_probe = nil
            native_restored, visual_probe =
                try_set_native_hover_visual(entry.actor, false)
            if stats ~= nil then
                stats.native_restore_ms =
                    performance_elapsed_ms(started_at)
                merge_visual_probe(stats, visual_probe)
            end
        end
        if selected_entry ~= nil then
            -- The stock dismantle event restores the building's normal
            -- presentation. Reapply our persistent selected/anchor role only
            -- after the transient ray highlight has been released.
            local started_at = probe_enabled and performance_now() or nil
            local _, _, _, visual_probe =
                try_set_selection_visual(selected_entry, true)
            if stats ~= nil then
                stats.persistent_reapply_ms =
                    performance_elapsed_ms(started_at)
                merge_visual_probe(stats, visual_probe)
            end
        elseif not native_restored then
            local started_at = probe_enabled and performance_now() or nil
            local _, _, _, visual_probe =
                try_set_selection_visual(entry, false)
            if stats ~= nil then
                stats.fallback_restore_ms =
                    performance_elapsed_ms(started_at)
                merge_visual_probe(stats, visual_probe)
            end
        end
        if entry.retain_hover_visual_state ~= true then
            entry.actor = nil
            entry.visual_material_states = nil
        end
        if stats ~= nil then
            stats.total_ms = performance_elapsed_ms(total_started_at)
        end
        return stats
    end

    local function clear_target_tracking()
        BlueprintSelectionMode.current_target = nil
        BlueprintSelectionMode.current_target_address = nil
        BlueprintSelectionMode.current_target_instance_id = nil
        BlueprintSelectionMode.current_target_identity = nil
        BlueprintSelectionMode.hover_entry = nil
        clear_hover_visual_cache()
    end

    function BlueprintSelectionMode.accept_session_target(target, source)
        if not BlueprintSelectionMode.active then return false end
        target = unwrap(target)
        local target_address = safe_object_address(target)
        if target_address
            == BlueprintSelectionMode.current_target_address then
            return true
        end

        BlueprintSelectionMode.current_target = target
        BlueprintSelectionMode.current_target_address = target_address
        local identity = nil
        if is_valid_object(target) then
            identity = get_build_object_identity(target)
        end
        BlueprintSelectionMode.current_target_identity = identity
        BlueprintSelectionMode.current_target_instance_id =
            identity ~= nil and identity.source_instance_id or nil

        BlueprintSelectionMode.update_hud_target_name(
            identity,
            source or "ue-selection-session",
            BlueprintSelectionMode.hud_widget
        )
        return true
    end

    function BlueprintSelectionMode.suspend_target_for_camera(reason)
        if not BlueprintSelectionMode.active then return false end
        -- End the selection subsystem's transient hover while every referenced
        -- Mesh and Session-owned role MID is still known to be current.  The
        -- camera controller remains responsible only for camera/pawn state.
        BlueprintSelectionMode.restore_hover()
        clear_target_tracking()
        BlueprintSelectionMode.update_hud_target_name(
            nil, "camera-suspend:" .. tostring(reason),
            BlueprintSelectionMode.hud_widget
        )
        return true
    end

    function BlueprintSelectionMode.resume_target_after_camera(reason)
        if not BlueprintSelectionMode.active then return false end
        -- Never dereference the pre-camera hover after restoring the view.
        -- The next Lua trace tick acquires the target and slot state afresh.
        clear_target_tracking()
        return true
    end

    function BlueprintSelectionMode.update_target(target, source)
        local probe_enabled = is_probe_logging_enabled() == true
        local total_started_at = probe_enabled
            and performance_now() or nil
        target = unwrap(target)
        local target_address = safe_object_address(target)
        if target_address
            == BlueprintSelectionMode.current_target_address then
            return
        end

        local old_target_address =
            BlueprintSelectionMode.current_target_address
        local restore_stats = BlueprintSelectionMode.restore_hover()
        BlueprintSelectionMode.current_target = target
        BlueprintSelectionMode.current_target_address = target_address

        local identity_started_at = probe_enabled
            and performance_now() or nil
        local identity = nil
        if is_valid_object(target) then
            identity = get_build_object_identity(target)
        end
        local identity_ms = probe_enabled
            and performance_elapsed_ms(identity_started_at) or 0.0
        local instance_id = identity ~= nil
            and identity.source_instance_id or nil
        BlueprintSelectionMode.current_target_instance_id = instance_id
        BlueprintSelectionMode.current_target_identity = identity

        local selected_lookup_started_at = probe_enabled
            and performance_now() or nil
        local selected_entry = instance_id ~= nil
            and get_selected_building(instance_id) or nil
        local selected_lookup_ms = probe_enabled
            and performance_elapsed_ms(selected_lookup_started_at) or 0.0
        local transition_stats = probe_enabled and {
            role_calls = 0,
            role_total_ms = 0.0,
            role_session_resolve_ms = 0.0,
            role_ue_call_ms = 0.0,
            role_acknowledgement_ms = 0.0,
        } or nil
        if transition_stats ~= nil and restore_stats ~= nil then
            transition_stats.role_calls = restore_stats.role_calls or 0
            transition_stats.role_total_ms =
                restore_stats.role_total_ms or 0.0
            transition_stats.role_session_resolve_ms =
                restore_stats.role_session_resolve_ms or 0.0
            transition_stats.role_ue_call_ms =
                restore_stats.role_ue_call_ms or 0.0
            transition_stats.role_acknowledgement_ms =
                restore_stats.role_acknowledgement_ms or 0.0
        end

        local hover_started_at = probe_enabled
            and performance_now() or nil
        local native_hover_ms = 0.0
        local cache_lookup_ms = 0.0
        local fallback_hover_ms = 0.0
        local cache_hit = false
        local native_hover_ok = false
        if identity ~= nil then
            local hover_entry = nil
            if type(try_set_native_hover_visual) == "function" then
                local started_at = probe_enabled
                    and performance_now() or nil
                local visual_probe = nil
                native_hover_ok, visual_probe =
                    try_set_native_hover_visual(target, true)
                if probe_enabled then
                    native_hover_ms =
                        performance_elapsed_ms(started_at)
                    merge_visual_probe(transition_stats, visual_probe)
                end
            end
            if native_hover_ok then
                -- The stock PalBuildObject event owns the high-frequency
                -- ray-highlight materials. Do not enumerate MeshComponents or
                -- material slots merely because the crosshair moved.
                hover_entry = {
                    actor = target,
                    record = selected_entry ~= nil
                        and selected_entry.record or {
                            source_instance_id =
                                identity.source_instance_id,
                            build_object_id = identity.build_object_id,
                            map_object_master_data_id =
                                identity.map_object_master_data_id,
                        },
                    native_dismantle_hover = true,
                }
                BlueprintSelectionMode.hover_entry = hover_entry
            elseif selected_entry ~= nil then
                -- Share the selected entry's slot state so hover does not
                -- enumerate the same meshes or allocate another set of MIDs.
                hover_entry = {
                    actor = target,
                    record = selected_entry.record,
                    visual_material_states =
                        selected_entry.visual_material_states,
                }
            else
                local started_at = probe_enabled
                    and performance_now() or nil
                hover_entry, cache_hit = get_cached_hover_entry(
                    instance_id, target, identity
                )
                if probe_enabled then
                    cache_lookup_ms =
                        performance_elapsed_ms(started_at)
                end
            end
            if hover_entry ~= nil and not native_hover_ok then
                local started_at = probe_enabled
                    and performance_now() or nil
                local _, _, visual_ok, visual_probe = try_set_selection_visual(
                    hover_entry, true, "hover"
                )
                if probe_enabled then
                    fallback_hover_ms =
                        performance_elapsed_ms(started_at)
                    merge_visual_probe(transition_stats, visual_probe)
                end
                if visual_ok then
                    BlueprintSelectionMode.hover_entry = hover_entry
                end
            end
        end
        local hover_total_ms = probe_enabled
            and performance_elapsed_ms(hover_started_at) or 0.0

        local hud_started_at = probe_enabled
            and performance_now() or nil
        BlueprintSelectionMode.update_hud_target_name(
            identity, source, BlueprintSelectionMode.hud_widget
        )
        local hud_ms = probe_enabled
            and performance_elapsed_ms(hud_started_at) or 0.0

        if probe_enabled then
            append_selection_probe(BlueprintSelectionMode, string.format(
                "blueprint performance selection-target-transition source=%s build=%s old=%s new=%s totalMs=%.3f restoreMs=%.3f restoreNativeMs=%.3f restorePersistentMs=%.3f restoreFallbackMs=%.3f identityMs=%.3f selectedLookupMs=%.3f hoverTotalMs=%.3f nativeHoverMs=%.3f cacheLookupMs=%.3f fallbackHoverMs=%.3f hudMs=%.3f roleCalls=%d roleTotalMs=%.3f roleSessionResolveMs=%.3f roleUeCallMs=%.3f roleAckMs=%.3f oldSelected=%s newSelected=%s nativeHover=%s cacheHit=%s",
                tostring(source),
                tostring(identity and identity.build_object_id or "<none>"),
                tostring(old_target_address or "<none>"),
                tostring(target_address or "<none>"),
                performance_elapsed_ms(total_started_at),
                tonumber(restore_stats and restore_stats.total_ms) or 0.0,
                tonumber(restore_stats and restore_stats.native_restore_ms)
                    or 0.0,
                tonumber(restore_stats and restore_stats.persistent_reapply_ms)
                    or 0.0,
                tonumber(restore_stats and restore_stats.fallback_restore_ms)
                    or 0.0,
                identity_ms, selected_lookup_ms, hover_total_ms,
                native_hover_ms, cache_lookup_ms, fallback_hover_ms,
                hud_ms,
                tonumber(transition_stats.role_calls) or 0,
                tonumber(transition_stats.role_total_ms) or 0.0,
                tonumber(transition_stats.role_session_resolve_ms) or 0.0,
                tonumber(transition_stats.role_ue_call_ms) or 0.0,
                tonumber(transition_stats.role_acknowledgement_ms) or 0.0,
                tostring(restore_stats and restore_stats.selected == true),
                tostring(selected_entry ~= nil),
                tostring(native_hover_ok), tostring(cache_hit)
            ))
        end
    end

    function BlueprintSelectionMode.finish(
        reason, preserve_saved_state, defer_native_cleanup
    )
        if BlueprintSelectionMode.finishing then return false end
        local was_active = BlueprintSelectionMode.active
        if is_name_dialog_open() then
            cancel_name_dialog("selection-finish:" .. tostring(reason))
        end
        BlueprintSelectionMode.active = false
        BlueprintSelectionMode.starting = false
        BlueprintSelectionMode.session_id = BlueprintSelectionMode.session_id + 1
        local tick_loop_handle = BlueprintSelectionMode.tick_loop_handle
        BlueprintSelectionMode.tick_loop_handle = nil
        BlueprintSelectionMode.tick_loop_session_id = nil
        BlueprintSelectionMode.tick_loop_tick_count = 0
        if tick_loop_handle ~= nil
            and type(CancelDelayedAction) == "function" then
            local cancel_ok, cancel_error = pcall(
                CancelDelayedAction, tick_loop_handle
            )
            if not cancel_ok then
                log("independent blueprint selection tick cancel failed handle="
                    .. tostring(tick_loop_handle) .. " error="
                    .. tostring(cancel_error))
            end
        end

        local function finish_native_cleanup()
            BlueprintSelectionMode.hide_hud(
                reason, BlueprintSelectionMode.hud_widget
            )
            BlueprintSelectionMode.restore_hover()
            BlueprintSelectionMode.flush_selection_probe_records(
                "selection-finish:" .. tostring(reason)
            )
            clear_hover_visual_cache()
            BlueprintSelectionMode.target_performance = nil
            BlueprintSelectionMode.current_target = nil
            BlueprintSelectionMode.current_target_address = nil
            BlueprintSelectionMode.current_target_instance_id = nil
            BlueprintSelectionMode.current_target_identity = nil
            BlueprintSelectionMode.action_target_override = nil
            BlueprintSelectionMode.action_target_identity_override = nil
            if BlueprintSelectionMode.input_active == true
                and BlueprintSelectionInputBridge ~= nil
                and BlueprintSelectionInputBridge.exit ~= nil then
                BlueprintSelectionInputBridge.exit(reason)
            end
            BlueprintSelectionMode.input_active = false
            -- Restore every selected Actor while the current-World Session and
            -- its role MIDs are still alive. Previously the Session was
            -- destroyed first, forcing teardown through a legacy path that had
            -- no original-material snapshot for UE-owned role visuals.
            if preserve_saved_state ~= true then clear_pending_selection() end
            selection_session.finish(
                reason, BlueprintSelectionMode.selection_session
            )
            BlueprintSelectionMode.selection_session = nil
            BlueprintSelectionMode.hud_widget = nil
            BlueprintSelectionMode.builder = nil
            BlueprintSelectionMode.player_controller = nil
            BlueprintSelectionMode.player_pawn = nil
            BlueprintSelectionMode.camera_manager = nil
            BlueprintSelectionMode.camera_hold_active = false
            BlueprintSelectionMode.finishing = false
            if was_active then
                log("independent blueprint selection mode stopped reason="
                    .. tostring(reason))
            end
        end

        if defer_native_cleanup == true then
            BlueprintSelectionMode.finishing = true
            local scheduled = schedule_cleanup(
                "selection-mode-finish:" .. tostring(reason),
                finish_native_cleanup
            )
            if scheduled ~= true then
                -- Never fall back to UObject calls while still inside the
                -- reflected native pre-hook. World cleanup will release the
                -- remaining references if scheduling itself is unavailable.
                BlueprintSelectionMode.finishing = false
                BlueprintSelectionMode.current_target = nil
                BlueprintSelectionMode.current_target_address = nil
                BlueprintSelectionMode.current_target_instance_id = nil
                BlueprintSelectionMode.current_target_identity = nil
                BlueprintSelectionMode.hover_entry = nil
                clear_hover_visual_cache()
                BlueprintSelectionMode.target_performance = nil
                BlueprintSelectionMode.action_target_override = nil
                BlueprintSelectionMode.action_target_identity_override = nil
                BlueprintSelectionMode.selection_session = nil
                BlueprintSelectionMode.hud_widget = nil
                BlueprintSelectionMode.builder = nil
                BlueprintSelectionMode.player_controller = nil
                BlueprintSelectionMode.player_pawn = nil
                BlueprintSelectionMode.camera_manager = nil
                BlueprintSelectionMode.camera_hold_active = false
                if BlueprintSelectionInputBridge ~= nil
                    and BlueprintSelectionInputBridge.abandon_world ~= nil then
                    BlueprintSelectionInputBridge.abandon_world(
                        "selection-finish-schedule-failed:" .. tostring(reason)
                    )
                end
                log("independent blueprint selection deferred cleanup could not be scheduled reason="
                    .. tostring(reason))
                return false
            end
            return true
        end
        finish_native_cleanup()
        return true
    end

    BlueprintSelectionMode.tick_loop_callback = function()
        local active_session_id =
            BlueprintSelectionMode.tick_loop_session_id
        if not BlueprintSelectionMode.active
            or active_session_id == nil
            or BlueprintSelectionMode.session_id
                ~= active_session_id then
            return
        end

        local tick_ok, tick_error = pcall(
            BlueprintSelectionMode.tick
        )
        if not tick_ok then
            log("independent blueprint selection tick isolated error="
                .. tostring(tick_error))
            BlueprintSelectionMode.finish("tick-error", false)
            return
        end
        BlueprintSelectionMode.tick_loop_tick_count =
            (tonumber(BlueprintSelectionMode.tick_loop_tick_count) or 0)
                + 1
    end

    function BlueprintSelectionMode.schedule_tick(active_session_id)
        if type(LoopInGameThreadWithDelay) ~= "function" then
            return false, "LoopInGameThreadWithDelay is unavailable"
        end
        local previous_handle = BlueprintSelectionMode.tick_loop_handle
        if previous_handle ~= nil
            and type(CancelDelayedAction) == "function" then
            pcall(CancelDelayedAction, previous_handle)
        end
        BlueprintSelectionMode.tick_loop_handle = nil
        BlueprintSelectionMode.tick_loop_session_id =
            active_session_id
        BlueprintSelectionMode.tick_loop_tick_count = 0

        local loop_ok, loop_handle = pcall(
            LoopInGameThreadWithDelay,
            33,
            BlueprintSelectionMode.tick_loop_callback
        )
        if not loop_ok or loop_handle == nil then
            BlueprintSelectionMode.tick_loop_session_id = nil
            return false, tostring(loop_handle)
        end
        BlueprintSelectionMode.tick_loop_handle = loop_handle
        log("independent blueprint selection Lua trace loop registered "
            .. "intervalMs=33 session="
            .. tostring(active_session_id))
        return true, nil
    end

    function BlueprintSelectionMode.tick()
        if not BlueprintSelectionMode.active
            or BlueprintSelectionMode.camera_hold_active then
            return
        end

        local builder = unwrap(BlueprintSelectionMode.builder)
        if not is_valid_object(builder)
            or not is_valid_object(BlueprintSelectionMode.player_pawn)
            or not is_valid_object(
                BlueprintSelectionMode.camera_manager
            ) then
            BlueprintSelectionMode.finish(
                "world-context-became-invalid", false
            )
            return
        end
        local incompatible_mode = false
        pcall(function()
            incompatible_mode = builder:IsDismantling()
                or builder:IsInPaintingMode()
                or builder:IsInBuildingMode()
        end)
        if incompatible_mode then
            BlueprintSelectionMode.finish(
                "original-builder-mode-became-active", false
            )
            return
        end
        BlueprintSelectionMode.update_target(
            BlueprintSelectionMode.trace_target(), "lua-trace"
        )
    end

    function BlueprintSelectionMode.abandon_world(reason)
        BlueprintSelectionMode.active = false
        BlueprintSelectionMode.starting = false
        BlueprintSelectionMode.finishing = false
        BlueprintSelectionMode.session_id =
            (tonumber(BlueprintSelectionMode.session_id) or 0) + 1
        local tick_loop_handle =
            BlueprintSelectionMode.tick_loop_handle
        BlueprintSelectionMode.tick_loop_handle = nil
        BlueprintSelectionMode.tick_loop_session_id = nil
        BlueprintSelectionMode.tick_loop_tick_count = 0
        if tick_loop_handle ~= nil
            and type(CancelDelayedAction) == "function" then
            pcall(CancelDelayedAction, tick_loop_handle)
        end
        -- World teardown must never call through departing UObjects. Drop the
        -- active-mode acceleration references without restoring materials;
        -- the World owns and destroys all of those objects.
        BlueprintSelectionMode.current_target = nil
        BlueprintSelectionMode.current_target_address = nil
        BlueprintSelectionMode.current_target_instance_id = nil
        BlueprintSelectionMode.current_target_identity = nil
        BlueprintSelectionMode.hover_entry = nil
        clear_hover_visual_cache()
        BlueprintSelectionMode.flush_selection_probe_records(
            "world-abandon:" .. tostring(reason)
        )
        BlueprintSelectionMode.target_performance = nil
        if type(BlueprintSelectionMode.clear_hud_target_name_handle)
            == "function" then
            BlueprintSelectionMode.clear_hud_target_name_handle()
        end
        BlueprintSelectionMode.action_target_override = nil
        BlueprintSelectionMode.action_target_identity_override = nil
        BlueprintSelectionMode.selection_session = nil
        BlueprintSelectionMode.hud_widget = nil
        BlueprintSelectionMode.builder = nil
        BlueprintSelectionMode.player_controller = nil
        BlueprintSelectionMode.player_pawn = nil
        BlueprintSelectionMode.camera_manager = nil
        BlueprintSelectionMode.camera_hold_active = false
        BlueprintSelectionMode.input_active = false
        log("independent blueprint selection abandoned reason="
            .. tostring(reason))
        return true
    end

    local function start_selection_mode()
        if has_pending_selection_state() then
            clear_pending_selection()
        end

        local menu = find_valid_instance(
            "WBP_PalBuildObjectList_ForDisplay_C", "/Engine/Transient"
        )
        if not is_valid_object(menu) then
            log("independent blueprint selection start rejected: build list menu not found")
            return
        end

        local player_controller = BlueprintSelectionInputBridge.get_local_player_controller()
        local player_pawn = unwrap(safe_property(player_controller, "Pawn"))
        local camera_manager = unwrap(safe_property(player_controller, "PlayerCameraManager"))
        local builder = BlueprintSelectionInputBridge.find_owned_component(
            "PalBuilderComponent", player_pawn
        )
        local input_actor = BlueprintSelectionInputBridge.find_actor(
            player_controller
        )
        if not is_valid_object(player_controller)
            or not is_valid_object(player_pawn)
            or not is_valid_object(camera_manager)
            or not is_valid_object(builder)
            or not is_valid_object(input_actor) then
            log(string.format(
                "independent blueprint selection start rejected: world context unavailable controller=%s pawn=%s camera=%s builder=%s inputActor=%s",
                object_name(player_controller), object_name(player_pawn),
                object_name(camera_manager), object_name(builder),
                object_name(input_actor)
            ))
            return
        end

        local original_range = tonumber(safe_property(builder, "InstallableRange"))
        BlueprintSelectionMode.effective_trace_range = BlueprintSelectionMode.trace_range
        if original_range ~= nil and original_range >= 100.0 and original_range <= 5000.0 then
            BlueprintSelectionMode.effective_trace_range = original_range
        end

        local closed, close_error = pcall(function()
            menu:OnInputAction_Close()
        end)
        if not closed then
            log("independent blueprint selection start rejected: safe menu close failed error="
                .. tostring(close_error))
            return
        end

        BlueprintSelectionMode.active = true
        BlueprintSelectionMode.input_active = false
        BlueprintSelectionMode.session_id = BlueprintSelectionMode.session_id + 1
        BlueprintSelectionMode.current_target = nil
        BlueprintSelectionMode.current_target_address = nil
        BlueprintSelectionMode.current_target_instance_id = nil
        BlueprintSelectionMode.current_target_identity = nil
        BlueprintSelectionMode.hover_entry = nil
        clear_hover_visual_cache()
        BlueprintSelectionMode.selection_probe_records = nil
        BlueprintSelectionMode.selection_probe_records_dropped = nil
        BlueprintSelectionMode.target_performance = nil
        BlueprintSelectionMode.action_target_override = nil
        BlueprintSelectionMode.action_target_identity_override = nil
        BlueprintSelectionMode.builder = builder
        BlueprintSelectionMode.player_controller = player_controller
        BlueprintSelectionMode.player_pawn = player_pawn
        BlueprintSelectionMode.camera_manager = camera_manager

        local hud_ok, hud_error, hud_widget =
            BlueprintSelectionMode.show_hud(player_controller)
        if not hud_ok then
            log("independent blueprint selection start rejected: HUD unavailable error="
                .. tostring(hud_error))
            BlueprintSelectionMode.finish("selection-hud-unavailable", false)
            send_blueprint_message("message.selection.hud_failed")
            return false
        end
        BlueprintSelectionMode.hud_widget = hud_widget

        local session_ok, session_error, session =
            selection_session.begin({
            input_actor = input_actor,
            controller = player_controller,
            pawn = player_pawn,
            builder = builder,
            camera_manager = camera_manager,
            hud = hud_widget,
            trace_range = BlueprintSelectionMode.effective_trace_range,
        })
        if not session_ok then
            log("independent blueprint selection start rejected: "
                .. "Selection Session unavailable error="
                .. tostring(session_error))
            BlueprintSelectionMode.hide_hud(
                "selection-session-unavailable", hud_widget
            )
            BlueprintSelectionMode.finish(
                "selection-session-unavailable", false
            )
            send_blueprint_message("message.selection.tick_failed")
            return false
        end
        BlueprintSelectionMode.selection_session = session
        if type(prepare_region_preview) == "function"
            and not prepare_region_preview(session) then
            log("selection region preview resources were not prepared")
        end
        local resumed, resume_error =
            selection_session.set_tick_paused(false, session)
        if not resumed then
            log("independent blueprint selection start rejected: "
                .. "UE Session trace resume failed error="
                .. tostring(resume_error))
            BlueprintSelectionMode.finish(
                "selection-session-resume-failed", false
            )
            send_blueprint_message("message.selection.tick_failed")
            return false
        end
        if BlueprintSelectionInputBridge == nil
            or BlueprintSelectionInputBridge.enter == nil
            or not BlueprintSelectionInputBridge.enter(
                player_controller, input_actor
            ) then
            BlueprintSelectionMode.finish(
                "input-context-unavailable", false
            )
            send_blueprint_message("message.selection.input_failed")
            return false
        end
        BlueprintSelectionMode.input_active = true
        log(string.format(
            "independent blueprint selection mode started backend=ue-native-selection-state-machine menuClose=OnInputAction_Close traceRange=%.1f input=left:toggle,middle:region,right:anchor,z:save,esc:cancel",
            BlueprintSelectionMode.effective_trace_range
        ))
        return true
    end

    function BlueprintSelectionMode.start()
        if is_placement_active() then
            log("independent blueprint selection start rejected: blueprint placement is active")
            return false
        end
        if BlueprintSelectionMode.active or BlueprintSelectionMode.starting
            or BlueprintSelectionMode.finishing then
            log("independent blueprint selection start ignored: lifecycle already active="
                .. tostring(BlueprintSelectionMode.active)
                .. " starting=" .. tostring(BlueprintSelectionMode.starting)
                .. " finishing=" .. tostring(BlueprintSelectionMode.finishing))
            return false
        end

        BlueprintSelectionMode.starting = true
        local ok, result_or_error = pcall(start_selection_mode)
        BlueprintSelectionMode.starting = false
        if not ok then
            log("independent blueprint selection start isolated error="
                .. tostring(result_or_error))
            if BlueprintSelectionMode.active then
                local cleanup_ok, cleanup_error = pcall(
                    BlueprintSelectionMode.finish, "start-error", false
                )
                if not cleanup_ok then
                    log("independent blueprint selection start cleanup failed error="
                        .. tostring(cleanup_error))
                end
            end
            return false
        end
        return result_or_error == true
    end

    function BlueprintSelectionMode.dispatch_target_action(label, action)
        -- Input hooks can be followed by another trace callback before the
        -- scheduled game-thread action runs. Snapshot the directly indexed
        -- target now, not after that scheduling boundary.
        local action_session_id = BlueprintSelectionMode.session_id
        local action_target = BlueprintSelectionMode.current_target
        local action_target_identity =
            BlueprintSelectionMode.current_target_identity
        local queued_at = performance_now()
        BlueprintCallbackScheduler.game_thread_now(
            "independent-selection-action:" .. tostring(label), function()
            if not BlueprintSelectionMode.active
                or BlueprintSelectionMode.session_id
                    ~= action_session_id then
                return
            end
            if BlueprintSelectionMode.camera_hold_active then return end
            local queue_wait_ms = performance_elapsed_ms(queued_at)
            local dispatch_started_at = performance_now()
            BlueprintSelectionMode.action_target_override =
                action_target
            BlueprintSelectionMode.action_target_identity_override =
                action_target_identity
            BlueprintSelectionMode.preserve_hover_visual_during_action = true
            local action_started_at = performance_now()
            local action_ok, action_result = pcall(action)
            local action_ms = performance_elapsed_ms(action_started_at)
            BlueprintSelectionMode.preserve_hover_visual_during_action = false
            BlueprintSelectionMode.action_target_override = nil
            BlueprintSelectionMode.action_target_identity_override = nil
            if not action_ok then
                log("independent blueprint selection action isolated error action="
                    .. tostring(label) .. " error=" .. tostring(action_result))
            end
            local validation_started_at = performance_now()
            local validation_ok, validation_error = pcall(function()
                validate_selection_state(
                    "independent-" .. tostring(label)
                )
            end)
            local validation_ms =
                performance_elapsed_ms(validation_started_at)
            if not validation_ok then
                log("independent blueprint selection state validation error action="
                    .. tostring(label) .. " error="
                    .. tostring(validation_error))
            end
            local action_performance = type(action_result) == "table"
                and action_result or {}
            local hud_ms = 0.0
            if is_probe_logging_enabled() then
                append_selection_probe(BlueprintSelectionMode, string.format(
                    "blueprint performance selection-action action=%s kind=%s queueWaitMs=%.3f actionMs=%.3f targetMs=%.3f recordMs=%.3f visualMs=%.3f businessTotalMs=%.3f validationMs=%.3f hudMs=%.3f dispatchTotalMs=%.3f hoverPreserved=true",
                    tostring(label),
                    tostring(action_performance.kind or "unknown"),
                    queue_wait_ms,
                    action_ms,
                    tonumber(action_performance.target_ms) or 0.0,
                    tonumber(action_performance.record_ms) or 0.0,
                    tonumber(action_performance.visual_ms) or 0.0,
                    tonumber(action_performance.total_ms) or action_ms,
                    validation_ms,
                    hud_ms,
                    performance_elapsed_ms(dispatch_started_at)
                ))
            end
            end
        )
    end

    function BlueprintSelectionMode.save()
        BlueprintCallbackScheduler.game_thread_now(
            "independent-selection-save", function()
            if not BlueprintSelectionMode.active then return end
            if BlueprintSelectionMode.camera_hold_active then return end
            if is_name_dialog_open() then return end
            local synchronized, synchronize_error =
                sync_selection_state(
                    BlueprintSelectionMode.selection_session
                )
            if synchronized ~= true then
                log("independent blueprint selection save snapshot failed error="
                    .. tostring(synchronize_error))
                return
            end
            local preflight_ok, can_save, preflight_error = pcall(
                can_save_selection
            )
            if not preflight_ok then
                log("independent blueprint selection save preflight failed error="
                    .. tostring(can_save))
                return
            end
            if can_save ~= true then
                if preflight_error ~= nil then
                    log("independent blueprint selection save rejected error="
                        .. tostring(preflight_error))
                end
                return
            end
            local target = BlueprintSelectionMode.current_target
            BlueprintSelectionMode.restore_hover()
            BlueprintSelectionMode.current_target_address = nil
            local opened, open_error = open_name_dialog(function(name)
                local previous_clipboard = get_blueprint_clipboard()
                local save_ok, saved, save_error = pcall(
                    commit_selection_to_clipboard, name
                )
                if not save_ok then
                    save_error = saved
                    saved = false
                    log("independent blueprint selection save isolated error="
                        .. tostring(save_error))
                end
                if saved == true
                    and get_blueprint_clipboard() ~= previous_clipboard
                    and not has_pending_selection_state() then
                    BlueprintCallbackScheduler.game_thread(
                        1, "selection-save-finish", function()
                        if BlueprintSelectionMode.active
                            and not has_pending_selection_state() then
                            BlueprintSelectionMode.finish(
                                "save-complete", true
                            )
                        end
                        end
                    )
                    return true, nil
                end
                return false, save_error or "blueprint save was rejected"
            end)
            if not opened then
                log("independent blueprint selection name dialog failed error="
                    .. tostring(open_error))
                BlueprintSelectionMode.current_target_address = nil
                BlueprintSelectionMode.update_target(
                    target, "after-name-dialog-failed"
                )
            end
            end
        )
    end

    return BlueprintSelectionMode
end

return BlueprintSelectionModeRuntime

-- Minimal runtime settings for BlueprintResearch.
--
-- The JSON file supplies the startup value.  A future in-game settings UI can
-- call the setter directly; collision validation only reads the in-memory flag.

local Json = require("BlueprintCodeCodec")

local Settings = {
    key = "validate_all_invalid_ghosts",
    blueprint_library_directory_key = "blueprint_library_directory",
    blueprint_collision_query_component_limit_key =
        "blueprint_collision_query_component_limit",
    world_coordinate_snap_range_cm_key =
        "world_coordinate_snap_range_cm",
    blueprint_overlap_gate_enabled_key =
        "blueprint_overlap_gate_enabled",
    blueprint_support_connection_gate_enabled_key =
        "blueprint_support_connection_gate_enabled",
    blueprint_material_gate_enabled_key =
        "blueprint_material_gate_enabled",
    blueprint_force_submit_invalid_enabled_key =
        "blueprint_force_submit_invalid_enabled",
    log_diagnostics_key = "log_diagnostics",
    log_probes_key = "log_probes",
    log_trace_key = "log_trace",
    default_validate_all_invalid_ghosts = false,
    validate_all_invalid_ghosts = false,
    default_blueprint_library_directory =
        "%LOCALAPPDATA%\\SimpleBuildingBlueprints",
    blueprint_library_directory =
        "%LOCALAPPDATA%\\SimpleBuildingBlueprints",
    default_blueprint_collision_query_component_limit = 1024,
    blueprint_collision_query_component_limit = 1024,
    default_world_coordinate_snap_range_cm = 4000,
    world_coordinate_snap_range_cm = 4000,
    default_blueprint_overlap_gate_enabled = true,
    blueprint_overlap_gate_enabled = true,
    default_blueprint_support_connection_gate_enabled = true,
    blueprint_support_connection_gate_enabled = true,
    default_blueprint_material_gate_enabled = true,
    blueprint_material_gate_enabled = true,
    default_blueprint_force_submit_invalid_enabled = false,
    blueprint_force_submit_invalid_enabled = false,
    default_log_diagnostics = false,
    log_diagnostics = false,
    default_log_probes = false,
    log_probes = false,
    default_log_trace = false,
    log_trace = false,
    config_path = nil,
}

local function add_unique_path(paths, seen, path)
    if type(path) ~= "string" or path == "" or seen[path] then return end
    seen[path] = true
    table.insert(paths, path)
end

local function get_config_path_candidates()
    local paths = {}
    local seen = {}
    local source = nil
    if debug ~= nil and type(debug.getinfo) == "function" then
        local info = debug.getinfo(1, "S")
        source = info and info.source or nil
    end
    if type(source) == "string" then
        source = source:gsub("^@", "")
        local script_directory = source:match("^(.*)[/\\][^/\\]+$")
        if script_directory ~= nil then
            local mod_directory = script_directory:gsub("[/\\]Scripts$", "")
            add_unique_path(
                paths, seen,
                mod_directory .. "\\BlueprintResearch.modconfig.json"
            )
        end
    end
    add_unique_path(
        paths, seen,
        ".\\Mods\\BlueprintResearch\\BlueprintResearch.modconfig.json"
    )
    return paths
end

local function read_file(path)
    local handle, open_error = io.open(path, "rb")
    if handle == nil then return nil, open_error end
    local content = handle:read("*a")
    handle:close()
    if type(content) ~= "string" then
        return nil, "config file did not contain text"
    end
    return content, nil
end

local function decode_config(content)
    content = content:gsub("^\239\187\191", "")
    local config, decode_error = Json.decode_json(content)
    if type(config) ~= "table" then
        return nil, "config JSON is invalid: " .. tostring(decode_error)
    end
    return config, nil
end

local function parse_live_boolean(config)
    local setting_object = config[Settings.key]
    if type(setting_object) ~= "table" then
        return nil, "setting object not found: " .. Settings.key
    end
    if type(setting_object.live) ~= "boolean" then
        return nil, "setting live value must be true or false"
    end
    return setting_object.live, nil
end

local function parse_optional_live_boolean(
    config, key, default_value
)
    local setting_object = config[key]
    if setting_object == nil then return default_value, nil end
    if type(setting_object) ~= "table"
        or type(setting_object.live) ~= "boolean" then
        return nil, "setting live value must be true or false: " .. key
    end
    return setting_object.live, nil
end

local function parse_blueprint_library_directory(config)
    local setting_object =
        config[Settings.blueprint_library_directory_key]
    if setting_object == nil then
        return Settings.default_blueprint_library_directory, nil
    end
    if type(setting_object) ~= "table"
        or type(setting_object.live) ~= "string" then
        return nil, "blueprint library directory live value "
            .. "must be a string"
    end
    local value = setting_object.live
        :gsub("^%s+", ""):gsub("%s+$", "")
    if value == "" then
        return nil, "blueprint library directory is empty"
    end
    if #value > 1024 then
        return nil, "blueprint library directory is too long"
    end
    return value, nil
end

local function parse_blueprint_collision_query_component_limit(config)
    local setting_object =
        config[Settings.blueprint_collision_query_component_limit_key]
    if setting_object == nil then
        return Settings.default_blueprint_collision_query_component_limit, nil
    end
    if type(setting_object) ~= "table"
        or type(setting_object.live) ~= "number" then
        return nil, "blueprint collision-query component limit live value "
            .. "must be an integer"
    end
    local value = setting_object.live
    if value ~= math.floor(value) then
        return nil, "blueprint collision-query component limit "
            .. "must be an integer"
    end
    return value, nil
end

local function parse_world_coordinate_snap_range_cm(config)
    local setting_object =
        config[Settings.world_coordinate_snap_range_cm_key]
    if setting_object == nil then
        return Settings.default_world_coordinate_snap_range_cm, nil
    end
    if type(setting_object) ~= "table"
        or type(setting_object.live) ~= "number" then
        return nil, "world-coordinate snap range live value "
            .. "must be a non-negative integer"
    end
    local value = setting_object.live
    if value ~= math.floor(value) or value < 0 then
        return nil, "world-coordinate snap range must be a "
            .. "non-negative integer"
    end
    return value, nil
end

function Settings.set_validate_all_invalid_ghosts(value)
    if type(value) ~= "boolean" then
        return false, "validate_all_invalid_ghosts must be boolean"
    end
    local changed = value ~= Settings.validate_all_invalid_ghosts
    Settings.validate_all_invalid_ghosts = value
    return changed, nil
end

function Settings.set_blueprint_library_directory(value)
    if type(value) ~= "string" or value == "" then
        return false, "blueprint library directory must be a string"
    end
    local changed = value ~= Settings.blueprint_library_directory
    Settings.blueprint_library_directory = value
    return changed, nil
end

function Settings.set_blueprint_collision_query_component_limit(value)
    if type(value) ~= "number"
        or value ~= math.floor(value) then
        return false, "blueprint collision-query component limit "
            .. "must be an integer"
    end
    local changed =
        value ~= Settings.blueprint_collision_query_component_limit
    Settings.blueprint_collision_query_component_limit = value
    return changed, nil
end

function Settings.set_world_coordinate_snap_range_cm(value)
    if type(value) ~= "number" or value ~= math.floor(value)
        or value < 0 then
        return false, "world-coordinate snap range must be a "
            .. "non-negative integer"
    end
    local changed = value ~= Settings.world_coordinate_snap_range_cm
    Settings.world_coordinate_snap_range_cm = value
    return changed, nil
end

local function set_boolean_setting(field_name, value)
    if type(value) ~= "boolean" then
        return false, field_name .. " must be boolean"
    end
    local changed = value ~= Settings[field_name]
    Settings[field_name] = value
    return changed, nil
end

function Settings.set_blueprint_overlap_gate_enabled(value)
    return set_boolean_setting("blueprint_overlap_gate_enabled", value)
end

function Settings.set_blueprint_support_connection_gate_enabled(value)
    return set_boolean_setting(
        "blueprint_support_connection_gate_enabled", value
    )
end

function Settings.set_blueprint_material_gate_enabled(value)
    return set_boolean_setting("blueprint_material_gate_enabled", value)
end

function Settings.set_blueprint_force_submit_invalid_enabled(value)
    return set_boolean_setting(
        "blueprint_force_submit_invalid_enabled", value
    )
end

function Settings.set_log_diagnostics(value)
    return set_boolean_setting("log_diagnostics", value)
end

function Settings.set_log_probes(value)
    return set_boolean_setting("log_probes", value)
end

function Settings.set_log_trace(value)
    return set_boolean_setting("log_trace", value)
end

function Settings.parse_config_content(content)
    local config, config_error = decode_config(content)
    if config == nil then return nil, config_error end
    local value, value_error = parse_live_boolean(config)
    if value == nil then return nil, value_error end
    local directory, directory_error =
        parse_blueprint_library_directory(config)
    if directory == nil then return nil, directory_error end
    local collision_query_component_limit, limit_error =
        parse_blueprint_collision_query_component_limit(config)
    if collision_query_component_limit == nil then
        return nil, limit_error
    end
    local world_coordinate_snap_range_cm, snap_range_error =
        parse_world_coordinate_snap_range_cm(config)
    if world_coordinate_snap_range_cm == nil then
        return nil, snap_range_error
    end
    local log_diagnostics, log_diagnostics_error =
        parse_optional_live_boolean(
            config, Settings.log_diagnostics_key,
            Settings.default_log_diagnostics
        )
    if log_diagnostics == nil then
        return nil, log_diagnostics_error
    end
    local log_probes, log_probes_error =
        parse_optional_live_boolean(
            config, Settings.log_probes_key,
            Settings.default_log_probes
        )
    if log_probes == nil then return nil, log_probes_error end
    local log_trace, log_trace_error =
        parse_optional_live_boolean(
            config, Settings.log_trace_key,
            Settings.default_log_trace
        )
    if log_trace == nil then return nil, log_trace_error end
    local overlap_gate_enabled, overlap_gate_error =
        parse_optional_live_boolean(
            config, Settings.blueprint_overlap_gate_enabled_key,
            Settings.default_blueprint_overlap_gate_enabled
        )
    if overlap_gate_enabled == nil then
        return nil, overlap_gate_error
    end
    local support_connection_gate_enabled, support_connection_gate_error =
        parse_optional_live_boolean(
            config,
            Settings.blueprint_support_connection_gate_enabled_key,
            Settings.default_blueprint_support_connection_gate_enabled
        )
    if support_connection_gate_enabled == nil then
        return nil, support_connection_gate_error
    end
    local material_gate_enabled, material_gate_error =
        parse_optional_live_boolean(
            config, Settings.blueprint_material_gate_enabled_key,
            Settings.default_blueprint_material_gate_enabled
        )
    if material_gate_enabled == nil then
        return nil, material_gate_error
    end
    local force_submit_invalid_enabled, force_submit_invalid_error =
        parse_optional_live_boolean(
            config,
            Settings.blueprint_force_submit_invalid_enabled_key,
            Settings.default_blueprint_force_submit_invalid_enabled
        )
    if force_submit_invalid_enabled == nil then
        return nil, force_submit_invalid_error
    end
    return {
        validate_all_invalid_ghosts = value,
        blueprint_library_directory = directory,
        blueprint_collision_query_component_limit =
            collision_query_component_limit,
        world_coordinate_snap_range_cm =
            world_coordinate_snap_range_cm,
        blueprint_overlap_gate_enabled = overlap_gate_enabled,
        blueprint_support_connection_gate_enabled =
            support_connection_gate_enabled,
        blueprint_material_gate_enabled = material_gate_enabled,
        blueprint_force_submit_invalid_enabled =
            force_submit_invalid_enabled,
        log_diagnostics = log_diagnostics,
        log_probes = log_probes,
        log_trace = log_trace,
    }, nil
end

function Settings.reload()
    local last_open_error = nil
    for _, path in ipairs(get_config_path_candidates()) do
        local content, open_error = read_file(path)
        if content ~= nil then
            local values, values_error =
                Settings.parse_config_content(content)
            if values == nil then
                return false, Settings.validate_all_invalid_ghosts,
                    path, values_error
            end
            local changed =
                Settings.set_validate_all_invalid_ghosts(
                    values.validate_all_invalid_ghosts
                )
            local directory_changed =
                Settings.set_blueprint_library_directory(
                    values.blueprint_library_directory
                )
            local collision_query_limit_changed =
                Settings.set_blueprint_collision_query_component_limit(
                    values.blueprint_collision_query_component_limit
                )
            local world_coordinate_snap_range_changed =
                Settings.set_world_coordinate_snap_range_cm(
                    values.world_coordinate_snap_range_cm
                )
            local overlap_gate_changed =
                Settings.set_blueprint_overlap_gate_enabled(
                    values.blueprint_overlap_gate_enabled
                )
            local support_connection_gate_changed =
                Settings.set_blueprint_support_connection_gate_enabled(
                    values.blueprint_support_connection_gate_enabled
                )
            local material_gate_changed =
                Settings.set_blueprint_material_gate_enabled(
                    values.blueprint_material_gate_enabled
                )
            local force_submit_invalid_changed =
                Settings.set_blueprint_force_submit_invalid_enabled(
                    values.blueprint_force_submit_invalid_enabled
                )
            local log_diagnostics_changed =
                Settings.set_log_diagnostics(values.log_diagnostics)
            local log_probes_changed =
                Settings.set_log_probes(values.log_probes)
            local log_trace_changed =
                Settings.set_log_trace(values.log_trace)
            Settings.config_path = path
            return changed or directory_changed
                    or collision_query_limit_changed
                    or world_coordinate_snap_range_changed
                    or overlap_gate_changed
                    or support_connection_gate_changed
                    or material_gate_changed
                    or force_submit_invalid_changed
                    or log_diagnostics_changed
                    or log_probes_changed
                    or log_trace_changed,
                values.validate_all_invalid_ghosts, path, nil
        end
        last_open_error = open_error
    end
    return false, Settings.validate_all_invalid_ghosts, nil,
        "BlueprintResearch.modconfig.json not found: "
            .. tostring(last_open_error)
end

function Settings.get_validate_all_invalid_ghosts()
    return Settings.validate_all_invalid_ghosts == true
end

function Settings.get_validation_mode_name()
    if Settings.get_validate_all_invalid_ghosts() then
        return "full-visual"
    end
    return "fast-gate"
end

function Settings.get_blueprint_library_directory()
    return Settings.blueprint_library_directory
end

function Settings.get_blueprint_collision_query_component_limit()
    return Settings.blueprint_collision_query_component_limit
end

function Settings.get_world_coordinate_snap_range_cm()
    return Settings.world_coordinate_snap_range_cm
end

function Settings.get_blueprint_overlap_gate_enabled()
    return Settings.blueprint_overlap_gate_enabled == true
end

function Settings.get_blueprint_support_connection_gate_enabled()
    return Settings.blueprint_support_connection_gate_enabled == true
end

function Settings.get_blueprint_material_gate_enabled()
    return Settings.blueprint_material_gate_enabled == true
end

function Settings.get_blueprint_force_submit_invalid_enabled()
    return Settings.blueprint_force_submit_invalid_enabled == true
end

function Settings.get_log_diagnostics()
    return Settings.log_diagnostics == true
end

function Settings.get_log_probes()
    return Settings.log_probes == true
end

function Settings.get_log_trace()
    return Settings.log_trace == true
end

function Settings.get_config_path()
    return Settings.config_path
end

-- Startup-only file read.  There is deliberately no timer, file watcher or
-- validation-time JSON access.
Settings.reload()

return Settings

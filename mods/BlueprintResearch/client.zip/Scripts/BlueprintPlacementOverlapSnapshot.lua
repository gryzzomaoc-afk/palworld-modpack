local BlueprintPlacementOverlapSnapshot = {}

function BlueprintPlacementOverlapSnapshot.install(deps)
    assert(type(deps) == "table",
        "BlueprintPlacementOverlapSnapshot dependencies are required")
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object dependency is required"
    )
    local safe_property = assert(
        deps.safe_property, "safe_property dependency is required"
    )
    local value_to_string = assert(
        deps.value_to_string, "value_to_string dependency is required"
    )
    local copy_transform = assert(
        deps.copy_transform, "copy_transform dependency is required"
    )
    local copy_vector = assert(
        deps.copy_vector, "copy_vector dependency is required"
    )
    local component_store = assert(
        deps.component_store, "component_store dependency is required"
    )

    local snapshot = {}

    local function array_count(values)
        if values == nil then return 0 end
        local count = 0
        local ok = pcall(function() count = #values end)
        return ok and count or 0
    end

    local function array_item(values, index)
        if values == nil then return nil end
        local value = nil
        pcall(function() value = unwrap(values[index]) end)
        return value
    end

    local function require_parallel_count(
        arrays, expected_count, label
    )
        for name, values in pairs(arrays) do
            local count = array_count(values)
            if count ~= expected_count then
                return false, string.format(
                    "%s array length mismatch field=%s expected=%d actual=%d",
                    tostring(label), tostring(name),
                    expected_count, count
                )
            end
        end
        return true, nil
    end

    local function decode(session)
        if safe_property(session, "SBB_OverlapSnapshotReady") ~= true then
            return nil, "placement overlap snapshot did not complete"
        end

        local object_arrays = {
            names = component_store.get_array(
                session, "overlap_world_names"
            ),
            build_ids = component_store.get_array(
                session, "overlap_world_build_ids"
            ),
            transforms = component_store.get_array(
                session, "overlap_world_transforms"
            ),
            is_build = component_store.get_array(
                session, "overlap_world_is_build"
            ),
            is_pal = component_store.get_array(
                session, "overlap_world_is_pal"
            ),
        }
        local object_count = array_count(object_arrays.names)
        local object_lengths_ok, object_length_error =
            require_parallel_count(
                object_arrays, object_count, "world object"
            )
        if not object_lengths_ok then
            return nil, object_length_error
        end

        local objects = {}
        for index = 1, object_count do
            local transform = copy_transform(array_item(
                object_arrays.transforms, index
            ))
            if transform == nil
                or transform.translation == nil
                or transform.rotation == nil then
                return nil,
                    "world object transform unavailable index="
                        .. tostring(index - 1)
            end
            objects[index] = {
                object_index = index - 1,
                object_name = value_to_string(array_item(
                    object_arrays.names, index
                )),
                build_object_id = value_to_string(array_item(
                    object_arrays.build_ids, index
                )),
                is_build_object =
                    array_item(object_arrays.is_build, index) == true,
                is_pal = array_item(
                    object_arrays.is_pal, index
                ) == true,
                model_location = transform.translation,
                model_rotation = transform.rotation,
                model_scale = transform.scale,
            }
        end

        local pair_arrays = {
            members = component_store.get_array(
                session, "overlap_pair_members"
            ),
            object_indices = component_store.get_array(
                session, "overlap_pair_world_indices"
            ),
            profiles = component_store.get_array(
                session, "overlap_pair_profiles"
            ),
            component_names = component_store.get_array(
                session, "overlap_pair_component_names"
            ),
            object_types = component_store.get_array(
                session, "overlap_pair_object_types"
            ),
            locations = component_store.get_array(
                session, "overlap_pair_locations"
            ),
        }
        local pair_count = array_count(pair_arrays.members)
        local pair_lengths_ok, pair_length_error =
            require_parallel_count(
                pair_arrays, pair_count, "component pair"
            )
        if not pair_lengths_ok then
            return nil, pair_length_error
        end

        local pairs = {}
        local pairs_by_member = {}
        for index = 1, pair_count do
            local member_index =
                tonumber(array_item(pair_arrays.members, index))
            local object_index = tonumber(array_item(
                pair_arrays.object_indices, index
            ))
            local world_object = object_index ~= nil
                and objects[object_index + 1] or nil
            if member_index == nil or world_object == nil then
                return nil,
                    "component pair references invalid index pair="
                        .. tostring(index - 1)
                        .. " member=" .. tostring(member_index)
                        .. " object=" .. tostring(object_index)
            end
            local pair = {
                pair_index = index - 1,
                member_index = member_index,
                object_index = object_index,
                world_object = world_object,
                profile = value_to_string(array_item(
                    pair_arrays.profiles, index
                )),
                component_name = value_to_string(array_item(
                    pair_arrays.component_names, index
                )),
                object_type = tonumber(array_item(
                    pair_arrays.object_types, index
                )),
                location = copy_vector(array_item(
                    pair_arrays.locations, index
                )),
            }
            pairs[index] = pair
            local member_pairs = pairs_by_member[member_index + 1]
            if member_pairs == nil then
                member_pairs = {}
                pairs_by_member[member_index + 1] = member_pairs
            end
            member_pairs[#member_pairs + 1] = pair
        end

        return {
            objects = objects,
            pairs = pairs,
            pairs_by_member = pairs_by_member,
            object_count = object_count,
            pair_count = pair_count,
        }, nil
    end

    function snapshot.run(
        session, building_states, collision_transforms, ignored_actors
    )
        session = unwrap(session)
        if not is_valid_object(session) then
            return nil, "placement Session unavailable"
        end
        building_states = building_states or {}
        collision_transforms = collision_transforms or {}
        if #building_states ~= #collision_transforms then
            return nil, "placement overlap input length mismatch"
        end

        for index = 1, #building_states do
            local query_component = component_store.get_array_item(
                session, "overlap_query_components", index
            )
            local transform = collision_transforms[index]
            if not is_valid_object(query_component)
                or transform == nil then
                return nil,
                    "placement overlap query input unavailable index="
                        .. tostring(index)
            end
            local moved, move_error = pcall(function()
                query_component:K2_SetWorldTransform(
                    transform, false, {}, true
                )
            end)
            if not moved then
                return nil,
                    "placement overlap query transform failed index="
                        .. tostring(index) .. " error="
                        .. tostring(move_error)
            end
        end

        local emptied, empty_error = component_store.empty_array(
            session, "overlap_ignored_actors"
        )
        if not emptied then return nil, empty_error end
        local ignored_index = 0
        for _, actor_value in ipairs(ignored_actors or {}) do
            local actor = unwrap(actor_value)
            if is_valid_object(actor) then
                ignored_index = ignored_index + 1
                local stored, store_error =
                    component_store.set_array_item(
                        session,
                        "overlap_ignored_actors",
                        ignored_index,
                        actor
                    )
                if not stored then
                    return nil,
                        "placement overlap ignored actor write failed index="
                            .. tostring(ignored_index)
                            .. " error=" .. tostring(store_error)
                end
            end
        end

        local called, call_error = pcall(function()
            session:SBB_RunOverlapSnapshot()
        end)
        if not called then
            return nil,
                "placement overlap Session call failed: "
                    .. tostring(call_error)
        end
        return decode(session)
    end

    function snapshot.select_pair_for_visual(session, pair_index)
        session = unwrap(session)
        pair_index = tonumber(pair_index)
        if not is_valid_object(session) or pair_index == nil then
            return nil, nil, "invalid overlap visual selection"
        end
        local selected, select_error = pcall(function()
            session:SBB_SelectOverlapPairForVisual(pair_index)
        end)
        if not selected then
            return nil, nil, tostring(select_error)
        end
        local actor = unwrap(component_store.get_reference(
            session, "blocker_actor"
        ))
        local component = unwrap(component_store.get_reference(
            session, "overlap_selected_component"
        ))
        if not is_valid_object(actor)
            or not is_valid_object(component) then
            return nil, nil,
                "overlap visual Session references unavailable"
        end
        return actor, component, nil
    end

    return snapshot
end

return BlueprintPlacementOverlapSnapshot

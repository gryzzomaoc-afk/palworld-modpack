-- Self-contained, deterministic blueprint-code codec.
--
-- Codec 3 stores canonical JSON.  Codec 4 stores a schema-driven compact binary
-- DTO with implied field names, a string pool, and a connection pool.  Both use
-- the same pure-Lua LZSS layer so clipboard import/export does not depend on a
-- version-locked native DLL.  Runtime UObject fields are never serialized.

local CompactBinary = require("BlueprintCompactBinary")

local Codec = {}

Codec.TEXT_PREFIX = "PWB1:"
Codec.FRAME_VERSION = 1
Codec.CODEC_NONE = 0
Codec.CODEC_LZSS = 3
Codec.CODEC_COMPACT_LZSS = 4
Codec.MAX_CODE_CHARS = 16 * 1024 * 1024
Codec.MAX_JSON_BYTES = 8 * 1024 * 1024
Codec.MAX_BUILDINGS = 4096

local ARRAY_FIELDS = {
    entries = true,
    buildings = true,
    saved_connections = true,
    connections = true,
    external_connections = true,
    connector_connections = true,
    preview_meshes = true,
    allowed_collision_profiles = true,
}

local RUNTIME_ONLY_FIELDS = {
    runtime_overlap_component = true,
}

local BASE64_ALPHABET =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
local BASE64_DECODE = {}
for index = 1, #BASE64_ALPHABET do
    BASE64_DECODE[string.byte(BASE64_ALPHABET, index)] = index - 1
end

local function pack_u16_le(value)
    return string.char(value % 256, math.floor(value / 256) % 256)
end

local function pack_u32_le(value)
    return string.char(
        value % 256,
        math.floor(value / 256) % 256,
        math.floor(value / 65536) % 256,
        math.floor(value / 16777216) % 256
    )
end

local function unpack_u16_le(data, offset)
    local first, second = string.byte(data, offset, offset + 1)
    if second == nil then return nil, offset, "truncated u16" end
    return first + second * 256, offset + 2, nil
end

local function unpack_u32_le(data, offset)
    local a, b, c, d = string.byte(data, offset, offset + 3)
    if d == nil then return nil, offset, "truncated u32" end
    return a + b * 256 + c * 65536 + d * 16777216,
        offset + 4, nil
end

local function crc32(data)
    local crc = 0xFFFFFFFF
    for index = 1, #data do
        crc = crc ~ string.byte(data, index)
        for _ = 1, 8 do
            if (crc & 1) ~= 0 then
                crc = (crc >> 1) ~ 0xEDB88320
            else
                crc = crc >> 1
            end
        end
    end
    return (~crc) & 0xFFFFFFFF
end

local function base64url_encode(data)
    local output = {}
    local index = 1
    while index <= #data do
        local a = string.byte(data, index) or 0
        local b = string.byte(data, index + 1)
        local c = string.byte(data, index + 2)
        local combined = a * 65536 + (b or 0) * 256 + (c or 0)
        output[#output + 1] = string.sub(
            BASE64_ALPHABET, math.floor(combined / 262144) % 64 + 1,
            math.floor(combined / 262144) % 64 + 1
        )
        output[#output + 1] = string.sub(
            BASE64_ALPHABET, math.floor(combined / 4096) % 64 + 1,
            math.floor(combined / 4096) % 64 + 1
        )
        if b ~= nil then
            output[#output + 1] = string.sub(
                BASE64_ALPHABET, math.floor(combined / 64) % 64 + 1,
                math.floor(combined / 64) % 64 + 1
            )
        end
        if c ~= nil then
            output[#output + 1] = string.sub(
                BASE64_ALPHABET, combined % 64 + 1, combined % 64 + 1
            )
        end
        index = index + 3
    end
    return table.concat(output)
end

local function base64url_decode(text)
    if #text % 4 == 1 then return nil, "invalid Base64URL length" end
    local output = {}
    local index = 1
    while index <= #text do
        local remaining = #text - index + 1
        local a = BASE64_DECODE[string.byte(text, index)]
        local b = BASE64_DECODE[string.byte(text, index + 1)]
        local c = remaining >= 3
            and BASE64_DECODE[string.byte(text, index + 2)] or nil
        local d = remaining >= 4
            and BASE64_DECODE[string.byte(text, index + 3)] or nil
        if a == nil or b == nil or (remaining >= 3 and c == nil)
            or (remaining >= 4 and d == nil) then
            return nil, "invalid Base64URL character"
        end
        local combined = a * 262144 + b * 4096 + (c or 0) * 64 + (d or 0)
        output[#output + 1] = string.char(math.floor(combined / 65536) % 256)
        if remaining >= 3 then
            output[#output + 1] = string.char(math.floor(combined / 256) % 256)
        end
        if remaining >= 4 then
            output[#output + 1] = string.char(combined % 256)
        end
        index = index + 4
    end
    return table.concat(output), nil
end

local function json_escape(value)
    local replacements = {
        [string.char(8)] = "\\b",
        [string.char(9)] = "\\t",
        [string.char(10)] = "\\n",
        [string.char(12)] = "\\f",
        [string.char(13)] = "\\r",
        ['"'] = '\\"',
        ['\\'] = '\\\\',
    }
    return '"' .. value:gsub('[%z\1-\31\\"]', function(character)
        return replacements[character]
            or string.format("\\u%04x", string.byte(character))
    end) .. '"'
end

local function table_kind(value, field_name)
    local numeric_count = 0
    local string_count = 0
    local maximum_index = 0
    for key in pairs(value) do
        if type(key) == "number" and key >= 1 and key % 1 == 0 then
            numeric_count = numeric_count + 1
            if key > maximum_index then maximum_index = key end
        elseif type(key) == "string" then
            string_count = string_count + 1
        else
            return nil, "JSON table has an unsupported key type"
        end
    end
    if numeric_count > 0 and string_count > 0 then
        return nil, "JSON table mixes array and object keys"
    end
    if numeric_count > 0 then
        if maximum_index ~= numeric_count then
            return nil, "JSON array has holes"
        end
        return "array", nil
    end
    if string_count > 0 then return "object", nil end
    return ARRAY_FIELDS[field_name] and "array" or "object", nil
end

local function encode_json_value(
    value, field_name, active_tables, number_formatter
)
    local value_type = type(value)
    if value_type == "nil" then return "null" end
    if value_type == "boolean" then return value and "true" or "false" end
    if value_type == "number" then
        if value ~= value or value == math.huge or value == -math.huge then
            error("JSON cannot encode a non-finite number")
        end
        if number_formatter ~= nil then return number_formatter(value) end
        return string.format("%.17g", value)
    end
    if value_type == "string" then
        if utf8 ~= nil and utf8.len(value) == nil then
            error("JSON string is not valid UTF-8")
        end
        return json_escape(value)
    end
    if value_type ~= "table" then
        error("JSON cannot encode value type=" .. value_type)
    end
    if active_tables[value] then error("JSON table contains a cycle") end
    active_tables[value] = true
    local kind, kind_error = table_kind(value, field_name)
    if kind == nil then error(kind_error) end
    local output = {}
    if kind == "array" then
        for index = 1, #value do
            output[#output + 1] = encode_json_value(
                value[index], field_name, active_tables, number_formatter
            )
        end
        active_tables[value] = nil
        return "[" .. table.concat(output, ",") .. "]"
    end

    local keys = {}
    for key in pairs(value) do
        if not RUNTIME_ONLY_FIELDS[key] then keys[#keys + 1] = key end
    end
    table.sort(keys)
    for _, key in ipairs(keys) do
        output[#output + 1] = json_escape(key) .. ":"
            .. encode_json_value(
                value[key], key, active_tables, number_formatter
            )
    end
    active_tables[value] = nil
    return "{" .. table.concat(output, ",") .. "}"
end

local function canonical_json_encode(value, number_formatter)
    return encode_json_value(value, nil, {}, number_formatter)
end

local function utf8_character(codepoint)
    if codepoint < 0 or codepoint > 0x10FFFF
        or (codepoint >= 0xD800 and codepoint <= 0xDFFF) then
        error("invalid Unicode codepoint")
    end
    return utf8.char(codepoint)
end

local function json_decode(text)
    if type(text) ~= "string" then error("JSON input must be a string") end
    if utf8 ~= nil and utf8.len(text) == nil then error("JSON is not valid UTF-8") end
    local position = 1
    local length = #text
    local maximum_depth = 128

    local function skip_space()
        while position <= length do
            local byte = string.byte(text, position)
            if byte ~= 0x20 and byte ~= 0x09 and byte ~= 0x0A and byte ~= 0x0D then
                break
            end
            position = position + 1
        end
    end

    local function parse_string()
        if string.byte(text, position) ~= 34 then error("expected JSON string") end
        position = position + 1
        local output = {}
        local chunk_start = position
        while position <= length do
            local byte = string.byte(text, position)
            if byte == 34 then
                if position > chunk_start then
                    output[#output + 1] = string.sub(text, chunk_start, position - 1)
                end
                position = position + 1
                return table.concat(output)
            end
            if byte == 92 then
                if position > chunk_start then
                    output[#output + 1] = string.sub(text, chunk_start, position - 1)
                end
                position = position + 1
                local escape = string.sub(text, position, position)
                local simple = {
                    ['"'] = '"', ['\\'] = '\\', ['/'] = '/',
                    b = string.char(8), f = string.char(12),
                    n = "\n", r = "\r", t = "\t",
                }
                if simple[escape] ~= nil then
                    output[#output + 1] = simple[escape]
                    position = position + 1
                elseif escape == "u" then
                    local hex = string.sub(text, position + 1, position + 4)
                    if #hex ~= 4 or not hex:match("^[0-9A-Fa-f]+$") then
                        error("invalid JSON Unicode escape")
                    end
                    local codepoint = tonumber(hex, 16)
                    position = position + 5
                    if codepoint >= 0xD800 and codepoint <= 0xDBFF then
                        if string.sub(text, position, position + 1) ~= "\\u" then
                            error("missing low Unicode surrogate")
                        end
                        local low_hex = string.sub(text, position + 2, position + 5)
                        if #low_hex ~= 4 or not low_hex:match("^[0-9A-Fa-f]+$") then
                            error("invalid low Unicode surrogate")
                        end
                        local low = tonumber(low_hex, 16)
                        if low < 0xDC00 or low > 0xDFFF then
                            error("invalid low Unicode surrogate")
                        end
                        codepoint = 0x10000
                            + (codepoint - 0xD800) * 0x400 + (low - 0xDC00)
                        position = position + 6
                    elseif codepoint >= 0xDC00 and codepoint <= 0xDFFF then
                        error("unexpected low Unicode surrogate")
                    end
                    output[#output + 1] = utf8_character(codepoint)
                else
                    error("invalid JSON escape")
                end
                chunk_start = position
            elseif byte < 0x20 then
                error("unescaped control character in JSON string")
            else
                position = position + 1
            end
        end
        error("unterminated JSON string")
    end

    local parse_value

    local function parse_number()
        local start = position
        if string.sub(text, position, position) == "-" then position = position + 1 end
        local first = string.sub(text, position, position)
        if first == "0" then
            position = position + 1
            if string.sub(text, position, position):match("%d") then
                error("JSON number has a leading zero")
            end
        elseif first:match("[1-9]") then
            repeat
                position = position + 1
            until not string.sub(text, position, position):match("%d")
        else
            error("invalid JSON number")
        end
        if string.sub(text, position, position) == "." then
            position = position + 1
            if not string.sub(text, position, position):match("%d") then
                error("JSON fraction has no digits")
            end
            repeat
                position = position + 1
            until not string.sub(text, position, position):match("%d")
        end
        local exponent = string.sub(text, position, position)
        if exponent == "e" or exponent == "E" then
            position = position + 1
            local sign = string.sub(text, position, position)
            if sign == "+" or sign == "-" then position = position + 1 end
            if not string.sub(text, position, position):match("%d") then
                error("JSON exponent has no digits")
            end
            repeat
                position = position + 1
            until not string.sub(text, position, position):match("%d")
        end
        local number_text = string.sub(text, start, position - 1)
        -- Lua 5.4 parses the valid JSON token "-0" as integer zero and loses
        -- the IEEE-754 sign bit.  Unreal transforms frequently contain -0.0,
        -- and the canonical encoder deliberately emits that value as "-0".
        -- Recreate a floating negative zero so re-encoding remains byte-exact.
        local value = number_text == "-0" and -0.0 or tonumber(number_text)
        if value == nil or value ~= value or value == math.huge or value == -math.huge then
            error("JSON number is outside the supported range")
        end
        return value
    end

    local function parse_array(depth)
        position = position + 1
        skip_space()
        local result = {}
        if string.sub(text, position, position) == "]" then
            position = position + 1
            return result
        end
        while true do
            result[#result + 1] = parse_value(depth + 1)
            skip_space()
            local delimiter = string.sub(text, position, position)
            if delimiter == "]" then
                position = position + 1
                return result
            end
            if delimiter ~= "," then error("expected comma in JSON array") end
            position = position + 1
            skip_space()
        end
    end

    local function parse_object(depth)
        position = position + 1
        skip_space()
        local result = {}
        local seen = {}
        if string.sub(text, position, position) == "}" then
            position = position + 1
            return result
        end
        while true do
            local key = parse_string()
            if seen[key] then error("duplicate JSON object key=" .. key) end
            seen[key] = true
            skip_space()
            if string.sub(text, position, position) ~= ":" then
                error("expected colon in JSON object")
            end
            position = position + 1
            result[key] = parse_value(depth + 1)
            skip_space()
            local delimiter = string.sub(text, position, position)
            if delimiter == "}" then
                position = position + 1
                return result
            end
            if delimiter ~= "," then error("expected comma in JSON object") end
            position = position + 1
            skip_space()
        end
    end

    parse_value = function(depth)
        if depth > maximum_depth then error("JSON nesting is too deep") end
        skip_space()
        local byte = string.byte(text, position)
        if byte == 34 then return parse_string() end
        if byte == 123 then return parse_object(depth) end
        if byte == 91 then return parse_array(depth) end
        if byte == 45 or (byte ~= nil and byte >= 48 and byte <= 57) then
            return parse_number()
        end
        if string.sub(text, position, position + 3) == "true" then
            position = position + 4
            return true
        end
        if string.sub(text, position, position + 4) == "false" then
            position = position + 5
            return false
        end
        if string.sub(text, position, position + 3) == "null" then
            error("null is not supported in the current blueprint DTO")
        end
        error("invalid JSON value")
    end

    local result = parse_value(0)
    skip_space()
    if position <= length then error("trailing data after JSON value") end
    return result
end

local function lzss_compress(data)
    local output = {}
    local candidates = {}
    local position = 1
    local data_length = #data

    local function add_position(candidate_position)
        if candidate_position + 2 > data_length then return end
        local key = string.sub(data, candidate_position, candidate_position + 2)
        local list = candidates[key]
        if list == nil then
            list = {}
            candidates[key] = list
        end
        list[#list + 1] = candidate_position
    end

    local function find_match(match_position)
        if match_position + 3 > data_length then return 0, 0 end
        local key = string.sub(data, match_position, match_position + 2)
        local list = candidates[key]
        if list == nil then return 0, 0 end
        local best_offset = 0
        local best_length = 0
        local maximum_length = math.min(258, data_length - match_position + 1)
        local minimum_candidate = math.max(1, #list - 63)
        for list_index = #list, minimum_candidate, -1 do
            local candidate = list[list_index]
            local offset = match_position - candidate
            if offset > 0 and offset <= 65535 then
                local match_length = 0
                while match_length < maximum_length
                    and string.byte(data, candidate + match_length)
                        == string.byte(data, match_position + match_length) do
                    match_length = match_length + 1
                end
                if match_length > best_length then
                    best_offset = offset
                    best_length = match_length
                    if best_length == maximum_length then break end
                end
            end
        end
        if best_length < 4 then return 0, 0 end
        return best_offset, best_length
    end

    while position <= data_length do
        local flags = 0
        local tokens = {}
        for bit_index = 0, 7 do
            if position > data_length then break end
            local offset, match_length = find_match(position)
            if match_length >= 4 then
                flags = flags | (1 << bit_index)
                tokens[#tokens + 1] = pack_u16_le(offset)
                    .. string.char(match_length - 3)
                for consumed = 0, match_length - 1 do
                    add_position(position + consumed)
                end
                position = position + match_length
            else
                tokens[#tokens + 1] = string.sub(data, position, position)
                add_position(position)
                position = position + 1
            end
        end
        output[#output + 1] = string.char(flags)
        output[#output + 1] = table.concat(tokens)
    end
    return table.concat(output)
end

local function lzss_decompress(data, expected_size)
    local output = {}
    local input_position = 1
    while input_position <= #data do
        local flags = string.byte(data, input_position)
        input_position = input_position + 1
        for bit_index = 0, 7 do
            if input_position > #data then break end
            if (flags & (1 << bit_index)) ~= 0 then
                local offset
                offset, input_position = unpack_u16_le(data, input_position)
                local encoded_length = string.byte(data, input_position)
                if offset == nil or encoded_length == nil then
                    error("truncated LZSS match")
                end
                input_position = input_position + 1
                local match_length = encoded_length + 3
                if offset <= 0 or offset > #output then
                    error("invalid LZSS match offset")
                end
                for _ = 1, match_length do
                    local source_index = #output - offset + 1
                    output[#output + 1] = output[source_index]
                    if #output > expected_size then
                        error("LZSS output exceeds declared size")
                    end
                end
            else
                output[#output + 1] = string.sub(
                    data, input_position, input_position
                )
                input_position = input_position + 1
                if #output > expected_size then
                    error("LZSS output exceeds declared size")
                end
            end
        end
    end
    if #output ~= expected_size then
        error("LZSS output size mismatch")
    end
    return table.concat(output)
end

local function connection_multiset(connections)
    local counts = {}
    for _, connection in ipairs(connections or {}) do
        local signature = canonical_json_encode(connection)
        counts[signature] = (counts[signature] or 0) + 1
    end
    return counts
end

local function validate_blueprint(blueprint)
    if type(blueprint) ~= "table" then return false, "blueprint is not an object" end
    if type(blueprint.schema_version) ~= "number" then
        return false, "blueprint schema_version is missing"
    end
    if type(blueprint.connection_schema_version) ~= "number" then
        return false, "blueprint connection_schema_version is missing"
    end
    if blueprint.anchor_was_user_selected ~= true then
        return false, "blueprint has no user-selected anchor"
    end
    if type(blueprint.anchor_instance_id) ~= "string"
        or blueprint.anchor_instance_id == "" then
        return false, "blueprint anchor_instance_id is missing"
    end
    if type(blueprint.buildings) ~= "table" or #blueprint.buildings == 0 then
        return false, "blueprint buildings are empty"
    end
    if #blueprint.buildings > Codec.MAX_BUILDINGS then
        return false, "blueprint building limit exceeded"
    end
    if type(blueprint.saved_connections) ~= "table" then
        return false, "blueprint saved_connections are missing"
    end

    local ids = {}
    local anchor_count = 0
    local per_building_connections = {}
    for index, building in ipairs(blueprint.buildings) do
        if type(building) ~= "table" then
            return false, "blueprint building is not an object index=" .. index
        end
        if tonumber(building.selection_index) ~= index then
            return false, "blueprint selection_index mismatch index=" .. index
        end
        if type(building.source_instance_id) ~= "string"
            or building.source_instance_id == "" then
            return false, "blueprint building has no source_instance_id index=" .. index
        end
        if ids[building.source_instance_id] then
            return false, "duplicate source_instance_id=" .. building.source_instance_id
        end
        ids[building.source_instance_id] = index
        if type(building.build_object_id) ~= "string"
            or building.build_object_id == "" then
            return false, "blueprint building has no build_object_id index=" .. index
        end
        if type(building.relative_transform) ~= "table"
            or type(building.actor_relative_to_model) ~= "table" then
            return false, "blueprint building transform is missing index=" .. index
        end
        if type(building.preview_meshes) ~= "table"
            or type(building.overlap_descriptor) ~= "table" then
            return false, "blueprint preview data is missing index=" .. index
        end
        if type(building.connections) ~= "table"
            or type(building.external_connections) ~= "table" then
            return false, "blueprint connector arrays are missing index=" .. index
        end
        if building.is_anchor == true then
            anchor_count = anchor_count + 1
            if building.source_instance_id ~= blueprint.anchor_instance_id then
                return false, "anchor building identity mismatch"
            end
        end
        for _, connection in ipairs(building.connections) do
            if type(connection) ~= "table" then
                return false, "connector edge is not an object index=" .. index
            end
            local source_index = tonumber(connection.source_selection_index)
            local target_index = tonumber(connection.target_selection_index)
            if source_index ~= index or target_index == nil
                or target_index < 1 or target_index > #blueprint.buildings then
                return false, "connector edge index is invalid source=" .. index
            end
            if connection.target_source_instance_id
                ~= blueprint.buildings[target_index].source_instance_id then
                return false, "connector target identity mismatch source=" .. index
            end
            per_building_connections[#per_building_connections + 1] = connection
        end
    end
    if anchor_count ~= 1 then return false, "blueprint must contain exactly one anchor" end
    if ids[blueprint.anchor_instance_id] == nil then
        return false, "blueprint anchor is not present in buildings"
    end

    local top_counts = connection_multiset(blueprint.saved_connections)
    local building_counts = connection_multiset(per_building_connections)
    for signature, count in pairs(top_counts) do
        if building_counts[signature] ~= count then
            return false, "saved_connections disagree with building connections"
        end
    end
    for signature, count in pairs(building_counts) do
        if top_counts[signature] ~= count then
            return false, "building connections disagree with saved_connections"
        end
    end
    return true, nil
end

function Codec.canonical_json(blueprint)
    local valid, validation_error = validate_blueprint(blueprint)
    if not valid then return nil, validation_error end
    local ok, json_or_error = pcall(canonical_json_encode, blueprint)
    if not ok then return nil, tostring(json_or_error) end
    if #json_or_error > Codec.MAX_JSON_BYTES then
        return nil, "canonical JSON exceeds the safety limit"
    end
    return json_or_error, nil
end

-- Raw JSON helpers used by the schema-9 clipboard path.  They intentionally
-- do not call the legacy schema-8 validator or create a PWB1 frame; the
-- caller owns schema validation.
function Codec.encode_json(value, options)
    local number_formatter = nil
    local decimal_places = options ~= nil
        and tonumber(options.decimal_places) or nil
    if decimal_places ~= nil then
        decimal_places = math.max(0, math.min(math.floor(decimal_places), 12))
        number_formatter = function(number)
            local formatted = string.format("%." .. decimal_places .. "f", number)
            formatted = string.gsub(formatted, "(%..-)0+$", "%1")
            formatted = string.gsub(formatted, "%.$", "")
            if formatted == "-0" then return "0" end
            return formatted
        end
    end
    local ok, json_or_error = pcall(
        canonical_json_encode, value, number_formatter
    )
    if not ok then return nil, tostring(json_or_error) end
    if #json_or_error > Codec.MAX_JSON_BYTES then
        return nil, "JSON exceeds the safety limit"
    end
    return json_or_error, { json_bytes = #json_or_error }
end

function Codec.decode_json(text)
    if type(text) ~= "string" then return nil, "JSON input must be a string" end
    if #text <= 0 or #text > Codec.MAX_JSON_BYTES then
        return nil, "JSON size is outside the safety limit"
    end
    local ok, value_or_error = pcall(json_decode, text)
    if not ok then return nil, tostring(value_or_error) end
    return value_or_error, { json_bytes = #text }
end

function Codec.encode(blueprint)
    local json, json_error = Codec.canonical_json(blueprint)
    if json == nil then return nil, json_error end
    local compressed = lzss_compress(json)
    local codec_id = Codec.CODEC_LZSS
    local payload = compressed
    if #compressed >= #json then
        codec_id = Codec.CODEC_NONE
        payload = json
    end
    local compact_stats = nil
    local compact_ok, compact_or_error, compact_stats_or_nil = pcall(
        CompactBinary.encode, blueprint
    )
    if compact_ok and compact_or_error ~= nil then
        local compact = compact_or_error
        local compact_compressed = lzss_compress(compact)
        local compact_payload = pack_u32_le(#compact) .. compact_compressed
        if #compact_payload < #payload then
            codec_id = Codec.CODEC_COMPACT_LZSS
            payload = compact_payload
            compact_stats = compact_stats_or_nil
        end
    end
    local checksum = crc32(json)
    local header = "PWB" .. string.char(Codec.FRAME_VERSION)
        .. string.char(codec_id)
        .. string.char(0)
        .. pack_u16_le(20)
        .. pack_u32_le(#json)
        .. pack_u32_le(#payload)
        .. pack_u32_le(checksum)
    local code = Codec.TEXT_PREFIX .. base64url_encode(header .. payload)
    if #code > Codec.MAX_CODE_CHARS then
        return nil, "blueprint code exceeds the safety limit"
    end
    return code, {
        codec_id = codec_id,
        json_bytes = #json,
        payload_bytes = #payload,
        code_chars = #code,
        crc32 = checksum,
        buildings = #blueprint.buildings,
        compact_binary_bytes = compact_stats ~= nil
            and compact_stats.binary_bytes or nil,
        compact_strings = compact_stats ~= nil and compact_stats.strings or nil,
        compact_connections = compact_stats ~= nil
            and compact_stats.connections or nil,
    }
end

function Codec.decode(code)
    if type(code) ~= "string" then return nil, "clipboard text is unavailable" end
    if #code > Codec.MAX_CODE_CHARS + 4096 then
        return nil, "clipboard text exceeds the blueprint-code safety limit"
    end
    code = code:gsub("%s+", "")
    if #code > Codec.MAX_CODE_CHARS then
        return nil, "blueprint code exceeds the safety limit"
    end
    if string.sub(code, 1, #Codec.TEXT_PREFIX) ~= Codec.TEXT_PREFIX then
        return nil, "clipboard does not contain a PWB1 blueprint code"
    end
    local frame, base64_error = base64url_decode(
        string.sub(code, #Codec.TEXT_PREFIX + 1)
    )
    if frame == nil then return nil, base64_error end
    if #frame < 20 or string.sub(frame, 1, 3) ~= "PWB" then
        return nil, "blueprint frame magic is invalid"
    end
    local frame_version = string.byte(frame, 4)
    local codec_id = string.byte(frame, 5)
    local flags = string.byte(frame, 6)
    if frame_version ~= Codec.FRAME_VERSION then
        return nil, "unsupported blueprint frame version=" .. tostring(frame_version)
    end
    if flags ~= 0 then return nil, "unsupported blueprint frame flags" end
    local offset = 7
    local header_size, parse_error
    header_size, offset, parse_error = unpack_u16_le(frame, offset)
    if parse_error ~= nil or header_size ~= 20 then
        return nil, "blueprint frame header is invalid"
    end
    local json_size
    json_size, offset, parse_error = unpack_u32_le(frame, offset)
    if parse_error ~= nil then return nil, parse_error end
    local payload_size
    payload_size, offset, parse_error = unpack_u32_le(frame, offset)
    if parse_error ~= nil then return nil, parse_error end
    local expected_crc
    expected_crc, offset, parse_error = unpack_u32_le(frame, offset)
    if parse_error ~= nil then return nil, parse_error end
    if json_size <= 0 or json_size > Codec.MAX_JSON_BYTES then
        return nil, "blueprint JSON size is outside the safety limit"
    end
    if payload_size ~= #frame - header_size then
        return nil, "blueprint payload size mismatch"
    end
    local payload = string.sub(frame, header_size + 1)
    local json
    local blueprint = nil
    if codec_id == Codec.CODEC_NONE then
        json = payload
        if #json ~= json_size then return nil, "raw JSON size mismatch" end
    elseif codec_id == Codec.CODEC_LZSS then
        local decompress_ok, result_or_error = pcall(
            lzss_decompress, payload, json_size
        )
        if not decompress_ok then return nil, tostring(result_or_error) end
        json = result_or_error
    elseif codec_id == Codec.CODEC_COMPACT_LZSS then
        local compact_size, compact_offset, compact_size_error =
            unpack_u32_le(payload, 1)
        if compact_size_error ~= nil or compact_size == nil then
            return nil, "compact blueprint size is missing"
        end
        if compact_size <= 0 or compact_size > Codec.MAX_JSON_BYTES then
            return nil, "compact blueprint size is outside the safety limit"
        end
        local decompress_ok, compact_or_error = pcall(
            lzss_decompress, string.sub(payload, compact_offset), compact_size
        )
        if not decompress_ok then return nil, tostring(compact_or_error) end
        local decode_ok, blueprint_or_error, compact_stats = pcall(
            CompactBinary.decode, compact_or_error
        )
        if not decode_ok then return nil, tostring(blueprint_or_error) end
        if blueprint_or_error == nil then return nil, tostring(compact_stats) end
        blueprint = blueprint_or_error
        local canonical_ok, canonical_or_error = pcall(
            canonical_json_encode, blueprint
        )
        if not canonical_ok then return nil, tostring(canonical_or_error) end
        json = canonical_or_error
        if #json ~= json_size then
            return nil, "compact blueprint canonical size mismatch"
        end
    else
        return nil, "unsupported blueprint payload codec=" .. tostring(codec_id)
    end
    local actual_crc = crc32(json)
    if actual_crc ~= expected_crc then return nil, "blueprint CRC32 mismatch" end

    if blueprint == nil then
        local parse_ok, blueprint_or_error = pcall(json_decode, json)
        if not parse_ok then return nil, tostring(blueprint_or_error) end
        blueprint = blueprint_or_error
    end
    local valid, validation_error = validate_blueprint(blueprint)
    if not valid then return nil, validation_error end
    local canonical_ok, canonical_or_error = pcall(canonical_json_encode, blueprint)
    if not canonical_ok then return nil, tostring(canonical_or_error) end
    if canonical_or_error ~= json then
        return nil, "blueprint JSON is not canonical"
    end
    return blueprint, {
        codec_id = codec_id,
        json_bytes = #json,
        payload_bytes = #payload,
        code_chars = #code,
        crc32 = actual_crc,
        buildings = #blueprint.buildings,
    }
end

function Codec.validate(blueprint)
    return validate_blueprint(blueprint)
end

return Codec

local BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")

local BlueprintNameDialog = {}

local CLASS_PATH =
    "/Game/Pal/Blueprint/UI/UserInterface/CharacterCreation/"
        .. "WBP_CharaCre_PlayerNameEdit.WBP_CharaCre_PlayerNameEdit_C"
local CONFIRM_EVENT = CLASS_PATH
    .. ":BndEvt__WBP_CharaCre_PlayerNameEdit_WBP_CommonButton_"
        .. "K2Node_ComponentBoundEvent_2_OnClicked__DelegateSignature"
local CANCEL_EVENT = CLASS_PATH .. ":OnCancelAction"
local CLOSE_BUTTON_EVENT = CLASS_PATH
    .. ":BndEvt__WBP_CharaCre_PlayerNameEdit_WBP_Menu_btn_"
        .. "K2Node_ComponentBoundEvent_3_OnButtonClicked__DelegateSignature"

function BlueprintNameDialog.install(deps)
    assert(type(deps) == "table",
        "BlueprintNameDialog dependencies are required")
    local log = assert(deps.log, "BlueprintNameDialog log is required")
    local unwrap = assert(deps.unwrap,
        "BlueprintNameDialog unwrap is required")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintNameDialog is_valid_object is required")
    local safe_object_address = assert(deps.safe_object_address,
        "BlueprintNameDialog safe_object_address is required")
    local value_to_string = assert(deps.value_to_string,
        "BlueprintNameDialog value_to_string is required")
    local get_player_controller = assert(deps.get_player_controller,
        "BlueprintNameDialog get_player_controller is required")
    local localize = assert(deps.localize,
        "BlueprintNameDialog localize is required")
    local validate_name = assert(deps.validate_name,
        "BlueprintNameDialog validate_name is required")
    local show_error = deps.show_error or function() end

    local dialog = {
        widget_address = nil,
        on_confirm = nil,
        on_cancel = nil,
        on_closed = nil,
        confirm_hook_registered = false,
        confirm_hook_callback = nil,
        cancel_hook_registered = false,
        close_button_hook_registered = false,
        cancel_hook_callback = nil,
        close_button_hook_callback = nil,
        closing = false,
        generation = 0,
    }

    local function quiet(callback, fallback)
        local ok, result = pcall(callback)
        if ok then return result end
        return fallback
    end

    local function object_full_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return "<invalid>" end
        return tostring(quiet(function() return value:GetFullName() end,
            "<unavailable>"))
    end

    local function same_object(left, right)
        left = unwrap(left)
        right = unwrap(right)
        if not is_valid_object(left) or not is_valid_object(right) then
            return false
        end
        local left_address = safe_object_address(left)
        local right_address = safe_object_address(right)
        if left_address ~= nil and right_address ~= nil then
            return left_address == right_address
        end
        return object_full_name(left) == object_full_name(right)
    end

    local function resolve(path)
        if type(StaticFindObject) ~= "function" then return nil end
        return unwrap(quiet(function() return StaticFindObject(path) end, nil))
    end

    local function get_world(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        return unwrap(quiet(function() return value:GetWorld() end, nil))
    end

    local function is_same_world(left, right)
        local left_world = get_world(left)
        local right_world = get_world(right)
        if not is_valid_object(left_world)
            or not is_valid_object(right_world) then
            return false
        end
        return same_object(left_world, right_world)
    end

    local function is_current_widget(value)
        value = unwrap(value)
        local address = safe_object_address(value)
        return address ~= nil and dialog.widget_address ~= nil
            and tostring(address) == tostring(dialog.widget_address)
    end

    local function clear_references()
        dialog.widget_address = nil
        dialog.on_confirm = nil
        dialog.on_cancel = nil
        dialog.on_closed = nil
        dialog.closing = false
    end

    local find_live_widget
    local find_live_container

    local function close_dialog(reason, confirmed)
        if dialog.closing then return false end
        dialog.closing = true
        local widget = find_live_widget ~= nil and find_live_widget() or nil
        local container = find_live_container ~= nil
            and find_live_container() or nil
        local on_cancel = dialog.on_cancel
        local on_closed = dialog.on_closed
        if is_valid_object(container) and is_valid_object(widget) then
            quiet(function() container:RemoveWidget(widget) end, nil)
        end
        dialog.generation = dialog.generation + 1
        clear_references()
        log("blueprint name dialog closed reason=" .. tostring(reason)
            .. " confirmed=" .. tostring(confirmed == true))
        if confirmed ~= true and type(on_cancel) == "function" then
            local ok, callback_error = pcall(on_cancel, reason)
            if not ok then
                log("blueprint name dialog cancel callback failed error="
                    .. tostring(callback_error))
            end
        end
        if type(on_closed) == "function" then
            local ok, callback_error = pcall(
                on_closed, reason, confirmed == true
            )
            if not ok then
                log("blueprint name dialog closed callback failed error="
                    .. tostring(callback_error))
            end
        end
        return true
    end

    local function read_name()
        local widget = find_live_widget ~= nil and find_live_widget() or nil
        local input = is_valid_object(widget) and unwrap(quiet(function()
            return widget.PalEditableTextBox_83
        end, nil)) or nil
        if not is_valid_object(input) then
            return nil, "blueprint name input is unavailable"
        end
        local raw = quiet(function() return input:GetText() end, nil)
        local value = value_to_string(raw)
        return validate_name(value)
    end

    local function confirm_dialog()
        if not is_valid_object(find_live_widget()) or dialog.closing then
            return false
        end
        local name, name_error = read_name()
        if name == nil then
            show_error("message.library.name_invalid", tostring(name_error))
            return false
        end
        local on_confirm = dialog.on_confirm
        if type(on_confirm) ~= "function" then
            show_error("message.library.save_failed", "confirm callback missing")
            return false
        end
        local callback_ok, accepted, callback_error = pcall(on_confirm, name)
        if not callback_ok then
            callback_error = accepted
            accepted = false
            show_error("message.library.save_failed", tostring(callback_error))
        end
        if accepted ~= true then
            log("blueprint name dialog confirm rejected error="
                .. tostring(callback_error))
            return false
        end
        return close_dialog("confirmed", true)
    end

    local function register_hooks()
        if not dialog.confirm_hook_registered then
            local callback = function(context)
                if not is_current_widget(context) then return end
                local generation = dialog.generation
                BlueprintCallbackScheduler.game_thread_now(
                    "blueprint-name-dialog-native-confirm", function()
                        if dialog.generation == generation then
                            confirm_dialog()
                        end
                    end
                )
            end
            local ok, pre_id, post_id = pcall(
                RegisterHook, CONFIRM_EVENT, callback
            )
            if not ok then
                return false, "confirm hook unavailable: " .. tostring(pre_id)
            end
            dialog.confirm_hook_callback = callback
            dialog.confirm_hook_registered = true
            log("blueprint name dialog confirm hook registered pre="
                .. tostring(pre_id) .. " post=" .. tostring(post_id))
        end
        if not dialog.cancel_hook_registered then
            local callback = function(context)
                if not is_current_widget(context) then return end
                local generation = dialog.generation
                BlueprintCallbackScheduler.game_thread_now(
                    "blueprint-name-dialog-native-cancel", function()
                        if dialog.generation == generation then
                            close_dialog("native-cancel", false)
                        end
                    end
                )
            end
            local ok, pre_id, post_id = pcall(
                RegisterHook, CANCEL_EVENT, callback
            )
            if not ok then
                return false, "cancel hook unavailable: " .. tostring(pre_id)
            end
            dialog.cancel_hook_callback = callback
            dialog.cancel_hook_registered = true
            log("blueprint name dialog cancel hook registered pre="
                .. tostring(pre_id) .. " post=" .. tostring(post_id))
        end
        if not dialog.close_button_hook_registered then
            local callback = function(context)
                if not is_current_widget(context) then return end
                local generation = dialog.generation
                BlueprintCallbackScheduler.game_thread_now(
                    "blueprint-name-dialog-close-button", function()
                        if dialog.generation == generation then
                            close_dialog("native-close-button", false)
                        end
                    end
                )
            end
            local ok, pre_id, post_id = pcall(
                RegisterHook, CLOSE_BUTTON_EVENT, callback
            )
            if not ok then
                return false, "close-button hook unavailable: "
                    .. tostring(pre_id)
            end
            dialog.close_button_hook_callback = callback
            dialog.close_button_hook_registered = true
            log("blueprint name dialog close-button hook registered pre="
                .. tostring(pre_id) .. " post=" .. tostring(post_id))
        end
        return true, nil
    end

    local function find_overall_layout(controller)
        if type(FindAllOf) ~= "function" then return nil end
        for _, raw in pairs(FindAllOf("WBP_PalOverallUILayout_C") or {}) do
            local candidate = unwrap(raw)
            if is_valid_object(candidate)
                and is_same_world(candidate, controller) then
                return candidate
            end
        end
        return nil
    end

    local function find_modal_container(overall)
        if not is_valid_object(overall)
            or type(FindAllOf) ~= "function" then
            return nil
        end
        local overall_path = object_full_name(overall):gsub("^[^ ]+ ", "")
        for _, raw in pairs(FindAllOf("PalActivatableWidgetContainer") or {}) do
            local candidate = unwrap(raw)
            local full_name = object_full_name(candidate)
            if is_valid_object(candidate)
                and string.find(full_name, overall_path, 1, true) ~= nil
                and string.match(full_name, "%.Modal$") then
                return candidate
            end
        end
        return nil
    end

    find_live_container = function()
        local controller = unwrap(get_player_controller())
        if not is_valid_object(controller) then return nil end
        return find_modal_container(find_overall_layout(controller))
    end

    find_live_widget = function()
        if type(FindAllOf) ~= "function" then return nil end
        local controller = unwrap(get_player_controller())
        if not is_valid_object(controller) then return nil end
        for _, raw in pairs(
            FindAllOf("WBP_CharaCre_PlayerNameEdit_C") or {}
        ) do
            local candidate = unwrap(raw)
            if is_valid_object(candidate)
                and is_same_world(candidate, controller)
                and is_current_widget(candidate) then
                return candidate
            end
        end
        return nil
    end

    function dialog.is_open()
        return not dialog.closing and is_valid_object(find_live_widget())
    end

    function dialog.open(options)
        options = options or {}
        if dialog.is_open() then
            return false, "blueprint name dialog is already open"
        end
        local controller = unwrap(get_player_controller())
        if not is_valid_object(controller) then
            return false, "local player controller is unavailable"
        end
        local class = resolve(CLASS_PATH)
        if not is_valid_object(class) then
            return false, "stock player-name widget class is unavailable"
        end
        local hooks_ready, hook_error = register_hooks()
        if not hooks_ready then return false, hook_error end

        local overall = find_overall_layout(controller)
        local container = find_modal_container(overall)
        if not is_valid_object(container) then
            return false, "stock modal container is unavailable"
        end
        local widget = unwrap(quiet(function()
            return container:BP_AddWidget(class)
        end, nil))
        if not is_valid_object(widget) then
            return false, "stock player-name widget could not be created"
        end

        quiet(function() widget:OnSetup() end, nil)
        local input = unwrap(quiet(function()
            return widget.PalEditableTextBox_83
        end, nil))
        local heading = unwrap(quiet(function()
            return widget.Text_Head
        end, nil))
        if not is_valid_object(input) or not is_valid_object(heading) then
            quiet(function() container:RemoveWidget(widget) end, nil)
            return false, "stock player-name widget fields are unavailable"
        end

        local widget_address = safe_object_address(widget)
        if widget_address == nil then
            quiet(function() container:RemoveWidget(widget) end, nil)
            return false, "stock player-name widget identity is unavailable"
        end

        local generation = dialog.generation + 1
        dialog.widget_address = tostring(widget_address)
        dialog.on_confirm = options.on_confirm
        dialog.on_cancel = options.on_cancel
        dialog.on_closed = options.on_closed
        dialog.generation = generation
        dialog.closing = false

        quiet(function()
            heading:SetText(FText(tostring(
                options.heading_text
                    or localize("ui.library.name_heading")
            )))
        end, nil)
        quiet(function()
            input:SetText(FText(tostring(
                options.default_name
                    or localize("ui.library.fallback_name")
            )))
        end, nil)
        quiet(function() widget:SetEnableConfirmButton(true) end, nil)
        quiet(function() widget:SetVisibility(4) end, nil)
        quiet(function() input:SetKeyboardFocus() end, nil)
        quiet(function() input:SelectAllText() end, nil)
        log("blueprint name dialog opened widget=" .. object_full_name(widget))
        return true, nil
    end

    function dialog.cancel(reason)
        if not dialog.is_open() then return false end
        local generation = dialog.generation
        local close_reason = reason or "external-cancel"
        local scheduled = BlueprintCallbackScheduler.game_thread_now(
            "blueprint-name-dialog-external-cancel", function()
                if dialog.generation == generation then
                    close_dialog(close_reason, false)
                end
            end
        )
        return scheduled == true
    end

    function dialog.reset_for_world_travel()
        dialog.generation = dialog.generation + 1
        clear_references()
    end

    return dialog
end

return BlueprintNameDialog

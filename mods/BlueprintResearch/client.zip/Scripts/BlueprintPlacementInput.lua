local BlueprintPlacementInput = {}

local ACTOR_PACKAGE_PATH =
    "/Game/Mods/BlueprintResearch/BP_BlueprintPlacementInput"
local ACTOR_CLASS_PATH = ACTOR_PACKAGE_PATH
    .. ".BP_BlueprintPlacementInput_C"
local ACTOR_CLASS_NAME = "BP_BlueprintPlacementInput_C"
local REQUEST_FUNCTION_PATH = ACTOR_CLASS_PATH .. ":RequestBlueprintPlacement"
local BUILDING_WIDGET_SETUP_INPUT_PATH =
    "/Game/Pal/Blueprint/UI/BuildMenu/WBP_PalBuilding."
        .. "WBP_PalBuilding_C:SetupInputAction"
local CAMERA_HOLD_FUNCTION_PATH =
    ACTOR_CLASS_PATH .. ":RequestBlueprintCameraHold"
local CAMERA_RELEASE_FUNCTION_PATH =
    ACTOR_CLASS_PATH .. ":ReleaseBlueprintCameraHold"
local WORLD_SNAP_TOGGLE_FUNCTION_PATH =
    ACTOR_CLASS_PATH .. ":RequestBlueprintWorldSnapToggle"
local CAMERA_PACKAGE_PATH =
    "/Game/Mods/BlueprintResearch/BP_BlueprintPlacementCamera"
local CAMERA_CLASS_PATH = CAMERA_PACKAGE_PATH
    .. ".BP_BlueprintPlacementCamera_C"
local CAMERA_STOCK_EXIT_FUNCTION_PATH =
    CAMERA_CLASS_PATH .. ":SBB_RequestStockCameraExit"
local MOD_ACTOR_CLASS_NAME = "ModActor_C"
local MOD_ACTOR_CLASS_FULL_NAME =
    "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/ModActor.ModActor_C"
local HARD_REFERENCE_PROPERTY = "BlueprintPlacementInputActorClass"
local STOCK_BUILD_ACTION = "BuildObject"
local STOCK_CONTINUOUS_BUILD_ACTION = "BuildObjectContinuous"
local STOCK_SNAP_ACTION = "BuildObjectChangeSnapMode"
local BLOCKED_BUILD_ACTION = "BlueprintResearch_BlockBuildObject"
local BLOCKED_CONTINUOUS_BUILD_ACTION =
    "BlueprintResearch_BlockBuildObjectContinuous"
local BLOCKED_SNAP_ACTION =
    "BlueprintResearch_BlockBuildObjectChangeSnapMode"

function BlueprintPlacementInput.install(deps)
    assert(type(deps) == "table", "BlueprintPlacementInput dependencies are required")

    local UEHelpers = assert(
        deps.UEHelpers, "BlueprintPlacementInput UEHelpers is required"
    )
    local log = assert(deps.log, "BlueprintPlacementInput log is required")
    local unwrap = assert(deps.unwrap, "BlueprintPlacementInput unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object, "BlueprintPlacementInput is_valid_object is required"
    )
    local is_usable_class_object = assert(
        deps.is_usable_class_object,
        "BlueprintPlacementInput is_usable_class_object is required"
    )
    local object_name = assert(
        deps.object_name, "BlueprintPlacementInput object_name is required"
    )
    local value_to_string = assert(
        deps.value_to_string,
        "BlueprintPlacementInput value_to_string is required"
    )
    local safe_object_address = assert(
        deps.safe_object_address,
        "BlueprintPlacementInput safe_object_address is required"
    )
    local safe_property = assert(
        deps.safe_property, "BlueprintPlacementInput safe_property is required"
    )
    local get_asset_path = assert(
        deps.get_asset_path,
        "BlueprintPlacementInput get_asset_path is required"
    )
    local find_valid_instance_by_address = assert(
        deps.find_valid_instance_by_address,
        "BlueprintPlacementInput find_valid_instance_by_address is required"
    )
    local get_local_player_controller = assert(
        deps.get_local_player_controller,
        "BlueprintPlacementInput get_local_player_controller is required"
    )
    local on_primary_action = assert(
        deps.on_primary_action,
        "BlueprintPlacementInput on_primary_action is required"
    )
    local on_world_snap_toggle = assert(
        deps.on_world_snap_toggle,
        "BlueprintPlacementInput on_world_snap_toggle is required"
    )
    local mode_ui = assert(
        deps.mode_ui, "BlueprintPlacementInput mode_ui is required"
    )
    local is_placement_active = assert(
        deps.is_placement_active,
        "BlueprintPlacementInput is_placement_active is required"
    )
    local begin_camera_hold = assert(
        deps.begin_camera_hold,
        "BlueprintPlacementInput begin_camera_hold is required"
    )
    local end_camera_hold = assert(
        deps.end_camera_hold,
        "BlueprintPlacementInput end_camera_hold is required"
    )
    local abandon_camera_hold = deps.abandon_camera_hold
    local is_camera_hold_active = assert(
        deps.is_camera_hold_active,
        "BlueprintPlacementInput is_camera_hold_active is required"
    )
    local matches_camera_context = assert(
        deps.matches_camera_context,
        "BlueprintPlacementInput matches_camera_context is required"
    )
    local schedule_cleanup = assert(
        deps.schedule_cleanup,
        "BlueprintPlacementInput schedule_cleanup is required"
    )
    local runtime_backend = assert(
        deps.runtime_backend,
        "BlueprintPlacementInput runtime_backend is required"
    )

    local controller = {
        active = false,
        active_actor_address = nil,
        primary_locked = false,
        request_hook_ready = false,
        request_hook_callback = nil,
        setup_input_hook_ready = false,
        setup_input_hook_callback = nil,
        stock_rebind_in_progress = false,
        camera_hold_hook_ready = false,
        camera_release_hook_ready = false,
        camera_stock_exit_hook_ready = false,
        world_snap_toggle_hook_ready = false,
        world_snap_toggle_hook_callback = nil,
        camera_hook_callbacks = {},
        blocker_rows_ready = false,
        camera_snap_blocked = false,
        retired_actor_addresses = {},
    }

    local function ensure_blocker_rows()
        if controller.blocker_rows_ready then return true, nil end
        if type(mode_ui.load_input_action_table) ~= "function"
            or type(mode_ui.install_input_action_row) ~= "function" then
            return false, "UI input action table helpers are unavailable"
        end
        local data_table = unwrap(mode_ui.load_input_action_table())
        if not is_valid_object(data_table) then
            return false, "DT_UIInputAction is unavailable"
        end

        local rows = {
            { name = BLOCKED_SNAP_ACTION, key = "F22" },
            { name = BLOCKED_BUILD_ACTION, key = "F23" },
            { name = BLOCKED_CONTINUOUS_BUILD_ACTION, key = "F24" },
        }
        for _, row in ipairs(rows) do
            local ok, error_value = mode_ui.install_input_action_row(
                data_table, row.name, row.key
            )
            if not ok then
                return false, row.name .. " row failed: "
                    .. tostring(error_value)
            end
        end
        controller.blocker_rows_ready = true
        log("blueprint placement CommonUI blocker rows ready")
        return true, nil
    end

    local function write_widget_actions(
        widget, single_action, continuous_action, snap_action
    )
        widget = unwrap(widget)
        if not is_valid_object(widget) then
            return false, "WBP_PalBuilding object is unavailable"
        end
        local write_ok, write_error = pcall(function()
            local build_action = safe_property(
                widget, "BuildObjectActionInput"
            )
            local continuous = safe_property(
                widget, "BuildObjectContinuousActionInput"
            )
            local snap = safe_property(
                widget, "BuildChangeSnapMode"
            )
            build_action.Key = FName(single_action)
            continuous.Key = FName(continuous_action)
            snap.Key = FName(snap_action)
            if value_to_string(build_action.Key) ~= single_action
                or value_to_string(continuous.Key) ~= continuous_action
                or value_to_string(snap.Key) ~= snap_action then
                error("building widget action verification failed")
            end
        end)
        if not write_ok then return false, tostring(write_error) end
        return true, nil
    end

    local function rebind_widget_actions(
        session, widget, single_action, continuous_action, snap_action,
        stock_rebind
    )
        session = unwrap(session)
        widget = unwrap(widget)
        if not is_valid_object(session) then
            return false, "placement session input helper is unavailable"
        end
        if not is_valid_object(widget) then
            return false, "WBP_PalBuilding object is unavailable"
        end

        controller.stock_rebind_in_progress = stock_rebind == true
        local rebind_ok, rebind_error = pcall(function()
            -- RegisterActionBinding is owned by UPalUserWidget, not by UMG's
            -- ListenForInputAction list. UE4SS cannot pass the input value of
            -- FPalUIActionBindData& from Lua: reflected Out parameters accept a
            -- Lua output table but discard its input. The current-world Session
            -- therefore performs the synchronous UE Blueprint loop and clears
            -- both its temporary copy and the Widget's source array.
            local handles = safe_property(widget, "BindedActionHandles")
            if handles == nil then
                error("Pal action handle array is unavailable")
            end
            session:SBB_UnregisterBuildingActionHandles(widget)
            if #handles ~= 0 then
                error("Pal action handle helper left stale entries")
            end

            -- Keep UMG's separate legacy input list clean as well. This does
            -- not replace the UE Pal action-handle helper above.
            widget:StopListeningForAllInputActions()

            local written, write_error = write_widget_actions(
                widget, single_action, continuous_action, snap_action
            )
            if not written then error(write_error) end

            -- SetupInputAction restores the complete immediate action set,
            -- while DelaySetupInputAction restores snap/change/replace actions.
            -- Rebinding only the two LMB delegates from Lua would require
            -- unsafe reflected delegate construction.
            widget.bCompletedDelayInputActionSetup = false
            widget:SetupInputAction()
            widget:DelaySetupInputAction()
            local rebuilt_handles = safe_property(
                widget, "BindedActionHandles"
            )
            if rebuilt_handles == nil or #rebuilt_handles < 1 then
                error("Pal action handles were not rebuilt")
            end
        end)
        controller.stock_rebind_in_progress = false
        if not rebind_ok then return false, tostring(rebind_error) end
        return true, nil
    end

    local function resolve_current_building_widget(building_model)
        building_model = unwrap(building_model)
        local model_address = safe_object_address(building_model)
        local model_path = get_asset_path(building_model)
        local widget_path = type(model_path) == "string"
            and string.match(model_path, "^(.*)%.") or nil
        if model_address == nil or widget_path == nil then
            return nil, "current building model parent path is unavailable"
        end

        local find_ok, widget = pcall(StaticFindObject, widget_path)
        widget = find_ok and unwrap(widget) or nil
        if not is_valid_object(widget) then
            return nil, "current WBP_PalBuilding parent is unavailable"
        end
        local widget_model = unwrap(safe_property(widget, "Model"))
        if not is_valid_object(widget_model)
            or safe_object_address(widget_model) ~= model_address then
            return nil, "current WBP_PalBuilding model identity mismatch"
        end
        return widget, nil
    end

    local function get_object_class_full_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return "<invalid>" end
        local ok, full_name = pcall(function()
            local object_class = unwrap(value:GetClass())
            return object_class:GetFullName()
        end)
        if not ok or full_name == nil then return "<unavailable>" end
        return tostring(full_name)
    end

    local function ensure_setup_input_hook()
        if controller.setup_input_hook_ready then return true, nil end

        local callback = function(context)
            if controller.stock_rebind_in_progress
                or not is_placement_active() then
                return
            end
            local widget = unwrap(context)
            local patched, patch_error = write_widget_actions(
                widget,
                BLOCKED_BUILD_ACTION,
                BLOCKED_CONTINUOUS_BUILD_ACTION,
                controller.camera_snap_blocked
                    and BLOCKED_SNAP_ACTION
                    or STOCK_SNAP_ACTION
            )
            if not patched then
                log("blueprint placement CommonUI upstream patch failed error="
                    .. tostring(patch_error))
            end
        end
        controller.setup_input_hook_callback = callback
        local hook_ok, pre_id, post_id = pcall(
            RegisterHook, BUILDING_WIDGET_SETUP_INPUT_PATH, callback
        )
        if not hook_ok then
            controller.setup_input_hook_callback = nil
            return false, tostring(pre_id)
        end
        controller.setup_input_hook_ready = true
        log("blueprint placement CommonUI upstream hook registered pre="
            .. tostring(pre_id) .. " post=" .. tostring(post_id))
        return true, nil
    end

    local function restore_session_widget_actions(session, reason)
        session = unwrap(session)
        local widget = unwrap(safe_property(
            session, "SBB_PlacementHUD"
        ))
        if not is_valid_object(widget) then
            log("blueprint placement exact CommonUI instance already invalid reason="
                .. tostring(reason))
            return true, nil
        end
        local restored, restore_error = rebind_widget_actions(
            session,
            widget,
            STOCK_BUILD_ACTION,
            STOCK_CONTINUOUS_BUILD_ACTION,
            STOCK_SNAP_ACTION,
            true
        )
        log("blueprint placement exact CommonUI instance restored reason="
            .. tostring(reason) .. " ok=" .. tostring(restored)
            .. (restored and "" or " error="
                .. tostring(restore_error)))
        return restored, restore_error
    end

    local function set_camera_snap_blocked(session, blocked, reason)
        session = unwrap(session)
        local widget = unwrap(safe_property(
            session, "SBB_PlacementHUD"
        ))
        if not is_valid_object(widget) then
            return false, "current placement HUD is unavailable"
        end
        local previous = controller.camera_snap_blocked
        controller.camera_snap_blocked = blocked == true
        local rebound, rebind_error = rebind_widget_actions(
            session,
            widget,
            BLOCKED_BUILD_ACTION,
            BLOCKED_CONTINUOUS_BUILD_ACTION,
            controller.camera_snap_blocked
                and BLOCKED_SNAP_ACTION
                or STOCK_SNAP_ACTION,
            false
        )
        if not rebound then
            controller.camera_snap_blocked = previous
            return false, rebind_error
        end
        log("blueprint placement camera Ctrl route "
            .. (controller.camera_snap_blocked and "captured" or "restored")
            .. " reason=" .. tostring(reason))
        return true, nil
    end

    local function load_actor_class()
        local actor_class = unwrap(StaticFindObject(ACTOR_CLASS_PATH))
        if is_usable_class_object(actor_class) then
            return actor_class, nil
        end

        -- The ordinary actor is kept in the cooked runtime load graph through
        -- a class-property default on the sole LogicMod ModActor entry. Read
        -- that reference from a live instance without retaining either UObject.
        local candidate_diagnostics = {}
        for _, mod_actor_value in ipairs(FindAllOf(MOD_ACTOR_CLASS_NAME) or {}) do
            local mod_actor = unwrap(mod_actor_value)
            if is_valid_object(mod_actor) then
                local class_full_name = get_object_class_full_name(mod_actor)
                candidate_diagnostics[#candidate_diagnostics + 1] =
                    "instance=" .. object_name(mod_actor)
                        .. " class=" .. class_full_name
                if class_full_name == MOD_ACTOR_CLASS_FULL_NAME then
                    actor_class = unwrap(safe_property(
                        mod_actor, HARD_REFERENCE_PROPERTY
                    ))
                    if is_usable_class_object(actor_class) then
                        return actor_class, nil
                    end
                end
            end
        end

        local package_result = nil
        local load_ok, load_error = pcall(function()
            package_result = unwrap(LoadAsset(ACTOR_PACKAGE_PATH))
        end)
        actor_class = unwrap(StaticFindObject(ACTOR_CLASS_PATH))
        if is_usable_class_object(actor_class) then
            return actor_class, nil
        end

        local generated_class = unwrap(safe_property(
            package_result, "GeneratedClass"
        ))
        if is_usable_class_object(generated_class) then
            return generated_class, nil
        end
        local base_error = load_ok
            and ("generated actor class unavailable asset="
                .. object_name(package_result))
            or tostring(load_error)
        return nil, base_error .. " expectedModActorClass="
            .. MOD_ACTOR_CLASS_FULL_NAME .. " candidates=["
            .. table.concat(candidate_diagnostics, " | ") .. "]"
    end

    local function ensure_camera_class_loaded(session)
        session = unwrap(session)
        local camera_class = unwrap(safe_property(
            session, "SBB_PlacementCameraClass"
        ))
        if is_usable_class_object(camera_class) then
            return true, nil, "placement-session-hard-reference"
        end

        camera_class = unwrap(StaticFindObject(CAMERA_CLASS_PATH))
        if is_usable_class_object(camera_class) then
            return true, nil, "already-loaded-generated-class"
        end

        local camera_asset = nil
        local load_ok, load_error = pcall(function()
            camera_asset = unwrap(LoadAsset(CAMERA_CLASS_PATH))
        end)
        camera_class = unwrap(StaticFindObject(CAMERA_CLASS_PATH))
        if is_usable_class_object(camera_class) then
            return true, nil, "explicit-generated-class-load"
        end

        local generated_class = unwrap(safe_property(
            camera_asset, "GeneratedClass"
        ))
        if is_usable_class_object(generated_class) then
            return true, nil, "explicit-blueprint-load"
        end
        return false, load_ok
            and ("generated camera class unavailable asset="
                .. object_name(camera_asset))
            or tostring(load_error)
    end

    local function ensure_request_hook()
        if controller.request_hook_ready then return true, nil end

        local callback = function(context)
            if not controller.active then return end
            context = unwrap(context)
            local context_address = safe_object_address(context)
            if context_address == nil
                or context_address ~= controller.active_actor_address then
                return
            end
            -- While locked, the Blueprint event itself still consumes the
            -- input, but Lua touches no business path.
            if controller.primary_locked
                or is_camera_hold_active(context) then
                return
            end
            local action_ok, action_error = pcall(on_primary_action)
            if not action_ok then
                log("blueprint placement input hook isolated error="
                    .. tostring(action_error))
            end
        end
        controller.request_hook_callback = callback
        local hook_ok, pre_id, post_id = pcall(
            RegisterHook, REQUEST_FUNCTION_PATH, callback
        )
        if not hook_ok then
            controller.request_hook_callback = nil
            return false, tostring(pre_id)
        end
        controller.request_hook_ready = true
        log("blueprint placement dedicated input hook registered pre="
            .. tostring(pre_id) .. " post=" .. tostring(post_id))
        return true, nil
    end

    local function ensure_world_snap_toggle_hook()
        if controller.world_snap_toggle_hook_ready then return true, nil end

        local callback = function(context)
            if not controller.active then return end
            context = unwrap(context)
            local context_address = safe_object_address(context)
            if context_address == nil
                or context_address ~= controller.active_actor_address
                or is_camera_hold_active(context) then
                return
            end
            local action_ok, action_error = pcall(
                on_world_snap_toggle, context
            )
            if not action_ok then
                log("blueprint placement world snap input isolated error="
                    .. tostring(action_error))
            end
        end
        local hook_ok, pre_id, post_id = pcall(
            RegisterHook, WORLD_SNAP_TOGGLE_FUNCTION_PATH, callback
        )
        if not hook_ok then return false, tostring(pre_id) end
        controller.world_snap_toggle_hook_callback = callback
        controller.world_snap_toggle_hook_ready = true
        log("blueprint placement world snap input hook registered pre="
            .. tostring(pre_id) .. " post=" .. tostring(post_id))
        return true, nil
    end

    local function ensure_camera_hooks(session)
        if controller.camera_hold_hook_ready
            and controller.camera_release_hook_ready
            and controller.camera_stock_exit_hook_ready then
            return true, nil
        end
        local camera_loaded, camera_load_error, camera_load_source =
            ensure_camera_class_loaded(session)
        if not camera_loaded then
            return false, "placement camera class load failed: "
                .. tostring(camera_load_error)
        end
        log("blueprint placement camera class ready source="
            .. tostring(camera_load_source))

        local function owns_context(context)
            if not controller.active then return false end
            local context_address = safe_object_address(context)
            return context_address ~= nil
                and context_address == controller.active_actor_address
        end

        local hold_callback = function(context)
            if not owns_context(context) then return end
            context = unwrap(context)
            local camera_was_active = is_camera_hold_active(context)
            local route_ok, route_error = set_camera_snap_blocked(
                context,
                not camera_was_active,
                camera_was_active
                    and "camera-toggle-exit"
                    or "camera-toggle-enter"
            )
            if not route_ok then
                log("blueprint placement camera Ctrl route failed error="
                    .. tostring(route_error))
                return
            end

            local call_ok, result, error_value
            if camera_was_active then
                call_ok, result, error_value = pcall(
                    end_camera_hold,
                    context,
                    context,
                    "placement-camera-toggle"
                )
            else
                call_ok, result, error_value = pcall(
                    begin_camera_hold,
                    context,
                    context
                )
            end
            if not call_ok or result ~= true then
                set_camera_snap_blocked(
                    context,
                    camera_was_active,
                    "camera-toggle-rollback"
                )
                log("blueprint placement camera toggle isolated error="
                    .. tostring(call_ok and error_value or result))
            end
            local paused_ok, paused_error =
                runtime_backend.set_tick_paused(
                    context,
                    is_camera_hold_active(context)
                )
            if not paused_ok then
                log("blueprint placement session Tick pause failed error="
                    .. tostring(paused_error))
            end
        end
        local release_callback = function(context)
            if not owns_context(context) then return end
            -- Caps Lock is a toggle. Consume key-up without restoring.
        end
        local stock_exit_callback = function(camera_context)
            if not controller.active then return end
            local session = unwrap(find_valid_instance_by_address(
                ACTOR_CLASS_NAME, controller.active_actor_address
            ))
            if not is_valid_object(session)
                or not is_camera_hold_active(session)
                or not matches_camera_context(
                    session, unwrap(camera_context)
                ) then
                return
            end
            local ok, error_value = pcall(
                end_camera_hold,
                session,
                session,
                "placement-camera-stock-exit"
            )
            if not ok then
                log("blueprint placement stock camera exit isolated error="
                    .. tostring(error_value))
            end
            local restored, restore_error = set_camera_snap_blocked(
                session, false, "camera-stock-exit"
            )
            if not restored then
                log("blueprint placement camera Ctrl restore failed error="
                    .. tostring(restore_error))
            end
        end

        local hold_pre, hold_post = "already-registered", nil
        if not controller.camera_hold_hook_ready then
            local hold_ok
            hold_ok, hold_pre, hold_post = pcall(
                RegisterHook, CAMERA_HOLD_FUNCTION_PATH, hold_callback
            )
            if not hold_ok then return false, tostring(hold_pre) end
            controller.camera_hook_callbacks.hold = hold_callback
            controller.camera_hold_hook_ready = true
        end

        local release_pre, release_post = "already-registered", nil
        if not controller.camera_release_hook_ready then
            local release_ok
            release_ok, release_pre, release_post = pcall(
                RegisterHook, CAMERA_RELEASE_FUNCTION_PATH, release_callback
            )
            if not release_ok then return false, tostring(release_pre) end
            controller.camera_hook_callbacks.release = release_callback
            controller.camera_release_hook_ready = true
        end
        local stock_pre, stock_post = "already-registered", nil
        if not controller.camera_stock_exit_hook_ready then
            local stock_ok
            stock_ok, stock_pre, stock_post = pcall(
                RegisterHook,
                CAMERA_STOCK_EXIT_FUNCTION_PATH,
                stock_exit_callback
            )
            if not stock_ok then return false, tostring(stock_pre) end
            controller.camera_hook_callbacks.stock_exit =
                stock_exit_callback
            controller.camera_stock_exit_hook_ready = true
        end
        log("blueprint placement camera input hooks registered holdPre="
            .. tostring(hold_pre) .. " holdPost=" .. tostring(hold_post)
            .. " releasePre=" .. tostring(release_pre)
            .. " releasePost=" .. tostring(release_post)
            .. " stockExitPre=" .. tostring(stock_pre)
            .. " stockExitPost=" .. tostring(stock_post))
        return true, nil
    end

    local function resolve_active_actor(address)
        return unwrap(find_valid_instance_by_address(
            ACTOR_CLASS_NAME, address
        ))
    end

    local function remember_retired_actor(address)
        if address == nil then return end
        controller.retired_actor_addresses[tostring(address)] = address
    end

    local function forget_retired_actor(address)
        if address == nil then return end
        controller.retired_actor_addresses[tostring(address)] = nil
    end

    local function disable_input_actor(address, reason)
        if address == nil then return true end
        local actor = resolve_active_actor(address)
        if not is_valid_object(actor) then
            log("blueprint placement dedicated input disable: actor already invalid reason="
                .. tostring(reason) .. " address=" .. tostring(address))
            return true
        end

        local player_controller = unwrap(get_local_player_controller())
        local disable_ok, disable_error = pcall(function()
            if is_valid_object(player_controller) then
                actor:DisableInput(player_controller)
            end
        end)
        log("blueprint placement dedicated input disabled reason="
            .. tostring(reason) .. " ok=" .. tostring(disable_ok)
            .. (disable_ok and ""
                or " error=" .. tostring(disable_error)))
        return disable_ok
    end

    local destroy_input_actor = nil

    function controller.prepare()
        local rows_ok, rows_error = ensure_blocker_rows()
        if not rows_ok then return false, rows_error end
        local hook_ok, hook_error = ensure_setup_input_hook()
        if not hook_ok then
            return false, "WBP_PalBuilding SetupInputAction hook failed: "
                .. tostring(hook_error)
        end
        log("blueprint placement input prepared without CommonUI CDO mutation")
        return true, nil
    end

    function controller.enter(session_context)
        session_context = type(session_context) == "table"
            and session_context or {}
        -- StartBuildObject has already constructed the current build HUD.
        -- Stage 5 patches exactly that instance and stores it on the session;
        -- class defaults and historical transient widgets are never touched.
        if controller.active then
            local existing = resolve_active_actor(
                controller.active_actor_address
            )
            if is_valid_object(existing) then
                return true, nil, existing
            end
            controller.active = false
            controller.active_actor_address = nil
        end
        controller.camera_snap_blocked = false

        -- A failed/dropped deferred destroy must never accumulate enabled
        -- input actors across placement sessions. These entries are addresses
        -- only and are reacquired in the current world before being touched.
        for key, retired_address in pairs(
            controller.retired_actor_addresses
        ) do
            if destroy_input_actor(retired_address, "enter-sanitize") then
                controller.retired_actor_addresses[key] = nil
            end
        end

        local player_controller = unwrap(get_local_player_controller())
        if not is_valid_object(player_controller) then
            return false, "local player controller is unavailable"
        end
        local world = unwrap(UEHelpers.GetWorld())
        if not is_valid_object(world) then
            return false, "current world is unavailable"
        end

        local actor_class, class_error = load_actor_class()
        if not is_usable_class_object(actor_class) then
            return false, "dedicated actor class load failed: "
                .. tostring(class_error)
        end
        local hook_ready, hook_error = ensure_request_hook()
        if not hook_ready then
            return false, "dedicated request hook failed: "
                .. tostring(hook_error)
        end
        local world_snap_hook_ready, world_snap_hook_error =
            ensure_world_snap_toggle_hook()
        if not world_snap_hook_ready then
            return false, "dedicated world snap hook failed: "
                .. tostring(world_snap_hook_error)
        end
        local actor = nil
        local spawn_ok, spawn_error = pcall(function()
            actor = unwrap(world:SpawnActor(actor_class, {}, {}))
        end)
        if not spawn_ok or not is_valid_object(actor) then
            return false, "dedicated actor spawn failed: "
                .. tostring(spawn_error)
        end
        local camera_hooks_ready, camera_hooks_error =
            ensure_camera_hooks(actor)
        if not camera_hooks_ready then
            pcall(function() actor:K2_DestroyActor() end)
            return false, "dedicated camera hooks failed: "
                .. tostring(camera_hooks_error)
        end

        local address = safe_object_address(actor)
        if address == nil then
            pcall(function() actor:K2_DestroyActor() end)
            return false, "dedicated actor address is unavailable"
        end

        local current_hud, current_hud_error =
            resolve_current_building_widget(session_context.building_model)
        if not is_valid_object(current_hud) then
            pcall(function() actor:K2_DestroyActor() end)
            return false, "current building HUD instance is unavailable: "
                .. tostring(current_hud_error)
        end
        session_context.hud = current_hud
        local hud_patched, hud_patch_error = rebind_widget_actions(
            actor,
            current_hud,
            BLOCKED_BUILD_ACTION,
            BLOCKED_CONTINUOUS_BUILD_ACTION,
            STOCK_SNAP_ACTION,
            false
        )
        if not hud_patched then
            rebind_widget_actions(
                actor,
                current_hud,
                STOCK_BUILD_ACTION,
                STOCK_CONTINUOUS_BUILD_ACTION,
                STOCK_SNAP_ACTION,
                true
            )
            pcall(function() actor:K2_DestroyActor() end)
            return false, "current building HUD input rebind failed: "
                .. tostring(hud_patch_error)
        end

        session_context.input_controller = player_controller
        local session_ok, session_error = runtime_backend.begin(
            actor, session_context
        )
        session_context.input_controller = nil
        if not session_ok then
            rebind_widget_actions(
                actor,
                current_hud,
                STOCK_BUILD_ACTION,
                STOCK_CONTINUOUS_BUILD_ACTION,
                STOCK_SNAP_ACTION,
                true
            )
            if runtime_backend.is_ue_authoritative() then
                pcall(function() actor:K2_DestroyActor() end)
                return false, "authoritative placement session failed: "
                    .. tostring(session_error)
            end
            log("blueprint placement shadow runtime session unavailable error="
                .. tostring(session_error))
        end

        local enable_ok, enable_error = pcall(function()
            actor:EnableInput(player_controller)
        end)
        if not enable_ok then
            restore_session_widget_actions(
                actor, "EnableInput-failed"
            )
            runtime_backend.finish(actor, "EnableInput-failed")
            pcall(function() actor:K2_DestroyActor() end)
            return false, "dedicated actor EnableInput failed: "
                .. tostring(enable_error)
        end

        controller.active_actor_address = address
        controller.active = true
        controller.primary_locked = false
        controller.camera_snap_blocked = false
        log("blueprint placement dedicated input entered actor="
            .. object_name(actor) .. " address=" .. tostring(address)
            .. " CommonUI=current-instance")
        return true, nil, actor
    end

    destroy_input_actor = function(address, reason)
        if address == nil then return true end
        local actor = resolve_active_actor(address)
        if not is_valid_object(actor) then
            log("blueprint placement dedicated input cleanup: actor already invalid reason="
                .. tostring(reason) .. " address=" .. tostring(address))
            return true
        end

        local disable_ok = disable_input_actor(address, reason)
        runtime_backend.finish(actor, reason)
        local destroy_ok, destroy_error = pcall(function()
            actor:K2_DestroyActor()
        end)
        log("blueprint placement dedicated input exited reason="
            .. tostring(reason) .. " disableOk=" .. tostring(disable_ok)
            .. " destroyOk=" .. tostring(destroy_ok)
            .. (destroy_ok and "" or " destroyError=" .. tostring(destroy_error)))
        return disable_ok and destroy_ok
    end

    function controller.exit(reason, options)
        options = type(options) == "table" and options or {}
        local defer_native_cleanup = options.defer_native_cleanup == true
        local address = controller.active_actor_address
        controller.primary_locked = true
        local active_actor = resolve_active_actor(address)
        if is_valid_object(active_actor) then
            end_camera_hold(
                active_actor,
                active_actor,
                "placement-input-exit:" .. tostring(reason)
            )
            runtime_backend.set_tick_paused(active_actor, true)
        end
        controller.camera_snap_blocked = false
        local widget_restored = restore_session_widget_actions(
            active_actor, reason
        )
        -- The Blueprint input event consumes LMB before it reaches Lua. Merely
        -- clearing controller.active cannot release ordinary building input.
        -- Disable the actor synchronously while its current-world identity is
        -- still available; defer only K2_DestroyActor when exiting a reflected
        -- hook stack.
        local disable_ok = disable_input_actor(address, reason)
        controller.active = false
        controller.active_actor_address = nil
        remember_retired_actor(address)

        if defer_native_cleanup then
            local scheduled, schedule_error = schedule_cleanup(
                "placement-input-exit:" .. tostring(reason), function()
                    if destroy_input_actor(address, reason) then
                        forget_retired_actor(address)
                    end
                end
            )
            if scheduled ~= true then
                log("blueprint placement dedicated input destroy scheduling failed reason="
                    .. tostring(reason) .. " error="
                    .. tostring(schedule_error))
            end
            return disable_ok and widget_restored
        end
        local destroyed = destroy_input_actor(address, reason)
        if destroyed then forget_retired_actor(address) end
        return disable_ok and destroyed and widget_restored
    end

    function controller.abandon_world(reason)
        if type(abandon_camera_hold) == "function" then
            pcall(abandon_camera_hold)
        end
        -- The old input Actor belongs to the world that is being torn down.
        -- Never resolve, DisableInput or destroy it from the new world.
        controller.primary_locked = true
        controller.active = false
        controller.active_actor_address = nil
        controller.camera_snap_blocked = false
        controller.retired_actor_addresses = {}
        runtime_backend.abandon_world(reason)
        return true
    end

    function controller.set_primary_locked(locked)
        controller.primary_locked = locked == true
    end

    function controller.with_active_session(callback)
        if type(callback) ~= "function" then
            return false, "placement session callback is required"
        end
        if not controller.active then
            return false, "placement input is inactive"
        end
        local actor = resolve_active_actor(controller.active_actor_address)
        if not is_valid_object(actor)
            or not runtime_backend.is_current_session(actor) then
            return false, "current placement session is unavailable"
        end
        return true, callback(actor)
    end

    function controller.set_tick_paused(paused)
        if not controller.active then
            return false, "placement input is inactive"
        end
        local actor = resolve_active_actor(controller.active_actor_address)
        if not is_valid_object(actor) then
            return false, "current placement session is unavailable"
        end
        return runtime_backend.set_tick_paused(actor, paused == true)
    end

    function controller.is_camera_active()
        if not controller.active then return false end
        local actor = resolve_active_actor(
            controller.active_actor_address
        )
        return is_valid_object(actor)
            and is_camera_hold_active(actor)
    end

    function controller.is_primary_locked()
        return controller.primary_locked == true
    end

    return controller
end

return BlueprintPlacementInput

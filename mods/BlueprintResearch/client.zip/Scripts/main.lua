local UEHelpers = require("UEHelpers")
package.path = ".\\Mods\\BlueprintResearch\\Scripts\\?.lua;" .. package.path
BlueprintWavePlanner = require("BlueprintWavePlanner")
BlueprintSupportGate = require("BlueprintSupportGate")
BlueprintExternalSupportMatcher =
    require("BlueprintExternalSupportMatcher")
BlueprintRpcSender = require("BlueprintRpcSender")
BlueprintBuildSessionRuntime = require("BlueprintBuildSessionRuntime")
BlueprintResearchSettings = require("BlueprintResearchSettings")
BlueprintJsonSchema = require("BlueprintJsonSchema")
BlueprintTransport = require("BlueprintTransport")
BlueprintMaterialGate = require("BlueprintMaterialGate")
BlueprintSelectionHUD = require("BlueprintSelectionHUD")
BlueprintSelectionHUDData = require("BlueprintSelectionHUDData")
BlueprintSelectionHUDMaterials = require("BlueprintSelectionHUDMaterials")
BlueprintSelectionHUDKeyGuides = require("BlueprintSelectionHUDKeyGuides")
BlueprintPlacementHUDMaterials = require("BlueprintPlacementHUDMaterials")
BlueprintPlacementHUDKeyGuides = require("BlueprintPlacementHUDKeyGuides")
BlueprintSelectionInput = require("BlueprintSelectionInput")
BlueprintPlacementInput = require("BlueprintPlacementInput")
BlueprintPlacementCamera = require("BlueprintPlacementCamera")
BlueprintSelectionSession = require("BlueprintSelectionSession")
BlueprintClipboard = require("BlueprintClipboard")
BlueprintRuntimeUtils = require("BlueprintRuntimeUtils")
BlueprintLog = require("BlueprintLog")
BlueprintModeUI = require("BlueprintModeUI")
BlueprintSelectionData = require("BlueprintSelectionData")
BlueprintSelectionModeRuntime = require("BlueprintSelectionMode")
BlueprintRegionPreview = require("BlueprintRegionPreview")
BlueprintSelectionVisual = require("BlueprintSelectionVisual")
BlueprintOverlapQuery = require("BlueprintOverlapQuery")
BlueprintBlockerVisual = require("BlueprintBlockerVisual")
BlueprintGhostRenderer = require("BlueprintGhostRenderer")
BlueprintWaveGhostRenderer = require("BlueprintWaveGhostRenderer")
BlueprintRegionGeometry = require("BlueprintRegionGeometry")
BlueprintSelectionTarget = require("BlueprintSelectionTarget")
BlueprintBuildEquivalence = require("BlueprintBuildEquivalence")
BlueprintUserMessage = require("BlueprintUserMessage")
BlueprintLocalization = require("BlueprintLocalization")
BlueprintCallbackScheduler = require("BlueprintCallbackScheduler")
BlueprintWorldLifecycle = require("BlueprintWorldLifecycle")
BlueprintPerformance = require("BlueprintPerformance")
BlueprintBuildQueueProbe = require("BlueprintBuildQueueProbe")
BlueprintOverlapTiming = require("BlueprintOverlapTiming")
BlueprintLibraryRuntime = require("BlueprintLibraryRuntime")
BlueprintLibraryManager = require("BlueprintLibraryManager")
BlueprintThumbnailRenderer = require("BlueprintThumbnailRenderer")
BlueprintNameDialog = require("BlueprintNameDialog")
BlueprintLibraryUI = require("BlueprintLibraryUI")
BlueprintConfirmDialog = require("BlueprintConfirmDialog")
BlueprintNativeUIStack = require("BlueprintNativeUIStack")
BlueprintWaterBuildingGate = require("BlueprintWaterBuildingGate")
BlueprintRuntimeBridge = require("BlueprintRuntimeBridge")
BlueprintPlacementRuntimeBackend =
    require("BlueprintPlacementRuntimeBackend")
BlueprintPlacementSessionComponents =
    require("BlueprintPlacementSessionComponents")
BlueprintPlacementOverlapSnapshot =
    require("BlueprintPlacementOverlapSnapshot")
BlueprintNativeOverlapGate =
    require("BlueprintNativeOverlapGate")
BlueprintStockVisualProbe =
    require("BlueprintStockVisualProbe")
BlueprintPlacementAnchorProbe =
    require("BlueprintPlacementAnchorProbe")

local TAG = "[BlueprintResearch]"
local blueprint_clipboard = nil
local selected_buildings_by_instance = {}
local selected_building_order = {}
local selected_anchor_instance_id = nil
local region_start_instance_id = nil
local region_end_instance_id = nil
local region_start_actor = nil
local region_end_actor = nil
local region_start_record = nil
local region_end_record = nil
local selection_builder = nil
local refresh_region_preview_for_target = nil
local prepare_region_preview = nil
local blueprint_selection_session = nil
local blueprint_selection_camera = nil
local get_build_object_instance_id = nil
local blueprint_preview_active = false
local blueprint_preview_anchor_build_object_id = nil
local blueprint_preview_wait_ticks = 0
local blueprint_preview_last_anchor_transform = nil
local blueprint_preview_all_placeable = false
local blueprint_preview_overlap_count = 0
local blueprint_preview_water_block_count = 0
local blueprint_preview_water_gate_unavailable = false
local blueprint_preview_water_capability = nil
local blueprint_preview_validation_signature = nil
local blueprint_preview_validation_dirty = false
local blueprint_preview_validation_cooldown_ticks = 0
blueprint_preview_validation_revision = 0
blueprint_native_overlap_pending_revision = nil
blueprint_native_overlap_completed_revision = nil
blueprint_native_overlap_last_report = nil
local blueprint_continuous_placement_requested = false
local blueprint_continuous_unlock_pending = false
local blueprint_continuous_next_anchor_seen = false
local blueprint_preview_building_model_address = nil
local blueprint_preview_network_component_handle = nil
local blueprint_preview_attached_anchor_address = nil
local blueprint_preview_anchor_correction_signature = nil
local blueprint_preview_anchor_frame_corrected = false
local blueprint_start_build_forward_in_progress = false
local handle_blueprint_placement_primary_action = nil
handle_blueprint_placement_session_tick = nil
blueprint_preview_session_tick_in_progress = false
blueprint_placement_runtime_backend = nil
blueprint_placement_input = nil
blueprint_placement_camera = nil
blueprint_native_overlap_gate = nil
local blueprint_commit_queued = false
local blueprint_build_transaction_sequence = 0
local blueprint_build_jobs_by_id = {}
local blueprint_build_job_count = 0
local blueprint_network_dispatch_guard = false
local blueprint_rpc_sender = BlueprintRpcSender.new({
    world_generation = 0,
})
local blueprint_rpc_dispatch_sequence = 0
local MAX_BLUEPRINT_QUERY_BUILDINGS =
    BlueprintResearchSettings.get_blueprint_collision_query_component_limit()
local BLUEPRINT_WORLD_SNAP_RANGE_CM =
    BlueprintResearchSettings.get_world_coordinate_snap_range_cm()
-- Diagnostic build switch. While enabled, settled and click-time overlap
-- validation scan every blueprint member so timings always describe the full
-- overlap gate even when the user's normal fast-gate setting is off.
local ENABLE_OVERLAP_TIMING_PROBE =
    BlueprintResearchSettings.get_log_probes()
-- Preview meshes are attached to the stock anchor and therefore move through
-- Unreal's native component hierarchy every rendered frame. The Lua-facing
-- Placement Session Tick is only a 4 Hz business monitor. Preview meshes move
-- through Unreal's native component hierarchy every rendered frame. Keep
-- overlap validation dormant while the anchor moves, then require four
-- unchanged monitor ticks (about one second) before one settled pass.
-- The primary-action path still performs a final synchronous validation.
local BLUEPRINT_VALIDATION_INTERVAL_TICKS = 4
-- Palworld's stock snapped preview can jitter by tiny floating-point amounts
-- even while it remains in the same authored connector slot. Treat those
-- changes as one business placement so settled validation is cached. Free
-- placement still moves far beyond these tolerances and therefore continues
-- to debounce until the anchor actually stops.
BlueprintAnchorSettle = {
    position_tolerance_cm = 0.5,
    rotation_tolerance_degrees = 0.05,
    scale_tolerance = 0.001,
    angular_distance_degrees = function(first, second)
        local distance = math.abs((first - second) % 360.0)
        if distance > 180.0 then distance = 360.0 - distance end
        return distance
    end,
}

-- Builder/checker/anchor references are owned by the current UE Placement
-- Session. Their reflected source chain only needs a slow lifecycle audit;
-- reading it every monitor tick previously consumed tens of milliseconds.
local BLUEPRINT_PLACEMENT_LIFECYCLE_AUDIT_TICKS = 8
BlueprintWaveRuntime = {
    blueprint_schema_version = 9,
    connection_schema_version = 1,
    request_settle_delay_ms = 150,
    wave_settle_delay_ms = 450,
    request_timeout_ms = 5000,
    wave_ghost_cleanup_batch = 8,
    external_support_location_tolerance = 35.0,
    external_support_rotation_dot_min = 0.9985,
    result_location_tolerance = 100.0,
    scheduled_callbacks = {},
    scheduled_callback_sequence = 0,
    world_generation = 0,
    preview_first_tick_pending = false,
    preview_session_tick_count = 0,
}

get_build_queue_probe = nil
record_build_queue_ms = nil
record_build_queue_elapsed = nil
stamp_build_queue_request = nil
record_build_queue_interval = nil
build_queue_request_context = nil

BUILD_QUEUE_PREPARE_PHASES = {
    "primary_input_lock",
    "click_validation",
    "material_gate",
    "session_reference_read",
    "anchor_transform_snapshot",
    "submission_network_resolve",
    "submit_click_prequeue",
    "submit_request_snapshot",
    "preplan_setup",
    "initial_roots",
    "root_expectation_prepare",
    "root_query",
    "root_snapshot",
    "root_index_match",
    "wave_planner",
    "visual_snapshot",
    "transaction_state_setup",
    "session_actor_begin",
    "foreground_preview_unlock",
    "visual_timer_arm",
    "submit_total",
}
BUILD_QUEUE_DISPATCH_PHASES = {
    "request_produce",
    "sender_enqueue",
    "sender_pump_entry",
    "sender_pump_work",
    "sender_begin_next",
    "network_resolve",
    "timeout_timer_arm",
    "dispatch_log",
    "request_name_prepare",
    "rpc_call",
    "session_actor_hint",
    "session_actor_resolve",
    "session_timer_library",
    "session_timer_clear",
    "session_timer_set",
    "session_status_write",
}
BUILD_QUEUE_COMPLETION_PHASES = {
    "server_result_route",
    "sender_complete",
    "result_callback_total",
    "result_bookkeeping",
    "outcome_log",
    "advance",
    "advance_timer_arm",
    "sender_repump_schedule",
    "session_pulse_callback",
    "session_wake",
    "wave_ghost_create",
    "ghost_request_dispose",
    "finish_schedule",
    "terminal_cancel_visual",
    "terminal_timer_arm",
    "terminal_state_cleanup",
    "terminal_ghost_hide",
    "terminal_user_message",
    "session_actor_destroy",
    "session_destroy_call",
    "terminal_finalize",
}
BUILD_QUEUE_LATENCY_PHASES = {
    "queue_wait_observed",
    "server_roundtrip_observed",
    "settle_timer_observed",
    "settle_timer_overrun",
}

BlueprintSelectionMode = {
    active = false,
    starting = false,
    finishing = false,
    session_id = 0,
    current_target = nil,
    current_target_address = nil,
    current_target_instance_id = nil,
    current_target_identity = nil,
    hover_entry = nil,
    action_target_override = nil,
    action_target_identity_override = nil,
    selection_session = nil,
    hud_widget = nil,
    builder = nil,
    player_controller = nil,
    player_pawn = nil,
    camera_manager = nil,
    tick_loop_handle = nil,
    tick_loop_session_id = nil,
    tick_loop_tick_count = 0,
    camera_hold_active = false,
    input_active = false,
    trace_range = 1000.0,
    effective_trace_range = 1000.0,
    hud_package_path = "/Game/Mods/BlueprintResearch/UI/" ..
        "WBP_BlueprintSelectionHUD",
    hud_class_path = "/Game/Mods/BlueprintResearch/UI/" ..
        "WBP_BlueprintSelectionHUD.WBP_BlueprintSelectionHUD_C",
    hud_asset_name = "WBP_BlueprintSelectionHUD",
    hud_class_name = "WBP_BlueprintSelectionHUD_C",
    hud_load_diagnostic_emitted = false,
    hud_name_widget_diagnostic_emitted = false,
}

local function refresh_selection_material_hud(reason)
    if type(BlueprintSelectionMode.refresh_hud_materials) ~= "function" then
        return false
    end
    local ok, result = pcall(
        BlueprintSelectionMode.refresh_hud_materials, reason
    )
    if not ok then
        log("selection material HUD refresh isolated error reason="
            .. tostring(reason) .. " error=" .. tostring(result))
        return false
    end
    return result == true
end

BlueprintSelectionInputBridge = {
    actor_class_name = "ModActor_C",
    actor_class_full_name =
        "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/ModActor.ModActor_C",
    function_path_prefix =
        "/Game/Mods/BlueprintResearch/ModActor.ModActor_C:",
    request_hooks = {},
    request_hook_callbacks = {},
}

local runtime_logger = BlueprintLog.install({
    tag = TAG,
    settings = BlueprintResearchSettings,
})
log = runtime_logger.log
log_required = runtime_logger.required
log_diagnostic = runtime_logger.diagnostic
log_probe = runtime_logger.probe
log_trace = runtime_logger.trace

get_build_queue_probe = function(transaction)
    local performance = type(transaction) == "table"
        and transaction.performance or nil
    return type(performance) == "table"
        and performance.build_queue_probe or nil
end

record_build_queue_ms = function(
    transaction, phase_name, elapsed_ms, context
)
    return BlueprintBuildQueueProbe.record_ms(
        get_build_queue_probe(transaction),
        phase_name, elapsed_ms, context
    )
end

record_build_queue_elapsed = function(
    transaction, phase_name, started_at, context
)
    return BlueprintBuildQueueProbe.record_elapsed(
        get_build_queue_probe(transaction),
        phase_name, started_at, context
    )
end

stamp_build_queue_request = function(request, stamp_name, at)
    return BlueprintBuildQueueProbe.stamp(request, stamp_name, at)
end

record_build_queue_interval = function(
    transaction, phase_name, request, start_stamp, end_stamp, context
)
    return BlueprintBuildQueueProbe.record_interval(
        get_build_queue_probe(transaction),
        phase_name, request, start_stamp, end_stamp, context
    )
end

build_queue_request_context = function(transaction, request)
    return string.format(
        "%d:%d:%d:%s",
        tonumber(transaction and transaction.id) or 0,
        math.max((tonumber(transaction
            and transaction.current_wave_number) or 1) - 1, 0),
        tonumber(transaction and transaction.current_member_number) or 0,
        tostring(request and request.build_object_id or "<none>")
    )
end

BlueprintCallbackScheduler.configure({ log = log })
unwrap = BlueprintRuntimeUtils.unwrap
value_to_string = BlueprintRuntimeUtils.value_to_string
object_name = BlueprintRuntimeUtils.object_name
is_valid_object = BlueprintRuntimeUtils.is_valid_object
is_usable_class_object = BlueprintRuntimeUtils.is_usable_class_object
class_object_name = BlueprintRuntimeUtils.class_object_name
safe_object_address = BlueprintRuntimeUtils.safe_object_address
find_valid_instance = BlueprintRuntimeUtils.find_valid_instance
find_valid_instance_by_address = BlueprintRuntimeUtils.find_valid_instance_by_address
safe_property = BlueprintRuntimeUtils.safe_property
format_number = BlueprintRuntimeUtils.format_number
format_vector = BlueprintRuntimeUtils.format_vector
format_quaternion = BlueprintRuntimeUtils.format_quaternion
format_transform = BlueprintRuntimeUtils.format_transform
copy_vector = BlueprintRuntimeUtils.copy_vector
copy_quaternion = BlueprintRuntimeUtils.copy_quaternion
copy_transform = BlueprintRuntimeUtils.copy_transform
restore_transform = BlueprintRuntimeUtils.restore_transform
get_asset_path = BlueprintRuntimeUtils.get_asset_path
copy_rotator = BlueprintRuntimeUtils.copy_rotator
format_guid = BlueprintRuntimeUtils.format_guid
get_actor_from_hit_result = BlueprintRuntimeUtils.get_actor_from_hit_result

local blueprint_stock_visual_probe = BlueprintStockVisualProbe.install({
    enabled = BlueprintResearchSettings.get_log_probes(),
    log = log,
    log_probe = log_probe,
    register_hook = RegisterHook,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    safe_object_address = safe_object_address,
    object_name = object_name,
})
blueprint_placement_anchor_probe = BlueprintPlacementAnchorProbe.install({
    enabled = BlueprintResearchSettings.get_log_probes(),
    log_probe = log_probe,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    safe_object_address = safe_object_address,
    object_name = object_name,
    value_to_string = value_to_string,
    format_transform = format_transform,
    format_vector = format_vector,
    get_math_library = UEHelpers.GetKismetMathLibrary,
})

local function make_runtime_object_handle(value)
    value = unwrap(value)
    if not is_valid_object(value) then return nil end
    local path = get_asset_path(value)
    local address = safe_object_address(value)
    if type(path) ~= "string" or path == "" or address == nil then
        return nil
    end
    return {
        path = path,
        address = address,
        world_generation = BlueprintCallbackScheduler.get_world_generation(),
    }
end

local function resolve_runtime_object_handle(handle)
    if type(handle) ~= "table" or type(handle.path) ~= "string"
        or handle.address == nil then
        return nil
    end
    if handle.world_generation
        ~= BlueprintCallbackScheduler.get_world_generation() then
        return nil
    end
    local ok, value = pcall(StaticFindObject, handle.path)
    value = ok and unwrap(value) or nil
    if not is_valid_object(value)
        or safe_object_address(value) ~= handle.address then
        return nil
    end
    return value
end

local function find_current_world_network_player_component()
    local current_world = unwrap(UEHelpers.GetWorld())
    local current_world_address = safe_object_address(current_world)
    if current_world_address == nil then
        return nil, "current World identity is unavailable"
    end

    -- Every PalPlayerController owns its own replicated NetworkTransmitter.
    -- A remote client can see more than one PalNetworkPlayerComponent in the
    -- current World, so choosing the first FindAllOf result may invoke a
    -- server RPC on an Actor that is not owned by the local connection. UE
    -- accepts that local UFunction call but silently drops the network RPC.
    local controller = unwrap(UEHelpers.GetPlayerController())
    if not is_valid_object(controller) then
        return nil, "local PlayerController is unavailable"
    end
    local controller_world = nil
    pcall(function()
        controller_world = unwrap(controller:GetWorld())
    end)
    if safe_object_address(controller_world) ~= current_world_address then
        return nil, "local PlayerController belongs to another World"
    end

    local local_check_ok, is_local_controller = pcall(function()
        return controller:IsLocalPlayerController()
    end)
    if local_check_ok and is_local_controller ~= true then
        return nil, "resolved PlayerController is not local"
    end

    local transmitter = unwrap(safe_property(controller, "Transmitter"))
    if not is_valid_object(transmitter) then
        return nil, "local PlayerController Transmitter is unavailable"
    end
    local transmitter_world = nil
    pcall(function()
        transmitter_world = unwrap(transmitter:GetWorld())
    end)
    if safe_object_address(transmitter_world) ~= current_world_address then
        return nil, "local NetworkTransmitter belongs to another World"
    end

    local network = nil
    local get_player_ok, get_player_error = pcall(function()
        network = unwrap(transmitter:GetPlayer())
    end)
    if not get_player_ok or not is_valid_object(network) then
        network = unwrap(safe_property(transmitter, "Player"))
    end
    if not is_valid_object(network) then
        return nil, "local NetworkTransmitter Player component is unavailable: "
            .. tostring(get_player_error)
    end
    local network_world = nil
    pcall(function()
        network_world = unwrap(network:GetWorld())
    end)
    if safe_object_address(network_world) ~= current_world_address then
        return nil, "local PalNetworkPlayerComponent belongs to another World"
    end

    local owner = nil
    pcall(function()
        owner = unwrap(network:GetOwner())
    end)
    if not is_valid_object(owner)
        or safe_object_address(owner) ~= safe_object_address(transmitter) then
        return nil, "PalNetworkPlayerComponent owner is not the local Transmitter"
    end

    return network, nil, {
        controller = controller,
        transmitter = transmitter,
        owner = owner,
    }
end

local function capture_blueprint_preview_network_handle()
    local network, network_error, route =
        find_current_world_network_player_component()
    if not is_valid_object(network) then
        blueprint_preview_network_component_handle = nil
        return false, network_error
    end
    local handle = make_runtime_object_handle(network)
    if handle == nil then
        blueprint_preview_network_component_handle = nil
        return false, "network component runtime identity is unavailable"
    end
    blueprint_preview_network_component_handle = handle
    log_required(
        "blueprint local RPC route captured controller="
            .. object_name(route and route.controller)
            .. " transmitter=" .. object_name(route and route.transmitter)
            .. " component=" .. object_name(network)
    )
    return true, nil
end

local function make_selection_entry(actor, record)
    actor = unwrap(actor)
    if type(record) ~= "table"
        or record.source_instance_id == nil
        or not is_valid_object(actor) then
        return nil
    end
    return {
        actor = actor,
        record = record,
    }
end

function make_current_selection_identity_record(target, source)
    target = unwrap(target)
    if not is_valid_object(target) then return nil end

    local target_address = safe_object_address(target)
    local identity = nil
    if BlueprintSelectionMode.active == true then
        local override = unwrap(BlueprintSelectionMode.action_target_override)
        if is_valid_object(override)
            and safe_object_address(override) == target_address then
            identity = BlueprintSelectionMode.action_target_identity_override
        elseif BlueprintSelectionMode.current_target_address
            == target_address then
            identity = BlueprintSelectionMode.current_target_identity
        end
    end
    if type(identity) ~= "table" then
        identity = get_build_object_identity(target)
    end
    local record = make_selection_identity_record(identity, source)
    if record == nil then
        log("selection identity unavailable source=" .. tostring(source)
            .. " target=" .. object_name(target))
    end
    return record
end

local function resolve_selection_entry_actor(entry)
    if type(entry) ~= "table" then return nil end
    return unwrap(entry.actor)
end

local function get_region_start_actor()
    return unwrap(region_start_actor)
end

local function get_region_end_actor()
    return unwrap(region_end_actor)
end

function with_active_placement_session(callback)
    if blueprint_placement_input == nil
        or type(blueprint_placement_input.with_active_session)
            ~= "function" then
        return false, "placement session controller is unavailable"
    end
    return blueprint_placement_input.with_active_session(callback)
end

function get_current_placement_reference(property_name)
    local result = nil
    local ok = with_active_placement_session(function(session)
        result = unwrap(safe_property(session, property_name))
    end)
    if not ok then return nil end
    return result
end

function update_current_placement_reference(reference_name, value)
    local updated = false
    local update_error = nil
    local active, active_error = with_active_placement_session(
        function(session)
            updated, update_error =
                blueprint_placement_runtime_backend.update_reference(
                    session, reference_name, value
                )
        end
    )
    if not active then return false, active_error end
    return updated, update_error
end

local function get_blueprint_preview_builder()
    return get_current_placement_reference(
        "SBB_PlacementBuilder"
    )
end

function get_blueprint_preview_anchor()
    return get_current_placement_reference("SBB_PlacementAnchor")
end

local blueprint_localization = BlueprintLocalization.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    value_to_string = value_to_string,
    decode_blueprint_code = BlueprintClipboard.decode_text,
})

local blueprint_user_message = BlueprintUserMessage.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
})

local blueprint_water_building_gate = BlueprintWaterBuildingGate.install({
    UEHelpers = UEHelpers,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    value_to_string = value_to_string,
    find_object = StaticFindObject,
    make_name = FName,
})

-- Preserve the established dependency name while routing presentation through
-- Palworld's local HUD instead of the chat/system-announce channel.
local function send_blueprint_announce(message, requested_kind)
    return blueprint_user_message.show(message, requested_kind)
end

local function send_blueprint_message(message_key, ...)
    local message, kind = blueprint_localization.message(message_key, ...)
    return blueprint_user_message.show(message, kind)
end

BlueprintClipboard.install({
    unwrap = unwrap,
    is_valid_object = is_valid_object,
})
export_blueprint_to_system_clipboard = BlueprintClipboard.export
read_system_clipboard_text = BlueprintClipboard.read_text
import_blueprint_from_system_clipboard = BlueprintClipboard.import
encode_blueprint_for_library = BlueprintClipboard.encode
decode_blueprint_text = BlueprintClipboard.decode_text
copy_blueprint_text_to_system_clipboard = BlueprintClipboard.copy_text

blueprint_library_manager = BlueprintLibraryManager.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    is_usable_class_object = is_usable_class_object,
    value_to_string = value_to_string,
    scheduler = BlueprintCallbackScheduler,
})
local blueprint_library_runtime = BlueprintLibraryRuntime.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    value_to_string = value_to_string,
    decode_blueprint_code = BlueprintClipboard.decode_text,
    get_blueprint_library_directory = function()
        return BlueprintResearchSettings.get_blueprint_library_directory()
    end,
    resource_manager = blueprint_library_manager,
})
local blueprint_thumbnail_renderer = BlueprintThumbnailRenderer.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    object_name = object_name,
    restore_transform = restore_transform,
})
local blueprint_name_dialog = BlueprintNameDialog.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_object_address = safe_object_address,
    value_to_string = value_to_string,
    get_player_controller = function()
        if type(BlueprintSelectionInputBridge.get_local_player_controller)
            ~= "function" then
            return nil
        end
        return BlueprintSelectionInputBridge.get_local_player_controller()
    end,
    localize = blueprint_localization.text,
    validate_name = function(value)
        return blueprint_library_runtime.store.validate_name(value)
    end,
    show_error = function(message_key, detail)
        send_blueprint_message(message_key, detail)
    end,
})
BlueprintCallbackScheduler.game_thread(
    2500, "blueprint-library-initialize", function()
        blueprint_library_runtime.initialize()
    end, { survive_world = true }
)

BlueprintSelectionData.install({ log = log })
BlueprintTypeRuntimeCache = BlueprintSelectionData.type_runtime_cache
get_build_object_identity =
    BlueprintSelectionData.get_build_object_identity
make_selection_identity_record =
    BlueprintSelectionData.make_identity_record
make_building_record = BlueprintSelectionData.make_building_record
capture_connector_connections = BlueprintSelectionData.capture_connector_connections
capture_connector_index_set =
    BlueprintSelectionData.capture_connector_index_set
collect_build_object_meshes = BlueprintSelectionData.collect_build_object_meshes
capture_preview_mesh_descriptors = BlueprintSelectionData.capture_preview_mesh_descriptors
capture_overlap_descriptor = BlueprintSelectionData.capture_overlap_descriptor
blueprint_identity_transform = BlueprintSelectionData.blueprint_identity_transform
make_blueprint_type_template = BlueprintSelectionData.make_blueprint_type_template
cache_blueprint_type_template = BlueprintSelectionData.cache_blueprint_type_template
resolve_blueprint_build_class = BlueprintSelectionData.resolve_blueprint_build_class
hydrate_blueprint_type_template_from_cdo = BlueprintSelectionData.hydrate_blueprint_type_template_from_cdo
ensure_blueprint_type_templates = BlueprintSelectionData.ensure_blueprint_type_templates

local function snapshot_blueprint_type_templates(compact_blueprint)
    local snapshot = {}
    if type(compact_blueprint) ~= "table"
        or type(compact_blueprint.t) ~= "table" then
        return snapshot
    end
    for _, build_object_id in ipairs(compact_blueprint.t) do
        local template = BlueprintTypeRuntimeCache[build_object_id]
        if type(template) == "table" then
            snapshot[build_object_id] =
                BlueprintJsonSchema.copy_type_template(template)
        end
    end
    return snapshot
end

local function restore_blueprint_type_templates(type_templates)
    if type(type_templates) ~= "table" then return 0 end
    local restored = 0
    for build_object_id, template in pairs(type_templates) do
        if type(build_object_id) == "string" and type(template) == "table"
            and template.build_object_id == build_object_id then
            local normalized = make_blueprint_type_template(template)
            if normalized ~= nil then
                BlueprintTypeRuntimeCache[build_object_id] = normalized
                restored = restored + 1
            end
        end
    end
    return restored
end

local selection_target = BlueprintSelectionTarget.install({
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    format_guid = format_guid,
    find_valid_instance = find_valid_instance,
    get_selection_mode = function() return BlueprintSelectionMode end,
    get_independent_target = function()
        return BlueprintSelectionMode.action_target_override
            or BlueprintSelectionMode.current_target
    end,
})
local get_dismantle_target_from_builder = selection_target.get_dismantle_target
local get_paint_target_from_builder = selection_target.get_paint_target
get_build_object_instance_id = selection_target.get_instance_id
local is_original_dismantle_mode_active = selection_target.is_dismantle_active
local is_original_paint_mode_active = selection_target.is_paint_active
local get_original_selection_host_mode = selection_target.get_host_mode
local is_original_selection_host_mode_active = selection_target.is_host_mode_active
local get_current_selection_target = selection_target.get_current

blueprint_selection_session = BlueprintSelectionSession.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    is_usable_class_object = is_usable_class_object,
    safe_property = safe_property,
    safe_object_address = safe_object_address,
    object_name = object_name,
    get_asset_path = get_asset_path,
    copy_transform = copy_transform,
    get_build_object_instance_id = get_build_object_instance_id,
    get_actor_from_hit_result = get_actor_from_hit_result,
    performance_now = BlueprintPerformance.now,
    performance_elapsed_ms = BlueprintPerformance.elapsed_ms,
    is_probe_logging_enabled =
        BlueprintResearchSettings.get_log_probes,
    on_target_changed = function(_, target)
        if type(BlueprintSelectionMode.accept_session_target)
            == "function" then
            BlueprintSelectionMode.accept_session_target(
                target, "ue-selection-session"
            )
        end
    end,
    on_camera_stock_exit = function(camera)
        if blueprint_selection_camera == nil then return end
        blueprint_selection_session.with_session(
            function(session)
                if blueprint_selection_camera.matches_camera(
                    session, camera
                ) then
                    local input_actor =
                        BlueprintSelectionInputBridge.find_actor(
                            BlueprintSelectionInputBridge
                                .get_local_player_controller()
                        )
                    blueprint_selection_camera.exit(
                        session,
                        input_actor,
                        "selection-camera-stock-exit"
                    )
                    BlueprintSelectionMode.camera_hold_active = false
                end
            end
        )
    end,
})

blueprint_selection_camera = BlueprintPlacementCamera.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    is_usable_class_object = is_usable_class_object,
    safe_property = safe_property,
    get_local_player_controller = function()
        return BlueprintSelectionInputBridge.get_local_player_controller()
    end,
    runtime_backend = {
        is_current_session = function(session)
            return blueprint_selection_session.is_current_session(session)
        end,
        set_tick_paused = function(session, paused)
            return blueprint_selection_session.set_tick_paused(
                paused == true, session
            )
        end,
    },
    property_names = {
        camera = "SBB_SelectionCamera",
        camera_active = "SBB_SelectionCameraActive",
        camera_class = "SBB_SelectionCameraClass",
    },
    get_frozen_anchor = function(session)
        -- Selection has no moving placement anchor. Pausing the Session Tick
        -- freezes the ray target; the camera Actor still requires an Actor
        -- transform snapshot, so the Session itself is the inert anchor.
        return session
    end,
    runtime_label = "blueprint selection",
    send_message = send_blueprint_message,
    on_restored = function(reason)
        BlueprintSelectionMode.camera_hold_active = false
        if type(BlueprintSelectionMode.resume_target_after_camera)
            == "function" then
            BlueprintSelectionMode.resume_target_after_camera(reason)
        end
    end,
})

local selection_visual = BlueprintSelectionVisual.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    safe_object_address = safe_object_address,
    object_name = object_name,
    find_valid_instance = find_valid_instance,
    get_asset_path = get_asset_path,
    collect_build_object_meshes = collect_build_object_meshes,
    get_build_object_instance_id = get_build_object_instance_id,
    get_selected_entry = function(instance_id)
        return selected_buildings_by_instance[instance_id]
    end,
    get_selected_anchor_instance_id = function()
        return selected_anchor_instance_id
    end,
    is_selection_active = function()
        return BlueprintSelectionMode.active == true
    end,
    get_selection_session = function()
        return BlueprintSelectionMode.selection_session
    end,
})
local get_original_anchor_material = selection_visual.get_anchor_material
local legacy_try_set_selection_visual = selection_visual.try_set
local legacy_repair_selected_entry_visual = selection_visual.repair
local legacy_flash_selection_serialization_errors =
    selection_visual.flash_serialization_errors
local function try_set_selection_visual(entry, enabled, requested_role)
    if blueprint_selection_session ~= nil
        and type(
            blueprint_selection_session.apply_actor_visual_role
        ) == "function"
        and entry ~= nil
        and is_valid_object(unwrap(entry.actor)) then
        -- A click acts on the Actor that is already carrying the transient
        -- ray-hover role. Keep that role visually dominant while Lua updates
        -- the persistent selected/anchor state. Replacing the same Actor's
        -- materials with normal, persistent, then hover again in one callback
        -- caused three render-state rebuilds for a single input action.
        if BlueprintSelectionMode.active == true
            and BlueprintSelectionMode.preserve_hover_visual_during_action
                == true
            and safe_object_address(unwrap(entry.actor))
                == BlueprintSelectionMode.current_target_address
            and requested_role ~= "hover" then
            return 0, "<ue-session:hover-preserved>", true, {
                skipped = true,
                reason = "hover-preserved",
            }
        end
        local role = requested_role
        if enabled ~= true then
            role = "normal"
        elseif role == nil then
            local instance_id = entry.record ~= nil
                and entry.record.source_instance_id or nil
            if entry.serialization_error_flash_active == true then
                role = "serialization-error"
            elseif instance_id ~= nil
                and instance_id == selected_anchor_instance_id then
                role = "anchor"
            else
                role = "selected"
            end
        end
        local role_id = role == "normal" and 0
            or role == "hover" and 1
            or role == "selected" and 2
            or role == "anchor" and 3
            or role == "serialization-error" and 4
            or nil
        if role_id ~= nil then
            local apply_ok, applied, _, visual_metrics = pcall(
                blueprint_selection_session.apply_actor_visual_role,
                entry.actor,
                role_id,
                BlueprintSelectionMode.selection_session
            )
            if apply_ok and applied == true then
                return 1, "<ue-session:" .. tostring(role) .. ">", true,
                    visual_metrics
            end
        end
    end
    return legacy_try_set_selection_visual(
        entry, enabled, requested_role
    )
end
local function try_set_native_hover_visual(actor, enabled)
    if blueprint_selection_session == nil
        or type(blueprint_selection_session.set_hover_actor)
            ~= "function" then
        return false
    end
    local ok, applied, _, visual_metrics = pcall(
        blueprint_selection_session.set_hover_actor,
        actor,
        enabled == true,
        BlueprintSelectionMode.selection_session
    )
    return ok and applied == true, visual_metrics
end
local function repair_selected_entry_visual(entry, source)
    return legacy_repair_selected_entry_visual(entry, source)
end
local function flash_selection_serialization_errors(instance_ids)
    return legacy_flash_selection_serialization_errors(instance_ids)
end
local observe_dismantle_target_transition = selection_visual.observe_dismantle_target
local reset_selection_visual_observer = selection_visual.reset_observer

BlueprintSelectionAsync = BlueprintSelectionAsync or {}
BlueprintSelectionAsync.next_job_id = BlueprintSelectionAsync.next_job_id or 0
BlueprintSelectionAsync.region_job = BlueprintSelectionAsync.region_job or nil
BlueprintSelectionAsync.slice_delay_ms = 16
BlueprintSelectionAsync.region_max_batch = 16
BlueprintSelectionAsync.region_slice_budget_ms = 2.5

local function release_region_job_references(job)
    if type(job) ~= "table" then return end
    job.actors = nil
    job.start_actor = nil
    job.end_actor = nil
    job.start_record = nil
    job.end_record = nil
    job.start_transform = nil
end

local function clear_selection_visuals()
    local performance_started_at = BlueprintPerformance.now()
    local selected_count = #selected_building_order
    local restored_slots = 0
    local failed_entries = 0

    -- Restore only the cached mesh/material pairs that were changed while the
    -- buildings were selected.  Do not scan the world or enqueue delayed work:
    -- those callbacks share UE4SS's EngineTick dispatcher with the blueprint
    -- ghost preview and can outlive the paint-mode widget that created them.
    for _, instance_id in ipairs(selected_building_order) do
        local entry = selected_buildings_by_instance[instance_id]
        if entry ~= nil then
            local changed, _, visual_ok = try_set_selection_visual(entry, false)
            restored_slots = restored_slots + (tonumber(changed) or 0)
            if not visual_ok then
                failed_entries = failed_entries + 1
            end
            entry.actor = nil
            entry.visual_material_states = nil
        end
    end

    if failed_entries > 0 then
        log(string.format(
            "selection visual teardown restore error selected=%d restoredSlots=%d restoreErrors=%d worldScan=false delayedCallbacks=false",
            selected_count, restored_slots, failed_entries
        ))
    end
    local elapsed_ms = BlueprintPerformance.elapsed_ms(performance_started_at)
    return elapsed_ms, restored_slots
end

local clear_region_preview_box = nil

local function clear_region_corners()
    local old_start = region_start_instance_id
    local old_end = region_end_instance_id
    clear_region_preview_box()
    region_start_instance_id = nil
    region_end_instance_id = nil
    region_start_actor = nil
    region_end_actor = nil
    region_start_record = nil
    region_end_record = nil
    return old_start, old_end
end

local function clear_pending_selection()
    if BlueprintSelectionAsync.region_job ~= nil then
        local cancelled_job = BlueprintSelectionAsync.region_job
        cancelled_job.cancelled = true
        BlueprintSelectionAsync.region_job = nil
        release_region_job_references(cancelled_job)
        log("region selection async cancelled by selection clear job="
            .. tostring(cancelled_job.id))
    end
    local visual_clear_ms, restored_slots = clear_selection_visuals()
    selected_buildings_by_instance = {}
    selected_building_order = {}
    selected_anchor_instance_id = nil
    if blueprint_selection_session ~= nil then
        blueprint_selection_session.set_anchor(nil)
    end
    clear_region_corners()
    selection_builder = nil
    reset_selection_visual_observer(true)
    refresh_selection_material_hud("selection-cleared")
    return visual_clear_ms, restored_slots
end

local function has_pending_selection_state()
    return #selected_building_order > 0
        or next(selected_buildings_by_instance) ~= nil
        or selected_anchor_instance_id ~= nil
        or region_start_instance_id ~= nil
        or region_end_instance_id ~= nil
        or region_start_record ~= nil
        or region_end_record ~= nil
        or selection_builder ~= nil
end

local selection_clear_scheduled = false
local selection_clear_reason = nil

local function schedule_pending_selection_clear(reason)
    if not has_pending_selection_state() then return false end
    selection_clear_reason = tostring(reason or "original-mode-transition")
    if selection_clear_scheduled then return true end
    selection_clear_scheduled = true
    -- Original-mode hooks are pre-hooks.  Do not perform UObject/property work
    -- while the original UI model is in its teardown call stack: UE4SS cannot
    -- contain a native access violation with Lua pcall.  Run once, immediately
    -- after that stack has unwound, on the game thread.
    BlueprintCallbackScheduler.game_thread(
        1, "selection-clear-after-original-mode", function()
        selection_clear_scheduled = false
        local deferred_reason = selection_clear_reason
        selection_clear_reason = nil
        if has_pending_selection_state() then
            clear_pending_selection()
            log("selection pending set cleared after original mode transition reason="
                .. tostring(deferred_reason))
        end
        end
    )
    return true
end

local function validate_selection_state(context)
    local repaired = false
    local seen = {}

    for index = #selected_building_order, 1, -1 do
        local instance_id = selected_building_order[index]
        local entry = selected_buildings_by_instance[instance_id]
        local valid_entry = entry ~= nil
            and entry.record ~= nil
            and entry.record.source_instance_id == instance_id
            and is_valid_object(resolve_selection_entry_actor(entry))
        if seen[instance_id] or not valid_entry then
            if entry ~= nil and not seen[instance_id] then
                try_set_selection_visual(entry, false)
                selected_buildings_by_instance[instance_id] = nil
            end
            table.remove(selected_building_order, index)
            repaired = true
        else
            seen[instance_id] = true
        end
    end

    for instance_id, entry in pairs(selected_buildings_by_instance) do
        if not seen[instance_id] then
            try_set_selection_visual(entry, false)
            selected_buildings_by_instance[instance_id] = nil
            repaired = true
        end
    end

    if selected_anchor_instance_id ~= nil
        and selected_buildings_by_instance[selected_anchor_instance_id] == nil then
        selected_anchor_instance_id = nil
        repaired = true
    end

    if region_start_instance_id == nil then
        if region_start_actor ~= nil
            or region_start_record ~= nil
            or region_end_instance_id ~= nil
            or region_end_actor ~= nil
            or region_end_record ~= nil then
            clear_region_corners()
            repaired = true
        end
    elseif not is_valid_object(get_region_start_actor())
        or region_start_record == nil
        or region_start_record.source_instance_id ~= region_start_instance_id then
        clear_region_corners()
        repaired = true
    elseif region_end_instance_id == nil then
        if region_end_record ~= nil or region_end_actor ~= nil then
            region_end_actor = nil
            region_end_record = nil
            repaired = true
        end
    elseif region_end_instance_id == region_start_instance_id
        or not is_valid_object(get_region_end_actor())
        or region_end_record == nil
        or region_end_record.source_instance_id ~= region_end_instance_id then
        region_end_instance_id = nil
        region_end_actor = nil
        region_end_record = nil
        repaired = true
    end

    if #selected_building_order == 0 then
        if selected_anchor_instance_id ~= nil then
            selected_anchor_instance_id = nil
            repaired = true
        end
        selection_builder = nil
    end

    if repaired then
        for _, instance_id in ipairs(selected_building_order) do
            local entry = selected_buildings_by_instance[instance_id]
            if entry ~= nil then try_set_selection_visual(entry, true) end
        end
        log(string.format(
            "selection state repaired context=%s count=%d anchor=%s regionStart=%s regionEnd=%s",
            tostring(context), #selected_building_order,
            tostring(selected_anchor_instance_id), tostring(region_start_instance_id),
            tostring(region_end_instance_id)
        ))
        refresh_selection_material_hud("selection-repaired-" .. tostring(context))
    end
    return not repaired
end

local function dispatch_selection_action(label, action)
    BlueprintCallbackScheduler.game_thread_now(
        "selection-action:" .. tostring(label), function()
        local action_ok, action_error = pcall(action)
        if not action_ok then
            log("selection action isolated an error action=" .. tostring(label)
                .. " error=" .. tostring(action_error))
        end
        local validation_ok, validation_error = pcall(function()
            validate_selection_state(label)
        end)
        if not validation_ok then
            log("selection state validation isolated an error action=" .. tostring(label)
                .. " error=" .. tostring(validation_error))
        end
        refresh_selection_material_hud("selection-action-" .. tostring(label))
        end
    )
end

local function toggle_current_selection_target()
    local performance_started_at = BlueprintPerformance.now()
    local performance = {
        kind = "toggle",
        target_ms = 0.0,
        record_ms = 0.0,
        visual_ms = 0.0,
    }
    local target_started_at = BlueprintPerformance.now()
    local builder, target = get_current_selection_target()
    performance.target_ms = BlueprintPerformance.elapsed_ms(target_started_at)
    if not BlueprintSelectionMode.active
        and not is_original_selection_host_mode_active(builder) then
        log("selection toggle ignored: no supported original selection host mode builder=" .. object_name(builder))
        return
    end
    if not is_valid_object(target) then
        log("selection toggle: no valid target builder=" .. object_name(builder)
            .. " host=" .. tostring(get_original_selection_host_mode(builder)))
        return
    end
    selection_builder = BlueprintSelectionMode.active and nil or builder

    local host_mode = get_original_selection_host_mode(builder) or "independent"

    local record_started_at = BlueprintPerformance.now()
    local record = make_current_selection_identity_record(
        target,
        BlueprintSelectionMode.active and "blueprint-selection-left-click"
            or ("original-" .. host_mode .. "-hotkey")
    )
    performance.record_ms = BlueprintPerformance.elapsed_ms(record_started_at)
    if record == nil then return end
    local instance_id = record.source_instance_id
    local existing = selected_buildings_by_instance[instance_id]
    if existing ~= nil then
        local removed_anchor = selected_anchor_instance_id == instance_id
        performance.kind = "toggle-remove"
        -- A selection edit invalidates the complete serialization-error flash
        -- generation. Cancel every delayed phase before releasing an entry so
        -- no callback can revisit material state from the previous save pass.
        selection_visual.cancel_serialization_errors(true)
        local visual_started_at = BlueprintPerformance.now()
        local visual_count = try_set_selection_visual(existing, false)
        performance.visual_ms = BlueprintPerformance.elapsed_ms(
            visual_started_at
        )
        if removed_anchor then
            selected_anchor_instance_id = nil
            if blueprint_selection_session ~= nil then
                blueprint_selection_session.set_anchor(nil)
            end
        end
        selected_buildings_by_instance[instance_id] = nil
        for index, ordered_instance_id in ipairs(selected_building_order) do
            if ordered_instance_id == instance_id then
                table.remove(selected_building_order, index)
                break
            end
        end
        -- The selection set owns these active-World references. Release them
        -- explicitly instead of leaving UObject wrappers and per-slot MIDs for
        -- Lua GC after the entry has been removed from the indexed set.
        existing.serialization_error_flash_active = nil
        existing.actor = nil
        existing.visual_material_states = nil
        log(string.format(
            "selection removed instance=%s build=%s count=%d restoredMaterialSlots=%d anchorCleared=%s",
            instance_id, record.build_object_id, #selected_building_order, visual_count,
            tostring(removed_anchor)
        ))
        if #selected_building_order == 0 then
            selection_builder = nil
        end
        performance.total_ms = BlueprintPerformance.elapsed_ms(
            performance_started_at
        )
        performance.selected_count = #selected_building_order
        return performance
    end

    local entry = make_selection_entry(target, record)
    if entry == nil then
        log("selection add rejected: target handle unavailable instance="
            .. tostring(instance_id))
        return
    end
    selected_buildings_by_instance[instance_id] = entry
    table.insert(selected_building_order, instance_id)
    performance.kind = "toggle-add"
    local visual_started_at = BlueprintPerformance.now()
    local visual_count, visual_material = try_set_selection_visual(entry, true)
    performance.visual_ms = BlueprintPerformance.elapsed_ms(visual_started_at)
    log(string.format(
        "selection added instance=%s build=%s count=%d overriddenMaterialSlots=%d material=%s",
        instance_id, record.build_object_id, #selected_building_order, visual_count, visual_material
    ))
    performance.total_ms = BlueprintPerformance.elapsed_ms(performance_started_at)
    performance.selected_count = #selected_building_order
    return performance
end

local function set_current_selection_anchor()
    local performance_started_at = BlueprintPerformance.now()
    local performance = {
        kind = "anchor",
        target_ms = 0.0,
        record_ms = 0.0,
        visual_ms = 0.0,
    }
    local target_started_at = BlueprintPerformance.now()
    local builder, target = get_current_selection_target()
    performance.target_ms = BlueprintPerformance.elapsed_ms(target_started_at)
    if not BlueprintSelectionMode.active
        and not is_original_selection_host_mode_active(builder) then
        log("anchor set ignored: no supported original selection host mode builder=" .. object_name(builder))
        return
    end
    if not is_valid_object(target) then
        log("anchor set ignored: no valid target builder=" .. object_name(builder)
            .. " host=" .. tostring(get_original_selection_host_mode(builder)))
        return
    end

    local host_mode = get_original_selection_host_mode(builder) or "independent"

    local record_started_at = BlueprintPerformance.now()
    local record = make_current_selection_identity_record(
        target,
        BlueprintSelectionMode.active and "blueprint-selection-right-click"
            or ("original-" .. host_mode .. "-anchor-hotkey")
    )
    performance.record_ms = BlueprintPerformance.elapsed_ms(record_started_at)
    if record == nil then return end
    local instance_id = record.source_instance_id
    local entry = selected_buildings_by_instance[instance_id]
    if entry == nil then
        log(string.format(
            "anchor set rejected: target is not selected instance=%s build=%s selectionCount=%d",
            instance_id, record.build_object_id, #selected_building_order
        ))
        return
    end
    selection_builder = BlueprintSelectionMode.active and nil or builder

    local previous_anchor_id = selected_anchor_instance_id
    selected_anchor_instance_id = instance_id
    if blueprint_selection_session ~= nil then
        blueprint_selection_session.set_anchor(target)
    end
    local visual_started_at = BlueprintPerformance.now()
    if previous_anchor_id ~= nil and previous_anchor_id ~= instance_id then
        local previous_entry = selected_buildings_by_instance[previous_anchor_id]
        if previous_entry ~= nil then
            local previous_slots, previous_material = try_set_selection_visual(previous_entry, true)
            log(string.format(
                "anchor previous target visual refreshed instance=%s slots=%d material=%s",
                previous_anchor_id, previous_slots, previous_material
            ))
        end
    end

    local visual_count, visual_material = try_set_selection_visual(entry, true)
    performance.visual_ms = BlueprintPerformance.elapsed_ms(visual_started_at)
    log(string.format(
        "anchor set instance=%s build=%s selectionCount=%d pendingRegionCornerOverlap=%s overriddenMaterialSlots=%d material=%s",
        instance_id, record.build_object_id, #selected_building_order,
        tostring(instance_id == region_start_instance_id or instance_id == region_end_instance_id),
        visual_count, visual_material
    ))
    performance.total_ms = BlueprintPerformance.elapsed_ms(performance_started_at)
    performance.selected_count = #selected_building_order
    return performance
end

function sync_independent_selection_state(session)
    if blueprint_selection_session == nil
        or type(blueprint_selection_session.get_selection_snapshot)
            ~= "function" then
        return false, "Selection Session snapshot API is unavailable"
    end
    local actors, anchor, snapshot_error =
        blueprint_selection_session.get_selection_snapshot(session)
    if actors == nil then return false, snapshot_error end

    for _, entry in pairs(selected_buildings_by_instance) do
        if type(entry) == "table" then
            entry.actor = nil
            entry.visual_material_states = nil
        end
    end
    selected_buildings_by_instance = {}
    selected_building_order = {}
    selected_anchor_instance_id = nil

    for _, actor in ipairs(actors) do
        local record = make_current_selection_identity_record(
            actor, "blueprint-selection-session-save"
        )
        local entry = make_selection_entry(actor, record)
        if entry == nil or record == nil then
            return false,
                "selected Actor identity could not be captured"
        end
        local instance_id = record.source_instance_id
        if selected_buildings_by_instance[instance_id] == nil then
            selected_buildings_by_instance[instance_id] = entry
            selected_building_order[#selected_building_order + 1] =
                instance_id
        end
    end

    if is_valid_object(anchor) then
        local anchor_instance_id = get_build_object_instance_id(anchor)
        if anchor_instance_id ~= nil
            and selected_buildings_by_instance[anchor_instance_id]
                ~= nil then
            selected_anchor_instance_id = anchor_instance_id
        end
    end
    return true, nil
end

local blueprint_region_geometry = BlueprintRegionGeometry.install({
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    find_valid_instance = find_valid_instance,
    value_to_string = value_to_string,
})
local get_relative_region_position =
    blueprint_region_geometry.get_relative_position
local get_region_overlap_object_types =
    blueprint_region_geometry.get_overlap_object_types
local transform_region_point = blueprint_region_geometry.transform_point
local get_region_geometry = blueprint_region_geometry.get_geometry

local function format_region_building_label(record)
    if record == nil then return "[unknown]" end
    return string.format(
        "[%s | %s]",
        tostring(record.build_object_id), tostring(record.source_instance_id)
    )
end

local function ensure_building_selected(actor, record)
    actor = unwrap(actor)
    if record == nil or not is_valid_object(actor) then return false end
    local instance_id = record.source_instance_id
    if selected_buildings_by_instance[instance_id] ~= nil then return false end
    if BlueprintSelectionMode.active == true
        and blueprint_selection_session ~= nil
        and not blueprint_selection_session.add_selected_actor(
            actor, BlueprintSelectionMode.selection_session
        ) then
        log("selection add rejected: Session registration failed instance="
            .. tostring(instance_id))
        return false
    end
    local entry = make_selection_entry(actor, record)
    if entry == nil then return false end
    selected_buildings_by_instance[instance_id] = entry
    table.insert(selected_building_order, instance_id)
    try_set_selection_visual(entry, true)
    return true
end

function BlueprintSelectionAsync.finish_region_job(job, applied, error_text)
    if job == nil then return end
    if BlueprintSelectionAsync.region_job == job then
        BlueprintSelectionAsync.region_job = nil
    end
    if job.cancelled then
        release_region_job_references(job)
        log("region selection async stopped job=" .. tostring(job.id)
            .. " reason=cancelled")
        return
    end

    if applied then
        local endpoint_visual_started_at = BlueprintPerformance.now()
        if ensure_building_selected(
            job.start_actor,
            job.start_record
        ) then
            job.added = job.added + 1
        end
        if ensure_building_selected(
            job.end_actor,
            job.end_record
        ) then
            job.added = job.added + 1
        end
        BlueprintPerformance.add_elapsed(
            job.performance, "visual_ms", endpoint_visual_started_at
        )
    end
    local total_selected = #selected_building_order
    log(string.format(
        "region selection async complete job=%d applied=%s start=%s end=%s query=BoxOverlapActors frame=start-local endLocal=(%.3f,%.3f,%.3f) padding=(%.3f,%.3f,%.3f) localBounds=[%.3f,%.3f,%.3f]-[%.3f,%.3f,%.3f] worldExtent=(%.3f,%.3f,%.3f) objectTypes=%d objectTypeFallback=%s queryResult=%s overlapActors=%d preciseInside=%d added=%d alreadySelected=%d unavailable=%d totalSelected=%d error=%s",
        job.id, tostring(applied), tostring(job.start_instance_id),
        tostring(job.end_instance_id), job.end_position.x, job.end_position.y,
        job.end_position.z, job.padding_x, job.padding_y, job.padding_z,
        job.min_x, job.min_y, job.min_z, job.max_x, job.max_y, job.max_z,
        job.world_extent.X, job.world_extent.Y, job.world_extent.Z,
        job.object_type_count, tostring(job.used_object_type_fallback),
        tostring(job.query_result), job.overlap_count, job.precise_inside,
        job.added, job.already_selected, job.unavailable, total_selected,
        tostring(error_text or "none")
    ))
    if applied then
        send_blueprint_message(
            "message.region.complete", job.added, total_selected
        )
    else
        send_blueprint_message("message.region.failed_job")
    end
    refresh_selection_material_hud("region-selection-complete")
    release_region_job_references(job)
end

function BlueprintSelectionAsync.schedule_region_slice(job)
    BlueprintCallbackScheduler.game_thread(
        BlueprintSelectionAsync.slice_delay_ms,
        "region-selection-slice:" .. tostring(job and job.id),
        function()
            if BlueprintSelectionAsync.region_job ~= job
                or job.cancelled then
                return
            end
            local ok, error_text = pcall(function()
                BlueprintSelectionAsync.run_region_slice(job)
            end)
            if not ok then
                BlueprintSelectionAsync.finish_region_job(
                    job, false, error_text
                )
            end
        end
    )
end

function BlueprintSelectionAsync.run_region_slice(job)
    if BlueprintSelectionAsync.region_job ~= job or job.cancelled then return end
    local math_library = UEHelpers.GetKismetMathLibrary()
    local start_transform = restore_transform(job.start_transform)
    if not is_valid_object(math_library) or start_transform == nil then
        BlueprintSelectionAsync.finish_region_job(
            job, false, "region slice transform dependencies unavailable"
        )
        return
    end
    local slice_started_at = BlueprintPerformance.now()
    local processed = 0
    while job.index <= job.overlap_count
        and processed < BlueprintSelectionAsync.region_max_batch do
        local index = job.index
        local actor = job.actors ~= nil
            and job.actors[index] or nil
        local record_started_at = BlueprintPerformance.now()
        if is_valid_object(actor) then
            -- Region membership needs one live Transform, but the selected
            -- set only needs stable identity until the final save pass. Reuse
            -- the Model returned by identity lookup instead of reflecting
            -- GetModel, Transform and class metadata through two snapshots.
            local identity, model = get_build_object_identity(actor)
            local record = make_selection_identity_record(
                identity, "region-Y-overlap"
            )
            local transform = safe_property(model, "InitialTransformCache")
            local local_position = get_relative_region_position(
                math_library, transform, start_transform
            )
            BlueprintPerformance.add_elapsed(
                job.performance, "record_ms", record_started_at
            )
            if record ~= nil and local_position ~= nil
                and local_position.x >= job.min_x and local_position.x <= job.max_x
                and local_position.y >= job.min_y and local_position.y <= job.max_y
                and local_position.z >= job.min_z and local_position.z <= job.max_z then
                job.precise_inside = job.precise_inside + 1
                local instance_id = record.source_instance_id
                if selected_buildings_by_instance[instance_id] ~= nil then
                    job.already_selected = job.already_selected + 1
                elseif not job.addition_seen[instance_id] then
                    job.addition_seen[instance_id] = true
                    local entry = make_selection_entry(actor, record)
                    local session_registered =
                        BlueprintSelectionMode.active ~= true
                        or blueprint_selection_session == nil
                        or blueprint_selection_session.add_selected_actor(
                            actor, BlueprintSelectionMode.selection_session
                        )
                    if entry ~= nil and session_registered then
                        selected_buildings_by_instance[instance_id] = entry
                        table.insert(selected_building_order, instance_id)
                        local visual_started_at = BlueprintPerformance.now()
                        try_set_selection_visual(entry, true)
                        BlueprintPerformance.add_elapsed(
                            job.performance, "visual_ms", visual_started_at
                        )
                        job.added = job.added + 1
                    else
                        job.unavailable = job.unavailable + 1
                    end
                end
            elseif record == nil or local_position == nil then
                job.unavailable = job.unavailable + 1
            end
        else
            BlueprintPerformance.add_elapsed(
                job.performance, "record_ms", record_started_at
            )
            job.unavailable = job.unavailable + 1
        end
        job.index = index + 1
        processed = processed + 1
        if processed > 0 and BlueprintPerformance.elapsed_ms(slice_started_at)
                >= BlueprintSelectionAsync.region_slice_budget_ms then
            break
        end
    end
    local slice_ms = BlueprintPerformance.elapsed_ms(slice_started_at)
    job.performance.slice_count = job.performance.slice_count + 1
    job.performance.max_slice_ms = math.max(
        job.performance.max_slice_ms, slice_ms
    )
    if job.index > job.overlap_count then
        BlueprintSelectionAsync.finish_region_job(job, true, nil)
    else
        BlueprintSelectionAsync.schedule_region_slice(job)
    end
end

local region_preview = BlueprintRegionPreview.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    with_session = blueprint_selection_session.with_session,
    get_region_geometry = get_region_geometry,
    transform_region_point = transform_region_point,
    get_region_start_actor = get_region_start_actor,
    get_region_start_instance_id = function() return region_start_instance_id end,
})
clear_region_preview_box = region_preview.clear
refresh_region_preview_for_target = region_preview.refresh
prepare_region_preview = region_preview.prepare

local function add_loaded_buildings_inside_region()
    local performance_started_at = BlueprintPerformance.now()
    local start_actor = get_region_start_actor()
    local end_actor = get_region_end_actor()
    local geometry, geometry_error = get_region_geometry(
        start_actor, end_actor
    )
    if geometry == nil then
        log("region selection aborted: " .. tostring(geometry_error))
        return false
    end
    local math_library = geometry.math_library
    local start_data = geometry.start_data
    local end_position = geometry.end_position
    local padding_x, padding_y, padding_z =
        geometry.padding_x, geometry.padding_y, geometry.padding_z
    local min_x, min_y, min_z = geometry.min_x, geometry.min_y, geometry.min_z
    local max_x, max_y, max_z = geometry.max_x, geometry.max_y, geometry.max_z
    local world_aabb = geometry.world_aabb
    local system_library = UEHelpers.GetKismetSystemLibrary()
    local actor_class_filter = unwrap(StaticFindObject("/Script/Pal.PalBuildObject"))
    if world_aabb == nil or not is_valid_object(system_library)
        or not is_valid_object(actor_class_filter) then
        log("region selection aborted: overlap query dependencies are unavailable")
        return false
    end

    local object_types, used_object_type_fallback = get_region_overlap_object_types()
    local out_actors = {}
    local query_started_at = BlueprintPerformance.now()
    local query_ok, query_result = pcall(function()
        return system_library:BoxOverlapActors(
            start_actor,
            world_aabb.center,
            world_aabb.extent,
            object_types,
            actor_class_filter,
            {},
            out_actors
        )
    end)
    if not query_ok then
        log("region selection aborted: BoxOverlapActors failed error=" .. tostring(query_result))
        return false
    end
    local query_ms = BlueprintPerformance.elapsed_ms(query_started_at)

    local overlap_actors = safe_property(out_actors, "OutActors") or out_actors
    local overlap_count = 0
    pcall(function() overlap_count = #overlap_actors end)
    local candidate_capture_started_at = BlueprintPerformance.now()
    local actors = {}
    for index = 1, overlap_count do
        pcall(function()
            local actor = unwrap(overlap_actors[index])
            if is_valid_object(actor) then
                actors[#actors + 1] = actor
            end
        end)
    end
    local candidate_capture_ms = BlueprintPerformance.elapsed_ms(
        candidate_capture_started_at
    )

    local start_transform = copy_transform(start_data.transform)
    if start_transform == nil then
        log("region selection aborted: start transform snapshot unavailable")
        return false
    end
    if not is_valid_object(start_actor)
        or not is_valid_object(end_actor) then
        log("region selection aborted: endpoint identity unavailable")
        return false
    end

    BlueprintSelectionAsync.next_job_id = BlueprintSelectionAsync.next_job_id + 1
    local job = {
        id = BlueprintSelectionAsync.next_job_id,
        actors = actors,
        overlap_count = overlap_count,
        index = 1,
        start_transform = start_transform,
        start_actor = start_actor,
        end_actor = end_actor,
        start_record = region_start_record,
        end_record = region_end_record,
        start_instance_id = region_start_instance_id,
        end_instance_id = region_end_instance_id,
        end_position = end_position,
        padding_x = padding_x,
        padding_y = padding_y,
        padding_z = padding_z,
        min_x = min_x,
        min_y = min_y,
        min_z = min_z,
        max_x = max_x,
        max_y = max_y,
        max_z = max_z,
        world_extent = {
            X = tonumber(safe_property(world_aabb.extent, "X")) or 0,
            Y = tonumber(safe_property(world_aabb.extent, "Y")) or 0,
            Z = tonumber(safe_property(world_aabb.extent, "Z")) or 0,
        },
        object_type_count = #object_types,
        used_object_type_fallback = used_object_type_fallback,
        query_result = query_result,
        addition_seen = {},
        precise_inside = 0,
        added = 0,
        already_selected = 0,
        unavailable = 0,
        performance = {
            total_started_at = performance_started_at,
            query_ms = query_ms,
            candidate_capture_ms = candidate_capture_ms,
            record_ms = 0.0,
            visual_ms = 0.0,
            max_slice_ms = 0.0,
            slice_count = 0,
        },
    }
    BlueprintSelectionAsync.region_job = job
    log(string.format(
        "region selection async scheduled job=%d overlapActors=%d maxBatch=%d budgetMs=%.1f delayMs=%d",
        job.id, overlap_count, BlueprintSelectionAsync.region_max_batch,
        BlueprintSelectionAsync.region_slice_budget_ms,
        BlueprintSelectionAsync.slice_delay_ms
    ))
    BlueprintSelectionAsync.schedule_region_slice(job)
    return true
end

local function set_current_region_corner()
    local builder, target = get_current_selection_target()
    if not BlueprintSelectionMode.active
        and not is_original_selection_host_mode_active(builder) then
        log("region corner ignored: no supported original selection host mode builder=" .. object_name(builder))
        return
    end
    if BlueprintSelectionAsync.region_job ~= nil then
        log("region corner ignored: async region selection still active job="
            .. tostring(BlueprintSelectionAsync.region_job.id))
        send_blueprint_message("message.region.busy")
        return
    end
    if not is_valid_object(target) then
        log("region corner ignored: no valid target builder=" .. object_name(builder)
            .. " host=" .. tostring(get_original_selection_host_mode(builder)))
        send_blueprint_message("message.region.no_target")
        return
    end

    local host_mode = get_original_selection_host_mode(builder) or "independent"

    local record = make_current_selection_identity_record(
        target,
        BlueprintSelectionMode.active and "blueprint-selection-middle-click"
            or ("original-" .. host_mode .. "-region-hotkey")
    )
    if record == nil then return end
    local instance_id = record.source_instance_id
    selection_builder = BlueprintSelectionMode.active and nil or builder

    if region_end_instance_id ~= nil then
        local stale_start = format_region_building_label(region_start_record)
        local stale_end = format_region_building_label(region_end_record)
        clear_region_corners()
        log(string.format(
            "region Y event=reset_stale_terminal start=%s end=%s",
            stale_start, stale_end
        ))
    end

    if region_start_instance_id == nil then
        region_start_instance_id = instance_id
        region_start_actor = target
        region_start_record = record
        log("region Y event=select_start building=" .. format_region_building_label(record))
        send_blueprint_message(
            "message.region.start_set", tostring(record.build_object_id)
        )
        if refresh_region_preview_for_target ~= nil then
            refresh_region_preview_for_target(target)
            log("region preview active update=target-transition edges=12 colors=X:red,Y:green,Z:blue")
        end
        return
    end

    if instance_id == region_start_instance_id then
        local cancelled_label = format_region_building_label(region_start_record)
        clear_region_corners()
        log("region Y event=cancel_start building=" .. cancelled_label)
        send_blueprint_message(
            "message.region.start_cancelled", tostring(record.build_object_id)
        )
        return
    end

    region_end_instance_id = instance_id
    region_end_actor = target
    region_end_record = record
    local start_label = format_region_building_label(region_start_record)
    local end_label = format_region_building_label(region_end_record)
    log("region Y event=select_end building=" .. end_label)
    log(string.format(
        "region Y event=apply_region start=%s end=%s mode=set_selected",
        start_label, end_label
    ))

    local apply_ok, applied_or_error = pcall(add_loaded_buildings_inside_region)
    local applied = apply_ok and applied_or_error == true
    if not apply_ok then
        log("region Y event=apply_error start=" .. start_label .. " end=" .. end_label
            .. " error=" .. tostring(applied_or_error))
    end
    clear_region_corners()
    if applied then
        send_blueprint_message("message.region.started")
    else
        send_blueprint_message("message.region.failed")
    end
    log(string.format(
        "region Y event=terminal_reset start=%s end=%s scheduled=%s totalSelectedNow=%d",
        start_label, end_label, tostring(applied), #selected_building_order
    ))
end

local function validate_selection_save_prerequisites()
    if BlueprintSelectionAsync.region_job ~= nil then
        log("selection save rejected: async region selection still active job="
            .. tostring(BlueprintSelectionAsync.region_job.id))
        send_blueprint_message("message.save.region_busy")
        return false
    end
    if #selected_building_order == 0 then
        log("selection save ignored: no pending selection")
        send_blueprint_message("message.save.no_selection")
        return false
    end
    if selected_anchor_instance_id == nil then
        log("selection save rejected: no manually assigned anchor; select an existing selection and press T")
        send_blueprint_message("message.save.no_anchor")
        return false
    end

    local anchor_entry = selected_buildings_by_instance[selected_anchor_instance_id]
    if anchor_entry == nil
        or not is_valid_object(resolve_selection_entry_actor(anchor_entry)) then
        log("selection save rejected: assigned anchor is no longer a valid selected building instance="
            .. tostring(selected_anchor_instance_id))
        send_blueprint_message("message.save.anchor_invalid")
        return false
    end
    return true
end

local function commit_selection_to_clipboard(blueprint_name)
    if not validate_selection_save_prerequisites() then return false end

    local anchor_entry = selected_buildings_by_instance[
        selected_anchor_instance_id
    ]

    local builder = find_valid_instance("PalBuilderComponent", "/Game/Pal/Maps/")
    if not BlueprintSelectionMode.active
        and not is_original_selection_host_mode_active(builder) then
        log("selection save ignored: no supported original selection host mode builder=" .. object_name(builder))
        return
    end

    local math = UEHelpers.GetKismetMathLibrary()
    if not is_valid_object(math) then
        log("selection save rejected: KismetMathLibrary unavailable")
        send_blueprint_message("message.save.math_unavailable")
        return
    end
    local map_object_manager = find_valid_instance(
        "PalMapObjectManager", "/Game/Pal/Maps/"
    )
    local anchor_actor = resolve_selection_entry_actor(anchor_entry)
    if not is_valid_object(anchor_actor) then
        send_blueprint_message("message.save.anchor_invalid")
        return false
    end
    local anchor_model = nil
    pcall(function() anchor_model = anchor_actor:GetModel() end)
    local anchor_transform = safe_property(anchor_model, "InitialTransformCache")
    if anchor_transform == nil then
        log("selection save rejected: assigned anchor has no InitialTransformCache instance="
            .. tostring(selected_anchor_instance_id))
        send_blueprint_message("message.save.anchor_transform_unavailable")
        return
    end
    local committed_buildings = {}
    local committed_anchor = false
    local serialization_error_count = 0
    local serialization_error_instance_ids = {}
    local function mark_serialization_error(instance_id)
        serialization_error_count = serialization_error_count + 1
        table.insert(serialization_error_instance_ids, instance_id)
    end
    local commit_type_templates = {}
    local function usable_commit_type_template(template)
        return type(template) == "table"
            and type(template.preview_meshes) == "table"
            and #template.preview_meshes > 0
            and type(template.overlap_descriptor) == "table"
    end
    local function recover_commit_type_template(build_object_id)
        local template = BlueprintTypeRuntimeCache[build_object_id]
        if usable_commit_type_template(template) then return template, nil end
        local hydrated, hydrate_error =
            hydrate_blueprint_type_template_from_cdo(build_object_id)
        if usable_commit_type_template(hydrated) then return hydrated, nil end
        return nil, hydrate_error or "type template is incomplete"
    end
    for _, instance_id in ipairs(selected_building_order) do
        local entry = selected_buildings_by_instance[instance_id]
        local entry_actor = resolve_selection_entry_actor(entry)
        if entry ~= nil and is_valid_object(entry_actor) then
            local model = nil
            pcall(function() model = entry_actor:GetModel() end)
            local world_transform = safe_property(model, "InitialTransformCache")
            if world_transform ~= nil then
                local relative_transform = nil
                local actor_transform = nil
                local actor_relative_to_model = nil
                pcall(function()
                    relative_transform = math:MakeRelativeTransform(world_transform, anchor_transform)
                    actor_transform = entry_actor:GetTransform()
                    actor_relative_to_model = math:MakeRelativeTransform(
                        actor_transform, world_transform
                    )
                end)
                if relative_transform == nil or actor_transform == nil
                    or actor_relative_to_model == nil then
                    mark_serialization_error(instance_id)
                    log("selection commit skipped: model/actor transform calibration failed instance="
                        .. tostring(instance_id))
                else
                    -- A failed atomic save must leave the live selection set
                    -- untouched. Build an attempt-local DTO instead of
                    -- enriching entry.record with transforms, connector data
                    -- or runtime collision references.
                    local source_record = entry.record
                    local build_object_class = nil
                    pcall(function()
                        build_object_class = entry_actor:GetClass()
                    end)
                    local record = {
                        source = source_record.source,
                        build_object_id = source_record.build_object_id,
                        map_object_master_data_id =
                            source_record.map_object_master_data_id,
                        source_instance_id =
                            source_record.source_instance_id,
                        world_transform = copy_transform(world_transform),
                        build_object_class_path =
                            get_asset_path(build_object_class),
                    }
                    local type_template = commit_type_templates[
                        record.build_object_id
                    ]
                    local metadata_source = "first-live-instance"
                    local preview_meshes = type_template ~= nil
                        and type_template.preview_meshes or nil
                    local preview_mesh_error = nil
                    if preview_meshes == nil then
                        preview_meshes, preview_mesh_error =
                            capture_preview_mesh_descriptors(
                                entry_actor, world_transform,
                                record.build_object_id
                            )
                    else
                        metadata_source = "same-type-cache"
                    end
                    if preview_meshes == nil then
                        type_template, preview_mesh_error =
                            recover_commit_type_template(record.build_object_id)
                        if type_template ~= nil then
                            preview_meshes = type_template.preview_meshes
                            metadata_source = "runtime-type-recovery"
                        end
                    end
                    local overlap_descriptor = type_template ~= nil
                        and type_template.overlap_descriptor or nil
                    local overlap_descriptor_error = nil
                    if overlap_descriptor == nil and preview_meshes ~= nil then
                        overlap_descriptor, overlap_descriptor_error =
                            capture_overlap_descriptor(entry_actor, world_transform)
                    end
                    if overlap_descriptor == nil and preview_meshes ~= nil then
                        type_template, overlap_descriptor_error =
                            recover_commit_type_template(record.build_object_id)
                        if type_template ~= nil then
                            overlap_descriptor = type_template.overlap_descriptor
                            metadata_source = "runtime-type-recovery"
                        end
                    end
                    if preview_meshes == nil then
                        mark_serialization_error(instance_id)
                        log("selection commit skipped: preview mesh capture failed instance="
                            .. tostring(instance_id) .. " build="
                            .. tostring(record.build_object_id) .. " error="
                            .. tostring(preview_mesh_error))
                    elseif overlap_descriptor == nil then
                        mark_serialization_error(instance_id)
                        log("selection commit skipped: overlap descriptor capture failed instance="
                            .. tostring(instance_id) .. " build="
                            .. tostring(record.build_object_id) .. " error="
                            .. tostring(overlap_descriptor_error))
                    else
                            local connector = unwrap(safe_property(model, "Connector"))
                            local install_location_offset = safe_property(
                                entry_actor, "InstallLocationOffset"
                            )
                            local spawn_location_offset = safe_property(
                                entry_actor, "SpawnLocationOffset"
                            )
                            record.world_transform = copy_transform(world_transform)
                            record.relative_transform = copy_transform(relative_transform)
                            record.actor_relative_to_model = copy_transform(
                                actor_relative_to_model
                            )
                            record.preview_meshes = preview_meshes
                            record.overlap_descriptor = overlap_descriptor
                            record.install_strategy = value_to_string(
                                safe_property(entry_actor, "InstallStrategy")
                            )
                            record.install_capacity_sink_rate_by_height = tonumber(
                                safe_property(
                                    entry_actor, "InstallCapacitySinkRateByHeight"
                                )
                            )
                            record.install_capacity_slope_angle = tonumber(
                                safe_property(entry_actor, "InstallCapacitySlopeAngle")
                            )
                            record.install_location_offset = copy_vector(
                                install_location_offset
                            )
                            record.spawn_location_offset = copy_vector(
                                spawn_location_offset
                            )
                            record.connector_class = is_valid_object(connector)
                                and object_name(connector) or "<none>"
                            record.connector_supported_level = tonumber(
                                safe_property(connector, "SupportedLevel")
                            )
                            record.connector_connections =
                                capture_connector_connections(
                                    connector, map_object_manager,
                                    anchor_transform, math
                                )
                            record.selection_index = #committed_buildings + 1
                            record.is_anchor = instance_id == selected_anchor_instance_id
                            local cached, cache_error =
                                cache_blueprint_type_template(record)
                            if not cached then
                                mark_serialization_error(instance_id)
                                log("selection commit skipped: type template cache failed instance="
                                    .. tostring(instance_id) .. " build="
                                    .. tostring(record.build_object_id)
                                    .. " error=" .. tostring(cache_error))
                            else
                                commit_type_templates[record.build_object_id] =
                                    BlueprintTypeRuntimeCache[
                                        record.build_object_id
                                    ]
                                if record.is_anchor then committed_anchor = true end
                                table.insert(committed_buildings, record)
                                if ENABLE_STABLE_RUNTIME_LOGS then
                                    log(string.format(
                                        "selection commit item index=%d instance=%s build=%s meshes=%d overlapShape=%s metadataSource=%s installStrategy=%s sinkRate=%s slopeAngle=%s connector=%s supportedLevel=%s connectorEdges=%d installOffset=%s spawnOffset=%s modelWorld=%s modelRelative=%s actorRelativeToModel=%s",
                                        record.selection_index,
                                        record.source_instance_id,
                                        record.build_object_id, #preview_meshes,
                                        tostring(overlap_descriptor.shape_type),
                                        tostring(metadata_source),
                                        tostring(record.install_strategy),
                                        tostring(record.install_capacity_sink_rate_by_height),
                                        tostring(record.install_capacity_slope_angle),
                                        tostring(record.connector_class),
                                        tostring(record.connector_supported_level),
                                        #record.connector_connections,
                                        format_vector(install_location_offset),
                                        format_vector(spawn_location_offset),
                                        format_transform(world_transform),
                                        format_transform(relative_transform),
                                        format_transform(actor_relative_to_model)
                                    ))
                                end
                            end
                    end
                end
            else
                mark_serialization_error(instance_id)
                log("selection commit skipped: selected target has no InitialTransformCache instance="
                    .. tostring(instance_id))
            end
        else
            mark_serialization_error(instance_id)
            log("selection commit skipped: selected target became invalid instance="
                .. tostring(instance_id))
        end
    end

    if #committed_buildings == 0 then
        log("selection commit aborted: all selected targets became invalid")
        flash_selection_serialization_errors(
            serialization_error_instance_ids
        )
        send_blueprint_message("message.save.all_invalid")
        return
    end
    if serialization_error_count > 0
        or #committed_buildings ~= #selected_building_order then
        log(string.format(
            "selection commit aborted atomically: serialized=%d selected=%d errors=%d",
            #committed_buildings, #selected_building_order, serialization_error_count
        ))
        flash_selection_serialization_errors(
            serialization_error_instance_ids
        )
        send_blueprint_message(
            "message.save.serialization_partial", serialization_error_count
        )
        return
    end
    if not committed_anchor then
        log("selection commit aborted: manually assigned anchor was not serialized instance="
            .. tostring(selected_anchor_instance_id))
        send_blueprint_message("message.save.anchor_missing")
        return
    end

    local committed_index_by_instance = {}
    for committed_index, record in ipairs(committed_buildings) do
        committed_index_by_instance[record.source_instance_id] = committed_index
    end
    local connector_edge_count = 0
    local external_connector_edge_count = 0
    local saved_connections = {}
    for _, record in ipairs(committed_buildings) do
        local selected_connections = {}
        local external_connections = {}
        for _, connection in ipairs(record.connector_connections or {}) do
            local target_selection_index = committed_index_by_instance[
                connection.target_source_instance_id
            ]
            if target_selection_index ~= nil then
                connection.source_selection_index = record.selection_index
                connection.target_selection_index = target_selection_index
                table.insert(selected_connections, connection)
                table.insert(saved_connections, connection)
                connector_edge_count = connector_edge_count + 1
            elseif connection.target_build_object_id ~= nil
                and connection.target_relative_to_anchor ~= nil then
                connection.source_selection_index = record.selection_index
                table.insert(external_connections, connection)
                external_connector_edge_count = external_connector_edge_count + 1
            end
        end
        record.connections = selected_connections
        record.external_connections = external_connections
        record.connector_connections = nil
    end

    local captured_runtime = {
        schema_version = BlueprintWaveRuntime.blueprint_schema_version,
        connection_schema_version = BlueprintWaveRuntime.connection_schema_version,
        anchor_was_user_selected = true,
        anchor_instance_id = selected_anchor_instance_id,
        anchor_build_object_id = anchor_entry.record.build_object_id,
        anchor_world_transform = copy_transform(anchor_transform),
        saved_connections = saved_connections,
        buildings = committed_buildings,
    }
    for _, record in ipairs(committed_buildings) do
        local cached, cache_error = cache_blueprint_type_template(record)
        if not cached then
            log("blueprint clipboard export aborted: type cache failed build="
                .. tostring(record.build_object_id) .. " error="
                .. tostring(cache_error))
            send_blueprint_message("message.save.metadata_unavailable")
            return
        end
    end
    local compact_blueprint, compact_stats_or_error =
        BlueprintJsonSchema.from_runtime(captured_runtime)
    if compact_blueprint == nil then
        log("blueprint clipboard export aborted: compact schema failed: "
            .. tostring(compact_stats_or_error))
        send_blueprint_message("message.save.compact_failed")
        return
    end
    local blueprint_code, export_stats_or_error =
        encode_blueprint_for_library(compact_blueprint)
    if blueprint_code == nil then
        log("blueprint code export aborted: "
            .. tostring(export_stats_or_error))
        send_blueprint_message("message.save.clipboard_failed")
        return false, export_stats_or_error
    end
    local hydrated_runtime, hydrate_stats_or_error =
        BlueprintJsonSchema.to_runtime(
            compact_blueprint, BlueprintTypeRuntimeCache
        )
    if hydrated_runtime == nil then
        log("blueprint clipboard export aborted: self-hydration failed: "
            .. tostring(hydrate_stats_or_error))
        send_blueprint_message("message.save.deserialize_failed")
        return false, hydrate_stats_or_error
    end
    local clipboard_ok, clipboard_stats_or_error =
        copy_blueprint_text_to_system_clipboard(blueprint_code)
    if not clipboard_ok then
        log("blueprint clipboard export aborted: "
            .. tostring(clipboard_stats_or_error))
        send_blueprint_message("message.save.clipboard_failed")
        return false, clipboard_stats_or_error
    end
    local library_entry = nil
    if blueprint_name ~= nil then
        if not blueprint_library_runtime.initialized then
            local initialized, initialize_error =
                blueprint_library_runtime.initialize()
            if not initialized then
                log("blueprint local library save aborted: "
                    .. tostring(initialize_error))
                send_blueprint_message(
                    "message.library.save_failed", initialize_error
                )
                return false, initialize_error
            end
        end
        local entry, library_error = blueprint_library_runtime.store.create(
            blueprint_name, blueprint_code, {
                building_count = #hydrated_runtime.buildings,
                blueprint_schema_version = hydrated_runtime.schema_version,
                type_templates = snapshot_blueprint_type_templates(
                    compact_blueprint
                ),
            }
        )
        if entry == nil then
            log("blueprint local library save aborted: "
                .. tostring(library_error))
            send_blueprint_message(
                "message.library.save_failed", library_error
            )
            return false, library_error
        end
        library_entry = entry
        log("blueprint local library record created id="
            .. tostring(entry.id) .. " name=" .. tostring(entry.name)
            .. " buildings=" .. tostring(entry.building_count))
        local thumbnail_path, thumbnail_path_error =
            blueprint_library_runtime.store.get_thumbnail_path(entry.id)
        local thumbnail_ready = false
        local thumbnail_error = thumbnail_path_error
        local thumbnail_resource = nil
        if thumbnail_path ~= nil then
            thumbnail_ready, thumbnail_error, thumbnail_resource =
                blueprint_thumbnail_renderer.render(
                    hydrated_runtime, thumbnail_path
                )
        end
        if thumbnail_ready and is_valid_object(thumbnail_resource) then
            blueprint_library_manager.put_thumbnail(
                entry.id, thumbnail_resource
            )
        end
        local thumbnail_state = thumbnail_ready and "ready" or "failed"
        local state_updated, state_error =
            blueprint_library_runtime.store.set_thumbnail_state(
                entry.id, thumbnail_state
            )
        if state_updated then
            entry.thumbnail_state = thumbnail_state
        end
        if not thumbnail_ready or not state_updated then
            log("blueprint local library thumbnail unavailable id="
                .. tostring(entry.id) .. " renderError="
                .. tostring(thumbnail_error) .. " stateError="
                .. tostring(state_error))
        end
    end
    blueprint_clipboard = hydrated_runtime
    log(string.format(
        "blueprint JSON committed schema=%d connectionSchema=%d buildings=%d types=%d savedConnectEdges=%d externalSupportEdges=%d anchor=%s anchorTransform=%s jsonBytes=%d compressedBytes=%d codeChars=%d transport=%s",
        blueprint_clipboard.schema_version,
        blueprint_clipboard.connection_schema_version,
        #blueprint_clipboard.buildings,
        compact_stats_or_error.types,
        connector_edge_count, external_connector_edge_count,
        blueprint_clipboard.anchor_instance_id,
        format_transform(anchor_transform),
        export_stats_or_error.json_bytes,
        export_stats_or_error.compressed_bytes,
        export_stats_or_error.code_chars,
        tostring(export_stats_or_error.transport)
    ))
    send_blueprint_message(
        "message.save.success",
        #blueprint_clipboard.buildings,
        tostring(blueprint_clipboard.anchor_build_object_id),
        export_stats_or_error.code_chars
    )

    clear_pending_selection()
    if BlueprintSelectionMode.active then
        log("selection save complete; independent blueprint selection mode will close")
    else
        log("selection save complete; original "
            .. tostring(get_original_selection_host_mode(builder))
            .. " mode remains active until its normal exit path runs")
    end
    return true, {
        entry = library_entry,
        compact_blueprint = compact_blueprint,
        runtime_blueprint = hydrated_runtime,
        blueprint_code = blueprint_code,
        stats = export_stats_or_error,
    }
end

BlueprintSelectionHUDData.install(BlueprintSelectionMode, {
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    value_to_string = value_to_string,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    make_runtime_object_handle = make_runtime_object_handle,
    resolve_runtime_object_handle = resolve_runtime_object_handle,
    find_in_instance = function(instance, wanted_name)
        if BlueprintModeUI == nil
            or BlueprintModeUI.find_in_instance == nil then
            return nil
        end
        return BlueprintModeUI.find_in_instance(instance, wanted_name)
    end,
    get_hud_widget = function()
        return BlueprintSelectionMode.hud_widget
    end,
})

BlueprintSelectionHUDMaterials.install(BlueprintSelectionMode)

local blueprint_placement_hud_materials =
    BlueprintPlacementHUDMaterials.install({
        material_gate = BlueprintMaterialGate,
        log = log,
        unwrap = unwrap,
        value_to_string = value_to_string,
        object_name = object_name,
        is_valid_object = is_valid_object,
        safe_object_address = safe_object_address,
        find_in_instance = function(instance, wanted_name)
            return BlueprintModeUI.find_in_instance(instance, wanted_name)
        end,
        get_blueprint = function() return blueprint_clipboard end,
        get_builder = get_blueprint_preview_builder,
        is_placement_active = function()
            return blueprint_preview_active == true
        end,
    })

local blueprint_placement_hud_key_guides =
    BlueprintPlacementHUDKeyGuides.install({
        UEHelpers = UEHelpers,
        mode_ui = BlueprintModeUI,
        log = log,
        unwrap = unwrap,
        object_name = object_name,
        is_valid_object = is_valid_object,
        is_usable_class_object = is_usable_class_object,
        safe_object_address = safe_object_address,
        safe_property = safe_property,
        make_runtime_object_handle = make_runtime_object_handle,
        resolve_runtime_object_handle = resolve_runtime_object_handle,
        find_in_instance = function(instance, wanted_name)
            return BlueprintModeUI.find_in_instance(instance, wanted_name)
        end,
        get_building_model = function()
            return find_valid_instance_by_address(
                "BP_PalUIBuildingModel_C",
                blueprint_preview_building_model_address
            )
        end,
        get_local_player_controller = function()
            if type(BlueprintSelectionInputBridge.get_local_player_controller)
                ~= "function" then
                return nil
            end
            return BlueprintSelectionInputBridge.get_local_player_controller()
        end,
        is_placement_active = function()
            return blueprint_preview_active == true
        end,
        localize = blueprint_localization.text,
        schedule_cleanup = function(label, work)
            return BlueprintCallbackScheduler.game_thread(
                1, "cleanup:" .. tostring(label), work
            )
        end,
    })

BlueprintSelectionHUDKeyGuides.install(BlueprintSelectionMode, {
    UEHelpers = UEHelpers,
    mode_ui = BlueprintModeUI,
    log = log,
    unwrap = unwrap,
    object_name = object_name,
    is_valid_object = is_valid_object,
    is_usable_class_object = is_usable_class_object,
    safe_property = safe_property,
    localize = blueprint_localization.text,
    find_in_instance = function(instance, wanted_name)
        if BlueprintModeUI == nil
            or BlueprintModeUI.find_in_instance == nil then
            return nil
        end
        return BlueprintModeUI.find_in_instance(instance, wanted_name)
    end,
})

BlueprintSelectionHUD.install(BlueprintSelectionMode, {
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    value_to_string = value_to_string,
    object_name = object_name,
    is_valid_object = is_valid_object,
    is_usable_class_object = is_usable_class_object,
    class_object_name = class_object_name,
    safe_property = safe_property,
    get_hud_widget = function()
        return BlueprintSelectionMode.hud_widget
    end,
})

BlueprintSelectionInput.install(BlueprintSelectionInputBridge, {
    mode = BlueprintSelectionMode,
    log = log,
    unwrap = unwrap,
    value_to_string = value_to_string,
    object_name = object_name,
    is_valid_object = is_valid_object,
    class_object_name = class_object_name,
    safe_object_address = safe_object_address,
    safe_property = safe_property,
    get_session_player_controller = function()
        return BlueprintSelectionMode.player_controller
    end,
    runtime_diagnostics_enabled = ENABLE_STABLE_RUNTIME_LOGS,
    toggle_current_selection_target = toggle_current_selection_target,
    set_current_selection_anchor = set_current_selection_anchor,
    set_current_region_corner = set_current_region_corner,
    begin_camera_hold = function(_, input_actor)
        if type(BlueprintSelectionMode.suspend_target_for_camera)
            == "function" then
            BlueprintSelectionMode.suspend_target_for_camera(
                "selection-camera-toggle"
            )
        end
        local entered, result, error_value =
            blueprint_selection_session.with_session(
                function(session)
                    return blueprint_selection_camera.enter(
                        session, input_actor
                    )
                end,
                BlueprintSelectionMode.selection_session
            )
        local ok = entered and result == true
        BlueprintSelectionMode.camera_hold_active = ok
        if not ok
            and type(BlueprintSelectionMode.resume_target_after_camera)
                == "function" then
            BlueprintSelectionMode.resume_target_after_camera(
                "selection-camera-enter-failed"
            )
        end
        return ok, entered and error_value or result
    end,
    end_camera_hold = function(reason)
        local exited, result =
            blueprint_selection_session.with_session(
                function(session)
                    local input_actor =
                        BlueprintSelectionInputBridge.find_actor(
                            BlueprintSelectionInputBridge
                                .get_local_player_controller()
                        )
                    return blueprint_selection_camera.exit(
                        session, input_actor, reason
                    )
                end,
                BlueprintSelectionMode.selection_session
            )
        BlueprintSelectionMode.camera_hold_active = false
        if type(BlueprintSelectionMode.resume_target_after_camera)
            == "function" then
            BlueprintSelectionMode.resume_target_after_camera(reason)
        end
        return not exited or result == true
    end,
    abandon_camera_hold = function()
        BlueprintSelectionMode.camera_hold_active = false
        return blueprint_selection_camera.abandon_world()
    end,
    is_camera_hold_active = function()
        return blueprint_selection_session.is_camera_active()
    end,
    is_modal_active = function()
        return blueprint_name_dialog.is_open()
    end,
    cancel_modal = function(reason)
        return blueprint_name_dialog.cancel(reason)
    end,
})

blueprint_placement_runtime_backend =
    BlueprintPlacementRuntimeBackend.install({
        log = log,
        unwrap = unwrap,
        is_valid_object = is_valid_object,
        safe_object_address = safe_object_address,
        find_all_of = function(class_name)
            return FindAllOf(class_name)
        end,
        read_property = function(value, property_name)
            return safe_property(value, property_name)
        end,
        write_property = function(value, property_name, property_value)
            value[property_name] = property_value
            return true
        end,
        get_world_generation = function()
            return BlueprintCallbackScheduler.get_world_generation()
        end,
        register_hook = function(function_path, callback)
            return RegisterHook(function_path, callback)
        end,
        on_tick = function(session)
            if type(handle_blueprint_placement_session_tick) == "function" then
                handle_blueprint_placement_session_tick(session)
            end
        end,
    })

blueprint_placement_camera = BlueprintPlacementCamera.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    is_usable_class_object = is_usable_class_object,
    safe_property = safe_property,
    get_local_player_controller =
        BlueprintSelectionInputBridge.get_local_player_controller,
    runtime_backend = blueprint_placement_runtime_backend,
    send_message = send_blueprint_message,
    on_restored = function()
        if blueprint_preview_active then
            blueprint_preview_last_anchor_transform = nil
            blueprint_preview_validation_dirty = true
            blueprint_preview_validation_cooldown_ticks = 0
        end
    end,
})

blueprint_placement_input = BlueprintPlacementInput.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    is_usable_class_object = is_usable_class_object,
    object_name = object_name,
    safe_object_address = safe_object_address,
    safe_property = safe_property,
    get_asset_path = get_asset_path,
    find_valid_instance_by_address = find_valid_instance_by_address,
    get_local_player_controller =
        BlueprintSelectionInputBridge.get_local_player_controller,
    value_to_string = value_to_string,
    mode_ui = BlueprintModeUI,
    is_placement_active = function()
        return blueprint_preview_active == true
    end,
    begin_camera_hold = function(session, input_actor)
        return blueprint_placement_camera.enter(session, input_actor)
    end,
    end_camera_hold = function(session, input_actor, reason)
        return blueprint_placement_camera.exit(
            session, input_actor, reason
        )
    end,
    abandon_camera_hold = function()
        return blueprint_placement_camera.abandon_world()
    end,
    is_camera_hold_active = function(session)
        return blueprint_placement_camera.is_active(session)
    end,
    matches_camera_context = function(session, camera)
        return blueprint_placement_camera.matches_camera(
            session, camera
        )
    end,
    schedule_cleanup = function(label, work)
        return BlueprintCallbackScheduler.game_thread(
            1, "cleanup:" .. tostring(label), work
        )
    end,
    runtime_backend = blueprint_placement_runtime_backend,
    on_primary_action = function()
        if type(handle_blueprint_placement_primary_action) == "function" then
            handle_blueprint_placement_primary_action()
        else
            log("blueprint placement primary action ignored: handler unavailable")
        end
    end,
    on_world_snap_toggle = function()
        if type(toggle_blueprint_world_snap) == "function" then
            toggle_blueprint_world_snap()
        else
            log("blueprint placement world snap ignored: handler unavailable")
        end
    end,
})

BlueprintSelectionModeRuntime.install(BlueprintSelectionMode, {
    log = log,
    log_probe = log_probe,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    safe_object_address = safe_object_address,
    object_name = object_name,
    get_actor_from_hit_result = get_actor_from_hit_result,
    find_valid_instance = find_valid_instance,
    get_build_object_instance_id = get_build_object_instance_id,
    get_build_object_identity = get_build_object_identity,
    get_selected_building = function(instance_id)
        return selected_buildings_by_instance[instance_id]
    end,
    try_set_selection_visual = try_set_selection_visual,
    try_set_native_hover_visual =
        try_set_native_hover_visual,
    repair_selected_entry_visual =
        repair_selected_entry_visual,
    make_building_record = make_building_record,
    prepare_region_preview = prepare_region_preview,
    is_placement_active = function()
        return blueprint_preview_active or blueprint_commit_queued
    end,
    get_blueprint_clipboard = function()
        return blueprint_clipboard
    end,
    clear_pending_selection = clear_pending_selection,
    has_pending_selection_state = has_pending_selection_state,
    validate_selection_state = validate_selection_state,
    can_save_selection = validate_selection_save_prerequisites,
    sync_selection_state = sync_independent_selection_state,
    commit_selection_to_clipboard = commit_selection_to_clipboard,
    open_name_dialog = function(on_confirm)
        if not blueprint_library_runtime.initialized then
            local initialized, initialize_error =
                blueprint_library_runtime.initialize()
            if not initialized then return false, initialize_error end
        end
        local entries, list_error = blueprint_library_runtime.store.list()
        if entries == nil then return false, list_error end
        return blueprint_name_dialog.open({
            default_name = blueprint_localization.text(
                "ui.library.default_name", #entries + 1
            ),
            on_confirm = on_confirm,
        })
    end,
    is_name_dialog_open = function()
        return blueprint_name_dialog.is_open()
    end,
    cancel_name_dialog = function(reason)
        return blueprint_name_dialog.cancel(reason)
    end,
    send_blueprint_message = send_blueprint_message,
    schedule_cleanup = function(label, work)
        return BlueprintCallbackScheduler.game_thread(
            1, "cleanup:" .. tostring(label), work
        )
    end,
    performance_now = BlueprintPerformance.now,
    performance_elapsed_ms = BlueprintPerformance.elapsed_ms,
    is_probe_logging_enabled =
        BlueprintResearchSettings.get_log_probes,
    input_bridge = BlueprintSelectionInputBridge,
    selection_session = blueprint_selection_session,
})

local blueprint_placement_session_components =
    BlueprintPlacementSessionComponents.install({
        unwrap = unwrap,
        is_valid_object = is_valid_object,
        read_property = function(value, property_name)
            return safe_property(value, property_name)
        end,
        write_property = function(value, property_name, property_value)
            value[property_name] = property_value
            return true
        end,
    })
local blueprint_ghost_renderer = BlueprintGhostRenderer.install({
    log = log,
    unwrap = unwrap,
    object_name = object_name,
    is_valid_object = is_valid_object,
    safe_object_address = safe_object_address,
    find_valid_instance = find_valid_instance,
    safe_property = safe_property,
    restore_transform = restore_transform,
    get_original_anchor_material = get_original_anchor_material,
    component_store = blueprint_placement_session_components,
    max_query_buildings = MAX_BLUEPRINT_QUERY_BUILDINGS,
})
local blueprint_ghost_state = blueprint_ghost_renderer.get_state()
local blueprint_blocker_visual = BlueprintBlockerVisual.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    safe_object_address = safe_object_address,
    object_name = object_name,
    find_valid_instance = find_valid_instance,
    collect_build_object_meshes = collect_build_object_meshes,
    component_store = blueprint_placement_session_components,
})

local BUILD_OBJECT_BLOCKER_PREFIX = "build-object:"

local function is_build_object_blocker_reason(reason)
    return type(reason) == "string"
        and string.sub(reason, 1, #BUILD_OBJECT_BLOCKER_PREFIX)
            == BUILD_OBJECT_BLOCKER_PREFIX
end

local function get_dynamic_blocker_localization_key(reason)
    local lowered = string.lower(tostring(reason or ""))
    if string.find(lowered, "pawn", 1, true) ~= nil
        or string.find(lowered, "character", 1, true) ~= nil
        or string.find(lowered, "pal", 1, true) ~= nil then
        return "message.placement.blocker_pal"
    end
    return "message.placement.blocker_world_object"
end
local blueprint_wave_ghost_renderer = BlueprintWaveGhostRenderer.install({
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    restore_transform = restore_transform,
    get_asset_path = get_asset_path,
    get_preview_material = function()
        local material = nil
        with_active_placement_session(function(session)
            material =
                blueprint_ghost_renderer.get_preview_material(session)
        end)
        return material or get_original_anchor_material()
    end,
})
blueprint_build_session_runtime =
    BlueprintBuildSessionRuntime.install({
        UEHelpers = UEHelpers,
        log = log,
        unwrap = unwrap,
        is_valid_object = is_valid_object,
        is_usable_class_object = is_usable_class_object,
        safe_property = safe_property,
        safe_object_address = safe_object_address,
        get_asset_path = get_asset_path,
        object_name = object_name,
        get_world_generation = function()
            return BlueprintWaveRuntime.world_generation
        end,
        record_performance = function(
            session_id, phase_name, elapsed_ms, context
        )
            local transaction =
                blueprint_build_jobs_by_id[tonumber(session_id)]
            if transaction ~= nil then
                record_build_queue_ms(
                    transaction, phase_name, elapsed_ms, context)
            end
        end,
    })
local function configure_blueprint_ghosts(session)
    local configured, configure_error, configure_failure =
        blueprint_ghost_renderer.configure(
        session, blueprint_clipboard
    )
    if not configured then
        return configured, configure_error, configure_failure
    end
    local world_transform = blueprint_clipboard
        and restore_transform(
            blueprint_clipboard.anchor_world_transform
        ) or nil
    local world_configured, world_error = pcall(function()
        session.SBB_TerrainSnapAvailable = world_transform ~= nil
        session.SBB_TerrainSnapActive = false
        session.SBB_TerrainSnapRangeCm = BLUEPRINT_WORLD_SNAP_RANGE_CM
        if world_transform ~= nil then
            session.SBB_TerrainSnapTargetTransform = world_transform
        end
    end)
    if not world_configured then
        return false, "world snap Session configuration failed: "
            .. tostring(world_error)
    end
    if world_transform ~= nil then
        log("blueprint original-world transform snap ready")
    end
    return true, nil
end

function get_transform_location_components(transform)
    local translation = safe_property(transform, "Translation")
    local x = tonumber(safe_property(translation, "X"))
    local y = tonumber(safe_property(translation, "Y"))
    local z = tonumber(safe_property(translation, "Z"))
    if x == nil or y == nil or z == nil then return nil end
    return x, y, z
end

function update_blueprint_terrain_snap(
    session, anchor_actor, raw_anchor_transform, force_root_update
)
    if not is_valid_object(session) or not is_valid_object(anchor_actor)
        or raw_anchor_transform == nil then
        return false, nil, "terrain snap dependencies unavailable"
    end
    local available = safe_property(
        session, "SBB_TerrainSnapAvailable"
    ) == true
    local previous_active = safe_property(
        session, "SBB_TerrainSnapActive"
    ) == true
    local target_transform = available and safe_property(
        session, "SBB_TerrainSnapTargetTransform"
    ) or nil
    local should_activate = previous_active and target_transform ~= nil
    if force_root_update == true then
        local applied, apply_error = blueprint_ghost_renderer.set_terrain_snap(
            session, anchor_actor, should_activate, target_transform
        )
        if not applied then return false, nil, apply_error end
        local write_ok, write_error = pcall(function()
            session.SBB_TerrainSnapActive = should_activate
        end)
        if not write_ok then return false, nil, tostring(write_error) end
    end
    return should_activate, should_activate and target_transform or nil, nil
end

function toggle_blueprint_world_snap()
    if not blueprint_preview_active then return false end
    local toggled = false
    local toggle_error = nil
    local active, active_error = with_active_placement_session(
        function(session)
            local available = safe_property(
                session, "SBB_TerrainSnapAvailable"
            ) == true
            local target_transform = available and safe_property(
                session, "SBB_TerrainSnapTargetTransform"
            ) or nil
            if target_transform == nil then
                send_blueprint_message("message.world_snap.unavailable")
                return
            end
            local references = synchronize_placement_session_references(
                session
            )
            local anchor_actor = references and references.anchor or nil
            if not is_valid_object(anchor_actor) then
                toggle_error = "placement anchor unavailable"
                return
            end
            local next_active = safe_property(
                session, "SBB_TerrainSnapActive"
            ) ~= true
            if next_active then
                local current_transform = nil
                local current_ok, current_error = pcall(function()
                    current_transform = unwrap(anchor_actor:GetTransform())
                end)
                local current_x, current_y, current_z =
                    get_transform_location_components(current_transform)
                local target_x, target_y, target_z =
                    get_transform_location_components(target_transform)
                if not current_ok or current_x == nil or target_x == nil then
                    toggle_error = "placement anchor transform unavailable: "
                        .. tostring(current_error)
                    return
                end
                local range_cm = tonumber(safe_property(
                    session, "SBB_TerrainSnapRangeCm"
                )) or BLUEPRINT_WORLD_SNAP_RANGE_CM
                if range_cm > 0 then
                    local dx = current_x - target_x
                    local dy = current_y - target_y
                    local dz = current_z - target_z
                    local distance_cm = math.sqrt(
                        dx * dx + dy * dy + dz * dz
                    )
                    if distance_cm > range_cm then
                        send_blueprint_message(
                            "message.world_snap.out_of_range",
                            distance_cm / 100.0,
                            range_cm / 100.0
                        )
                        log("blueprint original-world transform snap rejected distanceCm="
                            .. string.format("%.1f", distance_cm)
                            .. " rangeCm=" .. tostring(range_cm))
                        return
                    end
                end
            end
            local applied, apply_error =
                blueprint_ghost_renderer.set_terrain_snap(
                    session, anchor_actor, next_active, target_transform
                )
            if not applied then
                toggle_error = apply_error
                return
            end
            local write_ok, write_error = pcall(function()
                session.SBB_TerrainSnapActive = next_active
            end)
            if not write_ok then
                toggle_error = tostring(write_error)
                return
            end
            if type(invalidate_native_overlap_for_anchor_motion)
                == "function" then
                invalidate_native_overlap_for_anchor_motion(nil)
            else
                blueprint_preview_last_anchor_transform = nil
                blueprint_preview_all_placeable = false
                blueprint_preview_validation_dirty = true
                blueprint_preview_validation_cooldown_ticks = 0
            end
            send_blueprint_message(next_active
                and "message.world_snap.enabled"
                or "message.world_snap.disabled")
            log("blueprint original-world transform snap "
                .. (next_active and "enabled" or "disabled"))
            toggled = true
        end
    )
    if not active then toggle_error = active_error end
    if toggle_error ~= nil then
        log("blueprint original-world transform snap failed error="
            .. tostring(toggle_error))
        send_blueprint_message("message.world_snap.failed")
    end
    return toggled
end

function report_blueprint_terrain_snap_failure(context, error_value)
    log("blueprint " .. tostring(context)
        .. " terrain snap fail-open error=" .. tostring(error_value))
end

local function send_blueprint_preview_configuration_failure(failure)
    if type(failure) ~= "table" then return false end
    local requested = tonumber(failure.requested)
    local limit = tonumber(failure.limit)
    if requested == nil or limit == nil then return false end
    if failure.code == "collision_query_limit_exceeded" then
        send_blueprint_message(
            "message.placement.collision_query_limit",
            requested, limit
        )
        return true
    end
    return false
end

local update_blueprint_ghost_root_transform =
    blueprint_ghost_renderer.update_root_transform
local refresh_blueprint_ghost_world_transforms =
    blueprint_ghost_renderer.refresh_world_transforms
local set_blueprint_ghost_building_blocked =
    blueprint_ghost_renderer.set_building_blocked

local function stop_blueprint_preview(
    reason, preserve_ghosts, defer_native_cleanup
)
    local was_active = blueprint_preview_active
    if blueprint_preview_session_tick_in_progress then
        defer_native_cleanup = true
    end
    BlueprintWaveRuntime.preview_first_tick_pending = false
    BlueprintWaveRuntime.preview_session_tick_count = 0
    blueprint_continuous_placement_requested = false
    blueprint_continuous_unlock_pending = false
    blueprint_continuous_next_anchor_seen = false
    blueprint_start_build_forward_in_progress = false
    blueprint_preview_active = false
    local preview_session_released = false
    with_active_placement_session(function(session)
        blueprint_blocker_visual.clear(session)
        blueprint_ghost_renderer.destroy_session(session, reason)
        preview_session_released = true
    end)
    if not preview_session_released then
        blueprint_ghost_renderer.destroy_session(nil, reason)
    end
    blueprint_placement_input.exit(reason, {
        defer_native_cleanup = defer_native_cleanup == true,
    })
    blueprint_placement_hud_key_guides.cancel(
        reason, defer_native_cleanup == true
    )
    blueprint_placement_hud_materials.cancel(reason)
    blueprint_preview_anchor_build_object_id = nil
    blueprint_preview_building_model_address = nil
    blueprint_preview_network_component_handle = nil
    blueprint_preview_attached_anchor_address = nil
    blueprint_preview_anchor_correction_signature = nil
    blueprint_preview_anchor_frame_corrected = false
    blueprint_ghost_state.anchor_actor_relative_to_model = nil
    blueprint_preview_wait_ticks = 0
    blueprint_preview_last_anchor_transform = nil
    blueprint_preview_all_placeable = false
    blueprint_preview_overlap_count = 0
    blueprint_preview_water_block_count = 0
    blueprint_preview_water_gate_unavailable = false
    blueprint_preview_water_capability = nil
    blueprint_preview_validation_signature = nil
    blueprint_preview_validation_dirty = false
    blueprint_preview_validation_cooldown_ticks = 0
    blueprint_preview_validation_revision = 0
    blueprint_native_overlap_pending_revision = nil
    blueprint_native_overlap_completed_revision = nil
    blueprint_native_overlap_last_report = nil
    blueprint_commit_queued = false
    blueprint_placement_anchor_probe.reset()
    if blueprint_native_overlap_gate ~= nil then
        blueprint_native_overlap_gate.reset()
    end
    if was_active then
        log("blueprint placement mode exited reason=" .. tostring(reason))
    end
end

local function snapshot_world_build_object(actor)
    actor = unwrap(actor)
    if not is_valid_object(actor) then return nil end
    local model = nil
    pcall(function() model = unwrap(actor:GetModel()) end)
    if not is_valid_object(model) then return nil end
    local model_transform = safe_property(model, "InitialTransformCache")
    local model_location = copy_vector(safe_property(
        model_transform, "Translation"
    ))
    local model_rotation = copy_quaternion(safe_property(
        model_transform, "Rotation"
    ))
    local model_scale = copy_vector(safe_property(
        model_transform, "Scale3D"
    ))
    if model_location == nil or model_rotation == nil
        or model_scale == nil then
        return nil
    end
    local build_object_id = value_to_string(
        safe_property(model, "BuildObjectId")
    )
    if build_object_id == "<nil>" or build_object_id == "None"
        or build_object_id == "" then
        build_object_id = value_to_string(
            safe_property(actor, "BuildObjectId")
        )
    end
    if build_object_id == "<nil>" or build_object_id == "None"
        or build_object_id == "" then
        return nil
    end
    local instance_id = format_guid(safe_property(model, "InstanceId"))
    if instance_id == "<nil>" or instance_id == "None"
        or instance_id
            == "00000000-00000000-00000000-00000000" then
        instance_id = nil
    end
    return {
        instance_id = instance_id,
        actor_address = safe_object_address(actor),
        build_object_id = build_object_id,
        model_location = model_location,
        model_rotation = model_rotation,
        model_scale = model_scale,
    }
end

BlueprintNativeOverlapMismatchProbe = {
    observed_requests = {},
    query_extent_cm = 400.0,
    max_candidate_logs = 12,
}

local function diagnose_native_overlap_server_mismatch(request)
    if type(request) ~= "table"
        or tonumber(request.native_overlap_result) ~= 60 then
        return
    end
    local server_result = tostring(request.result_text or "")
    if server_result ~= "28" and server_result ~= "29" then return end

    local probe_key = table.concat({
        tostring(request.source_instance_id or "<none>"),
        tostring(request.request_index or "<none>"),
        server_result,
    }, "|")
    if BlueprintNativeOverlapMismatchProbe.observed_requests[
        probe_key
    ] then
        return
    end
    BlueprintNativeOverlapMismatchProbe.observed_requests[
        probe_key
    ] = true

    local expected_location = copy_vector(request.model_location)
    local expected_rotation = copy_quaternion(request.model_rotation)
    local system_library = unwrap(UEHelpers.GetKismetSystemLibrary())
    local world_context = unwrap(UEHelpers.GetPlayer())
    local build_object_class = unwrap(StaticFindObject(
        "/Script/Pal.PalBuildObject"
    ))
    if expected_location == nil or expected_rotation == nil
        or not is_valid_object(system_library)
        or not is_valid_object(world_context)
        or not is_valid_object(build_object_class) then
        log("blueprint native overlap mismatch probe unavailable build="
            .. tostring(request.build_object_id))
        return
    end

    local extent = BlueprintNativeOverlapMismatchProbe.query_extent_cm
    local out_actors = {}
    local query_started_at = BlueprintPerformance.now()
    local query_ok, query_error = pcall(function()
        system_library:BoxOverlapActors(
            world_context,
            {
                X = expected_location.x,
                Y = expected_location.y,
                Z = expected_location.z,
            },
            { X = extent, Y = extent, Z = extent },
            get_region_overlap_object_types(),
            build_object_class,
            {},
            out_actors
        )
    end)
    local query_ms = BlueprintPerformance.elapsed_ms(query_started_at)
    if not query_ok then
        log("blueprint native overlap mismatch probe query failed build="
            .. tostring(request.build_object_id) .. " error="
            .. tostring(query_error))
        return
    end

    local actors = safe_property(out_actors, "OutActors") or out_actors
    local actor_count = 0
    pcall(function() actor_count = #actors end)
    local candidates = {}
    local snapshot_started_at = BlueprintPerformance.now()
    for actor_index = 1, actor_count do
        local actor = nil
        pcall(function() actor = unwrap(actors[actor_index]) end)
        local candidate = snapshot_world_build_object(actor)
        if candidate ~= nil
            and tostring(candidate.build_object_id)
                == tostring(request.build_object_id) then
            local equivalent, details = BlueprintBuildEquivalence.compare({
                build_object_id = request.build_object_id,
                install_strategy = request.install_strategy,
                model_location = expected_location,
                model_rotation = expected_rotation,
            }, candidate)
            candidates[#candidates + 1] = {
                candidate = candidate,
                equivalent = equivalent == true,
                details = details or {},
            }
        end
    end
    local snapshot_ms = BlueprintPerformance.elapsed_ms(
        snapshot_started_at
    )
    table.sort(candidates, function(left, right)
        return (tonumber(left.details.position_error) or math.huge)
            < (tonumber(right.details.position_error) or math.huge)
    end)

    log(string.format(
        "blueprint native overlap mismatch probe build=%s source=%s localResult=%s serverResult=%s queriedActors=%d sameId=%d queryMs=%.2f snapshotMs=%.2f expectedModelLocation=(%.3f,%.3f,%.3f) expectedModelRotation=(%.9f,%.9f,%.9f,%.9f)",
        tostring(request.build_object_id),
        tostring(request.source_instance_id),
        tostring(request.native_overlap_result),
        server_result,
        actor_count,
        #candidates,
        query_ms,
        snapshot_ms,
        expected_location.x,
        expected_location.y,
        expected_location.z,
        expected_rotation.x,
        expected_rotation.y,
        expected_rotation.z,
        expected_rotation.w
    ))
    for index = 1, math.min(
        #candidates,
        BlueprintNativeOverlapMismatchProbe.max_candidate_logs
    ) do
        local item = candidates[index]
        local candidate = item.candidate
        local location = copy_vector(candidate.model_location) or {}
        local rotation = copy_quaternion(candidate.model_rotation) or {}
        log(string.format(
            "blueprint native overlap mismatch candidate index=%d equivalent=%s reason=%s positionError=%.3f angleError=%.3f equivalentYaw=%s instance=%s actor=%s modelLocation=(%.3f,%.3f,%.3f) modelRotation=(%.9f,%.9f,%.9f,%.9f)",
            index,
            tostring(item.equivalent),
            tostring(item.details.reason or "<none>"),
            tonumber(item.details.position_error) or -1.0,
            tonumber(item.details.angle_error_degrees) or -1.0,
            tostring(item.details.matched_equivalent_yaw),
            tostring(candidate.instance_id or "<none>"),
            tostring(candidate.actor_address or "<none>"),
            tonumber(location.x) or 0.0,
            tonumber(location.y) or 0.0,
            tonumber(location.z) or 0.0,
            tonumber(rotation.x) or 0.0,
            tonumber(rotation.y) or 0.0,
            tonumber(rotation.z) or 0.0,
            tonumber(rotation.w) or 0.0
        ))
    end
end

local overlap_query = BlueprintOverlapQuery.install({
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    value_to_string = value_to_string,
    safe_property = safe_property,
    object_name = object_name,
    get_query_component = function(session, building_state)
        return blueprint_ghost_renderer.get_query_component(
            session, building_state
        )
    end,
    snapshot_build_object = snapshot_world_build_object,
    apply_blocker_visual = function(
        session, actor, blocker_component
    )
        return blueprint_blocker_visual.apply(
            session, actor, blocker_component
        )
    end,
    pal_monster_class = unwrap(StaticFindObject(
        "/Script/Pal.PalMonsterCharacter"
    )),
})
local get_blueprint_validation_object_types = overlap_query.get_object_types
local classify_blueprint_snapshot_overlaps =
    overlap_query.classify_snapshot
local classify_blueprint_surface_intrusion =
    overlap_query.classify_surface_intrusion
local blueprint_placement_overlap_snapshot =
    BlueprintPlacementOverlapSnapshot.install({
        unwrap = unwrap,
        is_valid_object = is_valid_object,
        safe_property = safe_property,
        value_to_string = value_to_string,
        copy_transform = copy_transform,
        copy_vector = copy_vector,
        component_store = blueprint_placement_session_components,
    })
blueprint_native_overlap_gate = BlueprintNativeOverlapGate.install({
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_property = safe_property,
    write_property = function(value, property_name, property_value)
        value[property_name] = property_value
        return true
    end,
    make_name = FName,
    get_math_library = UEHelpers.GetKismetMathLibrary,
    component_store = blueprint_placement_session_components,
    value_to_string = value_to_string,
    compare_equivalence = BlueprintBuildEquivalence.compare,
})

local function get_blueprint_anchor_record()
    for _, building in ipairs(
        blueprint_clipboard and blueprint_clipboard.buildings or {}
    ) do
        if building.source_instance_id
            == blueprint_clipboard.anchor_instance_id then
            return building
        end
    end
    return nil
end

local function record_anchor_correction_diagnostic(alignment, source)
    if type(alignment) ~= "table"
        or alignment.status == "none" then
        return
    end
    if alignment.status == "normalized-presentation" then
        local delta = alignment.correction_delta or {}
        local raw_scale = alignment.raw_model_scale or {}
        local signature = table.concat({
            "normalized-presentation",
            string.format("%.3f", tonumber(delta.z) or 0.0),
            string.format("%.3f", tonumber(raw_scale.x) or 0.0),
        }, ":")
        if signature == blueprint_preview_anchor_correction_signature then
            return
        end
        blueprint_preview_anchor_correction_signature = signature
        log(string.format(
            "blueprint anchor presentation normalized source=%s kind=%s deltaZCm=%.3f rawScale=(%.3f,%.3f,%.3f)",
            tostring(source),
            tostring(alignment.normalization_kind or "uniform-scale"),
            tonumber(delta.z) or 0.0,
            tonumber(raw_scale.x) or 0.0,
            tonumber(raw_scale.y) or 0.0,
            tonumber(raw_scale.z) or 0.0
        ))
        return
    end
    if alignment.status ~= "matched" then return end
    local candidate = alignment.candidate or {}
    local candidate_key = candidate.instance_id
        or candidate.actor_address or "<unknown>"
    local delta = alignment.correction_delta or {}
    local raw_scale = alignment.raw_model_scale or {}
    local candidate_scale = alignment.candidate_model_scale or {}
    local signature = table.concat({
        tostring(candidate_key),
        string.format("%.3f", tonumber(delta.x) or 0.0),
        string.format("%.3f", tonumber(delta.y) or 0.0),
        string.format("%.3f", tonumber(delta.z) or 0.0),
        tostring(
            alignment.details
                and alignment.details.matched_equivalent_yaw
                or "<none>"
        ),
    }, ":")
    if signature == blueprint_preview_anchor_correction_signature then
        return
    end
    blueprint_preview_anchor_correction_signature = signature
    log(string.format(
        "blueprint anchor correction applied source=%s worldInstance=%s deltaCm=(%.3f,%.3f,%.3f) distanceCm=%.3f matchedYaw=%s rawScale=(%.3f,%.3f,%.3f) worldScale=(%.3f,%.3f,%.3f)",
        tostring(source), tostring(candidate_key),
        tonumber(delta.x) or 0.0,
        tonumber(delta.y) or 0.0,
        tonumber(delta.z) or 0.0,
        tonumber(
            alignment.details and alignment.details.position_error
        ) or 0.0,
        tostring(
            alignment.details
                and alignment.details.matched_equivalent_yaw
                or "<none>"
        ),
        tonumber(raw_scale.x) or 0.0,
        tonumber(raw_scale.y) or 0.0,
        tonumber(raw_scale.z) or 0.0,
        tonumber(candidate_scale.x) or 0.0,
        tonumber(candidate_scale.y) or 0.0,
        tonumber(candidate_scale.z) or 0.0
    ))
end

local function resolve_anchor_presentation_transform(
    raw_anchor_actor_transform, anchor_preview_actor, source
)
    local math_library = UEHelpers.GetKismetMathLibrary()
    local anchor_record = get_blueprint_anchor_record()
    if not is_valid_object(math_library)
        or raw_anchor_actor_transform == nil
        or blueprint_ghost_state.anchor_actor_relative_to_model == nil
        or anchor_record == nil then
        return nil, nil,
            "occupied-anchor correction dependencies unavailable"
    end

    local raw_anchor_model_transform = nil
    local model_ok, model_error = pcall(function()
        local model_relative_to_actor = math_library:InvertTransform(
            blueprint_ghost_state.anchor_actor_relative_to_model
        )
        raw_anchor_model_transform = math_library:ComposeTransforms(
            model_relative_to_actor, raw_anchor_actor_transform
        )
    end)
    if not model_ok or raw_anchor_model_transform == nil then
        return nil, nil, "occupied-anchor model transform failed error="
            .. tostring(model_error)
    end
    local raw_location = copy_vector(safe_property(
        raw_anchor_model_transform, "Translation"
    ))
    local raw_rotation = copy_quaternion(safe_property(
        raw_anchor_model_transform, "Rotation"
    ))
    local raw_scale = copy_vector(safe_property(
        raw_anchor_model_transform, "Scale3D"
    ))
    if raw_location == nil or raw_rotation == nil or raw_scale == nil then
        return nil, nil, "occupied-anchor model snapshot incomplete"
    end

    -- Invalid previews carry deterministic stock presentation scale (1.02).
    -- Normalize only that stock presentation frame. Whether an object at this
    -- position is equivalent is deliberately left to the independent native
    -- Checker request and the pure-data equivalence layer.
    local presentation_alignment =
        BlueprintBuildEquivalence
            .normalize_stock_invalid_anchor_preview({
                build_object_id = anchor_record.build_object_id
                    or blueprint_preview_anchor_build_object_id,
                install_strategy = anchor_record.install_strategy,
                model_location = raw_location,
                model_rotation = raw_rotation,
                model_scale = raw_scale,
            })
    if presentation_alignment ~= nil then
        record_anchor_correction_diagnostic(
            presentation_alignment, source
        )
        local corrected_model_transform = restore_transform(
            presentation_alignment.corrected_model_transform
        )
        local corrected_actor_transform = nil
        local correction_ok, correction_error = pcall(function()
            corrected_actor_transform = math_library:ComposeTransforms(
                blueprint_ghost_state.anchor_actor_relative_to_model,
                corrected_model_transform
            )
        end)
        if not correction_ok or corrected_actor_transform == nil then
            return nil, presentation_alignment,
                "anchor presentation normalization failed error="
                    .. tostring(correction_error)
        end
        return corrected_actor_transform, presentation_alignment, nil
    end

    return raw_anchor_actor_transform, { status = "none" }, nil
end

local function collect_preview_preexisting_world_matches(
    system_library, build_object_class, ignored_actors, timing_probe
)
    local world_context = unwrap(UEHelpers.GetPlayer())
    if not is_valid_object(system_library)
        or not is_valid_object(build_object_class)
        or not is_valid_object(world_context) then
        return nil, "preview preexisting query dependencies unavailable"
    end

    local expectations = {}
    local minimum = { x = math.huge, y = math.huge, z = math.huge }
    local maximum = { x = -math.huge, y = -math.huge, z = -math.huge }
    local expectations_started_at =
        BlueprintOverlapTiming.now(timing_probe)
    for _, building_state in ipairs(
        blueprint_ghost_state.buildings or {}
    ) do
        local transform = building_state.world_transform
        local location = copy_vector(safe_property(
            transform, "Translation"
        ))
        local rotation = copy_quaternion(safe_property(
            transform, "Rotation"
        ))
        if location == nil or rotation == nil then
            BlueprintOverlapTiming.add_elapsed(
                timing_probe, "preexisting_expectations_ms",
                expectations_started_at
            )
            return nil,
                "preview preexisting expectation transform unavailable"
        end
        expectations[#expectations + 1] = {
            source_instance_id = building_state.source_instance_id,
            selection_index = building_state.selection_index,
            build_object_id = building_state.build_object_id,
            install_strategy = building_state.install_strategy,
            model_location = location,
            model_rotation = rotation,
        }
        minimum.x = math.min(minimum.x, location.x)
        minimum.y = math.min(minimum.y, location.y)
        minimum.z = math.min(minimum.z, location.z)
        maximum.x = math.max(maximum.x, location.x)
        maximum.y = math.max(maximum.y, location.y)
        maximum.z = math.max(maximum.z, location.z)
    end
    BlueprintOverlapTiming.add_elapsed(
        timing_probe, "preexisting_expectations_ms",
        expectations_started_at
    )
    if #expectations == 0 then
        return {
            matches_by_source_id = {},
            matched_count = 0,
            expectation_count = 0,
            indexed_candidate_count = 0,
        }, nil
    end

    local padding =
        BlueprintBuildEquivalence.DEFAULT_POSITION_TOLERANCE + 50.0
    local out_actors = {}
    local query_started_at = BlueprintOverlapTiming.now(timing_probe)
    local query_ok, query_error = pcall(function()
        system_library:BoxOverlapActors(
            world_context,
            {
                X = (minimum.x + maximum.x) * 0.5,
                Y = (minimum.y + maximum.y) * 0.5,
                Z = (minimum.z + maximum.z) * 0.5,
            },
            {
                X = math.max(
                    (maximum.x - minimum.x) * 0.5 + padding,
                    padding
                ),
                Y = math.max(
                    (maximum.y - minimum.y) * 0.5 + padding,
                    padding
                ),
                Z = math.max(
                    (maximum.z - minimum.z) * 0.5 + padding,
                    padding
                ),
            },
            get_blueprint_validation_object_types(),
            build_object_class,
            ignored_actors or {},
            out_actors
        )
    end)
    BlueprintOverlapTiming.add_elapsed(
        timing_probe, "preexisting_query_ms", query_started_at
    )
    if not query_ok then
        return nil, "preview preexisting BoxOverlapActors failed: "
            .. tostring(query_error)
    end

    local actors = safe_property(out_actors, "OutActors") or out_actors
    local actor_count = 0
    pcall(function() actor_count = #actors end)
    local candidates = {}
    local seen = {}
    local snapshot_started_at =
        BlueprintOverlapTiming.now(timing_probe)
    for actor_index = 1, actor_count do
        local actor = nil
        pcall(function() actor = unwrap(actors[actor_index]) end)
        if is_valid_object(actor) then
            local candidate = snapshot_world_build_object(actor)
            local candidate_key = candidate and (
                candidate.instance_id or candidate.actor_address
            ) or nil
            if candidate_key ~= nil and not seen[candidate_key] then
                seen[candidate_key] = true
                candidate.ordinal = #candidates + 1
                candidates[#candidates + 1] = candidate
            end
        end
    end
    BlueprintOverlapTiming.add_elapsed(
        timing_probe, "preexisting_snapshot_ms",
        snapshot_started_at
    )
    BlueprintOverlapTiming.increment(
        timing_probe, "preexisting_actor_count", actor_count
    )
    BlueprintOverlapTiming.increment(
        timing_probe, "preexisting_candidate_count", #candidates
    )
    local match_started_at = BlueprintOverlapTiming.now(timing_probe)
    local match_result = BlueprintBuildEquivalence.match(
        expectations, candidates, {
            position_tolerance =
                BlueprintBuildEquivalence.DEFAULT_POSITION_TOLERANCE,
        }
    )
    BlueprintOverlapTiming.add_elapsed(
        timing_probe, "preexisting_match_ms", match_started_at
    )
    BlueprintOverlapTiming.increment(
        timing_probe, "preexisting_pair_checks",
        tonumber(match_result.candidate_checks) or 0
    )
    BlueprintOverlapTiming.increment(
        timing_probe, "preexisting_bucket_visits",
        tonumber(match_result.bucket_visits) or 0
    )
    return match_result, nil
end

local function validate_blueprint_ghost_overlaps_legacy(
    session, anchor_transform, session_references, trigger
)
    local timing_probe = nil
    if ENABLE_OVERLAP_TIMING_PROBE then
        timing_probe = BlueprintOverlapTiming.new(
            trigger,
            "full-visual",
            #(blueprint_ghost_state.buildings or {})
        )
    end
    local timing_scanned_buildings = 0
    local timing_blocker_count = 0
    local timing_broadphase_candidates = 0
    local timing_existing_matches = 0
    local function finish_timed_validation(ok, error_value)
        if timing_probe ~= nil then
            BlueprintOverlapTiming.set_context(
                timing_probe, "scanned_buildings",
                timing_scanned_buildings
            )
            BlueprintOverlapTiming.set_context(
                timing_probe, "blocker_count",
                timing_blocker_count
            )
            BlueprintOverlapTiming.set_context(
                timing_probe, "broadphase_candidates",
                timing_broadphase_candidates
            )
            BlueprintOverlapTiming.set_context(
                timing_probe, "existing_matches",
                timing_existing_matches
            )
            BlueprintOverlapTiming.finish(
                timing_probe, ok and "ok" or "failed", error_value
            )
            for _, line in ipairs(
                BlueprintOverlapTiming.format_lines(timing_probe)
            ) do
                log(line)
            end
        end
        return ok, error_value
    end

    local dependency_started_at =
        BlueprintOverlapTiming.now(timing_probe)
    local system_library = UEHelpers.GetKismetSystemLibrary()
    local math_library = UEHelpers.GetKismetMathLibrary()
    local build_object_class = unwrap(StaticFindObject("/Script/Pal.PalBuildObject"))
    local component_class = unwrap(StaticFindObject("/Script/Engine.PrimitiveComponent"))
    if not is_valid_object(system_library) or not is_valid_object(math_library)
        or not is_valid_object(build_object_class)
        or not is_valid_object(component_class) then
        BlueprintOverlapTiming.add_elapsed(
            timing_probe, "dependency_setup_ms",
            dependency_started_at
        )
        return finish_timed_validation(
            false, "overlap validation dependencies unavailable"
        )
    end
    local object_types = get_blueprint_validation_object_types()
    local ignored_actors = {}
    -- Every collision-query and preview component is owned by this Placement
    -- Session Actor. Dense blueprint members can overlap sibling query shapes;
    -- excluding the owner prevents those private checker components from
    -- masquerading as Custom-profile world blockers.
    local placement_session_actor = unwrap(session)
    if is_valid_object(placement_session_actor) then
        table.insert(ignored_actors, placement_session_actor)
    end
    local local_player = unwrap(UEHelpers.GetPlayer())
    if is_valid_object(local_player) then
        table.insert(ignored_actors, local_player)
    end
    local current_anchor = session_references
        and session_references.anchor or nil
    if is_valid_object(current_anchor) then
        table.insert(ignored_actors, current_anchor)
    end
    -- The original anchor preview owns separate checker actors in the world.
    -- They intentionally overlap the anchor while evaluating Palworld's own
    -- placement rules; custom blueprint ghosts must not treat those transient
    -- query actors as existing world obstructions.
    local original_install_checker = session_references
        and session_references.checker or nil
    if is_valid_object(original_install_checker) then
        table.insert(ignored_actors, original_install_checker)
        local original_overlap_checker = unwrap(
            safe_property(original_install_checker, "OverlapChecker")
        )
        if is_valid_object(original_overlap_checker) then
            table.insert(ignored_actors, original_overlap_checker)
        end
    end
    BlueprintOverlapTiming.add_elapsed(
        timing_probe, "dependency_setup_ms", dependency_started_at
    )

    -- Query components are Session-owned but are intentionally non-event
    -- shapes. Move them to the current collision frames, then execute one
    -- Blueprint-native batch. The returned snapshot contains only pure
    -- indices, names, IDs, transforms, profiles and positions.
    local collision_transforms = {}
    local compose_started_at =
        BlueprintOverlapTiming.now(timing_probe)
    for building_index, building_state in ipairs(
        blueprint_ghost_state.buildings
    ) do
        if building_state.world_transform == nil then
            return finish_timed_validation(
                false, "building world transform unavailable index="
                    .. tostring(building_index)
            )
        end
        collision_transforms[building_index] =
            math_library:ComposeTransforms(
                building_state.overlap_relative_transform,
                building_state.world_transform
            )
    end
    BlueprintOverlapTiming.add_elapsed(
        timing_probe, "member_transform_ms", compose_started_at
    )

    local native_shadow_generation = nil
    if not blueprint_native_overlap_gate.has_pending() then
        local native_error = nil
        native_shadow_generation, native_error =
            blueprint_native_overlap_gate.submit(
                session, blueprint_ghost_state.buildings
            )
        if native_shadow_generation == nil then
            log("blueprint native overlap shadow submit failed error="
                .. tostring(native_error))
        end
    end

    local snapshot_started_at =
        BlueprintOverlapTiming.now(timing_probe)
    local overlap_snapshot, snapshot_error =
        blueprint_placement_overlap_snapshot.run(
            session,
            blueprint_ghost_state.buildings,
            collision_transforms,
            ignored_actors
        )
    local snapshot_ms =
        BlueprintOverlapTiming.elapsed_ms(snapshot_started_at)
    BlueprintOverlapTiming.add_ms(
        timing_probe, "native_query_ms", snapshot_ms
    )
    BlueprintOverlapTiming.sample_ms(
        timing_probe, "native_query_ms", snapshot_ms
    )
    BlueprintOverlapTiming.increment(
        timing_probe, "native_query_calls", 1
    )
    if overlap_snapshot ~= nil then
        BlueprintOverlapTiming.increment(
            timing_probe, "native_query_components",
            tonumber(overlap_snapshot.pair_count) or 0
        )
    end
    if overlap_snapshot == nil then
        return finish_timed_validation(false, snapshot_error)
    end

    local validate_all_invalid_ghosts =
        BlueprintResearchSettings.get_validate_all_invalid_ghosts()
        or timing_probe ~= nil
    local overlap_count = 0
    local water_block_count = 0
    local water_gate_unavailable = false
    local broadphase_candidate_count = 0
    local scanned_building_count = 0
    local existing_world_match_count = 0
    local existing_match_claims = {}
    local status_parts = {}
    local stopped_at_index = nil
    local blocker_visual_applied = false
    -- Keep the original full-validation lifecycle intact for every visited
    -- unit: clear its previous state, query it, then apply its new material.
    -- Fast mode differs only by breaking after the first blocked unit.
    for building_index, building_state in ipairs(blueprint_ghost_state.buildings) do
        local member_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        local member_classify_ms = 0.0
        building_state.blocker = nil
        building_state.existing_world_match = nil
        scanned_building_count = scanned_building_count + 1
        timing_scanned_buildings = scanned_building_count
        local collision_transform =
            collision_transforms[building_index]
        local blocker, candidate_count, query_error = nil, 0, nil
        local member_pairs =
            overlap_snapshot.pairs_by_member[building_index] or {}
        local classify_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        local snapshot_metadata = nil
        blocker, candidate_count, query_error, snapshot_metadata =
            classify_blueprint_snapshot_overlaps(
                building_state,
                member_pairs,
                existing_match_claims
            )
        member_classify_ms = BlueprintOverlapTiming.elapsed_ms(
            classify_started_at
        )
        BlueprintOverlapTiming.add_ms(
            timing_probe, "member_classify_ms",
            member_classify_ms
        )
        BlueprintOverlapTiming.increment(
            timing_probe, "component_pair_visits",
            tonumber(candidate_count) or 0
        )

        -- Stock sinkable structures need one narrower terrain-only pass to
        -- distinguish legal contact from deep terrain intrusion. This path
        -- performs no GetModel/building snapshot and is normally skipped.
        if query_error == nil and blocker == nil
            and snapshot_metadata ~= nil
            and snapshot_metadata.has_surface_overlap == true then
            local intrusion_blocker, intrusion_count, intrusion_error =
                classify_blueprint_surface_intrusion(
                    session, system_library, math_library,
                    building_state, collision_transform,
                    object_types, ignored_actors, component_class,
                    build_object_class, timing_probe
                )
            blocker = intrusion_blocker
            candidate_count = candidate_count
                + (tonumber(intrusion_count) or 0)
            query_error = intrusion_error
        end
        if query_error ~= nil then
            local member_total_ms = BlueprintOverlapTiming.elapsed_ms(
                member_started_at
            )
            BlueprintOverlapTiming.add_ms(
                timing_probe, "member_total_ms", member_total_ms
            )
            BlueprintOverlapTiming.record_member(timing_probe, {
                index = building_index,
                source_instance_id =
                    building_state.source_instance_id,
                build_object_id = building_state.build_object_id,
                total_ms = member_total_ms,
                classify_ms = member_classify_ms,
                query_ms = 0.0,
                candidate_count = candidate_count,
                pair_visits = candidate_count,
                blocked = false,
                preexisting =
                    building_state.existing_world_match ~= nil,
            })
            return finish_timed_validation(
                false, "component overlap query failed instance="
                .. tostring(building_state.source_instance_id)
                .. " error=" .. tostring(query_error)
            )
        end
        broadphase_candidate_count = broadphase_candidate_count
            + (candidate_count or 0)
        timing_broadphase_candidates = broadphase_candidate_count
        building_state.blocker = blocker
        if building_state.existing_world_match ~= nil then
            existing_world_match_count =
                existing_world_match_count + 1
            timing_existing_matches = existing_world_match_count
        end
        if blocker ~= nil and blocker.visual_applied == true then
            blocker_visual_applied = true
        end
        if blocker ~= nil
            and blocker_visual_applied ~= true
            and blocker.category == "build_object"
            and blocker.visual_pair_index ~= nil then
            local blocker_actor, blocker_component =
                blueprint_placement_overlap_snapshot.
                    select_pair_for_visual(
                        session, blocker.visual_pair_index
                    )
            if is_valid_object(blocker_actor)
                and is_valid_object(blocker_component) then
                local visual_ok, visual_result = pcall(
                    blueprint_blocker_visual.apply,
                    session, blocker_actor, blocker_component
                )
                blocker.visual_applied =
                    visual_ok and visual_result == true
                blocker_visual_applied =
                    blocker.visual_applied == true
            end
        end

        local water_blocked = building_state.water_surface_overlap == true
            and (
                blueprint_preview_water_capability == nil
                or blueprint_preview_water_capability.unlocked ~= true
            )
        if water_blocked then
            water_block_count = water_block_count + 1
            water_gate_unavailable = water_gate_unavailable
                or blueprint_preview_water_capability == nil
                or blueprint_preview_water_capability.available ~= true
            building_state.blocker = {
                blocked = true,
                category = "water",
                reason = water_gate_unavailable
                    and "water-building-capability-unavailable"
                    or "water-building-locked",
                profile = "<water>",
            }
        end
        local blocked = building_state.blocker ~= nil or water_blocked
        local material_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        if not set_blueprint_ghost_building_blocked(
            session, building_state, blocked
        ) then
            BlueprintOverlapTiming.add_elapsed(
                timing_probe, "material_update_ms",
                material_started_at
            )
            local member_total_ms = BlueprintOverlapTiming.elapsed_ms(
                member_started_at
            )
            BlueprintOverlapTiming.add_ms(
                timing_probe, "member_total_ms", member_total_ms
            )
            BlueprintOverlapTiming.record_member(timing_probe, {
                index = building_index,
                source_instance_id =
                    building_state.source_instance_id,
                build_object_id = building_state.build_object_id,
                total_ms = member_total_ms,
                classify_ms = member_classify_ms,
                query_ms = 0.0,
                candidate_count = candidate_count,
                pair_visits = candidate_count,
                blocked = blocked,
                preexisting =
                    building_state.existing_world_match ~= nil,
            })
            return finish_timed_validation(
                false, "failed to update per-building overlap material"
            )
        end
        BlueprintOverlapTiming.add_elapsed(
            timing_probe, "material_update_ms",
            material_started_at
        )
        if blocked then
            overlap_count = overlap_count + 1
            timing_blocker_count = overlap_count
            local blocker_reason = building_state.blocker
                and building_state.blocker.reason or "unknown"
            if is_build_object_blocker_reason(
                blocker_reason
            ) then
                table.insert(status_parts, string.format(
                    "%s query=%s<-%s at=%s[%s]:%s",
                    tostring(building_state.source_instance_id),
                    format_vector(safe_property(
                        collision_transform, "Translation"
                    )),
                    tostring(building_state.blocker.actor_label),
                    format_vector(building_state.blocker.location),
                    tostring(blocker_reason),
                    tostring(building_state.blocker.component_label)
                ))
            else
                -- Dynamic blockers (especially Pal pawns) are intentionally
                -- opaque after classification. Calling reflected methods on
                -- them from Lua can race their movement/destruction and cause
                -- a native access violation that pcall cannot contain.
                table.insert(status_parts, string.format(
                    "%s query=%s<-dynamic[%s]",
                    tostring(building_state.source_instance_id),
                    format_vector(safe_property(
                        collision_transform, "Translation"
                    )),
                    tostring(blocker_reason)
                ))
            end
            if not validate_all_invalid_ghosts then
                stopped_at_index = building_index
                break
            end
        end
        local member_total_ms = BlueprintOverlapTiming.elapsed_ms(
            member_started_at
        )
        BlueprintOverlapTiming.add_ms(
            timing_probe, "member_total_ms", member_total_ms
        )
        BlueprintOverlapTiming.record_member(timing_probe, {
            index = building_index,
            source_instance_id = building_state.source_instance_id,
            build_object_id = building_state.build_object_id,
            total_ms = member_total_ms,
            classify_ms = member_classify_ms,
            query_ms = 0.0,
            candidate_count = candidate_count,
            pair_visits = candidate_count,
            blocked = blocked,
            preexisting =
                building_state.existing_world_match ~= nil,
        })
    end

    if not blocker_visual_applied then
        local blocker_clear_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        blueprint_blocker_visual.clear(session)
        BlueprintOverlapTiming.add_elapsed(
            timing_probe, "blocker_visual_clear_ms",
            blocker_clear_started_at
        )
    end

    -- Units after an early-stop point were not queried this pass.  They cannot
    -- retain red material or blocker metadata from an older full/fast pass.
    if stopped_at_index ~= nil then
        local tail_clear_started_at =
            BlueprintOverlapTiming.now(timing_probe)
        for building_index = stopped_at_index + 1,
            #blueprint_ghost_state.buildings do
            local building_state = blueprint_ghost_state.buildings[building_index]
            building_state.blocker = nil
            building_state.existing_world_match = nil
            building_state.water_surface_overlap = false
            if not set_blueprint_ghost_building_blocked(
                session, building_state, false
            ) then
                BlueprintOverlapTiming.add_elapsed(
                    timing_probe, "tail_clear_ms",
                    tail_clear_started_at
                )
                return finish_timed_validation(
                    false, "failed to clear unvisited overlap material"
                )
            end
        end
        BlueprintOverlapTiming.add_elapsed(
            timing_probe, "tail_clear_ms", tail_clear_started_at
        )
    end

    local finalize_started_at =
        BlueprintOverlapTiming.now(timing_probe)
    blueprint_preview_overlap_count = overlap_count
    blueprint_preview_water_block_count = water_block_count
    blueprint_preview_water_gate_unavailable = water_gate_unavailable
    blueprint_preview_all_placeable = overlap_count == 0
    local validation_signature = string.format(
        "mode=%s componentOverlaps=%d existingMatches=%d scanned=%d/%d candidates=%d obstructions=%s",
        validate_all_invalid_ghosts and "full-visual" or "fast-gate",
        overlap_count, existing_world_match_count,
        scanned_building_count, #blueprint_ghost_state.buildings,
        broadphase_candidate_count,
        table.concat(status_parts, ",")
    )
    if validation_signature ~= blueprint_preview_validation_signature then
        blueprint_preview_validation_signature = validation_signature
        log("blueprint placement validation changed " .. validation_signature)
    end
    timing_scanned_buildings = scanned_building_count
    timing_blocker_count = overlap_count
    timing_broadphase_candidates = broadphase_candidate_count
    timing_existing_matches = existing_world_match_count
    BlueprintOverlapTiming.add_elapsed(
        timing_probe, "finalize_ms", finalize_started_at
    )
    if native_shadow_generation ~= nil then
        blueprint_native_overlap_gate.remember_expected(
            native_shadow_generation, blueprint_ghost_state.buildings
        )
    end
    return finish_timed_validation(true, nil)
end

-- The legacy gate above remains available for rollback diagnostics, but the
-- production overlap path is authoritative from Palworld's own independent
-- InstallChecker pool.  A request is completed over subsequent stock Checker
-- evaluations; neither submission nor result application performs a world
-- UObject search.
function build_blueprint_native_overlap_query_states(anchor_transform)
    local math_library = UEHelpers.GetKismetMathLibrary()
    local anchor_record = get_blueprint_anchor_record()
    if not is_valid_object(math_library)
        or anchor_transform == nil
        or anchor_record == nil
        or blueprint_ghost_state.anchor_actor_relative_to_model == nil then
        return nil, "native overlap anchor query dependencies unavailable"
    end

    local anchor_model_transform = nil
    local transform_ok, transform_error = pcall(function()
        local model_relative_to_actor = math_library:InvertTransform(
            blueprint_ghost_state.anchor_actor_relative_to_model
        )
        anchor_model_transform = math_library:ComposeTransforms(
            model_relative_to_actor, anchor_transform
        )
    end)
    if not transform_ok or anchor_model_transform == nil then
        return nil, "native overlap anchor model transform failed error="
            .. tostring(transform_error)
    end

    local query_states = {}
    for _, building_state in ipairs(
        blueprint_ghost_state.buildings or {}
    ) do
        query_states[#query_states + 1] = building_state
    end
    query_states[#query_states + 1] = {
        build_object_id = anchor_record.build_object_id
            or blueprint_preview_anchor_build_object_id,
        source_instance_id = anchor_record.source_instance_id,
        selection_index = anchor_record.selection_index or 0,
        install_strategy = anchor_record.install_strategy,
        actor_relative_to_model =
            blueprint_ghost_state.anchor_actor_relative_to_model,
        overlap_relative_transform =
            blueprint_ghost_state.anchor_overlap_relative_transform,
        world_transform = anchor_model_transform,
        native_overlap_query_role = "anchor",
    }
    return query_states, nil
end

function validate_blueprint_ghost_overlaps(
    session, anchor_transform, session_references, trigger
)
    if not BlueprintResearchSettings
        .get_blueprint_overlap_gate_enabled() then
        if blueprint_native_overlap_gate.has_pending() then
            blueprint_native_overlap_gate.reset()
        end
        for _, building_state in ipairs(
            blueprint_ghost_state.buildings or {}
        ) do
            building_state.blocker = nil
            building_state.existing_world_match = nil
            building_state.water_surface_overlap = false
            -- Visual cleanup is best-effort in compatibility mode. A stale
            -- diagnostic material must never become a replacement gate.
            pcall(
                set_blueprint_ghost_building_blocked,
                session, building_state, false
            )
        end
        blueprint_blocker_visual.clear(session)
        blueprint_native_overlap_pending_revision = nil
        blueprint_native_overlap_completed_revision = nil
        blueprint_native_overlap_last_report = nil
        blueprint_preview_overlap_count = 0
        blueprint_preview_water_block_count = 0
        blueprint_preview_water_gate_unavailable = false
        blueprint_preview_all_placeable = true
        blueprint_preview_validation_dirty = false
        local signature = string.format(
            "mode=disabled revision=%d trigger=%s",
            tonumber(blueprint_preview_validation_revision) or 0,
            tostring(trigger or "unknown")
        )
        if signature ~= blueprint_preview_validation_signature then
            blueprint_preview_validation_signature = signature
            log("blueprint overlap gate bypassed " .. signature)
        end
        return true, nil
    end

    if blueprint_native_overlap_gate.has_pending() then
        blueprint_preview_all_placeable = false
        return true, "native overlap validation pending"
    end

    for _, building_state in ipairs(
        blueprint_ghost_state.buildings or {}
    ) do
        building_state.blocker = nil
        building_state.existing_world_match = nil
        building_state.water_surface_overlap = false
        if not set_blueprint_ghost_building_blocked(
            session, building_state, false
        ) then
            return false,
                "failed to clear native overlap member material"
        end
    end
    blueprint_blocker_visual.clear(session)

    local query_states, query_error =
        build_blueprint_native_overlap_query_states(anchor_transform)
    if query_states == nil then
        blueprint_preview_all_placeable = false
        return false, query_error
    end
    local generation, submit_error =
        blueprint_native_overlap_gate.submit(
            session, query_states
        )
    if generation == nil then
        blueprint_preview_all_placeable = false
        return false, submit_error
    end

    blueprint_native_overlap_pending_revision =
        blueprint_preview_validation_revision
    blueprint_native_overlap_completed_revision = nil
    blueprint_native_overlap_last_report = nil
    blueprint_preview_all_placeable = false
    blueprint_preview_overlap_count = 0
    blueprint_preview_water_block_count = 0
    blueprint_preview_water_gate_unavailable = false
    blueprint_preview_validation_signature = string.format(
        "mode=native-checker status=pending generation=%d revision=%d trigger=%s",
        tonumber(generation) or -1,
        tonumber(blueprint_preview_validation_revision) or 0,
        tostring(trigger or "unknown")
    )
    return true, nil
end

local function usable_native_blocker_text(value)
    local text = tostring(value or "")
    return text ~= "" and text ~= "None" and text ~= "<nil>"
        and text ~= "<unknown>" and text ~= "<unavailable>"
        and text ~= "<native-checker>"
end

local function native_blocker_display_label(blocker)
    blocker = blocker or {}
    local class_name = tostring(blocker.class_name or "")
    local object_name_value = tostring(blocker.object_name or "")
    if usable_native_blocker_text(class_name) then
        return class_name
    end
    if usable_native_blocker_text(object_name_value) then
        return string.gsub(object_name_value, "_%d+$", "")
    end
    return nil
end

function apply_native_overlap_authority_report(session, report)
    local member_results = report and report.member_results or {}
    local buildings = blueprint_ghost_state.buildings or {}
    local expected_result_count = #buildings + 1
    local native_error_count =
        tonumber(report and report.native_error_count) or 0
    if tonumber(report and report.status) == 3
        or native_error_count > 0 then
        return false,
            "native overlap checker failed status="
                .. tostring(report and report.status)
                .. " errors=" .. tostring(native_error_count)
    end
    if #member_results ~= expected_result_count then
        return false,
            "native overlap result count mismatch results="
                .. tostring(#member_results)
                .. " expected=" .. tostring(expected_result_count)
    end
    local anchor_result = member_results[expected_result_count]
    if anchor_result == nil
        or anchor_result.query_role ~= "anchor" then
        return false, "native overlap anchor result is missing"
    end

    local blocked_count = 0
    local existing_match_count = 0
    for building_index, building_state in ipairs(buildings) do
        local member_result = member_results[building_index]
        building_state.blocker = nil
        building_state.existing_world_match = nil
        building_state.water_surface_overlap = false

        if member_result.existing_world_match == true then
            local candidate = member_result.matched_candidate or {}
            local details = member_result.equivalence_details or {}
            building_state.existing_world_match = {
                instance_id = candidate.instance_id,
                build_object_id = candidate.build_object_id,
                model_location = candidate.location,
                model_rotation = candidate.rotation,
                position_error = details.position_error,
                angle_error_degrees =
                    details.angle_error_degrees,
                matched_equivalent_yaw =
                    details.matched_equivalent_yaw,
            }
            existing_match_count = existing_match_count + 1
        elseif member_result.blocked == true then
            blocked_count = blocked_count + 1
            local native_blocker =
                member_result.primary_blocker or {}
            local blocker_build_object_id =
                tostring(native_blocker.build_object_id or "")
            local blocker_is_build_object =
                native_blocker.is_build_object == true
                and usable_native_blocker_text(
                    blocker_build_object_id
                )
            local blocker_display_label =
                native_blocker_display_label(native_blocker)
            building_state.blocker = {
                blocked = true,
                category = blocker_is_build_object
                    and "build_object" or "native_checker",
                reason = member_result.native_error
                    and "native-checker-error"
                    or (blocker_is_build_object
                        and "build-object:native-checker"
                        or "native-checker-overlap"),
                profile = "result:"
                    .. tostring(member_result.native_result),
                build_object_id = blocker_is_build_object
                    and blocker_build_object_id or "<dynamic>",
                actor_label = native_blocker.object_name
                    or "<native-checker>",
                actor_class_label = native_blocker.class_name
                    or "<native-checker>",
                component_label = native_blocker.object_name
                    or "<native-checker>",
                component_class_label = native_blocker.class_name
                    or "<native-checker>",
                display_label = blocker_display_label,
                native_blocker_count =
                    tonumber(member_result.blocker_count) or 0,
                primary_actor_only = true,
                equivalence_rejection =
                    member_result.equivalence_rejection,
                rejected_candidate =
                    member_result.rejected_candidate,
            }
        end

        if not set_blueprint_ghost_building_blocked(
            session, building_state,
            building_state.blocker ~= nil
        ) then
            return false,
                "failed to apply native overlap member material index="
                    .. tostring(building_index)
        end
    end

    if anchor_result.existing_world_match == true then
        existing_match_count = existing_match_count + 1
    elseif anchor_result.blocked == true then
        blocked_count = blocked_count + 1
    end

    blueprint_blocker_visual.clear(session)
    blueprint_preview_overlap_count = blocked_count
    blueprint_preview_water_block_count = 0
    blueprint_preview_water_gate_unavailable = false
    blueprint_preview_all_placeable =
        report.placeable == true and blocked_count == 0
    blueprint_preview_validation_signature = string.format(
        "mode=native-checker status=complete generation=%d revision=%d blockers=%d existingMatches=%d scanned=%d/%d",
        tonumber(report.generation) or -1,
        tonumber(blueprint_preview_validation_revision) or 0,
        blocked_count,
        existing_match_count,
        #member_results,
        expected_result_count
    )
    return true, nil
end

local function read_placement_session_references(session)
    local references = {
        builder = unwrap(safe_property(
            session, "SBB_PlacementBuilder"
        )),
        checker = unwrap(safe_property(
            session, "SBB_PlacementChecker"
        )),
        anchor = unwrap(safe_property(
            session, "SBB_PlacementAnchor"
        )),
    }
    return references
end

function poll_native_overlap_authority(session)
    local report = blueprint_native_overlap_gate.poll(session)
    if report == nil then return end

    local completed_revision = blueprint_native_overlap_pending_revision
    blueprint_native_overlap_pending_revision = nil
    if completed_revision ~= blueprint_preview_validation_revision then
        log(string.format(
            "blueprint native overlap result discarded generation=%d requestRevision=%s currentRevision=%d",
            tonumber(report.generation) or -1,
            tostring(completed_revision),
            tonumber(blueprint_preview_validation_revision) or 0
        ))
        blueprint_preview_all_placeable = false
        blueprint_preview_validation_dirty = true
        blueprint_preview_validation_cooldown_ticks = 0
        return
    end

    local applied, apply_error =
        apply_native_overlap_authority_report(session, report)
    if not applied then
        blueprint_preview_all_placeable = false
        blueprint_preview_validation_dirty = true
        send_blueprint_message(
            "message.placement.overlap_checker_failed"
        )
        stop_blueprint_preview(
            "native-overlap-result-apply-failed-"
                .. tostring(apply_error)
        )
        return
    end
    blueprint_native_overlap_completed_revision =
        completed_revision
    blueprint_native_overlap_last_report = report
    blueprint_preview_validation_dirty = false
    log(string.format(
        "blueprint native overlap gate completed generation=%d revision=%d completed=%d/%d overlaps=%d candidates=%d blockerIdentities=%d clearCandidateMembers=%d clearCandidates=%d existingMatches=%d blockers=%d errors=%d placeable=%s",
        tonumber(report.generation) or -1,
        tonumber(completed_revision) or 0,
        tonumber(report.completed_count) or 0,
        tonumber(report.result_count) or 0,
        tonumber(report.native_overlap_count) or 0,
        tonumber(report.native_candidate_count) or 0,
        tonumber(report.native_blocker_count) or 0,
        tonumber(report.native_clear_candidate_member_count) or 0,
        tonumber(report.native_clear_candidate_count) or 0,
        tonumber(report.existing_match_count) or 0,
        tonumber(report.blocked_count) or 0,
        tonumber(report.native_error_count) or 0,
        tostring(report.placeable == true)
    ))
    local blocked_diagnostic_count = 0
    for _, member_result in ipairs(report.member_results or {}) do
        if member_result.blocked == true then
            blocked_diagnostic_count = blocked_diagnostic_count + 1
            if blocked_diagnostic_count > 8 then break end
            local rejection = member_result.equivalence_rejection or {}
            local rejected_candidate =
                member_result.rejected_candidate or {}
            local expected_location =
                rejection.expected_location or {}
            local candidate_location =
                rejection.candidate_location or {}
            local blocker_parts = {}
            for blocker_index, blocker in ipairs(
                member_result.blockers or {}
            ) do
                if blocker_index > 4 then break end
                blocker_parts[#blocker_parts + 1] = string.format(
                    "%d:{build=%s object=%s class=%s isBuild=%s}",
                    blocker_index,
                    tostring(blocker.build_object_id or "<nil>"),
                    tostring(blocker.object_name or "<nil>"),
                    tostring(blocker.class_name or "<nil>"),
                    tostring(blocker.is_build_object == true)
                )
            end
            log_diagnostic(string.format(
                "blueprint native overlap blocked-member generation=%d revision=%d member=%d role=%s source=%s build=%s nativeResult=%s candidates=%d blockers=%d rejection=%s positionErrorCm=%s positionToleranceCm=%s angleErrorDeg=%s angleToleranceDeg=%s matchedYaw=%s expected=(%s,%s,%s) candidate=(%s,%s,%s) candidateBuild=%s candidateObject=%s blockerDetails=[%s]",
                tonumber(report.generation) or -1,
                tonumber(completed_revision) or 0,
                tonumber(member_result.index) or -1,
                tostring(member_result.query_role or "<unknown>"),
                tostring(member_result.source_instance_id or "<unknown>"),
                tostring(member_result.build_object_id or "<unknown>"),
                tostring(member_result.native_result),
                tonumber(member_result.candidate_count) or 0,
                tonumber(member_result.blocker_count) or 0,
                tostring(rejection.reason or "<no-equivalent-candidate>"),
                tostring(rejection.position_error or "<nil>"),
                tostring(rejection.position_tolerance or "<nil>"),
                tostring(rejection.angle_error_degrees or "<nil>"),
                tostring(rejection.angle_tolerance_degrees or "<nil>"),
                tostring(rejection.matched_equivalent_yaw or "<nil>"),
                tostring(expected_location.x or "<nil>"),
                tostring(expected_location.y or "<nil>"),
                tostring(expected_location.z or "<nil>"),
                tostring(candidate_location.x or "<nil>"),
                tostring(candidate_location.y or "<nil>"),
                tostring(candidate_location.z or "<nil>"),
                tostring(
                    rejected_candidate.build_object_id or "<nil>"
                ),
                tostring(rejected_candidate.instance_id or "<nil>"),
                table.concat(blocker_parts, ",")
            ))
        end
    end
    for item_index, item in ipairs(
        report.native_clear_candidates or {}
    ) do
        if item_index > 16 then break end
        local candidate = item.candidate or {}
        local location = candidate.location or {}
        local rotation = candidate.rotation or {}
        log(string.format(
            "blueprint native overlap gate success-candidate generation=%d item=%d/%d member=%d build=%s nativeResult=%d candidateBuild=%s candidateObject=%s location=(%.3f,%.3f,%.3f) rotation=(X=%.6f,Y=%.6f,Z=%.6f,W=%.6f)",
            tonumber(report.generation) or -1,
            item_index,
            tonumber(report.native_clear_candidate_count) or 0,
            tonumber(item.index) or -1,
            tostring(item.build_object_id or "<unknown>"),
            tonumber(item.native_result) or -1,
            tostring(candidate.build_object_id or "<unknown>"),
            tostring(candidate.instance_id or "<unknown>"),
            tonumber(location.x) or 0.0,
            tonumber(location.y) or 0.0,
            tonumber(location.z) or 0.0,
            tonumber(rotation.x) or 0.0,
            tonumber(rotation.y) or 0.0,
            tonumber(rotation.z) or 0.0,
            tonumber(rotation.w) or 0.0
        ))
    end
    if (tonumber(report.native_clear_candidate_count) or 0) > 16 then
        log(string.format(
            "blueprint native overlap gate success-candidate omitted generation=%d count=%d",
            tonumber(report.generation) or -1,
            (tonumber(report.native_clear_candidate_count) or 0) - 16
        ))
    end
end

function synchronize_placement_session_references(session)
    local references = read_placement_session_references(session)
    if not is_valid_object(references.builder) then
        return references
    end

    local live_checker = unwrap(safe_property(
        references.builder, "InstallChecker"
    ))
    if is_valid_object(live_checker)
        and safe_object_address(live_checker)
            ~= safe_object_address(references.checker) then
        blueprint_placement_runtime_backend.update_reference(
            session, "checker", live_checker
        )
        references.checker = live_checker
    end
    if not is_valid_object(references.checker) then
        return references
    end

    local live_anchor = unwrap(safe_property(
        references.checker, "TargetBuildObject"
    ))
    if safe_object_address(live_anchor)
        ~= safe_object_address(references.anchor) then
        blueprint_placement_runtime_backend.update_reference(
            session,
            "anchor",
            is_valid_object(live_anchor) and live_anchor or nil
        )
        references.anchor =
            is_valid_object(live_anchor) and live_anchor or nil
    end
    return references
end

function get_current_placement_session_references()
    local references = nil
    local ok = with_active_placement_session(function(session)
        references = synchronize_placement_session_references(session)
    end)
    if not ok then return nil end
    return references
end

local function unlock_blueprint_submission_if_preview_ready(anchor_actor)
    if not blueprint_continuous_unlock_pending
        or not blueprint_preview_active
        or not blueprint_continuous_next_anchor_seen
        or not is_valid_object(anchor_actor)
        or blueprint_preview_last_anchor_transform == nil
        or blueprint_preview_validation_dirty
        or blueprint_preview_validation_signature == nil then
        return false
    end
    blueprint_continuous_unlock_pending = false
    blueprint_continuous_next_anchor_seen = false
    blueprint_commit_queued = false
    blueprint_placement_input.set_primary_locked(false)
    return true
end

function capture_blueprint_transform_motion_signature(transform)
    local translation = safe_property(transform, "Translation")
    local rotation = safe_property(transform, "Rotation")
    local scale = safe_property(transform, "Scale3D")
    local signature = {
        x = tonumber(safe_property(translation, "X")),
        y = tonumber(safe_property(translation, "Y")),
        z = tonumber(safe_property(translation, "Z")),
        pitch = tonumber(safe_property(rotation, "X")),
        yaw = tonumber(safe_property(rotation, "Y")),
        roll = tonumber(safe_property(rotation, "Z")),
        scale_x = tonumber(safe_property(scale, "X")),
        scale_y = tonumber(safe_property(scale, "Y")),
        scale_z = tonumber(safe_property(scale, "Z")),
    }
    for _, name in ipairs({
        "x", "y", "z", "pitch", "yaw", "roll",
        "scale_x", "scale_y", "scale_z",
    }) do
        if signature[name] == nil then return nil end
    end
    return signature
end

function capture_blueprint_anchor_motion_signature(anchor_actor)
    local motion_signature = nil
    pcall(function()
        local location = unwrap(anchor_actor:K2_GetActorLocation())
        local rotation = unwrap(anchor_actor:K2_GetActorRotation())
        local transform = unwrap(anchor_actor:GetTransform())
        local scale = unwrap(safe_property(transform, "Scale3D"))
        motion_signature = {
            x = tonumber(location.X),
            y = tonumber(location.Y),
            z = tonumber(location.Z),
            pitch = tonumber(rotation.Pitch),
            yaw = tonumber(rotation.Yaw),
            roll = tonumber(rotation.Roll),
            scale_x = tonumber(safe_property(scale, "X")),
            scale_y = tonumber(safe_property(scale, "Y")),
            scale_z = tonumber(safe_property(scale, "Z")),
        }
    end)
    if motion_signature == nil
        or motion_signature.x == nil or motion_signature.y == nil
        or motion_signature.z == nil or motion_signature.pitch == nil
        or motion_signature.yaw == nil
        or motion_signature.roll == nil
        or motion_signature.scale_x == nil
        or motion_signature.scale_y == nil
        or motion_signature.scale_z == nil then
        return nil
    end
    return motion_signature
end

function blueprint_anchor_motion_changed(current, previous)
    if current == nil then return false end
    if previous == nil then return true end
    local delta_x = current.x - previous.x
    local delta_y = current.y - previous.y
    local delta_z = current.z - previous.z
    local position_tolerance =
        BlueprintAnchorSettle.position_tolerance_cm
    local scale_tolerance =
        BlueprintAnchorSettle.scale_tolerance
    return delta_x * delta_x + delta_y * delta_y + delta_z * delta_z
            > position_tolerance * position_tolerance
        or BlueprintAnchorSettle.angular_distance_degrees(
            current.pitch, previous.pitch
        ) > BlueprintAnchorSettle.rotation_tolerance_degrees
        or BlueprintAnchorSettle.angular_distance_degrees(
            current.yaw, previous.yaw
        ) > BlueprintAnchorSettle.rotation_tolerance_degrees
        or BlueprintAnchorSettle.angular_distance_degrees(
            current.roll, previous.roll
        ) > BlueprintAnchorSettle.rotation_tolerance_degrees
        or math.abs(current.scale_x - previous.scale_x)
            > scale_tolerance
        or math.abs(current.scale_y - previous.scale_y)
            > scale_tolerance
        or math.abs(current.scale_z - previous.scale_z)
            > scale_tolerance
end

function invalidate_native_overlap_for_anchor_motion(
    motion_signature
)
    blueprint_preview_last_anchor_transform = motion_signature
    blueprint_preview_validation_revision =
        blueprint_preview_validation_revision + 1
    blueprint_native_overlap_completed_revision = nil
    blueprint_native_overlap_last_report = nil
    blueprint_preview_all_placeable = false
    blueprint_preview_validation_dirty = true
    blueprint_preview_validation_cooldown_ticks =
        BLUEPRINT_VALIDATION_INTERVAL_TICKS
end

local function tick_blueprint_preview_impl(session)
    if not blueprint_preview_active then return end
    poll_native_overlap_authority(session)
    BlueprintWaveRuntime.preview_session_tick_count =
        BlueprintWaveRuntime.preview_session_tick_count + 1
    local first_tick = BlueprintWaveRuntime.preview_first_tick_pending == true
    if blueprint_placement_input ~= nil
        and blueprint_placement_input.is_camera_active() then
        return
    end
    -- Preview ghosts retain their own ownership and may follow the stock next
    -- anchor while an independent, fixed wave-visual set is being constructed.
    -- Submission is locked only until the stock next anchor has been acquired
    -- and its first validation pass has settled.
    local monitor_tick =
        BlueprintWaveRuntime.preview_session_tick_count
    local lifecycle_audit_due = first_tick
        or monitor_tick
            % BLUEPRINT_PLACEMENT_LIFECYCLE_AUDIT_TICKS == 0
    local session_references = lifecycle_audit_due
        and synchronize_placement_session_references(session)
        or {
            anchor = unwrap(safe_property(
                session, "SBB_PlacementAnchor"
            )),
        }
    if not is_valid_object(session_references.anchor) then
        -- A stock preview may be created or replaced between monitor ticks.
        -- Reacquire immediately only when the UE-owned reference is missing.
        session_references =
            synchronize_placement_session_references(session)
        lifecycle_audit_due = true
    end
    local builder = session_references.builder
    if lifecycle_audit_due and not is_valid_object(builder) then
        stop_blueprint_preview("builder-invalid")
        return
    end
    local in_building_mode = true
    if lifecycle_audit_due then
        pcall(function()
            in_building_mode = builder:IsInBuildingMode()
        end)
    end
    if not in_building_mode then
        stop_blueprint_preview("original-building-mode-ended")
        return
    end

    local checker = session_references.checker
    local anchor_actor = session_references.anchor
    if first_tick then
        BlueprintWaveRuntime.preview_first_tick_pending = false
    end
    if not is_valid_object(anchor_actor) then
        blueprint_preview_wait_ticks = blueprint_preview_wait_ticks + 1
        if blueprint_preview_wait_ticks > 180 then
            stop_blueprint_preview("anchor-preview-timeout")
        end
        return
    end
    blueprint_preview_wait_ticks = 0
    if lifecycle_audit_due then
        local target_build_object_id = value_to_string(
            safe_property(anchor_actor, "BuildObjectId")
        )
        if target_build_object_id
            ~= blueprint_preview_anchor_build_object_id then
            stop_blueprint_preview(
                "original-target-changed-to-"
                    .. tostring(target_build_object_id)
            )
            return
        end
    end
    local anchor_address = safe_object_address(anchor_actor)
    if blueprint_continuous_unlock_pending and anchor_address ~= nil then
        -- Palworld may either replace the stock preview actor or reuse the
        -- same actor for continuous placement. Reaching this monitor tick
        -- means the original BuildObject/RequestBuild reflected stack has
        -- unwound, so a valid current TargetBuildObject is the next preview
        -- generation even when its address was reused.
        blueprint_continuous_next_anchor_seen = true
    end
    local root_attached = true
    local root_attach_error = nil
    local anchor_reference_changed = anchor_address == nil
        or anchor_address ~= blueprint_preview_attached_anchor_address
    if anchor_reference_changed then
        root_attached, root_attach_error =
            blueprint_ghost_renderer.attach_root_to_anchor(
                session, anchor_actor
            )
        if root_attached and anchor_address ~= nil then
            blueprint_preview_attached_anchor_address =
                anchor_address
        end
    end
    local raw_moved_anchor_transform = nil
    pcall(function()
        raw_moved_anchor_transform = anchor_actor:GetTransform()
    end)
    if raw_moved_anchor_transform == nil then return end
    local terrain_snap_active, terrain_snap_transform,
        terrain_snap_error = update_blueprint_terrain_snap(
            session, anchor_actor, raw_moved_anchor_transform,
            anchor_reference_changed
        )
    if terrain_snap_error ~= nil then
        report_blueprint_terrain_snap_failure(
            "preview", terrain_snap_error
        )
        terrain_snap_active = false
        terrain_snap_transform = nil
    end
    local motion_signature = terrain_snap_active
        and capture_blueprint_transform_motion_signature(
            terrain_snap_transform
        )
        or capture_blueprint_anchor_motion_signature(anchor_actor)
    if motion_signature == nil then return end
    local previous_motion = blueprint_preview_last_anchor_transform
    local anchor_moved = blueprint_anchor_motion_changed(
        motion_signature, previous_motion
    )
    if anchor_moved then
        invalidate_native_overlap_for_anchor_motion(
            motion_signature
        )
        local moved_anchor_transform = terrain_snap_transform
            or raw_moved_anchor_transform
        local moved_anchor_alignment = nil
        local moved_anchor_alignment_error = nil
        if not terrain_snap_active then
            moved_anchor_transform, moved_anchor_alignment,
                moved_anchor_alignment_error =
                    resolve_anchor_presentation_transform(
                        raw_moved_anchor_transform, anchor_actor,
                        "anchor-motion"
                    )
        end
        if moved_anchor_transform == nil then
            stop_blueprint_preview(
                "anchor-motion-correction-failed-"
                    .. tostring(moved_anchor_alignment_error)
            )
            return
        end
        local moved_frame_corrected = terrain_snap_active
            or (moved_anchor_alignment ~= nil
                and moved_anchor_alignment.presentation_normalized == true)
        if not terrain_snap_active
            and (not root_attached or moved_frame_corrected
                or blueprint_preview_anchor_frame_corrected) then
            local update_ok, update_error =
                update_blueprint_ghost_root_transform(
                    session, moved_anchor_transform
                )
            if not update_ok then
                stop_blueprint_preview(
                    "ghost-update-failed-" .. tostring(update_error)
                        .. "-attach-" .. tostring(root_attach_error)
                )
                return
            end
        end
        blueprint_preview_anchor_frame_corrected =
            moved_frame_corrected
    end

    if not blueprint_preview_validation_dirty then
        unlock_blueprint_submission_if_preview_ready(anchor_actor)
        return
    end
    if blueprint_preview_validation_cooldown_ticks > 0 then
        blueprint_preview_validation_cooldown_ticks =
            blueprint_preview_validation_cooldown_ticks - 1
        return
    end
    local overlap_gate_enabled =
        BlueprintResearchSettings.get_blueprint_overlap_gate_enabled()
    if not is_valid_object(session_references.builder)
        or (
            overlap_gate_enabled
            and not is_valid_object(session_references.checker)
        ) then
        session_references =
            synchronize_placement_session_references(session)
    end
    if not is_valid_object(session_references.builder)
        or (
            overlap_gate_enabled
            and not is_valid_object(session_references.checker)
        )
        or not is_valid_object(session_references.anchor) then
        stop_blueprint_preview("validation-references-invalid")
        return
    end
    anchor_actor = session_references.anchor
    local validation_anchor_address = safe_object_address(anchor_actor)
    if validation_anchor_address == nil then return end
    if validation_anchor_address
        ~= blueprint_preview_attached_anchor_address then
        local attached = blueprint_ghost_renderer.attach_root_to_anchor(
            session, anchor_actor
        )
        if attached then
            blueprint_preview_attached_anchor_address =
                validation_anchor_address
        end
    end
    local raw_anchor_transform = nil
    pcall(function()
        raw_anchor_transform = anchor_actor:GetTransform()
    end)
    if raw_anchor_transform == nil then return end
    terrain_snap_active, terrain_snap_transform, terrain_snap_error =
        update_blueprint_terrain_snap(
            session, anchor_actor, raw_anchor_transform,
            validation_anchor_address
                ~= blueprint_preview_attached_anchor_address
        )
    if terrain_snap_error ~= nil then
        report_blueprint_terrain_snap_failure(
            "settled-preview", terrain_snap_error
        )
        terrain_snap_active = false
        terrain_snap_transform = nil
    end
    blueprint_placement_anchor_probe.observe(
        session_references, "settled-preview-before-correction"
    )
    local anchor_transform = terrain_snap_transform or raw_anchor_transform
    local anchor_alignment = nil
    local alignment_error = nil
    if not terrain_snap_active then
        anchor_transform, anchor_alignment, alignment_error =
            resolve_anchor_presentation_transform(
                raw_anchor_transform, anchor_actor, "settled-preview"
            )
    end
    if anchor_transform == nil then
        stop_blueprint_preview(
            "anchor-correction-failed-" .. tostring(alignment_error)
        )
        return
    end
    if terrain_snap_active then
        blueprint_preview_anchor_frame_corrected = true
    elseif anchor_alignment ~= nil
        and anchor_alignment.presentation_normalized == true then
        local root_ok, root_error =
            update_blueprint_ghost_root_transform(
                session, anchor_transform
            )
        if not root_ok then
            stop_blueprint_preview(
                "anchor-correction-root-failed-"
                    .. tostring(root_error)
            )
            return
        end
        blueprint_preview_anchor_frame_corrected = true
    elseif blueprint_preview_anchor_frame_corrected then
        local root_ok, root_error =
            update_blueprint_ghost_root_transform(
                session, raw_anchor_transform
            )
        if not root_ok then
            stop_blueprint_preview(
                "anchor-correction-reset-failed-"
                    .. tostring(root_error)
            )
            return
        end
        blueprint_preview_anchor_frame_corrected = false
    end
    local world_ok, world_error = refresh_blueprint_ghost_world_transforms(
        session, anchor_transform
    )
    if not world_ok then
        stop_blueprint_preview(
            "validation-world-transform-failed-" .. tostring(world_error)
        )
        return
    end
    local validation_ok, validation_error =
        validate_blueprint_ghost_overlaps(
            session, anchor_transform, session_references,
            "settled-preview"
        )
    if not validation_ok then
        stop_blueprint_preview("overlap-validation-failed-" .. tostring(validation_error))
        return
    end
    pcall(
        blueprint_placement_hud_materials.refresh,
        "placement-validation-settled"
    )
    blueprint_preview_validation_cooldown_ticks =
        BLUEPRINT_VALIDATION_INTERVAL_TICKS
    unlock_blueprint_submission_if_preview_ready(anchor_actor)
end

local function tick_blueprint_preview(session)
    blueprint_preview_session_tick_in_progress = true
    local ok, error_value = pcall(
        tick_blueprint_preview_impl, session
    )
    blueprint_preview_session_tick_in_progress = false
    if ok then return end
    log("blueprint preview session Tick isolated error="
        .. tostring(error_value))
    pcall(stop_blueprint_preview, "session-tick-error", false, true)
end

handle_blueprint_placement_session_tick = function(session)
    tick_blueprint_preview(session)
end

local function start_blueprint_preview_monitor(builder, anchor_build_object_id)
    stop_blueprint_preview("restart")
    blueprint_placement_anchor_probe.reset()
    blueprint_native_overlap_gate.reset()
    blueprint_preview_water_capability =
        blueprint_water_building_gate.capture()
    if blueprint_preview_water_capability.available ~= true then
        log("blueprint water-building capability warning: "
            .. tostring(blueprint_preview_water_capability.error))
    else
        log("blueprint water-building capability captured unlocked="
            .. tostring(blueprint_preview_water_capability.unlocked)
            .. " count="
            .. tostring(blueprint_preview_water_capability.count))
    end
    blueprint_preview_active = true
    if not is_valid_object(builder) then
        stop_blueprint_preview("builder-unavailable")
        return false
    end
    blueprint_preview_anchor_build_object_id = anchor_build_object_id
    blueprint_preview_building_model_address = nil
    blueprint_preview_attached_anchor_address = nil
    blueprint_preview_anchor_correction_signature = nil
    blueprint_preview_anchor_frame_corrected = false
    local network_ready, network_error =
        capture_blueprint_preview_network_handle()
    if not network_ready then
        log("blueprint placement network handle unavailable at preview start error="
            .. tostring(network_error))
    end
    blueprint_preview_wait_ticks = 0
    blueprint_preview_last_anchor_transform = nil
    blueprint_preview_all_placeable = false
    blueprint_preview_overlap_count = 0
    blueprint_preview_water_block_count = 0
    blueprint_preview_water_gate_unavailable = false
    blueprint_preview_validation_signature = nil
    blueprint_preview_validation_dirty = false
    blueprint_preview_validation_cooldown_ticks = 0
    blueprint_preview_validation_revision = 0
    blueprint_native_overlap_pending_revision = nil
    blueprint_native_overlap_completed_revision = nil
    blueprint_native_overlap_last_report = nil
    blueprint_commit_queued = false
    blueprint_continuous_unlock_pending = false
    blueprint_continuous_next_anchor_seen = false
    BlueprintWaveRuntime.preview_first_tick_pending = true
    BlueprintWaveRuntime.preview_session_tick_count = 0
    return true
end

local function start_blueprint_preview_from_compact(
    imported_compact, import_stats_or_error, source_label,
    preview_import_started_at, persisted_type_templates
)
    if blueprint_commit_queued then
        log("preview start aborted: the current preview commit is still closing")
        send_blueprint_message("message.placement.exit_pending")
        return false
    end
    if type(imported_compact) ~= "table" then
        log("preview start aborted: compact blueprint is unavailable source="
            .. tostring(source_label))
        send_blueprint_message("message.placement.incompatible")
        return false
    end
    import_stats_or_error = import_stats_or_error or {}
    source_label = tostring(source_label or "runtime")
    local restored_type_count = restore_blueprint_type_templates(
        persisted_type_templates
    )
    if restored_type_count > 0 then
        log("blueprint placement restored persisted type templates count="
            .. tostring(restored_type_count) .. " source=" .. source_label)
    end
    local templates_ready, template_error =
        ensure_blueprint_type_templates(imported_compact)
    if not templates_ready then
        log("preview start aborted: type hydration failed: "
            .. tostring(template_error))
        send_blueprint_message("message.placement.build_id_restore_failed")
        return
    end
    local imported_runtime, hydrate_stats_or_error =
        BlueprintJsonSchema.to_runtime(
            imported_compact, BlueprintTypeRuntimeCache
        )
    if imported_runtime == nil then
        log("preview start aborted: JSON hydration failed: "
            .. tostring(hydrate_stats_or_error))
        send_blueprint_message("message.placement.deserialize_failed")
        return
    end
    blueprint_clipboard = imported_runtime
    log(string.format(
        "blueprint JSON imported source=%s buildings=%d types=%d connections=%d externalSupports=%d jsonBytes=%d compressedBytes=%d codeChars=%d transport=%s",
        source_label,
        #blueprint_clipboard.buildings,
        tonumber(hydrate_stats_or_error.types) or 0,
        tonumber(hydrate_stats_or_error.connections) or 0,
        tonumber(hydrate_stats_or_error.external_supports) or 0,
        tonumber(import_stats_or_error.json_bytes) or 0,
        tonumber(import_stats_or_error.compressed_bytes) or 0,
        tonumber(import_stats_or_error.code_chars)
            or tonumber(import_stats_or_error.json_bytes) or 0,
        tostring(import_stats_or_error.transport)
    ))
    if blueprint_clipboard == nil or blueprint_clipboard.buildings == nil
        or #blueprint_clipboard.buildings == 0 then
        log("preview start aborted: blueprint source is empty; save or import a blueprint first")
        send_blueprint_message("message.placement.empty")
        return
    end
    if blueprint_clipboard.schema_version
            ~= BlueprintWaveRuntime.blueprint_schema_version
        or blueprint_clipboard.anchor_was_user_selected ~= true
        or blueprint_clipboard.anchor_instance_id == nil then
        log("preview start aborted: blueprint schema is not placement-ready or has no manually assigned anchor")
        send_blueprint_message("message.placement.incompatible")
        return
    end

    local clipboard_building = nil
    for _, building in ipairs(blueprint_clipboard.buildings) do
        if building.source_instance_id == blueprint_clipboard.anchor_instance_id
            and building.is_anchor == true then
            clipboard_building = building
            break
        end
    end
    if clipboard_building == nil or clipboard_building.build_object_id == nil then
        log("preview start aborted: manually assigned anchor record is missing from blueprint buildings")
        return
    end

    local build_menu_model = find_valid_instance("PalUIBuildModel", "/Engine/Transient")
    if build_menu_model == nil then
        log("preview start aborted: open the original build menu first")
        return
    end
    local builder = find_valid_instance("PalBuilderComponent", "/Game/Pal/Maps/")
    if builder == nil then
        log("preview start aborted: player builder component is unavailable")
        return
    end

    local build_object_id_value = FName(clipboard_building.build_object_id)
    if value_to_string(build_object_id_value)
        ~= clipboard_building.build_object_id then
        log("preview start aborted: FName conversion failed build="
            .. clipboard_building.build_object_id)
        return
    end

    if not start_blueprint_preview_monitor(builder, clipboard_building.build_object_id) then
        return
    end

    local input_prepared, input_prepare_error =
        blueprint_placement_input.prepare()
    if not input_prepared then
        log("preview start aborted: placement input preparation failed: "
            .. tostring(input_prepare_error))
        send_blueprint_message("message.placement.input_failed")
        stop_blueprint_preview("placement-input-prepare-failed")
        return
    end
    blueprint_start_build_forward_in_progress = true
    local ok, err = pcall(function()
        build_menu_model:StartBuildObject(build_object_id_value)
    end)
    blueprint_start_build_forward_in_progress = false
    if not ok then
        stop_blueprint_preview("original-StartBuildObject-failed")
        log("preview start failed: " .. tostring(err))
        return
    end
    local building_model = find_valid_instance_by_address(
        "BP_PalUIBuildingModel_C", blueprint_preview_building_model_address
    )
    if not is_valid_object(building_model) then
        building_model = find_valid_instance(
            "BP_PalUIBuildingModel_C", "/Engine/Transient"
        )
        blueprint_preview_building_model_address = safe_object_address(
            building_model
        )
    end
    local input_ok, input_error, placement_session = false, nil, nil
    if is_valid_object(building_model) then
        local placement_checker = unwrap(safe_property(
            builder, "InstallChecker"
        ))
        local placement_anchor = unwrap(safe_property(
            placement_checker, "TargetBuildObject"
        ))
        input_ok, input_error, placement_session =
            blueprint_placement_input.enter({
            builder = builder,
            checker = placement_checker,
            anchor = placement_anchor,
            building_model = building_model,
            tick_paused = true,
        })
    else
        input_error = "active PalUIBuildingModel instance was not captured"
    end
    if not input_ok then
        log("blueprint placement input start failed: " .. tostring(input_error))
        send_blueprint_message("message.placement.input_failed")
        if is_valid_object(building_model) then
            pcall(function() building_model:FinishBuilding() end)
        end
        if blueprint_preview_active then
            stop_blueprint_preview("placement-input-start-failed")
        end
        return false
    end
    local configured, configure_error, configure_failure =
        configure_blueprint_ghosts(placement_session)
    if not configured then
        log("blueprint multi-preview start aborted: "
            .. tostring(configure_error))
        if not send_blueprint_preview_configuration_failure(
            configure_failure
        ) then
            send_blueprint_message("message.placement.input_failed")
        end
        if is_valid_object(building_model) then
            pcall(function() building_model:FinishBuilding() end)
        end
        if blueprint_preview_active then
            stop_blueprint_preview("placement-component-config-failed")
        end
        return false
    end
    local resumed, resume_error =
        blueprint_placement_input.set_tick_paused(false)
    if not resumed then
        log("blueprint placement Session Tick resume failed error="
            .. tostring(resume_error))
        if is_valid_object(building_model) then
            pcall(function() building_model:FinishBuilding() end)
        end
        stop_blueprint_preview("placement-session-resume-failed")
        return false
    end
    log("blueprint placement mode entered buildings="
        .. tostring(#blueprint_clipboard.buildings)
        .. " anchor=" .. tostring(clipboard_building.build_object_id))
    return true
end

local function start_clipboard_preview()
    if blueprint_commit_queued then
        log("preview start aborted: the current preview commit is still closing")
        send_blueprint_message("message.placement.exit_pending")
        return false
    end
    local preview_import_started_at = BlueprintPerformance.now()
    local imported_compact, import_stats_or_error =
        import_blueprint_from_system_clipboard()
    if imported_compact == nil then
        log("preview start aborted: " .. tostring(import_stats_or_error))
        send_blueprint_message("message.placement.clipboard_invalid")
        return false
    end
    return start_blueprint_preview_from_compact(
        imported_compact, import_stats_or_error, "clipboard",
        preview_import_started_at
    )
end

local function snapshot_blueprint_non_anchor_build_requests(anchor_actor_request_transform)
    local math_library = UEHelpers.GetKismetMathLibrary()
    if not is_valid_object(math_library) then
        return nil, "KismetMathLibrary unavailable"
    end
    if anchor_actor_request_transform == nil
        or blueprint_ghost_state.anchor_actor_relative_to_model == nil then
        return nil, "anchor request or actor/model calibration unavailable"
    end

    local anchor_model_target = nil
    local calibration_ok, calibration_error = pcall(function()
        local model_relative_to_actor = math_library:InvertTransform(
            blueprint_ghost_state.anchor_actor_relative_to_model
        )
        anchor_model_target = math_library:ComposeTransforms(
            model_relative_to_actor, anchor_actor_request_transform
        )
    end)
    if not calibration_ok or anchor_model_target == nil then
        return nil, "anchor model-frame calibration failed error="
            .. tostring(calibration_error)
    end
    log("blueprint anchor frame calibration actorRequest="
        .. format_transform(anchor_actor_request_transform)
        .. " actorRelativeToModel="
        .. format_transform(blueprint_ghost_state.anchor_actor_relative_to_model)
        .. " modelTarget=" .. format_transform(anchor_model_target))

    local ordered_buildings = {}
    for _, building_state in ipairs(blueprint_ghost_state.buildings) do
        table.insert(ordered_buildings, building_state)
    end
    table.sort(ordered_buildings, function(left, right)
        return (tonumber(left.selection_index) or 0)
            < (tonumber(right.selection_index) or 0)
    end)

    local clipboard_building_by_instance = {}
    for _, building in ipairs(blueprint_clipboard.buildings or {}) do
        clipboard_building_by_instance[building.source_instance_id] = building
    end

    local requests = {}
    for _, building_state in ipairs(ordered_buildings) do
        local actor_request_transform = nil
        local model_target = nil
        local transform_ok, transform_error = pcall(function()
            model_target = math_library:ComposeTransforms(
                building_state.building_relative_transform,
                anchor_model_target
            )
            actor_request_transform = math_library:ComposeTransforms(
                building_state.actor_relative_to_model,
                model_target
            )
        end)
        if not transform_ok or actor_request_transform == nil then
            return nil, "building actor-frame calibration failed instance="
                .. tostring(building_state.source_instance_id)
                .. " error=" .. tostring(transform_error)
        end
        local translation = safe_property(actor_request_transform, "Translation")
        local quaternion = safe_property(actor_request_transform, "Rotation")
        local location = copy_vector(translation)
        local request_quaternion = copy_quaternion(quaternion)
        local model_location = copy_vector(safe_property(
            model_target, "Translation"
        ))
        local model_rotation = copy_quaternion(safe_property(
            model_target, "Rotation"
        ))
        if location == nil or location.x == nil or location.y == nil
            or location.z == nil or request_quaternion == nil
            or request_quaternion.x == nil or request_quaternion.y == nil
            or request_quaternion.z == nil or request_quaternion.w == nil
            or model_location == nil or model_rotation == nil then
            return nil, "invalid build request transform instance="
                .. tostring(building_state.source_instance_id)
        end
        local clipboard_record = clipboard_building_by_instance[
            building_state.source_instance_id
        ] or {}
        local external_supports = {}
        for _, connection in ipairs(clipboard_record.external_connections or {}) do
            local target_relative_transform = restore_transform(
                connection.target_relative_to_anchor
            )
            local target_world_transform = nil
            if target_relative_transform ~= nil then
                pcall(function()
                    target_world_transform = math_library:ComposeTransforms(
                        target_relative_transform, anchor_model_target
                    )
                end)
            end
            local target_location = copy_vector(safe_property(
                target_world_transform, "Translation"
            ))
            local target_rotation = copy_quaternion(safe_property(
                target_world_transform, "Rotation"
            ))
            if connection.target_build_object_id ~= nil
                and target_location ~= nil and target_rotation ~= nil then
                table.insert(external_supports, {
                    target_source_instance_id =
                        connection.target_source_instance_id,
                    target_build_object_id = connection.target_build_object_id,
                    target_connector_class = connection.target_connector_class,
                    source_property = connection.source_property,
                    source_connect_index = connection.source_connect_index,
                    target_connect_index = connection.target_connect_index,
                    expected_location = {
                        X = target_location.x,
                        Y = target_location.y,
                        Z = target_location.z,
                    },
                    expected_rotation = {
                        X = target_rotation.x,
                        Y = target_rotation.y,
                        Z = target_rotation.z,
                        W = target_rotation.w,
                    },
                })
            end
        end
        table.insert(requests, {
            build_object_id = building_state.build_object_id,
            source_instance_id = building_state.source_instance_id,
            location = { X = location.x, Y = location.y, Z = location.z },
            rotation = {
                X = request_quaternion.x,
                Y = request_quaternion.y,
                Z = request_quaternion.z,
                W = request_quaternion.w,
            },
            model_location = {
                X = model_location.x,
                Y = model_location.y,
                Z = model_location.z,
            },
            model_rotation = {
                X = model_rotation.x,
                Y = model_rotation.y,
                Z = model_rotation.z,
                W = model_rotation.w,
            },
            install_strategy = building_state.install_strategy,
            selection_index = building_state.selection_index,
            connections = clipboard_record.connections or {},
            external_supports = external_supports,
            connector_class = clipboard_record.connector_class,
            connector_supported_level =
                clipboard_record.connector_supported_level,
        })
    end
    return requests, nil
end

local function collect_blueprint_preexisting_world_matches(
    anchor_actor_request_transform, member_requests,
    anchor_preview_actor_address
)
    local math_library = UEHelpers.GetKismetMathLibrary()
    local system_library = UEHelpers.GetKismetSystemLibrary()
    local world_context = unwrap(UEHelpers.GetPlayer())
    local build_object_class = unwrap(StaticFindObject(
        "/Script/Pal.PalBuildObject"
    ))
    if not is_valid_object(math_library)
        or not is_valid_object(system_library)
        or not is_valid_object(world_context)
        or not is_valid_object(build_object_class) then
        return nil, "preexisting building query dependencies unavailable"
    end
    if blueprint_ghost_state.anchor_actor_relative_to_model == nil then
        return nil, "anchor actor/model calibration unavailable"
    end

    local anchor_record = nil
    for _, building in ipairs(blueprint_clipboard.buildings or {}) do
        if building.source_instance_id
            == blueprint_clipboard.anchor_instance_id then
            anchor_record = building
            break
        end
    end
    if anchor_record == nil then
        return nil, "anchor clipboard record unavailable"
    end

    local anchor_model_target = nil
    local transform_ok, transform_error = pcall(function()
        local model_relative_to_actor = math_library:InvertTransform(
            blueprint_ghost_state.anchor_actor_relative_to_model
        )
        anchor_model_target = math_library:ComposeTransforms(
            model_relative_to_actor, anchor_actor_request_transform
        )
    end)
    if not transform_ok or anchor_model_target == nil then
        return nil, "preexisting anchor model transform failed error="
            .. tostring(transform_error)
    end
    local anchor_model_location = copy_vector(safe_property(
        anchor_model_target, "Translation"
    ))
    local anchor_model_rotation = copy_quaternion(safe_property(
        anchor_model_target, "Rotation"
    ))
    if anchor_model_location == nil or anchor_model_rotation == nil then
        return nil, "preexisting anchor model transform incomplete"
    end

    local expectations = {
        {
            source_instance_id = anchor_record.source_instance_id,
            selection_index = anchor_record.selection_index or 0,
            build_object_id = anchor_record.build_object_id
                or blueprint_preview_anchor_build_object_id,
            install_strategy = anchor_record.install_strategy,
            model_location = {
                X = anchor_model_location.x,
                Y = anchor_model_location.y,
                Z = anchor_model_location.z,
            },
            model_rotation = {
                X = anchor_model_rotation.x,
                Y = anchor_model_rotation.y,
                Z = anchor_model_rotation.z,
                W = anchor_model_rotation.w,
            },
        },
    }
    for _, request in ipairs(member_requests or {}) do
        table.insert(expectations, {
            source_instance_id = request.source_instance_id,
            selection_index = request.selection_index,
            build_object_id = request.build_object_id,
            install_strategy = request.install_strategy,
            model_location = request.model_location,
            model_rotation = request.model_rotation,
        })
    end

    local minimum = { x = math.huge, y = math.huge, z = math.huge }
    local maximum = { x = -math.huge, y = -math.huge, z = -math.huge }
    for _, expectation in ipairs(expectations) do
        local location = copy_vector(expectation.model_location)
        if location == nil then
            return nil, "preexisting expectation location incomplete source="
                .. tostring(expectation.source_instance_id)
        end
        minimum.x = math.min(minimum.x, location.x)
        minimum.y = math.min(minimum.y, location.y)
        minimum.z = math.min(minimum.z, location.z)
        maximum.x = math.max(maximum.x, location.x)
        maximum.y = math.max(maximum.y, location.y)
        maximum.z = math.max(maximum.z, location.z)
    end

    local padding =
        BlueprintBuildEquivalence.DEFAULT_POSITION_TOLERANCE + 50.0
    local center = {
        X = (minimum.x + maximum.x) * 0.5,
        Y = (minimum.y + maximum.y) * 0.5,
        Z = (minimum.z + maximum.z) * 0.5,
    }
    local extent = {
        X = math.max((maximum.x - minimum.x) * 0.5 + padding, padding),
        Y = math.max((maximum.y - minimum.y) * 0.5 + padding, padding),
        Z = math.max((maximum.z - minimum.z) * 0.5 + padding, padding),
    }
    local out_actors = {}
    local query_ok, query_error = pcall(function()
        system_library:BoxOverlapActors(
            world_context, center, extent,
            get_region_overlap_object_types(), build_object_class,
            {}, out_actors
        )
    end)
    if not query_ok then
        return nil, "preexisting BoxOverlapActors failed: "
            .. tostring(query_error)
    end

    local actors = safe_property(out_actors, "OutActors") or out_actors
    local actor_count = 0
    pcall(function() actor_count = #actors end)
    local world_candidates = {}
    for actor_index = 1, actor_count do
        local actor = nil
        pcall(function() actor = unwrap(actors[actor_index]) end)
        if is_valid_object(actor)
            and safe_object_address(actor)
                ~= anchor_preview_actor_address then
            local candidate = snapshot_world_build_object(actor)
            if candidate ~= nil then
                candidate.ordinal = #world_candidates + 1
                table.insert(world_candidates, candidate)
            end
        end
    end

    local result = BlueprintBuildEquivalence.match(
        expectations, world_candidates, {
            position_tolerance =
                BlueprintBuildEquivalence.DEFAULT_POSITION_TOLERANCE,
        }
    )
    local source_ids = {}
    for source_id, match in pairs(
        result.matches_by_source_id or {}
    ) do
        source_ids[source_id] = true
        for _, request in ipairs(member_requests or {}) do
            if request.source_instance_id == source_id then
                request.preexisting_world_match = {
                    matched_world_instance_id =
                        match.candidate.instance_id,
                    matched_world_actor_address =
                        match.candidate.actor_address,
                    position_error =
                        match.details.position_error,
                    angle_error_degrees =
                        match.details.angle_error_degrees,
                    matched_equivalent_yaw =
                        match.details.matched_equivalent_yaw,
                }
                break
            end
        end
    end
    result.source_ids = source_ids
    return result, nil
end

-- Builds the repair/skip set exclusively from candidates already returned by
-- the authoritative native Checker. No BoxOverlapActors, FindAllOf, GetModel
-- scan, or reflected world traversal is performed here. The Checker reports
-- candidates; the pure-data equivalence layer alone decides whether a member,
-- including the anchor query member, already exists.
function collect_native_checker_preexisting_matches(
    submission_context, member_requests
)
    local report = submission_context
        and submission_context.native_overlap_report or nil
    if report == nil
        or report ~= blueprint_native_overlap_last_report
        or blueprint_native_overlap_completed_revision
            ~= blueprint_preview_validation_revision then
        return nil, "native overlap result is unavailable or stale"
    end

    local result = {
        matches_by_source_id = {},
        source_ids = {},
        matched_count = 0,
        expectation_count = #(blueprint_clipboard.buildings or {}),
        indexed_candidate_count =
            tonumber(report.native_candidate_count) or 0,
    }
    local requests_by_source = {}
    for _, request in ipairs(member_requests or {}) do
        requests_by_source[request.source_instance_id] = request
    end

    local function add_match(source_id, candidate, details)
        if source_id == nil
            or result.matches_by_source_id[source_id] ~= nil then
            return
        end
        candidate = candidate or {}
        details = details or {}
        local match = {
            candidate = {
                instance_id = candidate.instance_id,
                actor_address = candidate.actor_address,
                build_object_id = candidate.build_object_id,
                model_location = candidate.location
                    or candidate.model_location,
                model_rotation = candidate.rotation
                    or candidate.model_rotation,
            },
            details = {
                position_error = details.position_error,
                angle_error_degrees =
                    details.angle_error_degrees,
                matched_equivalent_yaw =
                    details.matched_equivalent_yaw,
            },
        }
        result.matches_by_source_id[source_id] = match
        result.source_ids[source_id] = true
        result.matched_count = result.matched_count + 1
        local request = requests_by_source[source_id]
        if request ~= nil then
            request.preexisting_world_match = {
                matched_world_instance_id =
                    match.candidate.instance_id,
                matched_world_actor_address =
                    match.candidate.actor_address,
                position_error =
                    match.details.position_error,
                angle_error_degrees =
                    match.details.angle_error_degrees,
                matched_equivalent_yaw =
                    match.details.matched_equivalent_yaw,
            }
        end
    end

    for _, member_result in ipairs(report.member_results or {}) do
        local source_instance_id =
            member_result.source_instance_id
        local request = requests_by_source[
            source_instance_id
        ]
        if request ~= nil then
            request.native_overlap_result =
                member_result.native_result
            request.native_overlap_candidate_count =
                member_result.candidate_count
        end
        if member_result.existing_world_match == true then
            add_match(
                member_result.source_instance_id,
                member_result.matched_candidate,
                member_result.equivalence_details
            )
        end
    end

    return result, nil
end

local function is_successful_build_result(result_text)
    local normalized = string.lower(tostring(result_text or ""))
    return normalized == "60"
        or normalized == "success"
        or string.find(normalized, "::success", 1, true) ~= nil
end

local function current_process_has_server_authority()
    local world = unwrap(UEHelpers.GetWorld())
    local utility = unwrap(StaticFindObject(
        "/Script/Pal.Default__PalUtility"
    ))
    if not is_valid_object(world) or not is_valid_object(utility) then
        return nil
    end
    local ok, result = pcall(function()
        return utility:IsServer(world)
    end)
    if not ok then return nil end
    if type(result) == "boolean" then return result end
    local normalized = string.lower(value_to_string(result))
    if normalized == "true" or normalized == "1" then return true end
    if normalized == "false" or normalized == "0" then return false end
    return nil
end

function classify_blueprint_server_rejection(result_text)
    local normalized = string.lower(tostring(result_text or ""))
    local numeric_result = tonumber(normalized)
    -- EPalMapObjectOperationResult::FailedNotEnoughMaterials == 17.
    if numeric_result == 17
        or string.find(normalized, "failednotenoughmaterials", 1, true) ~= nil
        or string.find(normalized, "notenoughmaterials", 1, true) ~= nil then
        return "materials"
    end
    return "server_gate"
end

advance_blueprint_wave_if_ready = nil
dispatch_blueprint_wave = nil
local pump_blueprint_rpc_sender = nil
local complete_current_blueprint_rpc = nil
finalize_blueprint_wave_transaction = nil
handle_blueprint_build_session_wake = nil
handle_blueprint_build_session_visual_wake = nil

BUILD_SESSION_WAKE_ADVANCE = 1
BUILD_SESSION_WAKE_TERMINAL = 2
BUILD_SESSION_WAKE_TIMEOUT = 3
BUILD_SESSION_VISUAL_CREATE = 1

local function next_blueprint_rpc_dispatch_sequence()
    blueprint_rpc_dispatch_sequence = blueprint_rpc_dispatch_sequence + 1
    return blueprint_rpc_dispatch_sequence
end

local function schedule_blueprint_wave_callback(delay_ms, work)
    if type(work) ~= "function" then return false end
    BlueprintWaveRuntime.scheduled_callback_sequence =
        BlueprintWaveRuntime.scheduled_callback_sequence + 1
    local callback_id = BlueprintWaveRuntime.scheduled_callback_sequence
    local world_generation = BlueprintWaveRuntime.world_generation
    local callback = nil
    callback = function()
        BlueprintWaveRuntime.scheduled_callbacks[callback_id] = nil
        if BlueprintWaveRuntime.world_generation ~= world_generation then
            return
        end
        local ok, callback_error = pcall(work)
        if not ok then
            log("blueprint wave scheduled callback error id="
                .. tostring(callback_id) .. " error="
                .. tostring(callback_error))
        end
    end
    -- This UE4SS build can garbage-collect an unreferenced scheduled Lua
    -- callback before EngineTick invokes it, turning the registry entry into
    -- "Ref was not function" and removing the shared Tick hook. Retain every
    -- one-shot callback until its own invocation begins.
    BlueprintWaveRuntime.scheduled_callbacks[callback_id] = callback
    local scheduled, schedule_error = pcall(
        ExecuteInGameThreadWithDelay,
        math.max(tonumber(delay_ms) or 0, 0),
        callback
    )
    if not scheduled then
        BlueprintWaveRuntime.scheduled_callbacks[callback_id] = nil
        log("blueprint wave callback scheduling error id="
            .. tostring(callback_id) .. " error="
            .. tostring(schedule_error))
        return false
    end
    return true
end

local function blueprint_result_coordinate(value, lower, upper)
    if type(value) ~= "table" then return nil end
    return tonumber(value[lower] ~= nil and value[lower] or value[upper])
end

local function blueprint_result_distance(left, right)
    local left_x = blueprint_result_coordinate(left, "x", "X")
    local left_y = blueprint_result_coordinate(left, "y", "Y")
    local left_z = blueprint_result_coordinate(left, "z", "Z")
    local right_x = blueprint_result_coordinate(right, "x", "X")
    local right_y = blueprint_result_coordinate(right, "y", "Y")
    local right_z = blueprint_result_coordinate(right, "z", "Z")
    if left_x == nil or left_y == nil or left_z == nil
        or right_x == nil or right_y == nil or right_z == nil then
        return nil
    end
    local delta_x = left_x - right_x
    local delta_y = left_y - right_y
    local delta_z = left_z - right_z
    return math.sqrt(
        delta_x * delta_x + delta_y * delta_y + delta_z * delta_z
    )
end

local function find_current_blueprint_sender_request(
    build_object_id, result_location
)
    local envelope = BlueprintRpcSender.current(blueprint_rpc_sender)
    local payload = envelope ~= nil and envelope.payload or nil
    local transaction = type(payload) == "table"
        and payload.session or nil
    local request = type(payload) == "table"
        and payload.request or nil
    if envelope == nil or transaction == nil or request == nil
        or transaction.world_generation
            ~= BlueprintWaveRuntime.world_generation
        or transaction.inflight_request ~= request
        or request.result_received == true
        or request.dispatched ~= true then
        return nil, nil, { reason = "none" }
    end
    if build_object_id ~= nil
        and tostring(request.build_object_id)
            ~= tostring(build_object_id) then
        return nil, nil, { reason = "build-mismatch" }
    end
    local distance = nil
    if result_location ~= nil then
        distance = blueprint_result_distance(
            request.location, result_location
        )
        if distance == nil
            or distance
                > BlueprintWaveRuntime.result_location_tolerance then
            return nil, nil, {
                reason = "location-mismatch",
                matching_build_count = 1,
                nearest_distance = distance,
            }
        end
    end
    return transaction, request, {
        reason = nil,
        token = envelope.token,
        distance = distance,
    }
end

function is_active_blueprint_job(transaction)
    return transaction ~= nil
        and blueprint_build_jobs_by_id[transaction.id] == transaction
end

function complete_blueprint_inflight_request(
    transaction, request, success, result_text, result_source, details
)
    local callback_started_at = BlueprintPerformance.now()
    details = details or {}
    if not is_active_blueprint_job(transaction)
        or request == nil
        or transaction.inflight_request ~= request
        or request.result_received == true then
        return false
    end

    stamp_build_queue_request(request, "callback_started")
    local request_context = build_queue_request_context(transaction, request)
    local bookkeeping_started_at = BlueprintPerformance.now()
    request.result_received = true
    request.result_success = success == true
    request.result_text = tostring(result_text or "<nil>")
    request.result_source = tostring(result_source or "<unknown>")
    request.current_building_num = details.current_building_num
    request.server_created_instance_id = details.server_created_instance_id
    request.server_created_location = details.location
    request.failure_kind = details.failure_kind
    transaction.received_results = transaction.received_results + 1
    if request.result_success then
        transaction.success_count = transaction.success_count + 1
    else
        transaction.failure_count = transaction.failure_count + 1
    end
    table.insert(transaction.result_events, {
        result = request.result_text,
        source = request.result_source,
        success = request.result_success,
        install_location = details.location,
        location_text = details.location_text,
        current_building_num = details.current_building_num,
        server_created_instance_id = details.server_created_instance_id,
        request_index = request.request_index,
        request_kind = request.request_kind,
        build_object_id = request.build_object_id,
        source_instance_id = request.source_instance_id,
    })
    record_build_queue_elapsed(
        transaction, "result_bookkeeping",
        bookkeeping_started_at, request_context)
    local outcome_prefix = request.result_success
        and "blueprint authoritative outcome"
        or "blueprint authoritative request failed"
    local outcome_log_started_at = BlueprintPerformance.now()
    log(string.format(
        outcome_prefix .. " id=%d wave=%d member=%d received=%d/%d success=%s source=%s result=%s requestIndex=%s kind=%s build=%s sourceInstance=%s createdInstance=%s location=%s currentBuildingNum=%s",
        transaction.id, (transaction.current_wave_number or 1) - 1,
        transaction.current_member_number or 1,
        transaction.received_results,
        transaction.expected_results, tostring(request.result_success),
        request.result_source, request.result_text,
        tostring(request.request_index), tostring(request.request_kind),
        tostring(request.build_object_id), tostring(request.source_instance_id),
        tostring(details.server_created_instance_id or "<none>"),
        tostring(details.location_text or "<nil>"),
        tostring(details.current_building_num)
    ))
    record_build_queue_elapsed(
        transaction, "outcome_log", outcome_log_started_at, request_context)
    if not request.result_success then
        diagnose_native_overlap_server_mismatch(request)
    end
    advance_blueprint_wave_if_ready(transaction)
    stamp_build_queue_request(request, "callback_finished")
    record_build_queue_elapsed(
        transaction, "result_callback_total",
        callback_started_at, request_context)
    return true
end

complete_current_blueprint_rpc = function(
    success, result_text, result_source, details
)
    local envelope = BlueprintRpcSender.current(blueprint_rpc_sender)
    if envelope == nil then return false end
    local payload = type(envelope.payload) == "table"
        and envelope.payload or nil
    local transaction = type(payload) == "table"
        and payload.session or nil
    local request = type(payload) == "table"
        and payload.request or nil
    local request_context = transaction ~= nil and request ~= nil
        and build_queue_request_context(transaction, request) or "<unknown>"
    if transaction ~= nil and request ~= nil then
        stamp_build_queue_request(request, "outcome_received")
        record_build_queue_interval(
            transaction, "server_roundtrip_observed", request,
            "dispatched", "outcome_received", request_context)
    end
    local sender_complete_started_at = BlueprintPerformance.now()
    local completed, completion_error = BlueprintRpcSender.complete(
        blueprint_rpc_sender, envelope.token, {
            success = success == true,
            result_text = tostring(result_text or "<nil>"),
            result_source = tostring(result_source or "<unknown>"),
            details = type(details) == "table" and details or {},
        }
    )
    if transaction ~= nil then
        record_build_queue_elapsed(
            transaction, "sender_complete",
            sender_complete_started_at, request_context)
    end
    if not completed then
        log("blueprint RPC sender completion rejected token="
            .. tostring(envelope.token) .. " error="
            .. tostring(completion_error))
        return false
    end
    if completion_error ~= nil then
        log("blueprint RPC sender callback isolated error token="
            .. tostring(envelope.token) .. " error="
            .. tostring(completion_error))
    end
    return completion_error == nil
end

function accept_blueprint_server_model_created(
    build_object_id, location, details
)
    local route_started_at = BlueprintPerformance.now()
    local transaction, request, route_details =
        find_current_blueprint_sender_request(build_object_id, location)
    if transaction == nil or request == nil then
        if route_details ~= nil
            and route_details.reason == "location-mismatch" then
            log(string.format(
                "blueprint server-create ignored route=location-mismatch build=%s matchingRequests=%d nearestDistance=%.2f tolerance=%.2f",
                tostring(build_object_id),
                tonumber(route_details.matching_build_count) or 0,
                tonumber(route_details.nearest_distance) or -1.0,
                BlueprintWaveRuntime.result_location_tolerance
            ))
        end
        return false
    end

    details = type(details) == "table" and details or {}
    local result_source = tostring(
        details.result_source
            or "PalBaseCampManager.OnCreateMapObjectModelInServer"
    )
    local result_text = tostring(
        details.result_text or "ServerModelCreated"
    )
    details.location = location
    details.location_text = location ~= nil
        and string.format(
            "(%.3f,%.3f,%.3f)",
            tonumber(location.x) or 0,
            tonumber(location.y) or 0,
            tonumber(location.z) or 0
        ) or "<nil>"
    details.route_distance = route_details ~= nil
        and route_details.distance or nil
    record_build_queue_elapsed(
        transaction, "server_result_route", route_started_at,
        build_queue_request_context(transaction, request))
    local completed = complete_current_blueprint_rpc(
        true, result_text, result_source, details
    )
    return completed
end

finalize_blueprint_wave_transaction = function(
    transaction, success, reason, failure_kind, failed_request, session_actor
)
    local finalize_started_at = BlueprintPerformance.now()
    if not is_active_blueprint_job(transaction) then return end
    transaction.timeout_token = (transaction.timeout_token or 0) + 1
    local completed_with_failures = success == true
        and (tonumber(transaction.failure_count) or 0) > 0
    transaction.state = completed_with_failures
        and "COMPLETED_WITH_FAILURES"
        or (success and "COMPLETED" or "FAILED")
    transaction.failure_kind = failure_kind
    transaction.failed_build_object_id = failed_request ~= nil
        and failed_request.build_object_id or nil
    transaction.failed_result = failed_request ~= nil
        and failed_request.result_text or nil
    if success then
        log(string.format(
            "blueprint wave transaction completed id=%d state=%s completed=%d/%d failures=%d wave=%d member=%d reason=%s",
            transaction.id, transaction.state,
            transaction.success_count or 0,
            transaction.expected_results or 0,
            transaction.failure_count or 0,
            (transaction.current_wave_number or 1) - 1,
            transaction.current_member_number or 1, tostring(reason)
        ))
    else
        log(string.format(
            "blueprint wave transaction terminal id=%d state=%s success=%s completed=%d/%d failures=%d wave=%d member=%d failureKind=%s failedBuild=%s failedResult=%s reason=%s",
            transaction.id, transaction.state, tostring(success),
            transaction.success_count or 0,
            transaction.expected_results or 0,
            transaction.failure_count or 0,
            (transaction.current_wave_number or 1) - 1,
            transaction.current_member_number or 1,
            tostring(failure_kind or "none"),
            tostring(transaction.failed_build_object_id or "<none>"),
            tostring(transaction.failed_result or "<none>"),
            tostring(reason)
        ))
    end
    local state_cleanup_started_at = BlueprintPerformance.now()
    blueprint_build_jobs_by_id[transaction.id] = nil
    blueprint_build_job_count = math.max(blueprint_build_job_count - 1, 0)
    transaction.inflight_request = nil
    transaction.pending_wake = nil
    transaction.terminal_pending = nil
    record_build_queue_elapsed(
        transaction, "terminal_state_cleanup",
        state_cleanup_started_at, "transaction=" .. tostring(transaction.id))
    local visual = transaction.wave_visual
    transaction.wave_visual = nil
    local terminal_ghost_started_at = BlueprintPerformance.now()
    if visual ~= nil then
        if is_valid_object(unwrap(session_actor)) then
            blueprint_wave_ghost_renderer.hide_all(visual, session_actor)
        else
            blueprint_wave_ghost_renderer.abandon(
                visual, "terminal-session-actor-unavailable")
        end
    end
    record_build_queue_elapsed(
        transaction, "terminal_ghost_hide",
        terminal_ghost_started_at, "transaction=" .. tostring(transaction.id))
    transaction.wave_visual_snapshot = nil
    transaction.wave_visual_anchor_transform = nil
    transaction.requests = {}
    transaction.waves = {}
    local user_message_started_at = BlueprintPerformance.now()
    if completed_with_failures
        and transaction.force_submit_invalid == true then
        send_blueprint_message(
            "message.build.force_submit_complete",
            transaction.success_count or 0,
            transaction.failure_count or 0
        )
    elseif success then
        send_blueprint_message(
            "message.build.complete", transaction.success_count or 0
        )
    elseif failure_kind == "materials" then
        send_blueprint_message("message.build.stop_materials")
    elseif failure_kind == "server_gate" then
        send_blueprint_message("message.build.stop_server_gate")
    elseif failure_kind == "timeout" or string.find(
        tostring(reason), "silent-server-outcome-timeout", 1, true
    ) ~= nil then
        send_blueprint_message("message.build.stop_timeout")
    else
        send_blueprint_message("message.build.stop_generic")
    end
    record_build_queue_elapsed(
        transaction, "terminal_user_message",
        user_message_started_at, "transaction=" .. tostring(transaction.id))
    local session_destroy_started_at = BlueprintPerformance.now()
    local destroyed, destroy_error =
        blueprint_build_session_runtime.destroy(
            transaction.id, reason, session_actor)
    if not destroyed then
        log("Build Session terminal destroy failed id="
            .. tostring(transaction.id) .. " error="
            .. tostring(destroy_error))
    end
    record_build_queue_elapsed(
        transaction, "session_actor_destroy",
        session_destroy_started_at, "transaction=" .. tostring(transaction.id))
    record_build_queue_elapsed(
        transaction, "terminal_finalize",
        finalize_started_at, "transaction=" .. tostring(transaction.id))
    local queue_probe = get_build_queue_probe(transaction)
    if queue_probe ~= nil then
        log_probe(string.format(
            "blueprint build queue timing id=%d elapsedMs=%.2f prepare={%s} dispatch={%s} completion={%s} latency={%s}",
            tonumber(transaction.id) or 0,
            BlueprintBuildQueueProbe.session_elapsed_ms(queue_probe),
            BlueprintBuildQueueProbe.format_phases(
                queue_probe, BUILD_QUEUE_PREPARE_PHASES
            ),
            BlueprintBuildQueueProbe.format_phases(
                queue_probe, BUILD_QUEUE_DISPATCH_PHASES
            ),
            BlueprintBuildQueueProbe.format_phases(
                queue_probe, BUILD_QUEUE_COMPLETION_PHASES
            ),
            BlueprintBuildQueueProbe.format_phases(
                queue_probe, BUILD_QUEUE_LATENCY_PHASES
            )
        ))
    end
end

function finish_blueprint_wave_transaction(
    transaction, success, reason, failure_kind, failed_request
)
    local finish_started_at = BlueprintPerformance.now()
    if not is_active_blueprint_job(transaction)
        or transaction.terminal_pending ~= nil then
        return
    end
    transaction.terminal_pending = {
        success = success == true,
        reason = tostring(reason),
        failure_kind = failure_kind,
        failed_request = failed_request,
        due_at = BlueprintPerformance.now(),
    }
    transaction.state = "TERMINAL_PENDING"
    local cancel_visual_started_at = BlueprintPerformance.now()
    record_build_queue_elapsed(
        transaction, "terminal_cancel_visual",
        cancel_visual_started_at, "transaction=" .. tostring(transaction.id))
    local terminal_timer_started_at = BlueprintPerformance.now()
    record_build_queue_elapsed(
        transaction, "terminal_timer_arm",
        terminal_timer_started_at, "transaction=" .. tostring(transaction.id))
    record_build_queue_elapsed(
        transaction, "finish_schedule",
        finish_started_at, "transaction=" .. tostring(transaction.id))
end

function request_expects_connector(request)
    local connector_class = tostring(request.connector_class or "")
    return connector_class ~= "" and connector_class ~= "<none>"
        and connector_class ~= "<nil>"
end

function blueprint_object_class_token(value)
    local full_name = object_name(value)
    return string.match(full_name, "^([^%s]+)") or full_name
end

function collect_blueprint_initial_world_roots(anchor_request, member_requests)
    local anchor_preview_address = safe_object_address(
        get_blueprint_preview_anchor()
    )
    local roots = {}
    local expectation_started_at = BlueprintPerformance.now()
    local support_expectations = {}
    local requests_by_instance_id = {}
    local relevant_target_build_ids = {}
    local minimum = { x = math.huge, y = math.huge, z = math.huge }
    local maximum = { x = -math.huge, y = -math.huge, z = -math.huge }
    for _, request in ipairs(member_requests or {}) do
        requests_by_instance_id[request.source_instance_id] = request
        for _, support in ipairs(request.external_supports or {}) do
            local location = support.expected_location
            local x = tonumber(location and location.X)
            local y = tonumber(location and location.Y)
            local z = tonumber(location and location.Z)
            if x ~= nil and y ~= nil and z ~= nil then
                relevant_target_build_ids[
                    tostring(support.target_build_object_id or "")
                ] = true
                local connector_class_required =
                    support.target_connector_class ~= nil
                local connector_class_token = nil
                if connector_class_required then
                    connector_class_token = string.match(
                        tostring(support.target_connector_class),
                        "^([^%s]+)"
                    )
                end
                table.insert(support_expectations, {
                    request_id = request.source_instance_id,
                    target_build_object_id =
                        support.target_build_object_id,
                    expected_location = {
                        x = x,
                        y = y,
                        z = z,
                    },
                    expected_rotation = copy_quaternion(
                        support.expected_rotation
                    ),
                    connector_class_required =
                        connector_class_required,
                    target_connector_class_token =
                        connector_class_token,
                    source_connect_index =
                        support.source_connect_index,
                    target_connect_index =
                        support.target_connect_index,
                })
                minimum.x = math.min(minimum.x, x)
                minimum.y = math.min(minimum.y, y)
                minimum.z = math.min(minimum.z, z)
                maximum.x = math.max(maximum.x, x)
                maximum.y = math.max(maximum.y, y)
                maximum.z = math.max(maximum.z, z)
            end
        end
    end
    local expectation_prepare_ms = BlueprintPerformance.elapsed_ms(
        expectation_started_at
    )
    if #support_expectations == 0 then
        return roots, {
            expectation_count = 0,
            unique_expectation_count = 0,
            world_candidate_count = 0,
            indexed_candidate_count = 0,
            candidate_check_count = 0,
            matched_root_count = 0,
            mode = "anchor-only-no-external-support-stubs",
            expectation_prepare_ms = expectation_prepare_ms,
            query_ms = 0.0,
            snapshot_ms = 0.0,
            index_match_ms = 0.0,
        }, nil
    end

    local padding = BlueprintWaveRuntime.external_support_location_tolerance
        + 100.0
    local center = {
        X = (minimum.x + maximum.x) * 0.5,
        Y = (minimum.y + maximum.y) * 0.5,
        Z = (minimum.z + maximum.z) * 0.5,
    }
    local extent = {
        X = math.max((maximum.x - minimum.x) * 0.5 + padding, padding),
        Y = math.max((maximum.y - minimum.y) * 0.5 + padding, padding),
        Z = math.max((maximum.z - minimum.z) * 0.5 + padding, padding),
    }
    local world_context = unwrap(UEHelpers.GetPlayer())
    local system_library = UEHelpers.GetKismetSystemLibrary()
    local build_object_class = unwrap(StaticFindObject(
        "/Script/Pal.PalBuildObject"
    ))
    if not is_valid_object(world_context) or not is_valid_object(system_library)
        or not is_valid_object(build_object_class) then
        return nil, nil, "initial-world-root query dependencies unavailable"
    end

    local query_started_at = BlueprintPerformance.now()
    local out_actors = {}
    local query_ok, query_error = pcall(function()
        system_library:BoxOverlapActors(
            world_context, center, extent,
            get_region_overlap_object_types(), build_object_class,
            {}, out_actors
        )
    end)
    if not query_ok then
        return nil, nil, "initial-world-root BoxOverlapActors failed: "
            .. tostring(query_error)
    end
    local query_ms = BlueprintPerformance.elapsed_ms(query_started_at)
    local actors = safe_property(out_actors, "OutActors") or out_actors
    local actor_count = 0
    pcall(function() actor_count = #actors end)
    local snapshot_started_at = BlueprintPerformance.now()
    local world_candidates = {}
    for actor_index = 1, actor_count do
        local actor = nil
        pcall(function() actor = unwrap(actors[actor_index]) end)
        if is_valid_object(actor)
            and safe_object_address(actor)
                ~= anchor_preview_address then
            local model = nil
            pcall(function() model = unwrap(actor:GetModel()) end)
            if is_valid_object(model) then
                local instance_id = format_guid(safe_property(model, "InstanceId"))
                local model_transform = safe_property(model, "InitialTransformCache")
                local model_location = copy_vector(safe_property(
                    model_transform, "Translation"
                ))
                local model_rotation = copy_quaternion(safe_property(
                    model_transform, "Rotation"
                ))
                if instance_id ~= "<nil>" and instance_id ~= "None"
                    and instance_id
                        ~= "00000000-00000000-00000000-00000000"
                    and model_location ~= nil and model_rotation ~= nil then
                    local build_object_id = value_to_string(
                        safe_property(model, "BuildObjectId")
                    )
                    local connector_class_token = nil
                    local connector_indexes = {}
                    if relevant_target_build_ids[
                        tostring(build_object_id)
                    ] == true then
                        local connector = unwrap(
                            safe_property(model, "Connector")
                        )
                        connector_class_token =
                            blueprint_object_class_token(connector)
                        connector_indexes =
                            capture_connector_index_set(connector)
                    end
                    table.insert(world_candidates, {
                        ordinal = #world_candidates + 1,
                        instance_id = instance_id,
                        build_object_id = build_object_id,
                        location = model_location,
                        rotation = model_rotation,
                        connector_class_token = connector_class_token,
                        connector_indexes = connector_indexes,
                    })
                end
            end
        end
    end
    local snapshot_ms = BlueprintPerformance.elapsed_ms(snapshot_started_at)

    local index_match_started_at = BlueprintPerformance.now()
    local match_result = BlueprintExternalSupportMatcher.match(
        support_expectations, world_candidates, {
            location_tolerance =
                BlueprintWaveRuntime.external_support_location_tolerance,
            rotation_dot_min =
                BlueprintWaveRuntime.external_support_rotation_dot_min,
        }
    )
    local index_match_ms = BlueprintPerformance.elapsed_ms(
        index_match_started_at
    )
    local matched_roots = 0
    for request_id, match in pairs(
        match_result.matches_by_request_id or {}
    ) do
        local request = requests_by_instance_id[request_id]
        local candidate = match.candidate
        local expectation = match.expectation
        if request ~= nil and candidate ~= nil and expectation ~= nil
            and not roots[request_id] then
            roots[request_id] = true
            request.initial_world_support = {
                matched_world_instance_id = candidate.instance_id,
                target_build_object_id = candidate.build_object_id,
                source_connect_index =
                    expectation.source_connect_index,
                target_connect_index =
                    expectation.target_connect_index,
            }
            matched_roots = matched_roots + 1
        end
    end
    return roots, {
        expectation_count = #support_expectations,
        unique_expectation_count =
            tonumber(match_result.unique_expectation_count) or 0,
        world_candidate_count = #world_candidates,
        indexed_candidate_count =
            tonumber(match_result.indexed_candidate_count) or 0,
        candidate_check_count =
            tonumber(match_result.candidate_checks) or 0,
        bucket_visit_count =
            tonumber(match_result.bucket_visits) or 0,
        matched_root_count = matched_roots,
        mode = "saved-external-connect-stub-exact-transform-indexed",
        expectation_prepare_ms = expectation_prepare_ms,
        query_ms = query_ms,
        snapshot_ms = snapshot_ms,
        index_match_ms = index_match_ms,
    }, nil
end

function build_blueprint_wave_plan(
    anchor_request, member_requests, options
)
    options = type(options) == "table" and options or {}
    local force_submit_invalid =
        options.force_submit_invalid == true
    local work_classification_started_at = BlueprintPerformance.now()
    local work_classification, work_classification_error =
        BlueprintMaterialGate.annotate_build_requests(
            anchor_request, member_requests
        )
    if work_classification == nil then
        return nil, "build-work classification failed: "
            .. tostring(work_classification_error)
    end
    local work_classification_ms = BlueprintPerformance.elapsed_ms(
        work_classification_started_at
    )
    local roots_started_at = BlueprintPerformance.now()
    local support_connection_gate_enabled =
        BlueprintResearchSettings
            .get_blueprint_support_connection_gate_enabled()
    local initial_roots = nil
    local root_diagnostics = nil
    local root_error = nil
    if force_submit_invalid then
        initial_roots = {}
        root_diagnostics = {
            expectation_count = 0,
            unique_expectation_count = 0,
            world_candidate_count = 0,
            indexed_candidate_count = 0,
            candidate_check_count = 0,
            bucket_visit_count = 0,
            matched_root_count = 0,
            mode = "force-submit-foundation-or-fallback-component-roots",
            expectation_prepare_ms = 0.0,
            query_ms = 0.0,
            snapshot_ms = 0.0,
            index_match_ms = 0.0,
        }
    elseif support_connection_gate_enabled then
        initial_roots, root_diagnostics, root_error =
            collect_blueprint_initial_world_roots(
                anchor_request, member_requests
            )
        if initial_roots == nil then return nil, root_error end
    else
        initial_roots = {}
        if anchor_request ~= nil
            and anchor_request.source_instance_id ~= nil then
            initial_roots[anchor_request.source_instance_id] = true
        end
        for _, request in ipairs(member_requests or {}) do
            if request.source_instance_id ~= nil then
                initial_roots[request.source_instance_id] = true
            end
        end
        root_diagnostics = {
            expectation_count = 0,
            unique_expectation_count = 0,
            world_candidate_count = 0,
            indexed_candidate_count = 0,
            candidate_check_count = 0,
            bucket_visit_count = 0,
            matched_root_count = 0,
            mode = "disabled-all-requests-are-roots",
            expectation_prepare_ms = 0.0,
            query_ms = 0.0,
            snapshot_ms = 0.0,
            index_match_ms = 0.0,
        }
    end
    local roots_ms = BlueprintPerformance.elapsed_ms(roots_started_at)
    local planner_started_at = BlueprintPerformance.now()
    local plan, plan_error, failure_details = BlueprintWavePlanner.plan(
        anchor_request, member_requests, initial_roots, {
            force_submit_invalid = force_submit_invalid,
            support_gate = support_connection_gate_enabled
                and not force_submit_invalid
                and BlueprintSupportGate or nil,
            -- Keep the first runtime version conservative.  Unknown/rootless
            -- connector components abstain instead of introducing a false
            -- rejection; the established planner and server remain the final
            -- authorities for those candidates.
            support_gate_options = {
                strict_rootless = false,
            },
        }
    )
    if plan == nil then
        local unreachable = failure_details ~= nil
            and table.concat(failure_details.unreachable or {}, ",") or "<unknown>"
        return nil, tostring(plan_error) .. " unreachable=" .. unreachable,
            failure_details
    end
    plan.root_diagnostics = root_diagnostics
    plan.force_submit_invalid = force_submit_invalid
    plan.build_work_classification = work_classification
    plan.performance = {
        build_work_classification_ms = work_classification_ms,
        initial_roots_ms = roots_ms,
        planner_ms = BlueprintPerformance.elapsed_ms(planner_started_at),
        root_expectation_prepare_ms =
            tonumber(root_diagnostics.expectation_prepare_ms) or 0.0,
        root_query_ms =
            tonumber(root_diagnostics.query_ms) or 0.0,
        root_snapshot_ms =
            tonumber(root_diagnostics.snapshot_ms) or 0.0,
        root_index_match_ms =
            tonumber(root_diagnostics.index_match_ms) or 0.0,
    }
    return plan, nil
end

function schedule_blueprint_wave_timeout(
    transaction, request, sender_token, wave_number, delay_ms,
    session_actor
)
    transaction.timeout_token = (transaction.timeout_token or 0) + 1
    local timeout_delay_ms = math.max(tonumber(delay_ms) or 0, 1)
    transaction.timeout_context = {
        timeout_token = transaction.timeout_token,
        request = request,
        sender_token = sender_token,
        wave_number = wave_number,
        expected_delay_ms = timeout_delay_ms,
        due_at = BlueprintPerformance.now() + timeout_delay_ms / 1000.0,
    }
    return true, nil
end

function begin_blueprint_wave_transaction(
    network_component, anchor_actor_request_transform, member_requests,
    anchor_preview_actor_address, preexisting_match_result,
    force_submit_invalid
)
    local transaction_started_at = BlueprintPerformance.now()
    blueprint_build_transaction_sequence = blueprint_build_transaction_sequence + 1
    local anchor_translation = copy_vector(
        safe_property(anchor_actor_request_transform, "Translation")
    )
    local anchor_rotation = copy_quaternion(
        safe_property(anchor_actor_request_transform, "Rotation")
    )
    if anchor_translation == nil or anchor_rotation == nil then
        return nil, "anchor transform is incomplete"
    end
    if not is_valid_object(unwrap(network_component)) then
        return nil, "original network component is unavailable"
    end
    if anchor_preview_actor_address == nil then
        return nil, "anchor preview identity is unavailable"
    end
    local anchor_record = nil
    for _, building in ipairs(blueprint_clipboard.buildings or {}) do
        if building.source_instance_id == blueprint_clipboard.anchor_instance_id then
            anchor_record = building
            break
        end
    end
    if anchor_record == nil then return nil, "anchor clipboard record is missing" end

    local anchor_request = {
        request_kind = "anchor",
        build_object_id = blueprint_preview_anchor_build_object_id,
        source_instance_id = anchor_record.source_instance_id,
        selection_index = anchor_record.selection_index or 0,
        location = {
            X = anchor_translation.x,
            Y = anchor_translation.y,
            Z = anchor_translation.z,
        },
        rotation = {
            X = anchor_rotation.x,
            Y = anchor_rotation.y,
            Z = anchor_rotation.z,
            W = anchor_rotation.w,
        },
        install_strategy = anchor_record.install_strategy,
        connections = anchor_record.connections or {},
        connector_class = anchor_record.connector_class,
        preexisting_world_match =
            preexisting_match_result ~= nil
            and preexisting_match_result.matches_by_source_id ~= nil
            and preexisting_match_result.matches_by_source_id[
                anchor_record.source_instance_id
            ] or nil,
    }
    for _, request in ipairs(member_requests or {}) do
        request.request_kind = "member"
    end
    local preplan_setup_ms = BlueprintPerformance.elapsed_ms(
        transaction_started_at)
    local plan, plan_error, plan_failure = build_blueprint_wave_plan(
        anchor_request, member_requests, {
            force_submit_invalid = force_submit_invalid == true,
        }
    )
    if plan == nil then
        return nil, "placement preflight failed: " .. tostring(plan_error),
            plan_failure
    end
    local visual_snapshot_started_at = BlueprintPerformance.now()
    local preexisting_source_set = {}
    for _, source_id in ipairs(
        plan.preexisting_source_ids or {}
    ) do
        preexisting_source_set[source_id] = true
    end
    local wave_visual_snapshot, wave_visual_snapshot_error =
        blueprint_wave_ghost_renderer.snapshot(
            blueprint_clipboard, preexisting_source_set
        )
    if wave_visual_snapshot == nil then
        return nil, "wave visual snapshot failed: "
            .. tostring(wave_visual_snapshot_error)
    end
    local visual_snapshot_ms = BlueprintPerformance.elapsed_ms(
        visual_snapshot_started_at
    )
    local transaction_state_started_at = BlueprintPerformance.now()
    local transaction = {
        id = blueprint_build_transaction_sequence,
        session_kind = "PlacementSession",
        mode = "waves",
        world_generation = BlueprintWaveRuntime.world_generation,
        expected_results = #plan.requests,
        received_results = 0,
        success_count = 0,
        failure_count = 0,
        requests = plan.requests,
        waves = plan.waves,
        current_wave_number = 1,
        current_member_number = 1,
        inflight_request = nil,
        state = "WAITING_FIRST_RPC_SLOT",
        result_events = {},
        anchor_preview_actor_address = anchor_preview_actor_address,
        wave_visual = nil,
        wave_visual_snapshot = wave_visual_snapshot,
        wave_visual_anchor_transform = nil,
        build_session_handle = nil,
        pending_wake = nil,
        terminal_pending = nil,
        timeout_context = nil,
        edge_count = plan.edge_count,
        directed_connection_count = plan.directed_connection_count,
        initial_root_count = plan.initial_root_count,
        initial_root_ids = plan.initial_root_ids,
        preexisting_count = plan.preexisting_count,
        preexisting_source_ids = plan.preexisting_source_ids,
        root_diagnostics = plan.root_diagnostics,
        support_gate_stats = plan.support_gate_stats,
        force_submit_invalid = plan.force_submit_invalid == true,
        deferred_count = plan.deferred_count,
        dispatch_sequence = 0,
        performance = {
            network_resolve_total_ms = 0.0,
            network_resolve_max_ms = 0.0,
            rpc_call_total_ms = 0.0,
            rpc_call_max_ms = 0.0,
            custom_dispatch_count = 0,
            build_queue_probe =
                BlueprintResearchSettings.get_log_probes()
                and BlueprintBuildQueueProbe.new_session(
                    blueprint_build_transaction_sequence,
                    transaction_started_at
                ) or nil,
        },
        continuous_placement =
            blueprint_continuous_placement_requested == true,
    }
    record_build_queue_ms(
        transaction, "preplan_setup", preplan_setup_ms, "transaction-start")
    record_build_queue_ms(
        transaction, "initial_roots",
        tonumber((plan.performance or {}).initial_roots_ms) or 0.0,
        "wave-plan")
    record_build_queue_ms(
        transaction, "root_expectation_prepare",
        tonumber((plan.performance or {}).root_expectation_prepare_ms) or 0.0,
        "wave-plan")
    record_build_queue_ms(
        transaction, "root_query",
        tonumber((plan.performance or {}).root_query_ms) or 0.0,
        "wave-plan")
    record_build_queue_ms(
        transaction, "root_snapshot",
        tonumber((plan.performance or {}).root_snapshot_ms) or 0.0,
        "wave-plan")
    record_build_queue_ms(
        transaction, "root_index_match",
        tonumber((plan.performance or {}).root_index_match_ms) or 0.0,
        "wave-plan")
    record_build_queue_ms(
        transaction, "wave_planner",
        tonumber((plan.performance or {}).planner_ms) or 0.0,
        "wave-plan")
    record_build_queue_ms(
        transaction, "visual_snapshot", visual_snapshot_ms,
        "buildings=" .. tostring(#(blueprint_clipboard.buildings or {})))
    wave_visual_snapshot = nil
    blueprint_continuous_placement_requested = false

    local wave_visual_anchor_transform = {
        Translation = {
            X = anchor_translation.x,
            Y = anchor_translation.y,
            Z = anchor_translation.z,
        },
        Rotation = {
            X = anchor_rotation.x,
            Y = anchor_rotation.y,
            Z = anchor_rotation.z,
            W = anchor_rotation.w,
        },
        Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
    }
    transaction.wave_visual_anchor_transform =
        wave_visual_anchor_transform
    record_build_queue_elapsed(
        transaction, "transaction_state_setup",
        transaction_state_started_at, "transaction=" .. tostring(transaction.id))
    local session_actor_begin_started_at = BlueprintPerformance.now()
    local build_session_handle, build_session_error =
        blueprint_build_session_runtime.begin({
            session_id = transaction.id,
            generation = transaction.world_generation,
            network_component = network_component,
            on_wake = function(session_actor, wake)
                handle_blueprint_build_session_wake(
                    session_actor, wake)
            end,
        })
    record_build_queue_elapsed(
        transaction, "session_actor_begin",
        session_actor_begin_started_at, "transaction=" .. tostring(transaction.id))
    if build_session_handle == nil then
        return nil, "Build Session initialization failed: "
            .. tostring(build_session_error)
    end
    transaction.build_session_handle = build_session_handle
    blueprint_build_jobs_by_id[transaction.id] = transaction
    blueprint_build_job_count = blueprint_build_job_count + 1
    -- The foreground preview is independent from this fixed background Build
    -- Session. It remains movable immediately; the next click still performs
    -- the full synchronous legality and material gates.
    local foreground_unlock_started_at = BlueprintPerformance.now()
    blueprint_commit_queued = false
    blueprint_continuous_unlock_pending = false
    blueprint_continuous_next_anchor_seen = false
    blueprint_placement_input.set_primary_locked(false)
    blueprint_preview_validation_revision =
        blueprint_preview_validation_revision + 1
    blueprint_native_overlap_completed_revision = nil
    blueprint_native_overlap_last_report = nil
    blueprint_preview_all_placeable = false
    blueprint_preview_validation_dirty = true
    blueprint_preview_validation_cooldown_ticks = 0
    record_build_queue_elapsed(
        transaction, "foreground_preview_unlock",
        foreground_unlock_started_at, "transaction=" .. tostring(transaction.id))

    local visual_timer_started_at = BlueprintPerformance.now()
    record_build_queue_elapsed(
        transaction, "visual_timer_arm", visual_timer_started_at,
        "pulse-owned transaction=" .. tostring(transaction.id))

    local wave_counts = {}
    for wave_number, wave in ipairs(transaction.waves) do
        table.insert(wave_counts, string.format("%d:%d", wave_number - 1, #wave))
    end
    log(string.format(
        "blueprint wave plan id=%d plannerSchema=%d activeJobs=%d members=%d savedConnectEdges=%d directedConnectRecords=%d initialRoots=%d rootMode=%s rootExpectations=%d rootCandidates=%d rootMatches=%d deferred=%d waves=[%s] requestMode=one-in-flight settleMs=%d continuous=%s",
        transaction.id, plan.planner_schema_version,
        blueprint_build_job_count, #transaction.requests,
        transaction.edge_count, transaction.directed_connection_count,
        transaction.initial_root_count,
        tostring((transaction.root_diagnostics or {}).mode),
        tonumber((transaction.root_diagnostics or {}).expectation_count) or 0,
        tonumber((transaction.root_diagnostics or {}).world_candidate_count) or 0,
        tonumber((transaction.root_diagnostics or {}).matched_root_count) or 0,
        transaction.deferred_count, table.concat(wave_counts, ","),
        BlueprintWaveRuntime.wave_settle_delay_ms,
        tostring(transaction.continuous_placement)
    ))
    -- The dedicated input path no longer calls the stock BuildObject. Produce
    -- the first request before returning; the single-slot Sender owns actual
    -- dispatch and all later fairness.
    dispatch_blueprint_wave(transaction, 1, 1)
    return transaction, nil
end

dispatch_blueprint_wave = function(
    transaction, wave_number, member_number, session_actor
)
    local produce_started_at = BlueprintPerformance.now()
    if not is_active_blueprint_job(transaction) then return end
    member_number = member_number or 1
    if transaction.inflight_request ~= nil then
        finish_blueprint_wave_transaction(
            transaction, false,
            "scheduler invariant violated: request already active"
        )
        return
    end
    local wave = transaction.waves[wave_number]
    if wave == nil or #wave == 0 then
        finish_blueprint_wave_transaction(
            transaction, false, "wave plan contains an empty wave"
        )
        return
    end
    local request = wave[member_number]
    if request == nil then
        finish_blueprint_wave_transaction(
            transaction, false,
            "wave member is missing wave=" .. tostring(wave_number - 1)
                .. " member=" .. tostring(member_number)
        )
        return
    end
    transaction.current_wave_number = wave_number
    transaction.current_member_number = member_number
    transaction.inflight_request = request
    transaction.state = "WAITING_RPC_SLOT"
    local request_context = build_queue_request_context(transaction, request)
    stamp_build_queue_request(request, "produced")
    local enqueue_started_at = BlueprintPerformance.now()
    local sender_token, enqueue_error = BlueprintRpcSender.enqueue(
        blueprint_rpc_sender, {
            diagnostic_id = string.format(
                "%d:%d:%d", transaction.id, wave_number, member_number
            ),
            payload = {
                session = transaction,
                request = request,
            },
            on_complete = function(outcome)
                if not is_active_blueprint_job(transaction)
                    or transaction.inflight_request ~= request then
                    return false
                end
                local callback_ok, callback_result = pcall(
                    complete_blueprint_inflight_request,
                    transaction, request, outcome.success,
                    outcome.result_text, outcome.result_source,
                    outcome.details
                )
                if not callback_ok then
                    finish_blueprint_wave_transaction(
                        transaction, false,
                        "request completion callback error: "
                            .. tostring(callback_result)
                    )
                    return false
                end
                return callback_result
            end,
        }
    )
    record_build_queue_elapsed(
        transaction, "sender_enqueue", enqueue_started_at, request_context)
    if sender_token == nil then
        transaction.inflight_request = nil
        finish_blueprint_wave_transaction(
            transaction, false,
            "RPC sender enqueue failed: " .. tostring(enqueue_error)
        )
        return
    end
    request.sender_token = sender_token
    stamp_build_queue_request(request, "enqueued")
    record_build_queue_elapsed(
        transaction, "request_produce", produce_started_at, request_context)
    local pump_entry_started_at = BlueprintPerformance.now()
    pump_blueprint_rpc_sender(session_actor, transaction.id)
    record_build_queue_elapsed(
        transaction, "sender_pump_entry",
        pump_entry_started_at, request_context)
end

pump_blueprint_rpc_sender = function(session_actor, pulsing_session_id)
    if BlueprintRpcSender.current(blueprint_rpc_sender) ~= nil then return end
    session_actor = unwrap(session_actor)
    if not is_valid_object(session_actor) then
        -- The first request is produced synchronously before the first UE
        -- Session pulse. Keep it queued until SBB_BuildSessionWake supplies
        -- the owning Actor; never dequeue a request without that context.
        return
    end
    while true do
        local queued = BlueprintRpcSender.peek_next(blueprint_rpc_sender)
        if queued == nil then return end
        local queued_payload = type(queued.payload) == "table"
            and queued.payload or nil
        local queued_transaction = type(queued_payload) == "table"
            and queued_payload.session or nil
        if is_active_blueprint_job(queued_transaction)
            and tonumber(pulsing_session_id)
                ~= tonumber(queued_transaction.id) then
            -- FIFO ownership is strict. A different Session's pulse may not
            -- borrow its UE network reference to dispatch the queue head.
            return
        end
        local begin_next_started_at = BlueprintPerformance.now()
        local envelope, begin_error =
            BlueprintRpcSender.begin_next(blueprint_rpc_sender)
        if envelope == nil then
            if begin_error ~= nil and begin_error ~= "sender is busy" then
                log("blueprint RPC sender begin error="
                    .. tostring(begin_error))
            end
            return
        end
        local payload = envelope.payload
        local transaction = type(payload) == "table"
            and payload.session or nil
        local request = type(payload) == "table"
            and payload.request or nil
        local pump_work_started_at = BlueprintPerformance.now()
        if transaction == nil or request == nil
            or not is_active_blueprint_job(transaction)
            or transaction.inflight_request ~= request
            or request.sender_token ~= envelope.token then
            BlueprintRpcSender.complete(
                blueprint_rpc_sender, envelope.token, {
                    success = false,
                    result_text = "AbandonedBuildSession",
                    result_source = "BlueprintRpcSender",
                    details = { failure_kind = "abandoned" },
                }
            )
        else
            local request_context =
                build_queue_request_context(transaction, request)
            record_build_queue_elapsed(
                transaction, "sender_begin_next",
                begin_next_started_at, request_context)
            stamp_build_queue_request(request, "dequeued")
            record_build_queue_interval(
                transaction, "queue_wait_observed", request,
                "enqueued", "dequeued", request_context)
            local network_resolve_started_at = BlueprintPerformance.now()
            local network, network_error =
                blueprint_build_session_runtime.get_network_component(
                    transaction.id, session_actor
                )
            local network_resolve_ms = BlueprintPerformance.elapsed_ms(
                network_resolve_started_at
            )
            local performance = transaction.performance or {}
            transaction.performance = performance
            record_build_queue_ms(
                transaction, "network_resolve",
                network_resolve_ms,
                build_queue_request_context(transaction, request))
            performance.network_resolve_total_ms =
                (tonumber(performance.network_resolve_total_ms) or 0.0)
                + network_resolve_ms
            performance.network_resolve_max_ms = math.max(
                tonumber(performance.network_resolve_max_ms) or 0.0,
                network_resolve_ms
            )
            if network == nil then
                complete_current_blueprint_rpc(
                    false, "NetworkComponentInvalid",
                    "BlueprintRpcSender", {
                        failure_kind = "network",
                        error = tostring(network_error),
                    }
                )
                record_build_queue_elapsed(
                    transaction, "sender_pump_work",
                    pump_work_started_at, request_context)
                return
            else
                transaction.state = "WAITING_SERVER_RESULT"
                request.dispatched = true
                request.dispatch_source = "sender"
                request.global_dispatch_sequence =
                    next_blueprint_rpc_dispatch_sequence()
                transaction.dispatch_sequence =
                    transaction.dispatch_sequence + 1
                request.dispatch_sequence = transaction.dispatch_sequence
                local timeout_timer_started_at = BlueprintPerformance.now()
                local timeout_armed, timeout_error =
                    schedule_blueprint_wave_timeout(
                    transaction, request, envelope.token,
                    transaction.current_wave_number,
                    BlueprintWaveRuntime.request_timeout_ms,
                    session_actor
                )
                record_build_queue_elapsed(
                    transaction, "timeout_timer_arm",
                    timeout_timer_started_at, request_context)
                if not timeout_armed then
                    complete_current_blueprint_rpc(
                        false, "TimeoutTimerUnavailable",
                        "BlueprintBuildSessionRuntime", {
                            failure_kind = "timeout",
                            error = tostring(timeout_error),
                        })
                    record_build_queue_elapsed(
                        transaction, "sender_pump_work",
                        pump_work_started_at, request_context)
                    return
                end
                local wave = transaction.waves[
                    transaction.current_wave_number
                ] or {}
                local dispatch_log_started_at = BlueprintPerformance.now()
                log(string.format(
                    "blueprint request dispatch id=%d wave=%d member=%d/%d build=%s sourceInstance=%s reason=%s unlockSources=[%s] location=%s",
                    transaction.id,
                    transaction.current_wave_number - 1,
                    transaction.current_member_number, #wave,
                    tostring(request.build_object_id),
                    tostring(request.source_instance_id),
                    tostring(request.plan_reason),
                    table.concat(request.unlock_source_instance_ids or {}, ","),
                    format_vector(request.location)
                ))
                record_build_queue_elapsed(
                    transaction, "dispatch_log",
                    dispatch_log_started_at, request_context)
                local request_name_started_at = BlueprintPerformance.now()
                local build_object_name = nil
                local name_ok, name_error = pcall(function()
                    build_object_name = FName(request.build_object_id)
                    if value_to_string(build_object_name)
                        ~= request.build_object_id then
                        error("FName unavailable for build="
                            .. tostring(request.build_object_id))
                    end
                end)
                record_build_queue_elapsed(
                    transaction, "request_name_prepare",
                    request_name_started_at, request_context)
                if not name_ok then
                    complete_current_blueprint_rpc(
                        false, "DispatchError",
                        "BlueprintRpcSender", {
                            failure_kind = "dispatch",
                            error = tostring(name_error),
                        }
                    )
                    record_build_queue_elapsed(
                        transaction, "sender_pump_work",
                        pump_work_started_at, request_context)
                    return
                end
                stamp_build_queue_request(request, "dispatched")
                local rpc_call_started_at = BlueprintPerformance.now()
                local dispatch_ok, dispatch_error = pcall(function()
                    blueprint_network_dispatch_guard = true
                    network:RequestBuild_ToServer(
                        build_object_name,
                        request.location,
                        request.rotation,
                        {},
                        { bNotConsumeMaterials = false }
                    )
                    blueprint_network_dispatch_guard = false
                end)
                local rpc_call_ms = BlueprintPerformance.elapsed_ms(
                    rpc_call_started_at
                )
                performance.custom_dispatch_count =
                    (tonumber(performance.custom_dispatch_count) or 0) + 1
                performance.rpc_call_total_ms =
                    (tonumber(performance.rpc_call_total_ms) or 0.0)
                    + rpc_call_ms
                performance.rpc_call_max_ms = math.max(
                    tonumber(performance.rpc_call_max_ms) or 0.0,
                    rpc_call_ms
                )
                record_build_queue_ms(
                    transaction, "rpc_call", rpc_call_ms, request_context)
                blueprint_network_dispatch_guard = false
                if not dispatch_ok then
                    complete_current_blueprint_rpc(
                        false, "DispatchError",
                        "BlueprintRpcSender", {
                            failure_kind = "dispatch",
                            error = tostring(dispatch_error),
                        }
                    )
                end
                record_build_queue_elapsed(
                    transaction, "sender_pump_work",
                    pump_work_started_at, request_context)
                return
            end
        end
    end
end

advance_blueprint_wave_if_ready = function(transaction)
    local advance_function_started_at = BlueprintPerformance.now()
    if not is_active_blueprint_job(transaction) then return end
    local wave_number = transaction.current_wave_number
    local wave = transaction.waves[wave_number] or {}
    local member_number = transaction.current_member_number or 1
    local request = transaction.inflight_request
    if request == nil or request.result_received ~= true then return end
    transaction.timeout_token = (transaction.timeout_token or 0) + 1
    transaction.timeout_context = nil
    if request.result_success ~= true then
        local failure_kind = request.failure_kind
            or classify_blueprint_server_rejection(request.result_text)
        local force_continue = transaction.force_submit_invalid == true
            and failure_kind ~= "dispatch"
        if not force_continue then
            finish_blueprint_wave_transaction(
                transaction, false,
                "server rejected wave=" .. tostring(wave_number - 1)
                    .. " member=" .. tostring(member_number)
                    .. " build=" .. tostring(request.build_object_id)
                    .. " result=" .. tostring(request.result_text),
                failure_kind, request
            )
            record_build_queue_elapsed(
                transaction, "advance",
                advance_function_started_at,
                build_queue_request_context(transaction, request))
            return
        end
        log(string.format(
            "blueprint force-submit continuing after rejection id=%d wave=%d member=%d build=%s result=%s failureKind=%s",
            transaction.id, wave_number - 1, member_number,
            tostring(request.build_object_id),
            tostring(request.result_text), tostring(failure_kind)
        ))
    end
    request.server_accepted = request.result_success == true
    transaction.inflight_request = nil
    transaction.state = "WAITING_NEXT_REQUEST"

    local next_wave_number = wave_number
    local next_member_number = member_number + 1
    local delay_ms = BlueprintWaveRuntime.request_settle_delay_ms
    if next_member_number > #wave then
        log(string.format(
            "blueprint wave complete id=%d wave=%d members=%d totalSuccess=%d/%d failures=%d",
            transaction.id, wave_number - 1, #wave,
            transaction.success_count, transaction.expected_results,
            transaction.failure_count or 0
        ))
        next_wave_number = wave_number + 1
        next_member_number = 1
        delay_ms = BlueprintWaveRuntime.wave_settle_delay_ms
    end
    transaction.pending_wake = {
        accepted_request = request,
        next_wave_number = next_wave_number,
        next_member_number = next_member_number,
        terminal_success =
            next_wave_number > #transaction.waves,
        expected_delay_ms = delay_ms,
        due_at = BlueprintPerformance.now() + delay_ms / 1000.0,
    }
    local advance_timer_started_at = BlueprintPerformance.now()
    record_build_queue_elapsed(
        transaction, "advance_timer_arm",
        advance_timer_started_at,
        build_queue_request_context(transaction, request))
    stamp_build_queue_request(request, "settle_timer_armed")
    record_build_queue_elapsed(
        transaction, "advance",
        advance_function_started_at,
        build_queue_request_context(transaction, request))
end

handle_blueprint_build_session_visual_wake = function(
    session_actor, wake
)
    local visual_wake_started_at = BlueprintPerformance.now()
    if type(wake) ~= "table"
        or wake.kind ~= BUILD_SESSION_VISUAL_CREATE then
        return
    end
    local transaction = blueprint_build_jobs_by_id[wake.session_id]
    if not is_active_blueprint_job(transaction)
        or transaction.world_generation ~= wake.generation
        or transaction.terminal_pending ~= nil then
        return
    end
    local snapshot = transaction.wave_visual_snapshot
    local anchor_transform = transaction.wave_visual_anchor_transform
    transaction.wave_visual_snapshot = nil
    transaction.wave_visual_anchor_transform = nil
    if snapshot == nil or anchor_transform == nil then return end
    local visual, visual_error = blueprint_wave_ghost_renderer.create(
        snapshot, anchor_transform, session_actor)
    record_build_queue_elapsed(
        transaction, "wave_ghost_create",
        visual_wake_started_at, "transaction=" .. tostring(transaction.id))
    if visual == nil then
        log("blueprint wave ghost creation error transaction="
            .. tostring(transaction.id) .. " error="
            .. tostring(visual_error))
        return
    end
    if not is_active_blueprint_job(transaction)
        or transaction.terminal_pending ~= nil then
        blueprint_wave_ghost_renderer.hide_all(
            visual, session_actor)
        return
    end
    transaction.wave_visual = visual
end

handle_blueprint_build_session_wake = function(session_actor, wake)
    local wake_started_at = BlueprintPerformance.now()
    if type(wake) ~= "table" then return end
    local transaction = blueprint_build_jobs_by_id[wake.session_id]
    if not is_active_blueprint_job(transaction)
        or transaction.world_generation ~= wake.generation then
        return
    end

    if transaction.wave_visual_snapshot ~= nil
        and transaction.terminal_pending == nil then
        handle_blueprint_build_session_visual_wake(session_actor, {
            session_id = wake.session_id,
            generation = wake.generation,
            kind = BUILD_SESSION_VISUAL_CREATE,
        })
    end

    if transaction.state == "WAITING_RPC_SLOT" then
        pump_blueprint_rpc_sender(session_actor, transaction.id)
    end

    local now = BlueprintPerformance.now()
    local terminal = transaction.terminal_pending
    if type(terminal) == "table"
        and now >= (tonumber(terminal.due_at) or 0.0) then
        record_build_queue_elapsed(
            transaction, "session_wake",
            wake_started_at, "terminal:" .. tostring(transaction.id))
        finalize_blueprint_wave_transaction(
            transaction, terminal.success, terminal.reason,
            terminal.failure_kind, terminal.failed_request, session_actor)
        return
    end

    local timeout = transaction.timeout_context
    if type(timeout) == "table"
        and now >= (tonumber(timeout.due_at) or 0.0) then
        transaction.timeout_context = nil
        if transaction.timeout_token ~= timeout.timeout_token
            or transaction.current_wave_number ~= timeout.wave_number
            or transaction.inflight_request ~= timeout.request then
            return
        end
        local current = BlueprintRpcSender.current(
            blueprint_rpc_sender)
        if current == nil
            or current.token ~= timeout.sender_token then
            return
        end
        complete_current_blueprint_rpc(
            false, "NoServerOutcomeTimeout",
            "BlueprintBuildSessionRuntime.Timeout", {
                failure_kind = "timeout",
            })
        record_build_queue_elapsed(
            transaction, "session_wake",
            wake_started_at, "timeout:" .. tostring(transaction.id))
        return
    end

    local pending = transaction.pending_wake
    if type(pending) ~= "table"
        or now < (tonumber(pending.due_at) or 0.0) then
        return
    end
    transaction.pending_wake = nil
    if transaction.state ~= "WAITING_NEXT_REQUEST" then
        return
    end
    local accepted_request = pending.accepted_request
    local request_context = build_queue_request_context(
        transaction, accepted_request)
    stamp_build_queue_request(accepted_request, "settle_timer_fired")
    local settle_observed_ms = record_build_queue_interval(
        transaction, "settle_timer_observed", accepted_request,
        "settle_timer_armed", "settle_timer_fired", request_context)
    if settle_observed_ms ~= nil then
        record_build_queue_ms(
            transaction, "settle_timer_overrun",
            math.max(
                settle_observed_ms
                    - (tonumber(pending.expected_delay_ms) or 0.0),
                0.0
            ),
            request_context
        )
    end
    if transaction.wave_visual ~= nil then
        local ghost_dispose_started_at = BlueprintPerformance.now()
        blueprint_wave_ghost_renderer.dispose_request(
            transaction.wave_visual, pending.accepted_request,
            session_actor)
        record_build_queue_elapsed(
            transaction, "ghost_request_dispose",
            ghost_dispose_started_at, request_context)
    end
    if pending.terminal_success == true then
        record_build_queue_elapsed(
            transaction, "session_wake",
            wake_started_at, "advance-terminal:" .. request_context)
        finalize_blueprint_wave_transaction(
            transaction, true,
            transaction.force_submit_invalid == true
                and "all waves attempted" or "all waves accepted by server",
            nil, nil, session_actor)
        return
    end
    dispatch_blueprint_wave(
        transaction, pending.next_wave_number,
        pending.next_member_number, session_actor)
    record_build_queue_elapsed(
        transaction, "session_wake",
        wake_started_at, "advance:" .. request_context)
end

function queue_blueprint_wave_build_requests(
    network_component, anchor_actor_request_transform,
    anchor_preview_actor_address, submission_probe,
    prepared_member_requests, preexisting_match_result,
    force_submit_invalid
)
    local submit_started_at = BlueprintPerformance.now()
    if blueprint_commit_queued then
        return false, "the current blueprint preview was already committed"
    end
    if not blueprint_preview_active
        or (
            not blueprint_preview_all_placeable
            and force_submit_invalid ~= true
        ) then
        return false, "blueprint placement validation is not green"
    end
    local request_snapshot_started_at = BlueprintPerformance.now()
    local member_requests = prepared_member_requests
    local snapshot_error = nil
    if member_requests == nil then
        member_requests, snapshot_error =
            snapshot_blueprint_non_anchor_build_requests(
                anchor_actor_request_transform
            )
    end
    if member_requests == nil then return false, snapshot_error end
    local request_snapshot_ms = BlueprintPerformance.elapsed_ms(
        request_snapshot_started_at
    )
    local transaction_started_at = BlueprintPerformance.now()
    local transaction, begin_error, begin_failure = begin_blueprint_wave_transaction(
        network_component, anchor_actor_request_transform, member_requests,
        anchor_preview_actor_address, preexisting_match_result,
        force_submit_invalid == true
    )
    if transaction == nil then return false, begin_error, begin_failure end
    for phase_name, elapsed_ms in pairs(
        type(submission_probe) == "table" and submission_probe or {}
    ) do
        record_build_queue_ms(
            transaction, phase_name, elapsed_ms, "primary-action")
    end
    record_build_queue_ms(
        transaction, "submit_request_snapshot", request_snapshot_ms,
        "members=" .. tostring(#member_requests))
    record_build_queue_ms(
        transaction, "submit_total",
        BlueprintPerformance.elapsed_ms(submit_started_at),
        "members=" .. tostring(#member_requests))
    log(string.format(
        "blueprint anchor accepted into wave scheduler id=%d pendingMembers=%d",
        transaction.id, #member_requests
    ))
    return true, nil
end

local BLUEPRINT_BATCH_MAGIC = "PBLUBAT1"
local BLUEPRINT_BATCH_PROTOCOL_VERSION = 1
local BLUEPRINT_BATCH_NATIVE_LOG =
    "J:\\SteamLibrary\\steamapps\\common\\Palworld\\Pal\\Binaries\\Win64"
    .. "\\ue4ss\\Mods\\BlueprintBatchBridge\\dlls\\BlueprintBatchBridge.log"

local function is_blueprint_batch_native_ready()
    local file = io.open(BLUEPRINT_BATCH_NATIVE_LOG, "rb")
    if file == nil then return false, "native bridge log is missing" end
    local content = file:read("*a") or ""
    file:close()

    local function last_position(needle)
        local last = nil
        local start = 1
        while true do
            local found = string.find(content, needle, start, true)
            if found == nil then break end
            last = found
            start = found + 1
        end
        return last
    end

    local attached = last_position("DLL_PROCESS_ATTACH")
    local installed = last_position("native hooks installed")
    if attached == nil or installed == nil or installed < attached then
        return false, "native bridge did not install hooks in the current process"
    end
    return true, nil
end

local function pack_blueprint_batch_payload(
    anchor_actor_request_transform, non_anchor_requests
)
    if string.pack == nil then return nil, "Lua string.pack is unavailable" end
    local anchor_translation = copy_vector(
        safe_property(anchor_actor_request_transform, "Translation")
    )
    local anchor_rotation = copy_quaternion(
        safe_property(anchor_actor_request_transform, "Rotation")
    )
    if anchor_translation == nil or anchor_rotation == nil then
        return nil, "anchor request transform is incomplete"
    end

    local anchor_clipboard_record = nil
    for _, building in ipairs(blueprint_clipboard.buildings or {}) do
        if building.source_instance_id == blueprint_clipboard.anchor_instance_id then
            anchor_clipboard_record = building
            break
        end
    end
    if anchor_clipboard_record == nil then
        return nil, "anchor clipboard record is missing"
    end

    local records = {
        {
            source_instance_id = anchor_clipboard_record.source_instance_id,
            build_object_id = anchor_clipboard_record.build_object_id,
            location = {
                X = anchor_translation.x,
                Y = anchor_translation.y,
                Z = anchor_translation.z,
            },
            rotation = {
                X = anchor_rotation.x,
                Y = anchor_rotation.y,
                Z = anchor_rotation.z,
                W = anchor_rotation.w,
            },
            connections = anchor_clipboard_record.connections or {},
            is_anchor = true,
        },
    }
    for _, request in ipairs(non_anchor_requests or {}) do
        table.insert(records, request)
    end

    local batch_index_by_source_instance = {}
    for record_index, record in ipairs(records) do
        batch_index_by_source_instance[record.source_instance_id] = record_index - 1
    end

    local body_parts = {}
    local encoded_edge_count = 0
    for _, record in ipairs(records) do
        local source_instance_id = tostring(record.source_instance_id or "")
        local build_object_id = tostring(record.build_object_id or "")
        if #source_instance_id == 0 or #source_instance_id > 65535
            or #build_object_id == 0 or #build_object_id > 65535 then
            return nil, "batch record has an invalid source/build identifier"
        end

        local edges = {}
        local seen_target = {}
        for _, connection in ipairs(record.connections or {}) do
            local target_index = batch_index_by_source_instance[
                connection.target_source_instance_id
            ]
            if target_index ~= nil and not seen_target[target_index] then
                seen_target[target_index] = true
                table.insert(edges, target_index)
            end
        end
        if #edges > 65535 then
            return nil, "batch record has too many connector edges"
        end

        local location = record.location or {}
        local rotation = record.rotation or {}
        local values = {
            tonumber(location.X or location.x),
            tonumber(location.Y or location.y),
            tonumber(location.Z or location.z),
            tonumber(rotation.X or rotation.x),
            tonumber(rotation.Y or rotation.y),
            tonumber(rotation.Z or rotation.z),
            tonumber(rotation.W or rotation.w),
        }
        for _, value in ipairs(values) do
            if value == nil or value ~= value
                or value == math.huge or value == -math.huge then
                return nil, "batch record has a non-finite transform"
            end
        end

        table.insert(body_parts, string.pack(
            "<I2I2I2I2ddddddd",
            #source_instance_id,
            #build_object_id,
            #edges,
            record.is_anchor == true and 1 or 0,
            table.unpack(values)
        ))
        table.insert(body_parts, source_instance_id)
        table.insert(body_parts, build_object_id)
        for _, target_index in ipairs(edges) do
            table.insert(body_parts, string.pack("<I4I1xxx", target_index, 0))
            encoded_edge_count = encoded_edge_count + 1
        end
    end

    local body = table.concat(body_parts)
    local payload_size = 32 + #body
    local header = BLUEPRINT_BATCH_MAGIC .. string.pack(
        "<I2I2I4I4I4I4I4",
        BLUEPRINT_BATCH_PROTOCOL_VERSION,
        32,
        0,
        #records,
        0,
        payload_size,
        0
    )
    local payload = header .. body
    local bytes = {}
    for index = 1, #payload do
        bytes[index] = string.byte(payload, index)
    end
    return {
        bytes = bytes,
        byte_count = #payload,
        member_count = #records,
        edge_count = encoded_edge_count,
    }, nil
end

local function append_blueprint_batch_archive(extra_parameter_archives, batch_payload)
    local archives = unwrap(extra_parameter_archives)
    if archives == nil then return false, "ExtraParameterArchives is unavailable" end
    local original_count = 0
    local appended_count = 0
    local stored_byte_count = 0
    local ok, error_value = pcall(function()
        original_count = #archives
        archives[original_count + 1] = { Bytes = batch_payload.bytes }
        appended_count = #archives
        local appended_archive = unwrap(archives[original_count + 1])
        local stored_bytes = unwrap(safe_property(appended_archive, "Bytes"))
        stored_byte_count = #stored_bytes
    end)
    if not ok then return false, tostring(error_value) end
    if appended_count ~= original_count + 1
        or stored_byte_count ~= batch_payload.byte_count then
        return false, string.format(
            "archive verification failed original=%d appended=%d bytes=%d expected=%d",
            original_count, appended_count, stored_byte_count,
            batch_payload.byte_count
        )
    end
    return true, {
        original_archive_count = original_count,
        final_archive_count = appended_count,
    }
end

local retained_runtime_hook_callbacks = {}

local function retain_runtime_hook_callback(path, phase, callback)
    local retained = function(...)
        local outcome = table.pack(pcall(callback, ...))
        if not outcome[1] then
            log("runtime hook isolated error path=" .. tostring(path)
                .. " phase=" .. tostring(phase)
                .. " error=" .. tostring(outcome[2]))
            return
        end
        return table.unpack(outcome, 2, outcome.n)
    end
    table.insert(retained_runtime_hook_callbacks, retained)
    return retained
end

local function register_hook(path, callback, options)
    options = type(options) == "table" and options or {}
    local retained = retain_runtime_hook_callback(path, "pre", callback)
    local ok, pre_id, post_id = pcall(RegisterHook, path, retained)
    if ok then
        log(string.format("hooked %s pre=%s post=%s", path, tostring(pre_id), tostring(post_id)))
    elseif options.silent_failure ~= true then
        log(string.format("hook failed %s error=%s", path, tostring(pre_id)))
    end
    if not ok then
        for index = #retained_runtime_hook_callbacks, 1, -1 do
            if retained_runtime_hook_callbacks[index] == retained then
                table.remove(retained_runtime_hook_callbacks, index)
                break
            end
        end
    end
    return ok, pre_id, post_id
end

local function register_post_hook(path, callback)
    local pre_callback = retain_runtime_hook_callback(
        path, "pre-noop", function() end
    )
    local post_callback = retain_runtime_hook_callback(path, "post", callback)
    local ok, pre_id, post_id = pcall(
        RegisterHook, path, pre_callback, post_callback
    )
    if ok then
        log(string.format("post-hooked %s pre=%s post=%s", path, tostring(pre_id), tostring(post_id)))
    else
        log(string.format("post-hook failed %s error=%s", path, tostring(pre_id)))
    end
end

BlueprintRuntimeBridgeController = BlueprintRuntimeBridge.install({
    log = log,
    register_hook = register_hook,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_object_address = safe_object_address,
    object_name = object_name,
    get_class_full_name = function(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local ok, full_name = pcall(function()
            local object_class = unwrap(value:GetClass())
            return object_class:GetFullName()
        end)
        if not ok or full_name == nil then return nil end
        return tostring(full_name)
    end,
    get_player_controller = function()
        return UEHelpers.GetPlayerController()
    end,
    read_property = safe_property,
    write_property = function(value, property_name, property_value)
        value = unwrap(value)
        if not is_valid_object(value) then return false end
        if property_name == "SBB_RuntimeGeneration" then
            value.SBB_RuntimeGeneration = property_value
        elseif property_name == "SBB_RuntimeAuthoritative" then
            value.SBB_RuntimeAuthoritative = property_value
        elseif property_name == "SBB_RuntimeActive" then
            value.SBB_RuntimeActive = property_value
        elseif property_name == "SBB_RuntimeShadowMode" then
            value.SBB_RuntimeShadowMode = property_value
        else
            return false
        end
        return true
    end,
    set_tick_enabled = function(value, enabled)
        value = unwrap(value)
        if not is_valid_object(value) then return false end
        value:SetActorTickEnabled(enabled == true)
        return true
    end,
    schedule_retry = function(delay_ms, label, callback)
        return BlueprintCallbackScheduler.game_thread(
            delay_ms,
            label,
            callback,
            { survive_world = true }
        )
    end,
    find_mod_actor_instances = function()
        return FindAllOf("ModActor_C") or {}
    end,
})

register_hook("/Script/Pal.PalUIBuildModel:StartBuildObject", function(context, build_object_id)
    if BlueprintSelectionMode.active then
        BlueprintSelectionMode.finish(
            "original-StartBuildObject", false, true
        )
    end
    if blueprint_preview_active
        and not blueprint_start_build_forward_in_progress then
        -- This pre-hook runs before the stock building widget copies its input
        -- actions from WBP_PalBuilding's CDO. Restore the stock LMB rows now;
        -- waiting for the preview monitor's next tick is already too late for
        -- the newly created ordinary-build widget.
        stop_blueprint_preview(
            "original-StartBuildObject-switch",
            false,
            true
        )
    end
    log(string.format("StartBuildObject context=%s BuildObjectId=%s", object_name(context), value_to_string(build_object_id)))
end)

register_hook("/Script/Pal.PalUIBuildingModel:Setup", function(context, build_object_id)
    log(string.format("BuildingModel.Setup context=%s BuildObjectId=%s", object_name(context), value_to_string(build_object_id)))
    if blueprint_preview_active
        and tostring(value_to_string(build_object_id))
            == tostring(blueprint_preview_anchor_build_object_id) then
        local address = safe_object_address(context)
        if address ~= nil then
            blueprint_preview_building_model_address = address
            log("blueprint placement building model address captured context="
                .. object_name(context) .. " address=" .. tostring(address))
        end
    end
end)

local function refresh_blueprint_click_time_validation()
    local session = nil
    local session_references = nil
    local session_active, session_error =
        with_active_placement_session(function(current_session)
            session = current_session
            session_references =
                synchronize_placement_session_references(
                    current_session
                )
        end)
    if not session_active or not is_valid_object(session) then
        return false, "placement Session unavailable: "
            .. tostring(session_error)
    end
    local anchor_actor = session_references
        and session_references.anchor or nil
    if not is_valid_object(anchor_actor) then
        blueprint_preview_all_placeable = false
        blueprint_preview_water_block_count = 0
        blueprint_preview_water_gate_unavailable = false
        return false, "anchor actor unavailable"
    end

    local raw_anchor_transform = nil
    pcall(function()
        raw_anchor_transform = anchor_actor:GetTransform()
    end)
    if raw_anchor_transform == nil then
        blueprint_preview_all_placeable = false
        blueprint_preview_water_block_count = 0
        blueprint_preview_water_gate_unavailable = false
        return false, "anchor transform unavailable"
    end
    local terrain_snap_active, terrain_snap_transform,
        terrain_snap_error = update_blueprint_terrain_snap(
            session, anchor_actor, raw_anchor_transform, false
        )
    if terrain_snap_error ~= nil then
        report_blueprint_terrain_snap_failure(
            "click", terrain_snap_error
        )
        terrain_snap_active = false
        terrain_snap_transform = nil
    end
    local click_motion = terrain_snap_active
        and capture_blueprint_transform_motion_signature(
            terrain_snap_transform
        )
        or capture_blueprint_anchor_motion_signature(anchor_actor)
    if blueprint_anchor_motion_changed(
        click_motion, blueprint_preview_last_anchor_transform
    ) then
        invalidate_native_overlap_for_anchor_motion(click_motion)
        -- The click itself is an explicit request for an up-to-date check.
        -- Submit immediately instead of waiting for the settled-preview
        -- debounce, but never block the game thread waiting for completion.
        blueprint_preview_validation_cooldown_ticks = 0
    end
    local overlap_gate_enabled =
        BlueprintResearchSettings.get_blueprint_overlap_gate_enabled()
    local final_anchor_transform = terrain_snap_transform
        or raw_anchor_transform
    local anchor_alignment = nil
    local alignment_error = nil
    if not terrain_snap_active then
        final_anchor_transform, anchor_alignment, alignment_error =
            resolve_anchor_presentation_transform(
                raw_anchor_transform, anchor_actor, "click"
            )
    end
    if final_anchor_transform == nil then
        blueprint_preview_all_placeable = false
        return false, tostring(alignment_error)
    end
    local update_ok, update_error = update_blueprint_ghost_root_transform(
        session, final_anchor_transform
    )
    local validation_ok, validation_error = false, nil
    if update_ok then
        local world_ok, world_error = refresh_blueprint_ghost_world_transforms(
            session, final_anchor_transform
        )
        if world_ok then
            if not overlap_gate_enabled then
                validation_ok, validation_error =
                    validate_blueprint_ghost_overlaps(
                        session, final_anchor_transform,
                        session_references, "click"
                    )
            else
                local native_result_current =
                    blueprint_preview_validation_dirty ~= true
                    and blueprint_native_overlap_last_report ~= nil
                    and blueprint_native_overlap_completed_revision
                        == blueprint_preview_validation_revision
                if native_result_current then
                    validation_ok = true
                else
                    local submitted, submit_error =
                        validate_blueprint_ghost_overlaps(
                            session, final_anchor_transform,
                            session_references, "click"
                        )
                    validation_ok = false
                    validation_error = submitted
                        and "native overlap validation pending"
                        or submit_error
                end
            end
        else
            validation_error = world_error
        end
    else
        validation_error = update_error
    end
    blueprint_preview_anchor_frame_corrected = terrain_snap_active
        or (anchor_alignment ~= nil
            and anchor_alignment.presentation_normalized == true)
    if not validation_ok then
        blueprint_preview_all_placeable = false
        blueprint_preview_water_block_count = 0
        blueprint_preview_water_gate_unavailable = false
        log("blueprint final click-time validation failed error="
            .. tostring(validation_error))
    end
    blueprint_preview_validation_cooldown_ticks =
        BLUEPRINT_VALIDATION_INTERVAL_TICKS
    local anchor_transform_snapshot = copy_transform(final_anchor_transform)
    local anchor_address = safe_object_address(anchor_actor)
    if anchor_transform_snapshot == nil or anchor_address == nil then
        return false, "anchor snapshot is unavailable"
    end
    return validation_ok and blueprint_preview_all_placeable,
        validation_error, {
            session = session,
            references = session_references,
            anchor_address = anchor_address,
            anchor_transform_snapshot = anchor_transform_snapshot,
            anchor_alignment = anchor_alignment,
            native_overlap_report =
                blueprint_native_overlap_last_report,
        }
end

local function get_compact_runtime_object_label(value)
    local full_name = object_name(value)
    if full_name == "<nil>" or full_name == "<invalid>" then
        return full_name
    end

    local class_name = string.match(full_name, "^([^%s]+)")
    local object_path = string.match(full_name, "%s+(.+)$") or full_name
    local leaf_name = string.match(object_path, "([^%.:/]+)$")
    if leaf_name ~= nil then
        leaf_name = string.gsub(leaf_name, "_%d+$", "")
    end
    if class_name ~= nil and leaf_name ~= nil
        and class_name ~= leaf_name then
        return class_name .. ":" .. leaf_name
    end
    return leaf_name or class_name or full_name
end

local function format_equivalence_vector(value)
    if type(value) ~= "table" then return "<nil>" end
    return string.format(
        "(%.3f,%.3f,%.3f)",
        tonumber(value.x or value.X) or 0.0,
        tonumber(value.y or value.Y) or 0.0,
        tonumber(value.z or value.Z) or 0.0
    )
end

local function get_blueprint_overlap_detail_message()
    for _, building_state in ipairs(blueprint_ghost_state.buildings or {}) do
        local blocker = building_state.blocker
        if blocker ~= nil then
            local reason = tostring(blocker.reason or "unknown")
            local blocker_is_build_object =
                blocker.category == "build_object"
                or is_build_object_blocker_reason(reason)
            local profile = blocker.profile
                or string.match(reason, "^[^:]+:(.+)$")
                or "<unavailable>"
            local blocker_build_object_id =
                blocker.build_object_id or "<dynamic>"
            local blueprint_label = tostring(
                building_state.build_object_id or "<unknown>"
            )
            pcall(function()
                local _, localized_label =
                    BlueprintSelectionMode.resolve_build_object_display_name(
                        building_state.build_object_id, nil
                    )
                if localized_label ~= nil and localized_label ~= "" then
                    blueprint_label = localized_label
                end
            end)

            local blocker_label = nil
            if blocker_is_build_object then
                blocker_label = blocker_build_object_id
                pcall(function()
                    local _, localized_label = BlueprintSelectionMode.
                        resolve_build_object_display_name(
                            blocker_build_object_id, nil
                        )
                    if localized_label ~= nil and localized_label ~= "" then
                        blocker_label = localized_label
                    end
                end)
                if blocker_label == "<nil>" or blocker_label == "None"
                    or blocker_label == "" then
                    blocker_label = blocker.actor_label
                        or blocker.component_label
                        or "<unknown>"
                end
            else
                -- Never inspect a Pal/dynamic blocker to build a user-facing
                -- label. Native Checker metadata is already a pure string
                -- copied while the blocker was alive, so it is safe to show.
                blocker_label = blocker.display_label
                if not usable_native_blocker_text(blocker_label) then
                    blocker_label = blueprint_localization.text(
                        get_dynamic_blocker_localization_key(reason)
                    )
                end
            end
            if blocker_is_build_object then
                local equivalence = blocker.equivalence_rejection
                log(string.format(
                    "blueprint overlap diagnostic count=%d blueprintBuild=%s source=%s blockerBuild=%s blockerActor=%s blockerActorClass=%s blockerComponent=%s blockerComponentClass=%s objectType=%s reason=%s profile=%s equivalenceReason=%s positionErrorCm=%s angleErrorDeg=%s matchedYaw=%s expectedCenter=%s candidateCenter=%s",
                    blueprint_preview_overlap_count,
                    tostring(building_state.build_object_id or "<unknown>"),
                    tostring(building_state.source_instance_id or "<unknown>"),
                    tostring(blocker_build_object_id),
                    tostring(blocker.actor_label or "<unavailable>"),
                    tostring(blocker.actor_class_label or "<unavailable>"),
                    tostring(blocker.component_label or "<unavailable>"),
                    tostring(blocker.component_class_label or "<unavailable>"),
                    tostring(blocker.object_type or "<unavailable>"),
                    reason, tostring(profile),
                    tostring(
                        equivalence and equivalence.reason
                            or "<not-same-type>"
                    ),
                    tostring(
                        equivalence and equivalence.position_error
                            or "<unavailable>"
                    ),
                    tostring(
                        equivalence and equivalence.angle_error_degrees
                            or "<unavailable>"
                    ),
                    tostring(
                        equivalence and equivalence.matched_equivalent_yaw
                            or "<unavailable>"
                    ),
                    format_equivalence_vector(
                        equivalence and equivalence.expected_location
                    ),
                    format_equivalence_vector(
                        equivalence and equivalence.candidate_location
                    )
                ))
            else
                log(string.format(
                    "blueprint overlap diagnostic count=%d blueprintBuild=%s source=%s blockerBuild=<dynamic> blockerActor=%s blockerActorClass=%s blockerComponent=%s blockerComponentClass=%s objectType=%s reason=%s profile=%s",
                    blueprint_preview_overlap_count,
                    tostring(building_state.build_object_id or "<unknown>"),
                    tostring(building_state.source_instance_id or "<unknown>"),
                    tostring(blocker.actor_label or "<unavailable>"),
                    tostring(blocker.actor_class_label or "<unavailable>"),
                    tostring(blocker.component_label or "<unavailable>"),
                    tostring(blocker.component_class_label or "<unavailable>"),
                    tostring(blocker.object_type or "<unavailable>"),
                    reason, tostring(profile)
                ))
            end
            local message_key = blocker.primary_actor_only == true
                and "message.placement.overlap_primary_actor"
                or "message.placement.overlap_detail"
            return blueprint_localization.text(
                message_key,
                blueprint_preview_overlap_count,
                tostring(blueprint_label),
                tostring(blocker_label)
            )
        end
    end
    return nil
end

local function get_blueprint_invalid_placement_message()
    if blueprint_native_overlap_gate ~= nil
        and blueprint_native_overlap_gate.has_pending() then
        return blueprint_localization.text(
            "message.placement.checking"
        )
    end
    if blueprint_preview_water_block_count > 0 then
        if blueprint_preview_water_gate_unavailable then
            return blueprint_localization.text(
                "message.placement.water_capability_unavailable"
            )
        end
        return blueprint_localization.text(
            "message.placement.water_building_locked"
        )
    end
    if blueprint_preview_overlap_count > 0 then
        local detail_message = get_blueprint_overlap_detail_message()
        if detail_message ~= nil then return detail_message end
        return blueprint_localization.text(
            "message.placement.overlap",
            blueprint_preview_overlap_count
        )
    end
    return blueprint_localization.text("message.placement.anchor_invalid")
end

local function get_localized_material_shortage_summary(report)
    if report == nil then return "" end
    local ui_utility = unwrap(StaticFindObject(
        "/Script/Pal.Default__PalUIUtility"
    ))
    local world = unwrap(UEHelpers.GetWorld())
    local parts = {}
    for _, item_id in ipairs(report.material_order or {}) do
        local need = tonumber(report.required and report.required[item_id]) or 0
        local have = tonumber(report.available and report.available[item_id]) or 0
        local shortage = math.max(need - have, 0)
        if shortage > 0 then
            local item_label = tostring(item_id)
            if is_valid_object(ui_utility) and is_valid_object(world) then
                local output = {}
                local name_ok = pcall(function()
                    ui_utility:GetItemName(world, FName(item_id), output)
                end)
                local localized_name = output.outName or output.OutName
                local localized_label = value_to_string(localized_name)
                if name_ok and localized_name ~= nil
                    and localized_label ~= ""
                    and localized_label ~= "<nil>" then
                    item_label = localized_label
                end
            end
            parts[#parts + 1] = string.format(
                "%s ×%d", item_label, shortage
            )
        end
    end
    if #parts == 0 then return tostring(report.shortage_summary or "") end
    return table.concat(parts, ", ")
end

local function check_blueprint_submission_materials(
    builder, excluded_source_ids
)
    if not BlueprintResearchSettings
        .get_blueprint_material_gate_enabled() then
        log("blueprint aggregate material gate bypassed by configuration")
        return true, {
            kind = "disabled",
            building_count = #(
                blueprint_clipboard
                    and blueprint_clipboard.buildings or {}
            ),
        }
    end

    local material_blueprint = blueprint_clipboard
    if type(excluded_source_ids) == "table"
        and next(excluded_source_ids) ~= nil then
        material_blueprint = { buildings = {} }
        for _, building in ipairs(
            blueprint_clipboard.buildings or {}
        ) do
            if excluded_source_ids[
                building.source_instance_id
            ] ~= true then
                table.insert(material_blueprint.buildings, building)
            end
        end
        if #material_blueprint.buildings == 0 then
            return true, {
                kind = "already_complete",
                building_count = 0,
            }
        end
    end
    local material_ok, material_report = BlueprintMaterialGate.check(
        material_blueprint,
        is_valid_object(unwrap(builder))
            and unwrap(builder) or get_blueprint_preview_builder()
    )
    if not material_ok then
        local material_message = material_report ~= nil
            and material_report.message or "unknown material gate failure"
        log("blueprint build blocked at aggregate material gate: "
            .. tostring(material_message))
        if material_report ~= nil
            and material_report.kind == "insufficient" then
            send_blueprint_message(
                "message.placement.materials_insufficient",
                get_localized_material_shortage_summary(material_report)
            )
        else
            send_blueprint_message("message.placement.material_check_failed")
        end
        return false, material_report
    end
    if material_report ~= nil and material_report.kind == "unavailable" then
        log("blueprint aggregate material gate unavailable; fail-open reason="
            .. tostring(material_report.message))
    elseif material_report ~= nil then
        log(string.format(
            "blueprint aggregate material gate passed buildings=%d buildTypes=%d materialTypes=%d totals=[%s]",
            material_report.building_count or 0,
            material_report.build_type_count or 0,
            material_report.material_type_count or 0,
            tostring(material_report.summary or "")
        ))
    end
    return true, material_report
end

local function submit_current_blueprint_preview(source)
    local primary_action_started_at = BlueprintPerformance.now()
    local submission_probe = {}
    local force_submit_invalid = BlueprintResearchSettings
        .get_blueprint_force_submit_invalid_enabled()
    if blueprint_commit_queued then
        return false, "foreground submission is already in progress"
    end

    local input_lock_started_at = BlueprintPerformance.now()
    blueprint_placement_input.set_primary_locked(true)
    submission_probe.primary_input_lock =
        BlueprintPerformance.elapsed_ms(input_lock_started_at)
    local function fail(error_value)
        blueprint_placement_input.set_primary_locked(false)
        return false, error_value
    end

    local validation_started_at = BlueprintPerformance.now()
    local placement_ready, validation_error, submission_context =
        refresh_blueprint_click_time_validation()
    submission_probe.click_validation =
        BlueprintPerformance.elapsed_ms(validation_started_at)
    local force_overlap_bypass = false
    if force_submit_invalid
        and type(submission_context) == "table"
        and BlueprintResearchSettings
            .get_blueprint_overlap_gate_enabled() then
        local native_report = submission_context.native_overlap_report
        force_overlap_bypass = type(native_report) == "table"
            and tonumber(native_report.status) == 2
            and tonumber(native_report.native_error_count or 0) == 0
            and blueprint_native_overlap_completed_revision
                == blueprint_preview_validation_revision
            and not blueprint_native_overlap_gate.has_pending()
    end
    if (
        not placement_ready
        and not force_overlap_bypass
    ) or type(submission_context) ~= "table" then
        local message = get_blueprint_invalid_placement_message()
        log("blueprint placement click blocked source=" .. tostring(source)
            .. " message=" .. message)
        send_blueprint_announce(message, "warning")
        return fail("blueprint placement validation is not green: "
            .. tostring(validation_error))
    end
    local references = submission_context.references
    local reference_read_started_at = BlueprintPerformance.now()
    local anchor_actor = references ~= nil
        and unwrap(references.anchor) or nil
    submission_probe.session_reference_read =
        BlueprintPerformance.elapsed_ms(reference_read_started_at)
    if not is_valid_object(anchor_actor) then
        log("blueprint placement click blocked: current anchor is unavailable")
        send_blueprint_message("message.placement.hud_expired")
        return fail("current anchor is unavailable")
    end
    local anchor_actor_request_transform = nil
    local anchor_transform_started_at = BlueprintPerformance.now()
    local transform_ok, transform_error = pcall(function()
        anchor_actor_request_transform = restore_transform(
            submission_context.anchor_transform_snapshot
        )
    end)
    submission_probe.anchor_transform_snapshot =
        BlueprintPerformance.elapsed_ms(anchor_transform_started_at)
    if not transform_ok or anchor_actor_request_transform == nil then
        log("blueprint placement click blocked: anchor transform unavailable error="
            .. tostring(transform_error))
        send_blueprint_message("message.build.request_error")
        return fail("anchor transform is unavailable")
    end

    local request_snapshot_started_at = BlueprintPerformance.now()
    local prepared_member_requests, snapshot_error =
        snapshot_blueprint_non_anchor_build_requests(
            anchor_actor_request_transform
        )
    submission_probe.submit_request_snapshot =
        BlueprintPerformance.elapsed_ms(request_snapshot_started_at)
    if prepared_member_requests == nil then
        log("blueprint placement click blocked: request snapshot failed error="
            .. tostring(snapshot_error))
        send_blueprint_message("message.build.request_error")
        return fail(snapshot_error)
    end

    local preexisting_match_started_at = BlueprintPerformance.now()
    local preexisting_match_result = nil
    local preexisting_match_error = nil
    if BlueprintResearchSettings.get_blueprint_overlap_gate_enabled() then
        preexisting_match_result, preexisting_match_error =
            collect_native_checker_preexisting_matches(
                submission_context,
                prepared_member_requests
            )
    else
        -- Exact-overlap repair is derived from the native overlap Checker.
        -- When that gate is explicitly disabled, do not require a Checker
        -- result: submit every blueprint request and let the unrestricted
        -- building mod/server own overlap behaviour.
        preexisting_match_result = {
            matches_by_source_id = {},
            source_ids = {},
            matched_count = 0,
            expectation_count = #(blueprint_clipboard.buildings or {}),
            indexed_candidate_count = 0,
            overlap_gate_disabled = true,
        }
    end
    submission_probe.preexisting_world_match =
        BlueprintPerformance.elapsed_ms(preexisting_match_started_at)
    if preexisting_match_result == nil then
        log("blueprint placement click blocked: preexisting match failed error="
            .. tostring(preexisting_match_error))
        send_blueprint_message("message.build.request_error")
        return fail(preexisting_match_error)
    end
    local blueprint_building_count =
        #(blueprint_clipboard.buildings or {})
    if preexisting_match_result.matched_count
        >= blueprint_building_count then
        blueprint_placement_input.set_primary_locked(false)
        send_blueprint_message("message.build.already_complete")
        log("blueprint placement skipped: every building already exists count="
            .. tostring(preexisting_match_result.matched_count))
        return true, nil
    end

    local material_gate_started_at = BlueprintPerformance.now()
    local materials_ready = check_blueprint_submission_materials(
        references and references.builder,
        preexisting_match_result.source_ids
    )
    submission_probe.material_gate =
        BlueprintPerformance.elapsed_ms(material_gate_started_at)
    if not materials_ready then
        return fail("aggregate material gate rejected the placement")
    end

    local network_resolve_started_at = BlueprintPerformance.now()
    local network = resolve_runtime_object_handle(
        blueprint_preview_network_component_handle
    )
    if not is_valid_object(network) then
        local captured, capture_error =
            capture_blueprint_preview_network_handle()
        if captured then
            network = resolve_runtime_object_handle(
                blueprint_preview_network_component_handle
            )
        end
        if not is_valid_object(network) then
            log("blueprint placement click blocked: network component unavailable error="
                .. tostring(capture_error))
            send_blueprint_message("message.build.request_error")
            return fail("network component is unavailable")
        end
    end
    submission_probe.submission_network_resolve =
        BlueprintPerformance.elapsed_ms(network_resolve_started_at)

    blueprint_continuous_placement_requested = true
    submission_probe.submit_click_prequeue =
        BlueprintPerformance.elapsed_ms(primary_action_started_at)
    local queued, queue_error, queue_failure =
        queue_blueprint_wave_build_requests(
            network, anchor_actor_request_transform,
            submission_context.anchor_address, submission_probe,
            prepared_member_requests, preexisting_match_result,
            force_submit_invalid
        )
    if not queued then
        blueprint_continuous_placement_requested = false
        log("blueprint direct placement submission failed source="
            .. tostring(source) .. " error=" .. tostring(queue_error))
        if queue_failure ~= nil
            and queue_failure.kind == "structure_unbuildable" then
            send_blueprint_message("message.build.structure_unbuildable")
        else
            send_blueprint_message("message.build.start_failed")
        end
        return fail(queue_error)
    end
    -- The custom-anchor transaction releases the foreground lock before it
    -- returns. Keep this explicit for failure-safe future backend changes.
    blueprint_placement_input.set_primary_locked(false)
    if force_submit_invalid then
        send_blueprint_message("message.build.force_submit_started")
    end
    log("blueprint direct placement submitted source=" .. tostring(source)
        .. " activeJobs=" .. tostring(blueprint_build_job_count)
        .. " forceSubmitInvalid=" .. tostring(force_submit_invalid))
    return true, nil
end

handle_blueprint_placement_primary_action = function()
    if not blueprint_preview_active then return false end
    if blueprint_placement_input ~= nil
        and blueprint_placement_input.is_camera_active() then
        return true
    end
    submit_current_blueprint_preview("dedicated-input")
    return true
end

register_hook("/Script/Pal.PalUIBuildingModel:BuildObject", function(context, continuously)
    log(string.format("BuildingModel.BuildObject context=%s continuously=%s", object_name(context), value_to_string(continuously)))
    if blueprint_preview_active then
        local address = safe_object_address(context)
        if address ~= nil then
            blueprint_preview_building_model_address = address
        end
        -- BuildObject is void and a UE4SS pre-hook cannot cancel it. Reaching
        -- this branch means the exact Widget rebind failed or another mod
        -- replaced the action bindings after us. Never start a second direct
        -- submission here; the terminal RPC hook remains the sole emergency
        -- compatibility path for this leaked stock call.
        log("blueprint CRITICAL stock BuildObject escaped current-widget input rebind")
    end
end)

register_hook("/Script/Pal.PalUIBuildingModel:FinishBuilding", function(context)
    log("BuildingModel.FinishBuilding context=" .. object_name(context))
    stop_blueprint_preview(
        "BuildingModel.FinishBuilding",
        false,
        true
    )
end)

register_hook("/Script/Pal.PalUIBuildingModel:Dispose", function(context)
    log("BuildingModel.Dispose context=" .. object_name(context))
    stop_blueprint_preview(
        "BuildingModel.Dispose",
        false,
        true
    )
end)

register_hook("/Script/Pal.PalUIBuildModel:StartDismantleMode", function(context)
    if BlueprintSelectionMode.active then
        BlueprintSelectionMode.finish(
            "original-StartDismantleMode", false, true
        )
    end
    stop_blueprint_preview("BuildModel.StartDismantleMode", false, true)
    reset_selection_visual_observer(true)
    if blueprint_stock_visual_probe ~= nil
        and type(blueprint_stock_visual_probe.reset_target)
            == "function" then
        blueprint_stock_visual_probe.reset_target()
    end
    schedule_pending_selection_clear("BuildModel.StartDismantleMode")
    log("BuildModel.StartDismantleMode context=" .. object_name(context))
end)

register_hook("/Script/Pal.PalUIBuildModel:FinishDismantleMode", function(context)
    log("BuildModel.FinishDismantleMode")
    schedule_pending_selection_clear("BuildModel.FinishDismantleMode")
    reset_selection_visual_observer(false)
    if blueprint_stock_visual_probe ~= nil
        and type(blueprint_stock_visual_probe.reset_target)
            == "function" then
        blueprint_stock_visual_probe.reset_target()
    end
end)

register_hook("/Script/Pal.PalUIBuildModel:StartPaintMode", function(context)
    if BlueprintSelectionMode.active then
        BlueprintSelectionMode.finish(
            "original-StartPaintMode", false, true
        )
    end
    stop_blueprint_preview("BuildModel.StartPaintMode", false, true)
    reset_selection_visual_observer(true)
    schedule_pending_selection_clear("BuildModel.StartPaintMode")
    log("BuildModel.StartPaintMode context=" .. object_name(context))
end)

register_hook("/Script/Pal.PalUIBuildModel:FinishPaintMode", function(context)
    log("BuildModel.FinishPaintMode")
    schedule_pending_selection_clear("BuildModel.FinishPaintMode")
    reset_selection_visual_observer(false)
end)

register_hook("/Script/Pal.PalUIDismantlingModel:FinishDismantling", function(context)
    log("DismantlingModel.FinishDismantling")
    schedule_pending_selection_clear("DismantlingModel.FinishDismantling")
    reset_selection_visual_observer(false)
end)

register_hook("/Script/Pal.PalUIDismantlingModel:Dispose", function(context)
    log("DismantlingModel.Dispose")
    schedule_pending_selection_clear("DismantlingModel.Dispose")
    reset_selection_visual_observer(false)
end)

register_post_hook("/Script/Pal.PalBuilderComponent:GetDismantleTargetObject", function(context)
    local builder = unwrap(context)
    local checker = unwrap(safe_property(builder, "DismantleChecker"))
    local target = unwrap(safe_property(checker, "TargetBuildObject"))
    if blueprint_stock_visual_probe ~= nil
        and type(blueprint_stock_visual_probe.observe_target)
            == "function" then
        blueprint_stock_visual_probe.observe_target(
            target, "Builder.GetDismantleTargetObject"
        )
    end
    observe_dismantle_target_transition(target, "Builder.GetDismantleTargetObject")
end)

register_post_hook("/Script/Pal.PalDismantleObjectChecker:GetTargetObject", function(context)
    local checker = unwrap(context)
    local target = unwrap(safe_property(checker, "TargetBuildObject"))
    if blueprint_stock_visual_probe ~= nil
        and type(blueprint_stock_visual_probe.observe_target)
            == "function" then
        blueprint_stock_visual_probe.observe_target(
            target, "DismantleChecker.GetTargetObject"
        )
    end
    observe_dismantle_target_transition(target, "DismantleChecker.GetTargetObject")
end)

register_post_hook("/Script/Pal.PalUIPaintModel:SetTargetBuildObject", function(context, target)
    local builder = find_valid_instance("PalBuilderComponent", "/Game/Pal/Maps/")
    if not is_original_paint_mode_active(builder) then return end
    local paint_model = unwrap(context)
    local observed_target = unwrap(safe_property(paint_model, "TargetBuildObject"))
    if not is_valid_object(observed_target) then observed_target = unwrap(target) end
    observe_dismantle_target_transition(
        observed_target, "PaintModel.SetTargetBuildObject"
    )
end)

register_hook("/Script/Pal.PalUIPaintModel:FinishPainting", function(context)
    log("PaintModel.FinishPainting")
    schedule_pending_selection_clear("PaintModel.FinishPainting")
    reset_selection_visual_observer(false)
end)

register_hook("/Script/Pal.PalUIPaintModel:Dispose", function(context)
    log("PaintModel.Dispose")
    schedule_pending_selection_clear("PaintModel.Dispose")
    reset_selection_visual_observer(false)
end)

register_hook("/Script/Pal.PalNetworkPlayerComponent:RequestBuild_ToServer", function(
    context, build_object_id, location, rotation, extra_parameter_archives,
    debug_parameter
)
    -- Custom member requests re-enter this hook. RemoteUnrealParam wrappers
    -- only live for the native call, so the guard must precede every access.
    if blueprint_network_dispatch_guard or not blueprint_preview_active then
        return
    end
    local requested_build_object_id = value_to_string(build_object_id)
    if requested_build_object_id ~= blueprint_preview_anchor_build_object_id then
        return
    end

    local request_location = copy_vector(location)
    local request_quaternion = copy_quaternion(rotation)

    local anchor_actor_request_transform = nil
    if request_location ~= nil and request_location.x ~= nil
        and request_location.y ~= nil and request_location.z ~= nil
        and request_quaternion ~= nil and request_quaternion.x ~= nil
        and request_quaternion.y ~= nil and request_quaternion.z ~= nil
        and request_quaternion.w ~= nil then
        anchor_actor_request_transform = {
            Translation = {
                X = request_location.x,
                Y = request_location.y,
                Z = request_location.z,
            },
            Rotation = {
                X = request_quaternion.x,
                Y = request_quaternion.y,
                Z = request_quaternion.z,
                W = request_quaternion.w,
            },
            Scale3D = { X = 1.0, Y = 1.0, Z = 1.0 },
        }
    end
    if anchor_actor_request_transform == nil then
        log("blueprint escaped stock request diagnostic failed: anchor RPC transform unavailable")
        return
    end

    if not blueprint_preview_all_placeable then
        local replaced = false
        local replace_error = nil
        local ok, err = pcall(function()
            build_object_id:set(FName("None"))
            replaced = value_to_string(build_object_id) == "None"
        end)
        if not ok then replace_error = err end
        log(string.format(
            "blueprint CRITICAL overlap gate reached network request originalBuild=%s overlaps=%d replacedWithNone=%s error=%s",
            requested_build_object_id, blueprint_preview_overlap_count,
            tostring(replaced), tostring(replace_error)
        ))
        return
    end

    -- PalUIBuildingModel:BuildObject is a void UFunction and UE4SS cannot
    -- reliably cancel it from this hook. Treat an escaped stock binding as a
    -- compatibility diagnostic only. Starting a second BuildSession here
    -- would duplicate the dedicated-input submission and bypass the Sender.
    log("blueprint stock BuildObject escaped current-widget input rebind build="
        .. tostring(requested_build_object_id)
        .. " direct Sender submission was not started")
end)

register_hook("/Script/Pal.PalPlayerState:ReceiveBuildResult_ToRequestClient", function(
    context, result, build_result_parameter
)
    local route_started_at = BlueprintPerformance.now()
    local result_text = value_to_string(result)
    local result_success = is_successful_build_result(result_text)
    -- A listen server or single-player process observes the authoritative
    -- OnCreateMapObjectModelInServer event and must not also advance from its
    -- later client RPC. Remote success normally arrives through
    -- PalMapObject.OnRep_MapObjectModel, but accept an explicit success RPC
    -- as a compatible supplemental acknowledgement when a game version
    -- actually sends one. If NetMode cannot be resolved, prefer accepting
    -- that explicit result over incorrectly waiting for the timeout.
    --
    -- Never touch build_result_parameter: it is a short-lived UScriptStruct
    -- wrapper and was the repeating crash-stack family under long queues.
    if result_success
        and current_process_has_server_authority() == true then
        return
    end
    local transaction, request =
        find_current_blueprint_sender_request(nil)
    if transaction == nil or request == nil then return end
    record_build_queue_elapsed(
        transaction, "server_result_route", route_started_at,
        build_queue_request_context(transaction, request))
    complete_current_blueprint_rpc(
        result_success,
        result_text, "PalPlayerState.ReceiveBuildResult_ToRequestClient", {}
    )
end)

register_hook("/Script/Pal.PalUIInGameGeneralDispatchEventReciever:CloseDismantlingUI", function(context)
    log("HUDReceiver.CloseDismantlingUI")
    schedule_pending_selection_clear("HUDReceiver.CloseDismantlingUI")
end)

register_hook("/Script/Pal.PalUIInGameGeneralDispatchEventReciever:ClosePaintingUI", function(context)
    log("HUDReceiver.ClosePaintingUI")
    schedule_pending_selection_clear("HUDReceiver.ClosePaintingUI")
    reset_selection_visual_observer(false)
end)

register_hook("/Script/Pal.PalUIInGameGeneralDispatchEventReciever:CloseBuildingUI", function(context)
    -- This event is emitted before the stock construction widget tree is
    -- destroyed. Stop here so all placement references are discarded before
    -- destruction; the monitor's mode-ended check may run one cycle later.
    stop_blueprint_preview("HUDReceiver.CloseBuildingUI", false, true)
    log("HUDReceiver.CloseBuildingUI context=" .. object_name(context))
end)

register_hook("/Script/Pal.PalBaseCampManager:OnCreateMapObjectModelInServer", function(
    context, created_model, location
)
    if blueprint_build_job_count == 0 then return end
    local model = unwrap(created_model)
    local build_object_id = value_to_string(safe_property(model, "BuildObjectId"))
    local created_location = copy_vector(location)
    local created_instance_id = format_guid(
        safe_property(model, "InstanceId")
    )
    accept_blueprint_server_model_created(
        build_object_id, created_location, {
            server_created_instance_id = created_instance_id,
        }
    )
end)

register_post_hook("/Script/Pal.PalMapObject:OnRep_MapObjectModel", function(
    context
)
    if blueprint_build_job_count == 0 then return end

    -- Remote clients cannot observe the server-process
    -- OnCreateMapObjectModelInServer event, and successful builds do not
    -- reliably emit ReceiveBuildResult_ToRequestClient. The replicated
    -- PalMapObject model is therefore the remote success acknowledgement.
    --
    -- Keep every UObject callback-local. Copy only the scalar routing data
    -- before returning so a later world unload cannot leave Lua holding the
    -- replicated actor or model.
    local actor = unwrap(context)
    if not is_valid_object(actor) then return end
    local model = unwrap(safe_property(actor, "MapObjectModel"))
    if not is_valid_object(model) then
        pcall(function() model = unwrap(actor:GetModel()) end)
    end
    if not is_valid_object(model) then return end

    local build_object_id = value_to_string(
        safe_property(model, "BuildObjectId")
    )
    local model_transform = safe_property(
        model, "InitialTransformCache"
    )
    local created_location = copy_vector(
        safe_property(model_transform, "Translation")
    )
    if created_location == nil then
        local actor_location = nil
        pcall(function()
            actor_location = unwrap(actor:K2_GetActorLocation())
        end)
        created_location = copy_vector(actor_location)
    end
    local created_instance_id = format_guid(
        safe_property(model, "InstanceId")
    )

    accept_blueprint_server_model_created(
        build_object_id, created_location, {
            server_created_instance_id = created_instance_id,
            result_text = "ReplicatedModelCreated",
            result_source = "PalMapObject.OnRep_MapObjectModel",
        }
    )
end)

local function save_paint_selection_and_exit()
    local builder = find_valid_instance("PalBuilderComponent", "/Game/Pal/Maps/")
    if not is_original_paint_mode_active(builder) then return end

    local previous_clipboard = blueprint_clipboard
    commit_selection_to_clipboard()
    if blueprint_clipboard == previous_clipboard or has_pending_selection_state() then
        return
    end

    local paint_widget = find_valid_instance("WBP_PalPainting_C", "/Engine/Transient")
    if not is_valid_object(paint_widget) then
        log("painting-hosted blueprint save completed; active WBP_PalPainting not found, use the original cancel key to exit")
        return
    end
    local exited, exit_error = pcall(function() paint_widget:OnEsc() end)
    if exited then
        log("painting-hosted blueprint save completed; original WBP_PalPainting.OnEsc exit requested")
    else
        log("painting-hosted blueprint save completed but original paint exit failed error="
            .. tostring(exit_error))
    end
end

local function dispatch_paint_selection_action(label, action)
    BlueprintCallbackScheduler.game_thread_now(
        "paint-selection-action:" .. tostring(label), function()
        local builder = find_valid_instance("PalBuilderComponent", "/Game/Pal/Maps/")
        if not is_original_paint_mode_active(builder) then return end

        local action_ok, action_error = pcall(action)
        if not action_ok then
            log("painting-hosted selection action isolated error action="
                .. tostring(label) .. " error=" .. tostring(action_error))
        end
        local validation_ok, validation_error = pcall(function()
            validate_selection_state("painting-" .. tostring(label))
        end)
        if not validation_ok then
            log("painting-hosted selection validation isolated error action="
                .. tostring(label) .. " error=" .. tostring(validation_error))
        end
        end
    )
end

local function import_blueprint_code_into_library(
    code, default_name, decoded_compact
)
    if type(code) ~= "string" or code == "" then
        return nil, "blueprint code is empty"
    end
    local compact = decoded_compact
    if type(compact) ~= "table" then
        local decode_stats_or_error = nil
        compact, decode_stats_or_error = decode_blueprint_text(code)
        if compact == nil then return nil, decode_stats_or_error end
    end

    local templates_ready, template_error =
        ensure_blueprint_type_templates(compact)
    if not templates_ready then return nil, template_error end
    local runtime_blueprint, hydrate_stats_or_error =
        BlueprintJsonSchema.to_runtime(
            compact, BlueprintTypeRuntimeCache
        )
    if runtime_blueprint == nil then
        return nil, hydrate_stats_or_error
    end
    local canonical_code, encode_stats_or_error =
        encode_blueprint_for_library(compact)
    if canonical_code == nil then return nil, encode_stats_or_error end

    local initialized, initialize_error =
        blueprint_library_runtime.initialize()
    if not initialized then return nil, initialize_error end
    local entry, create_error = blueprint_library_runtime.store.create(
        default_name, canonical_code, {
            building_count = #runtime_blueprint.buildings,
            blueprint_schema_version = runtime_blueprint.schema_version,
            type_templates = snapshot_blueprint_type_templates(compact),
        }
    )
    if entry == nil then return nil, create_error end

    local thumbnail_path, thumbnail_path_error =
        blueprint_library_runtime.store.get_thumbnail_path(entry.id)
    local thumbnail_ready = false
    local thumbnail_error = thumbnail_path_error
    local thumbnail_resource = nil
    if thumbnail_path ~= nil then
        thumbnail_ready, thumbnail_error, thumbnail_resource =
            blueprint_thumbnail_renderer.render(
                runtime_blueprint, thumbnail_path
            )
    end
    if thumbnail_ready and is_valid_object(thumbnail_resource) then
        blueprint_library_manager.put_thumbnail(
            entry.id, thumbnail_resource
        )
    end
    local thumbnail_state = thumbnail_ready and "ready" or "failed"
    local state_updated, state_error =
        blueprint_library_runtime.store.set_thumbnail_state(
            entry.id, thumbnail_state
        )
    if state_updated then
        entry.thumbnail_state = thumbnail_state
    end
    if not thumbnail_ready or not state_updated then
        log("blueprint library imported thumbnail unavailable id="
            .. tostring(entry.id) .. " renderError="
            .. tostring(thumbnail_error) .. " stateError="
            .. tostring(state_error))
    end
    log("blueprint library code imported id=" .. tostring(entry.id)
        .. " name=" .. tostring(entry.name)
        .. " buildings=" .. tostring(entry.building_count))
    return entry, nil
end

local blueprint_native_ui_stack = BlueprintNativeUIStack.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    safe_object_address = safe_object_address,
})

local blueprint_confirm_dialog = BlueprintConfirmDialog.install({
    UEHelpers = UEHelpers,
    log = log,
    unwrap = unwrap,
    is_valid_object = is_valid_object,
    copy_native_widget_id = blueprint_native_ui_stack.copy_widget_id,
    close_native_widget_id = blueprint_native_ui_stack.close_widget_id,
})

local blueprint_library_ui = BlueprintLibraryUI.install({
    UEHelpers = UEHelpers,
    log = log,
    localize = blueprint_localization.text,
    store = blueprint_library_runtime.store,
    resource_manager = blueprint_library_manager,
    find_in_instance = function(instance, wanted_name)
        return BlueprintModeUI.find_in_instance(instance, wanted_name)
    end,
    read_clipboard = read_system_clipboard_text,
    copy_clipboard = copy_blueprint_text_to_system_clipboard,
    decode_blueprint = decode_blueprint_text,
    import_blueprint = import_blueprint_code_into_library,
    on_place = function(
        compact, stats, source_label, library_entry_id,
        persisted_type_templates
    )
        local accepted = start_blueprint_preview_from_compact(
            compact, stats, source_label, BlueprintPerformance.now(),
            persisted_type_templates
        )
        if accepted == true and library_entry_id ~= nil then
            local stored, store_error =
                blueprint_library_runtime.store.set_type_templates(
                    library_entry_id,
                    snapshot_blueprint_type_templates(compact)
                )
            if not stored then
                log("blueprint library type-template persistence failed id="
                    .. tostring(library_entry_id) .. " error="
                    .. tostring(store_error))
            end
        end
        return accepted
    end,
    request_confirm = blueprint_confirm_dialog.request,
    request_name = function(options)
        return blueprint_name_dialog.open(options)
    end,
    cancel_name = function(reason)
        return blueprint_name_dialog.cancel(reason)
    end,
    cancel_confirm = function(reason)
        return blueprint_confirm_dialog.cancel(reason)
    end,
    native_ui_stack = blueprint_native_ui_stack,
    send_message = send_blueprint_message,
})

local blueprint_runtime_world_identity = nil
local blueprint_world_shutdown_active = false
local MOD_ACTOR_CLASS_FULL_NAME =
    "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/"
        .. "ModActor.ModActor_C"

local function get_runtime_world_identity(context)
    context = unwrap(context)
    if not is_valid_object(context) then return nil end
    local world = nil
    pcall(function() world = unwrap(context:GetWorld()) end)
    if not is_valid_object(world) then return nil end
    local address = safe_object_address(world)
    if address == nil then return nil end
    return tostring(address) .. "|" .. object_name(world)
end

local function clear_table_in_place(values)
    if type(values) ~= "table" then return end
    for key in pairs(values) do values[key] = nil end
end

local function abandon_blueprint_runtime_for_world_travel(reason)
    reason = tostring(reason or "world-travel")

    if BlueprintRuntimeBridgeController ~= nil then
        BlueprintRuntimeBridgeController.abandon_world(reason)
    end

    -- This must happen before any subsystem releases its state. Every queued
    -- game-thread callback captures the generation at scheduling time and
    -- therefore becomes a no-op as soon as world teardown begins.
    BlueprintCallbackScheduler.invalidate_world(reason)
    BlueprintCallbackScheduler.cancel_all_world_actions(reason)
    clear_table_in_place(BlueprintWaveRuntime.scheduled_callbacks)

    BlueprintWaveRuntime.preview_first_tick_pending = false
    BlueprintWaveRuntime.preview_session_tick_count = 0
    -- Invalidate every queued wave callback before releasing its business
    -- state. The callback itself remains retained until UE4SS invokes it, but
    -- its generation check makes it a no-op in the new world.
    BlueprintWaveRuntime.world_generation =
        (tonumber(BlueprintWaveRuntime.world_generation) or 0) + 1
    BlueprintRpcSender.reset(
        blueprint_rpc_sender, BlueprintWaveRuntime.world_generation)
    blueprint_build_session_runtime.abandon_world(reason)
    local abandoned_transactions = {}
    local function abandon_transaction(transaction)
        if type(transaction) ~= "table"
            or abandoned_transactions[transaction] then
            return
        end
        abandoned_transactions[transaction] = true
        transaction.timeout_token = (tonumber(transaction.timeout_token) or 0)
            + 1
        transaction.state = "ABANDONED_WORLD"
        transaction.timeout_context = nil
        transaction.pending_wake = nil
        transaction.terminal_pending = nil
        transaction.wave_visual_snapshot = nil
        transaction.wave_visual_anchor_transform = nil
        transaction.build_session_handle = nil
        if transaction.wave_visual ~= nil then
            blueprint_wave_ghost_renderer.abandon(
                transaction.wave_visual, reason
            )
            transaction.wave_visual = nil
        end
        transaction.inflight_request = nil
    end
    for _, transaction in pairs(blueprint_build_jobs_by_id or {}) do
        abandon_transaction(transaction)
    end

    -- Drop Lua's active selection UObjects before the owning World/session
    -- subsystems release themselves. This function never dereferences them.
    BlueprintSelectionMode.abandon_world(reason)
    blueprint_ghost_renderer.abandon_world(reason)
    blueprint_blocker_visual.abandon_world()
    region_preview.abandon_world()
    selection_visual.abandon_world()
    blueprint_placement_hud_key_guides.abandon_world()
    blueprint_placement_hud_materials.cancel(reason)
    blueprint_placement_input.abandon_world(reason)
    BlueprintSelectionInputBridge.abandon_world(reason)
    blueprint_selection_camera.abandon_world()
    blueprint_selection_session.abandon_world()
    blueprint_name_dialog.reset_for_world_travel()
    blueprint_confirm_dialog.reset_for_world_travel()
    blueprint_library_ui.reset_for_world_travel()
    BlueprintModeUI.abandon_world(reason)
    blueprint_user_message.reset_for_world_travel()

    if BlueprintSelectionAsync.region_job ~= nil then
        local region_job = BlueprintSelectionAsync.region_job
        region_job.cancelled = true
        release_region_job_references(region_job)
        BlueprintSelectionAsync.region_job = nil
    end
    selected_buildings_by_instance = {}
    selected_building_order = {}
    selected_anchor_instance_id = nil
    region_start_instance_id = nil
    region_end_instance_id = nil
    region_start_actor = nil
    region_end_actor = nil
    region_start_record = nil
    region_end_record = nil
    selection_builder = nil
    selection_clear_scheduled = false
    selection_clear_reason = nil

    BlueprintSelectionMode.hud_material_signature = nil
    BlueprintSelectionMode.hud_material_last_error = nil

    blueprint_preview_active = false
    blueprint_preview_anchor_build_object_id = nil
    blueprint_preview_building_model_address = nil
    blueprint_preview_network_component_handle = nil
    blueprint_preview_attached_anchor_address = nil
    blueprint_preview_wait_ticks = 0
    blueprint_preview_last_anchor_transform = nil
    blueprint_preview_all_placeable = false
    blueprint_preview_overlap_count = 0
    blueprint_preview_water_block_count = 0
    blueprint_preview_water_gate_unavailable = false
    blueprint_preview_water_capability = nil
    blueprint_preview_validation_signature = nil
    blueprint_preview_validation_dirty = false
    blueprint_preview_validation_cooldown_ticks = 0
    blueprint_preview_validation_revision = 0
    blueprint_native_overlap_pending_revision = nil
    blueprint_native_overlap_completed_revision = nil
    blueprint_native_overlap_last_report = nil
    if blueprint_native_overlap_gate ~= nil then
        blueprint_native_overlap_gate.reset()
    end
    blueprint_continuous_placement_requested = false
    blueprint_continuous_unlock_pending = false
    blueprint_continuous_next_anchor_seen = false
    blueprint_start_build_forward_in_progress = false
    blueprint_commit_queued = false
    blueprint_build_jobs_by_id = {}
    blueprint_build_job_count = 0
    blueprint_network_dispatch_guard = false
    blueprint_clipboard = nil
    clear_table_in_place(BlueprintTypeRuntimeCache)

    log("blueprint runtime world references abandoned reason=" .. reason
        .. " generation="
        .. tostring(BlueprintWaveRuntime.world_generation))
end

local function observe_blueprint_mod_actor_world(context)
    blueprint_world_shutdown_active = false
    local identity = get_runtime_world_identity(context)
    if identity == nil or identity == blueprint_runtime_world_identity then
        return
    end
    local previous = blueprint_runtime_world_identity
    blueprint_runtime_world_identity = identity
    abandon_blueprint_runtime_for_world_travel(
        previous == nil and "initial-world" or "world-changed"
    )
end

local function get_runtime_class_full_name(value)
    value = unwrap(value)
    if not is_valid_object(value) then return nil end
    local ok, full_name = pcall(function()
        local object_class = unwrap(value:GetClass())
        return object_class:GetFullName()
    end)
    if not ok or full_name == nil then return nil end
    return tostring(full_name)
end

local function observe_blueprint_mod_actor_end_play(context)
    if blueprint_world_shutdown_active then return end
    if get_runtime_class_full_name(context)
        ~= MOD_ACTOR_CLASS_FULL_NAME then
        return
    end

    -- ReceiveEndPlay may run after large parts of the old world and UI tree
    -- have already started destruction. From this point the teardown path is
    -- deliberately pure Lua: invalidate callbacks and release references,
    -- but never resolve, restore, remove or destroy an old-world UObject.
    blueprint_world_shutdown_active = true
    blueprint_runtime_world_identity = nil
    abandon_blueprint_runtime_for_world_travel(
        "modactor-receive-end-play"
    )
end

BlueprintWorldLifecycleController = BlueprintWorldLifecycle.install({
    log = log,
    on_load_map_pre = function(reason)
        -- UEngine::LoadMap is the authoritative full-world boundary. Invalidate
        -- every scheduled callback before Unreal starts destroying the old
        -- world; old-world Actor and Widget instances are abandoned without
        -- being resolved, restored or destroyed.
        blueprint_world_shutdown_active = true
        blueprint_runtime_world_identity = nil
        abandon_blueprint_runtime_for_world_travel(reason)
    end,
    on_load_map_post = function(world, reason)
        blueprint_world_shutdown_active = false
        if BlueprintRuntimeBridgeController ~= nil then
            BlueprintRuntimeBridgeController.resume_world(reason)
        end
        blueprint_runtime_world_identity =
            get_runtime_world_identity(world)
        log("blueprint runtime new world registered reason="
            .. tostring(reason) .. " identity="
            .. tostring(blueprint_runtime_world_identity))
    end,
})

local function open_blueprint_library_from_construction_menu()
    log("construction-menu blueprint library requested")
    local menu = BlueprintModeUI.get_open_construction_menu()
    if not is_valid_object(menu) then
        log("construction-menu blueprint library ignored: no active visible build-list menu")
        return false
    end

    if blueprint_library_ui.is_open() then return true end

    local builder = find_valid_instance("PalBuilderComponent", "/Game/Pal/Maps/")
    if not is_valid_object(builder) then
        log("construction-menu blueprint library ignored: player builder is unavailable")
        return false
    end

    local incompatible_mode_active = false
    pcall(function()
        incompatible_mode_active = builder:IsDismantling()
            or builder:IsInPaintingMode()
    end)
    if incompatible_mode_active then
        log("construction-menu blueprint library ignored: dismantle or paint mode is active")
        return false
    end
    if blueprint_preview_active or blueprint_commit_queued then
        log(string.format(
            "construction-menu blueprint library ignored: foreground placement lifecycle is active preview=%s commit=%s activeJobs=%d",
            tostring(blueprint_preview_active),
            tostring(blueprint_commit_queued),
            blueprint_build_job_count
        ))
        send_blueprint_message("message.placement.state_busy")
        return false
    end

    local opened, open_error = blueprint_library_ui.open()
    if not opened then
        log("blueprint library panel open failed error="
            .. tostring(open_error))
        send_blueprint_message("message.library.open_failed", open_error)
        return false
    end
    return true
end

BlueprintModeUI.install({
    UEHelpers = UEHelpers,
    log = log,
    localize = blueprint_localization.text,
    on_create = function()
        if blueprint_library_ui.is_open() then
            log("blueprint create button ignored: blueprint library is open")
            return false
        end
        local menu = BlueprintModeUI.find_active_construction_menu()
        if not is_valid_object(menu) then
            log("blueprint create button ignored: construction menu is not active")
            return false
        end
        if blueprint_preview_active or blueprint_commit_queued then
            log("blueprint create button ignored: placement lifecycle is active")
            return false
        end
        -- Defensive no-op in normal flow.  If an earlier stock UI teardown
        -- ended between monitor ticks, discard any placement HUD session
        -- references before creation mode starts touching another widget tree.
        blueprint_placement_hud_materials.cancel(
            "selection-mode-start-sanitize"
        )
        local ok, result_or_error = pcall(BlueprintSelectionMode.start)
        if ok and result_or_error == true then
            log("blueprint create button entered independent selection mode")
            return true
        end
        log("blueprint create button failed to enter independent selection mode result="
            .. tostring(result_or_error))
        return false
    end,
    on_place = open_blueprint_library_from_construction_menu,
})

log("legacy F6/F7/F8/F9 blueprint hotkeys disabled to avoid UE/debug key conflicts")

BlueprintRuntimeKeyCallbacks = {
    retained = {},
}

function BlueprintRuntimeKeyCallbacks.is_input_suppressed()
    return blueprint_name_dialog.is_open()
        or blueprint_library_ui.is_open()
end

function BlueprintRuntimeKeyCallbacks.register(key, label, callback)
    local retained = function(...)
        if BlueprintRuntimeKeyCallbacks.is_input_suppressed() then return end
        local ok, error_value = pcall(callback, ...)
        if not ok then
            log("runtime key callback isolated error label="
                .. tostring(label) .. " error=" .. tostring(error_value))
        end
    end
    table.insert(BlueprintRuntimeKeyCallbacks.retained, retained)
    RegisterKeyBind(key, retained)
end

if not IsKeyBindRegistered(Key.G) then
    BlueprintRuntimeKeyCallbacks.register(Key.G, "G", function()
        if is_valid_object(BlueprintModeUI.find_active_construction_menu()) then
            BlueprintModeUI.dispatch_click("create", "hotkey-G")
            return
        end
        dispatch_paint_selection_action("G-toggle", toggle_current_selection_target)
    end)
    log("registered context-sensitive G hotkey construction=create paint=toggle")
else
    log("context-sensitive G hotkey unavailable: key is already registered")
end

if not IsKeyBindRegistered(Key.T) then
    BlueprintRuntimeKeyCallbacks.register(Key.T, "T", function()
        dispatch_paint_selection_action("T-anchor", set_current_selection_anchor)
    end)
    log("registered painting-hosted selection T anchor hotkey")
else
    log("painting-hosted T anchor unavailable: key is already registered")
end

if not IsKeyBindRegistered(Key.Y) then
    BlueprintRuntimeKeyCallbacks.register(Key.Y, "Y", function()
        dispatch_paint_selection_action("Y-region", set_current_region_corner)
    end)
    log("registered painting-hosted selection Y region hotkey")
else
    log("painting-hosted Y region unavailable: key is already registered")
end

if not IsKeyBindRegistered(Key.Z) then
    BlueprintRuntimeKeyCallbacks.register(Key.Z, "Z", function()
        dispatch_paint_selection_action("Z-save", save_paint_selection_and_exit)
    end)
    log("registered painting-hosted selection Z save-and-exit hotkey")
else
    log("painting-hosted Z save unavailable: key is already registered")
end

if not IsKeyBindRegistered(Key.K) then
    BlueprintRuntimeKeyCallbacks.register(Key.K, "K", function()
        if is_valid_object(BlueprintModeUI.find_active_construction_menu()) then
            BlueprintModeUI.dispatch_click("place", "hotkey-K")
        end
    end)
    log("registered construction-menu-only K blueprint placement hotkey")
else
    log("construction-menu K placement unavailable: key is already registered")
end

log("Simple Building Blueprints runtime loaded")

local BlueprintLibraryFileSystem = {}

local function trim(value)
    return (value:gsub("^%s+", ""):gsub("%s+$", ""))
end

function BlueprintLibraryFileSystem.normalize_directory(path)
    if type(path) ~= "string" then return nil end
    path = trim(path):gsub("/", "\\"):gsub("\\+$", "")
    if path == "" then return nil end
    return path
end

function BlueprintLibraryFileSystem.join_path(directory, name)
    directory = BlueprintLibraryFileSystem.normalize_directory(directory)
    if directory == nil or type(name) ~= "string" or name == "" then
        return nil
    end
    return directory .. "\\" .. name
end

function BlueprintLibraryFileSystem.read_file(path)
    local handle, open_error = io.open(path, "rb")
    if handle == nil then return nil, open_error end
    local content, read_error = handle:read("*a")
    local close_ok, close_error = handle:close()
    if content == nil then return nil, read_error end
    if close_ok == nil then return nil, close_error end
    return content, nil
end

function BlueprintLibraryFileSystem.write_file(path, content)
    local handle, open_error = io.open(path, "wb")
    if handle == nil then return false, open_error end
    local write_ok, write_error = handle:write(content)
    if write_ok == nil then
        handle:close()
        return false, write_error
    end
    local flush_ok, flush_error = handle:flush()
    if flush_ok == nil then
        handle:close()
        return false, flush_error
    end
    local close_ok, close_error = handle:close()
    if close_ok == nil then return false, close_error end
    return true, nil
end

function BlueprintLibraryFileSystem.file_exists(path)
    local handle = io.open(path, "rb")
    if handle == nil then return false end
    handle:close()
    return true
end

function BlueprintLibraryFileSystem.safe_remove(path)
    if not BlueprintLibraryFileSystem.file_exists(path) then
        return true, nil
    end
    local ok, error_value = os.remove(path)
    if ok then return true, nil end
    return false, error_value
end

function BlueprintLibraryFileSystem.rename_file(source, destination)
    local ok, error_value = os.rename(source, destination)
    if ok then return true, nil end
    return false, error_value
end

function BlueprintLibraryFileSystem.atomic_write(path, content)
    local temporary_path = path .. ".tmp"
    local backup_path = path .. ".bak"
    local removed, remove_error =
        BlueprintLibraryFileSystem.safe_remove(temporary_path)
    if not removed then
        return false, "temporary cleanup failed: "
            .. tostring(remove_error)
    end
    local written, write_error =
        BlueprintLibraryFileSystem.write_file(temporary_path, content)
    if not written then
        BlueprintLibraryFileSystem.safe_remove(temporary_path)
        return false, "temporary write failed: " .. tostring(write_error)
    end
    local verify_content, verify_error =
        BlueprintLibraryFileSystem.read_file(temporary_path)
    if verify_content ~= content then
        BlueprintLibraryFileSystem.safe_remove(temporary_path)
        return false, "temporary verification failed: "
            .. tostring(verify_error or "content mismatch")
    end

    local had_primary = BlueprintLibraryFileSystem.file_exists(path)
    if had_primary then
        local backup_removed, backup_remove_error =
            BlueprintLibraryFileSystem.safe_remove(backup_path)
        if not backup_removed then
            BlueprintLibraryFileSystem.safe_remove(temporary_path)
            return false, "old backup cleanup failed: "
                .. tostring(backup_remove_error)
        end
        local backup_ok, backup_error =
            BlueprintLibraryFileSystem.rename_file(path, backup_path)
        if not backup_ok then
            BlueprintLibraryFileSystem.safe_remove(temporary_path)
            return false, "primary backup failed: "
                .. tostring(backup_error)
        end
    end

    local promote_ok, promote_error =
        BlueprintLibraryFileSystem.rename_file(temporary_path, path)
    if promote_ok then return true, nil end

    if had_primary
        and BlueprintLibraryFileSystem.file_exists(backup_path) then
        BlueprintLibraryFileSystem.rename_file(backup_path, path)
    end
    BlueprintLibraryFileSystem.safe_remove(temporary_path)
    return false, "temporary promotion failed: "
        .. tostring(promote_error)
end

function BlueprintLibraryFileSystem.copy_file(source, destination)
    local content, read_error =
        BlueprintLibraryFileSystem.read_file(source)
    if content == nil then return false, read_error end
    return BlueprintLibraryFileSystem.atomic_write(destination, content)
end

function BlueprintLibraryFileSystem.verify_writable_directory(
    directory, probe_name
)
    directory = BlueprintLibraryFileSystem.normalize_directory(directory)
    if directory == nil then return false, "directory path is invalid" end
    local probe_path = BlueprintLibraryFileSystem.join_path(
        directory,
        probe_name or "SimpleBuildingBlueprints.write-probe.tmp"
    )
    local probe_ok, probe_error =
        BlueprintLibraryFileSystem.write_file(probe_path, "SBB-PROBE")
    if not probe_ok then return false, probe_error end
    local probe_content, probe_read_error =
        BlueprintLibraryFileSystem.read_file(probe_path)
    BlueprintLibraryFileSystem.safe_remove(probe_path)
    if probe_content ~= "SBB-PROBE" then
        return false, "write probe verification failed: "
            .. tostring(probe_read_error or "content mismatch")
    end
    return true, nil
end

function BlueprintLibraryFileSystem.ensure_writable_directory(
    directory, create_directory
)
    local writable, write_error =
        BlueprintLibraryFileSystem.verify_writable_directory(directory)
    if writable then return true, nil end
    if type(create_directory) ~= "function" then
        return false, write_error
    end
    local created, create_error = create_directory(directory)
    if created ~= true then
        return false, "directory creation failed: "
            .. tostring(create_error)
    end
    local verified, verify_error =
        BlueprintLibraryFileSystem.verify_writable_directory(directory)
    if not verified then
        return false, "created directory is not writable: "
            .. tostring(verify_error)
    end
    return true, nil
end

function BlueprintLibraryFileSystem.get_local_app_data_directory(
    subdirectory
)
    if type(subdirectory) ~= "string"
        or subdirectory:match("^[A-Za-z0-9._-]+$") == nil then
        return nil, "local application data subdirectory is invalid"
    end
    local root = BlueprintLibraryFileSystem.normalize_directory(
        os.getenv("LOCALAPPDATA")
    )
    if root == nil then
        return nil, "LOCALAPPDATA is unavailable"
    end
    return BlueprintLibraryFileSystem.join_path(root, subdirectory), nil
end

function BlueprintLibraryFileSystem.resolve_configured_directory(value)
    if type(value) ~= "string" then
        return nil, "configured directory must be a string"
    end
    value = trim(value)
    if value == "" then return nil, "configured directory is empty" end
    if value:find("[%z\r\n\"]") ~= nil then
        return nil, "configured directory contains unsupported characters"
    end

    local missing_environment = nil
    value = value:gsub("%%([A-Za-z_][A-Za-z0-9_]*)%%", function(name)
        local expanded = os.getenv(name)
        if type(expanded) ~= "string" or expanded == "" then
            missing_environment = name
            return ""
        end
        return expanded
    end)
    if missing_environment ~= nil then
        return nil, "environment variable is unavailable: "
            .. missing_environment
    end
    if value:find("%%", 1, true) ~= nil then
        return nil, "configured directory contains an invalid "
            .. "environment variable expression"
    end

    value = BlueprintLibraryFileSystem.normalize_directory(value)
    if value == nil then return nil, "configured directory is invalid" end
    local is_drive_absolute =
        value:match("^[A-Za-z]:\\.+") ~= nil
    local is_unc_absolute =
        value:match("^\\\\[^\\]+\\[^\\]+\\?.*") ~= nil
    if not is_drive_absolute and not is_unc_absolute then
        return nil, "configured directory must be an absolute path"
    end
    if value:match("^[A-Za-z]:\\?$") ~= nil then
        return nil, "configured directory cannot be a drive root"
    end
    for segment in value:gmatch("[^\\]+") do
        if segment == "." or segment == ".." then
            return nil, "configured directory cannot contain dot segments"
        end
    end
    return value, nil
end

function BlueprintLibraryFileSystem.create_configured_directory(
    configured_value, expected_path
)
    local resolved, resolve_error =
        BlueprintLibraryFileSystem.resolve_configured_directory(
            configured_value
        )
    if resolved == nil then return false, resolve_error end
    if BlueprintLibraryFileSystem.normalize_directory(expected_path)
        ~= resolved then
        return false, "refusing to create an unexpected directory"
    end

    local command = 'mkdir "' .. resolved .. '" >nul 2>nul'
    local execute_ok, execute_kind, execute_code = os.execute(command)
    if execute_ok == true or execute_ok == 0 then return true, nil end
    return false, tostring(execute_kind)
        .. " code=" .. tostring(execute_code)
end

function BlueprintLibraryFileSystem.create_local_app_data_directory(
    subdirectory, expected_path
)
    local resolved, resolve_error =
        BlueprintLibraryFileSystem.get_local_app_data_directory(subdirectory)
    if resolved == nil then return false, resolve_error end
    if BlueprintLibraryFileSystem.normalize_directory(expected_path)
        ~= resolved then
        return false, "refusing to create an unexpected directory"
    end

    -- The command is intentionally ASCII-only and expands LOCALAPPDATA inside
    -- cmd.exe. No user-controlled path or blueprint name enters the command.
    local command = 'mkdir "%LOCALAPPDATA%\\'
        .. subdirectory .. '" >nul 2>nul'
    local execute_ok, execute_kind, execute_code = os.execute(command)
    if execute_ok == true or execute_ok == 0 then return true, nil end
    return false, tostring(execute_kind)
        .. " code=" .. tostring(execute_code)
end

function BlueprintLibraryFileSystem.create_child_directory(
    parent_directory, child_name, expected_path
)
    parent_directory =
        BlueprintLibraryFileSystem.normalize_directory(parent_directory)
    if parent_directory == nil then
        return false, "parent directory is invalid"
    end
    if type(child_name) ~= "string"
        or child_name:match("^[A-Za-z0-9._-]+$") == nil then
        return false, "child directory name is invalid"
    end
    local resolved = BlueprintLibraryFileSystem.join_path(
        parent_directory, child_name
    )
    if BlueprintLibraryFileSystem.normalize_directory(expected_path)
        ~= resolved then
        return false, "refusing to create an unexpected directory"
    end
    if resolved:find('"', 1, true) ~= nil
        or resolved:find("[\r\n]") ~= nil then
        return false, "directory path cannot be passed to mkdir"
    end

    -- This path originates from UE's project Saved directory. The fixed child
    -- name prevents blueprint data or user-entered names from reaching cmd.
    local command = 'mkdir "' .. resolved .. '" >nul 2>nul'
    local execute_ok, execute_kind, execute_code = os.execute(command)
    if execute_ok == true or execute_ok == 0 then return true, nil end
    return false, tostring(execute_kind)
        .. " code=" .. tostring(execute_code)
end

return BlueprintLibraryFileSystem

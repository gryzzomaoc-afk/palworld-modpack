local BlueprintPlacementRuntimeBackend = {}

local SESSION_CLASS_FULL_NAME =
    "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/"
        .. "BP_BlueprintPlacementInput.BP_BlueprintPlacementInput_C"
local MOD_ACTOR_CLASS_NAME = "ModActor_C"
local MOD_ACTOR_CLASS_FULL_NAME =
    "BlueprintGeneratedClass /Game/Mods/BlueprintResearch/"
        .. "ModActor.ModActor_C"
local OWNER_PROPERTY = "SBB_PlacementSession"
local TICK_FUNCTION_PATH =
    "/Game/Mods/BlueprintResearch/BP_BlueprintPlacementInput."
        .. "BP_BlueprintPlacementInput_C:SBB_PlacementTick"
local UE_SESSION_BACKEND = "ue-placement-session"

function BlueprintPlacementRuntimeBackend.install(deps)
    assert(type(deps) == "table",
        "BlueprintPlacementRuntimeBackend dependencies are required")
    local log = assert(deps.log,
        "BlueprintPlacementRuntimeBackend log is required")
    local unwrap = assert(deps.unwrap,
        "BlueprintPlacementRuntimeBackend unwrap is required")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintPlacementRuntimeBackend is_valid_object is required")
    local safe_object_address = assert(deps.safe_object_address,
        "BlueprintPlacementRuntimeBackend safe_object_address is required")
    local find_all_of = assert(deps.find_all_of,
        "BlueprintPlacementRuntimeBackend find_all_of is required")
    local read_property = assert(deps.read_property,
        "BlueprintPlacementRuntimeBackend read_property is required")
    local write_property = assert(deps.write_property,
        "BlueprintPlacementRuntimeBackend write_property is required")
    local get_world_generation = assert(deps.get_world_generation,
        "BlueprintPlacementRuntimeBackend get_world_generation is required")
    local register_hook = assert(deps.register_hook,
        "BlueprintPlacementRuntimeBackend register_hook is required")
    local on_tick = assert(deps.on_tick,
        "BlueprintPlacementRuntimeBackend on_tick is required")

    local controller = {
        session_sequence = 0,
        generation_sequence = 0,
        active_session_id = nil,
        active_generation = nil,
        active_world_generation = nil,
        active_session_address = nil,
        begin_count = 0,
        end_count = 0,
        abandon_count = 0,
        tick_hook_ready = false,
        tick_hook_callback = nil,
        tick_count = 0,
        paused_tick_count = 0,
        stale_tick_count = 0,
        tick_error_count = 0,
    }

    local function get_class_full_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local ok, full_name = pcall(function()
            local object_class = unwrap(value:GetClass())
            return object_class:GetFullName()
        end)
        if not ok or full_name == nil then return nil end
        return tostring(full_name)
    end

    local function get_world(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local ok, world = pcall(function()
            return unwrap(value:GetWorld())
        end)
        if not ok or not is_valid_object(world) then return nil end
        return world
    end

    local function is_same_object(left, right)
        left = unwrap(left)
        right = unwrap(right)
        if not is_valid_object(left) or not is_valid_object(right) then
            return false
        end
        local left_address = safe_object_address(left)
        local right_address = safe_object_address(right)
        return left_address ~= nil and left_address == right_address
    end

    local function find_owner(session)
        local session_world = get_world(session)
        if not is_valid_object(session_world) then
            return nil, "placement session World is unavailable"
        end
        for _, candidate_value in ipairs(
            find_all_of(MOD_ACTOR_CLASS_NAME) or {}
        ) do
            local candidate = unwrap(candidate_value)
            if is_valid_object(candidate)
                and get_class_full_name(candidate)
                    == MOD_ACTOR_CLASS_FULL_NAME
                and is_same_object(get_world(candidate), session_world) then
                return candidate, nil
            end
        end
        return nil, "exact same-World SBB ModActor is unavailable"
    end

    local function write(value, property_name, property_value)
        local ok, result = pcall(
            write_property, value, property_name, property_value
        )
        return ok and result ~= false
    end

    local function clear_terrain_snap_state(session)
        local ok = write(session, "SBB_TerrainSnapAvailable", false)
        ok = write(session, "SBB_TerrainSnapActive", false) and ok
        ok = write(session, "SBB_TerrainSnapRangeCm", 0) and ok
        return ok
    end

    local reference_properties = {
        builder = "SBB_PlacementBuilder",
        checker = "SBB_PlacementChecker",
        anchor = "SBB_PlacementAnchor",
        building_model = "SBB_PlacementBuildingModel",
        input_controller = "SBB_PlacementInputController",
        hud = "SBB_PlacementHUD",
    }

    local function reset_active_scalars()
        controller.active_session_id = nil
        controller.active_generation = nil
        controller.active_world_generation = nil
        controller.active_session_address = nil
    end

    local function clear_session_references(session)
        for _, property_name in pairs(reference_properties) do
            write(session, property_name, nil)
        end
    end

    local function set_actor_tick_enabled(session, enabled)
        local ok, error_value = pcall(function()
            session:SetActorTickEnabled(enabled == true)
        end)
        if not ok then return false, tostring(error_value) end
        return true, nil
    end

    local function is_current_session(session)
        session = unwrap(session)
        if not is_valid_object(session) then return false end
        local address = safe_object_address(session)
        if address == nil
            or address ~= controller.active_session_address
            or controller.active_world_generation ~= get_world_generation()
            or read_property(session, "SBB_PlacementActive") ~= true
            or tonumber(read_property(
                session, "SBB_PlacementSessionId"
            )) ~= controller.active_session_id
            or tonumber(read_property(
                session, "SBB_PlacementGeneration"
            )) ~= controller.active_generation then
            return false
        end
        return true
    end

    local function ensure_tick_hook()
        if controller.tick_hook_ready then return true, nil end
        local callback = function(context)
            local session = unwrap(context)
            if not is_current_session(session) then
                controller.stale_tick_count =
                    controller.stale_tick_count + 1
                return
            end
            if read_property(session, "SBB_PlacementTickPaused") == true then
                controller.paused_tick_count =
                    controller.paused_tick_count + 1
                return
            end
            controller.tick_count = controller.tick_count + 1
            local ok, error_value = pcall(on_tick, session)
            if not ok then
                controller.tick_error_count =
                    controller.tick_error_count + 1
                log("blueprint placement session Tick isolated error="
                    .. tostring(error_value))
            end
        end
        local hook_ok, pre_id, post_id = pcall(
            register_hook, TICK_FUNCTION_PATH, callback
        )
        if not hook_ok then return false, tostring(pre_id) end
        controller.tick_hook_callback = callback
        controller.tick_hook_ready = true
        log("blueprint placement session Tick hook registered pre="
            .. tostring(pre_id) .. " post=" .. tostring(post_id))
        return true, nil
    end

    function controller.begin(session, context)
        session = unwrap(session)
        context = type(context) == "table" and context or {}
        if not is_valid_object(session)
            or get_class_full_name(session) ~= SESSION_CLASS_FULL_NAME then
            return false, "placement session class mismatch"
        end

        local owner, owner_error = find_owner(session)
        if not is_valid_object(owner) then
            return false, owner_error
        end

        controller.session_sequence = controller.session_sequence + 1
        controller.generation_sequence =
            controller.generation_sequence + 1
        local session_id = controller.session_sequence
        local generation = controller.generation_sequence
        local tick_paused = context.tick_paused == true
        local hook_ready, hook_error = ensure_tick_hook()
        if not hook_ready then
            return false, "placement session Tick hook failed: "
                .. tostring(hook_error)
        end

        local writes_ok =
            write(session, "SBB_PlacementSessionId", session_id)
            and write(
                session, "SBB_PlacementGeneration", generation
            )
            and write(session, "SBB_PlacementActive", true)
            and write(
                session,
                "SBB_PlacementAuthoritative",
                true
            )
            and write(
                session, "SBB_PlacementShadowMode", false
            )
            and write(
                session, "SBB_PlacementTickPaused", tick_paused
            )
            and write(
                session, "SBB_PlacementCameraActive", false
            )
            and write(session, "SBB_PlacementCamera", nil)
            and clear_terrain_snap_state(session)
        for context_name, property_name in pairs(reference_properties) do
            writes_ok = write(
                session, property_name, unwrap(context[context_name])
            ) and writes_ok
        end
        writes_ok = write(owner, OWNER_PROPERTY, session) and writes_ok
        if not writes_ok then
            write(owner, OWNER_PROPERTY, nil)
            write(session, "SBB_PlacementActive", false)
            write(session, "SBB_PlacementAuthoritative", false)
            write(session, "SBB_PlacementSessionId", 0)
            write(session, "SBB_PlacementGeneration", 0)
            write(session, "SBB_PlacementShadowMode", true)
            clear_session_references(session)
            return false, "placement session property write failed"
        end

        controller.active_session_id = session_id
        controller.active_generation = generation
        controller.active_world_generation = get_world_generation()
        controller.active_session_address = safe_object_address(session)
        if controller.active_session_address == nil then
            write(owner, OWNER_PROPERTY, nil)
            write(session, "SBB_PlacementActive", false)
            write(session, "SBB_PlacementAuthoritative", false)
            write(session, "SBB_PlacementSessionId", 0)
            write(session, "SBB_PlacementGeneration", 0)
            write(session, "SBB_PlacementShadowMode", true)
            write(session, "SBB_PlacementTickPaused", false)
            clear_session_references(session)
            reset_active_scalars()
            return false, "placement session address is unavailable"
        end
        local tick_enabled, tick_error =
            set_actor_tick_enabled(session, true)
        if not tick_enabled then
            write(owner, OWNER_PROPERTY, nil)
            write(session, "SBB_PlacementActive", false)
            write(session, "SBB_PlacementAuthoritative", false)
            write(session, "SBB_PlacementSessionId", 0)
            write(session, "SBB_PlacementGeneration", 0)
            write(session, "SBB_PlacementShadowMode", true)
            write(session, "SBB_PlacementTickPaused", false)
            clear_session_references(session)
            reset_active_scalars()
            return false, "placement session Tick enable failed: "
                .. tostring(tick_error)
        end
        controller.begin_count = controller.begin_count + 1
        log("blueprint placement runtime session began id="
            .. tostring(session_id) .. " generation="
            .. tostring(generation))
        return true, session_id
    end

    function controller.finish(session, reason)
        session = unwrap(session)
        if not is_valid_object(session)
            or get_class_full_name(session) ~= SESSION_CLASS_FULL_NAME then
            return false, "placement session is unavailable"
        end

        local session_id = tonumber(
            read_property(session, "SBB_PlacementSessionId")
        )
        if read_property(
            session, "SBB_PlacementAuthoritative"
        ) == true then
            set_actor_tick_enabled(session, false)
        end
        local owner = find_owner(session)
        if is_valid_object(owner) then
            local owned_session = unwrap(
                read_property(owner, OWNER_PROPERTY)
            )
            if is_same_object(owned_session, session) then
                write(owner, OWNER_PROPERTY, nil)
            end
        end

        write(session, "SBB_PlacementActive", false)
        write(session, "SBB_PlacementAuthoritative", false)
        -- A destroyed Actor can remain readable in the UObject array until
        -- GC. Clear its scalar identity so native consumers can distinguish
        -- that tombstone from a newly spawned current Placement Session.
        write(session, "SBB_PlacementSessionId", 0)
        write(session, "SBB_PlacementGeneration", 0)
        write(session, "SBB_PlacementShadowMode", true)
        write(session, "SBB_PlacementTickPaused", false)
        write(session, "SBB_PlacementCameraActive", false)
        write(session, "SBB_PlacementCamera", nil)
        clear_terrain_snap_state(session)
        clear_session_references(session)

        if session_id ~= nil
            and session_id == controller.active_session_id then
            reset_active_scalars()
        end
        controller.end_count = controller.end_count + 1
        log("blueprint placement runtime session ended id="
            .. tostring(session_id) .. " reason=" .. tostring(reason))
        return true, nil
    end

    function controller.abandon_world(reason)
        -- The session and its owner belong to the World being destroyed.
        -- Releasing scalar diagnostics is the only legal Lua action here.
        reset_active_scalars()
        controller.abandon_count = controller.abandon_count + 1
        log("blueprint placement runtime session abandoned reason="
            .. tostring(reason))
        return true
    end

    function controller.is_ue_authoritative()
        return true
    end

    function controller.is_current_session(session)
        return is_current_session(session)
    end

    function controller.set_tick_paused(session, paused)
        session = unwrap(session)
        if not is_current_session(session) then
            return false, "placement session is not current"
        end
        if not write(
            session, "SBB_PlacementTickPaused", paused == true
        ) then
            return false, "placement session pause write failed"
        end
        return true, nil
    end

    function controller.update_reference(session, reference_name, value)
        session = unwrap(session)
        local property_name = reference_properties[reference_name]
        if property_name == nil then
            return false, "unknown placement session reference"
        end
        if not is_current_session(session) then
            return false, "placement session is not current"
        end
        if not write(session, property_name, unwrap(value)) then
            return false, "placement session reference write failed"
        end
        return true, nil
    end

    function controller.get_diagnostics()
        return {
            production_backend = UE_SESSION_BACKEND,
            session_sequence = controller.session_sequence,
            generation_sequence = controller.generation_sequence,
            active_session_id = controller.active_session_id,
            active_generation = controller.active_generation,
            active_world_generation =
                controller.active_world_generation,
            active_session_address = controller.active_session_address,
            begin_count = controller.begin_count,
            end_count = controller.end_count,
            abandon_count = controller.abandon_count,
            tick_hook_ready = controller.tick_hook_ready,
            tick_count = controller.tick_count,
            paused_tick_count = controller.paused_tick_count,
            stale_tick_count = controller.stale_tick_count,
            tick_error_count = controller.tick_error_count,
        }
    end

    return controller
end

return BlueprintPlacementRuntimeBackend

-- Versioned clipboard transport for compact schema-9 blueprint JSON.
--
-- Text format:
--   PWB9D.<Base64URL(VarUInt(JsonSize) | CRC32 | RawFixedDeflate)>
--
-- The schema JSON remains the authoritative payload.  This layer is lossless
-- and only makes the clipboard representation shorter and corruption-aware.

local Deflate = require("BlueprintDeflate")

local Transport = {}

Transport.PREFIX = "PWB9D."
Transport.MAX_JSON_BYTES = 8 * 1024 * 1024
Transport.MAX_CODE_CHARS = 16 * 1024 * 1024

local BASE64_ALPHABET =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
local BASE64_DECODE = {}
for index = 1, #BASE64_ALPHABET do
    BASE64_DECODE[string.byte(BASE64_ALPHABET, index)] = index - 1
end

local function crc32(data)
    local crc = 0xFFFFFFFF
    for index = 1, #data do
        crc = crc ~ string.byte(data, index)
        for _ = 1, 8 do
            if (crc & 1) ~= 0 then
                crc = (crc >> 1) ~ 0xEDB88320
            else
                crc = crc >> 1
            end
        end
    end
    return (~crc) & 0xFFFFFFFF
end

local function pack_u32_le(value)
    return string.char(
        value & 0xFF,
        (value >> 8) & 0xFF,
        (value >> 16) & 0xFF,
        (value >> 24) & 0xFF
    )
end

local function unpack_u32_le(data, offset)
    if offset + 3 > #data then return nil, offset, "truncated CRC32" end
    local a, b, c, d = string.byte(data, offset, offset + 3)
    return a | (b << 8) | (c << 16) | (d << 24), offset + 4, nil
end

local function pack_varuint(value)
    local output = {}
    repeat
        local byte = value & 0x7F
        value = value >> 7
        if value ~= 0 then byte = byte | 0x80 end
        output[#output + 1] = string.char(byte)
    until value == 0
    return table.concat(output)
end

local function unpack_varuint(data, offset)
    local value = 0
    local shift = 0
    for _ = 1, 5 do
        local byte = string.byte(data, offset)
        if byte == nil then return nil, offset, "truncated JSON size" end
        offset = offset + 1
        value = value | ((byte & 0x7F) << shift)
        if (byte & 0x80) == 0 then return value, offset, nil end
        shift = shift + 7
    end
    return nil, offset, "JSON size VarUInt is too long"
end

local function base64url_encode(data)
    local output = {}
    local position = 1
    while position <= #data do
        local a = string.byte(data, position)
        local b = string.byte(data, position + 1)
        local c = string.byte(data, position + 2)
        local combined = (a << 16) | ((b or 0) << 8) | (c or 0)
        output[#output + 1] = string.sub(
            BASE64_ALPHABET, ((combined >> 18) & 0x3F) + 1,
            ((combined >> 18) & 0x3F) + 1
        )
        output[#output + 1] = string.sub(
            BASE64_ALPHABET, ((combined >> 12) & 0x3F) + 1,
            ((combined >> 12) & 0x3F) + 1
        )
        if b ~= nil then
            output[#output + 1] = string.sub(
                BASE64_ALPHABET, ((combined >> 6) & 0x3F) + 1,
                ((combined >> 6) & 0x3F) + 1
            )
        end
        if c ~= nil then
            output[#output + 1] = string.sub(
                BASE64_ALPHABET, (combined & 0x3F) + 1,
                (combined & 0x3F) + 1
            )
        end
        position = position + 3
    end
    return table.concat(output)
end

local function base64url_decode(text)
    if #text == 0 then return nil, "empty Base64URL payload" end
    if #text % 4 == 1 then return nil, "invalid Base64URL length" end
    local output = {}
    local position = 1
    while position <= #text do
        local remaining = #text - position + 1
        if remaining < 2 then return nil, "truncated Base64URL quartet" end
        local a = BASE64_DECODE[string.byte(text, position)]
        local b = BASE64_DECODE[string.byte(text, position + 1)]
        local c = remaining >= 3
            and BASE64_DECODE[string.byte(text, position + 2)] or nil
        local d = remaining >= 4
            and BASE64_DECODE[string.byte(text, position + 3)] or nil
        if a == nil or b == nil
            or (remaining >= 3 and c == nil)
            or (remaining >= 4 and d == nil) then
            return nil, "invalid Base64URL character"
        end
        local combined = (a << 18) | (b << 12)
            | ((c or 0) << 6) | (d or 0)
        output[#output + 1] = string.char((combined >> 16) & 0xFF)
        if remaining >= 3 then
            output[#output + 1] = string.char((combined >> 8) & 0xFF)
        end
        if remaining >= 4 then
            output[#output + 1] = string.char(combined & 0xFF)
        end
        position = position + 4
    end
    return table.concat(output), nil
end

local function trim(text)
    return string.match(text, "^%s*(.-)%s*$")
end

function Transport.is_code(text)
    return type(text) == "string"
        and string.sub(trim(text), 1, #Transport.PREFIX) == Transport.PREFIX
end

function Transport.encode_json(json)
    if type(json) ~= "string" then return nil, "JSON payload must be a string" end
    if #json <= 0 or #json > Transport.MAX_JSON_BYTES then
        return nil, "JSON payload size is outside the safety limit"
    end
    local compressed, compression_error = Deflate.compress(json)
    if compressed == nil then
        return nil, "DEFLATE compression failed: " .. tostring(compression_error)
    end
    local checksum = crc32(json)
    local frame = pack_varuint(#json) .. pack_u32_le(checksum) .. compressed
    local code = Transport.PREFIX .. base64url_encode(frame)
    if #code > Transport.MAX_CODE_CHARS then
        return nil, "blueprint code exceeds the safety limit"
    end
    return code, {
        transport = "pwb9d-fixed-deflate",
        json_bytes = #json,
        compressed_bytes = #compressed,
        frame_bytes = #frame,
        code_chars = #code,
        crc32 = checksum,
    }
end

function Transport.decode_code(text)
    if type(text) ~= "string" then return nil, "blueprint code must be a string" end
    text = trim(text)
    if #text > Transport.MAX_CODE_CHARS then
        return nil, "blueprint code exceeds the safety limit"
    end
    if string.sub(text, 1, #Transport.PREFIX) ~= Transport.PREFIX then
        return nil, "clipboard does not contain a PWB9D blueprint code"
    end
    local frame, base64_error = base64url_decode(
        string.sub(text, #Transport.PREFIX + 1)
    )
    if frame == nil then return nil, base64_error end

    local json_size, offset, size_error = unpack_varuint(frame, 1)
    if json_size == nil then return nil, size_error end
    if json_size <= 0 or json_size > Transport.MAX_JSON_BYTES then
        return nil, "declared JSON size is outside the safety limit"
    end
    local expected_crc
    expected_crc, offset, size_error = unpack_u32_le(frame, offset)
    if expected_crc == nil then return nil, size_error end
    local compressed = string.sub(frame, offset)
    if #compressed == 0 then return nil, "compressed payload is empty" end

    local json, decompression_error = Deflate.decompress(compressed, json_size)
    if json == nil then
        return nil, "DEFLATE decompression failed: " .. tostring(decompression_error)
    end
    local actual_crc = crc32(json)
    if actual_crc ~= expected_crc then return nil, "blueprint CRC32 mismatch" end
    return json, {
        transport = "pwb9d-fixed-deflate",
        json_bytes = #json,
        compressed_bytes = #compressed,
        frame_bytes = #frame,
        code_chars = #text,
        crc32 = actual_crc,
    }
end

return Transport

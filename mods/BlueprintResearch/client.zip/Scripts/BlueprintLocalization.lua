local BlueprintLocalization = {}

local DEFAULT_LOCALE = "en"
local INTERNATIONALIZATION_LIBRARY_PATH =
    "/Script/Engine.Default__KismetInternationalizationLibrary"

local EN = {
    ["ui.library.title"] = "Blueprint Library",
    ["ui.library.code_hint"] = "Paste a PWB9D blueprint code here",
    ["ui.library.paste"] = "Paste",
    ["ui.library.import"] = "Import",
    ["ui.library.rename"] = "Rename",
    ["ui.library.export"] = "Export",
    ["ui.library.delete"] = "Delete",
    ["ui.library.delete_confirm"] = "Delete blueprint \"%s\"? This cannot be undone.",
    ["ui.library.empty"] = "No local blueprints",
    ["ui.library.status"] = "%d blueprints",
    ["ui.library.imported_name"] = "Imported Blueprint %d",
    ["ui.library.import_name_heading"] = "Name Imported Blueprint",
    ["ui.library.rename_heading"] = "Rename Blueprint",
    ["ui.library.thumbnail_pending"] = "Generating thumbnail...",
    ["ui.library.thumbnail_failed"] = "No thumbnail",
    ["ui.library.import_invalid_reason"] =
        "the blueprint code is invalid, damaged, or from an unsupported version",
    ["ui.library.import_invalid_status"] =
        "Import failed: invalid, damaged, or unsupported blueprint code",
    ["ui.library.import_runtime_reason"] =
        "the required building data could not be restored or the local record could not be saved",
    ["ui.library.import_runtime_status"] =
        "Import failed: required building data could not be restored",
    ["message.library.open_failed"] = { "Could not open the blueprint library: %s", "warning" },
    ["message.library.clipboard_read_failed"] = { "Could not read a blueprint code from the clipboard: %s", "warning" },
    ["message.library.import_failed"] = { "Could not import the blueprint: %s", "warning" },
    ["message.library.import_success"] = { "Blueprint imported: %s", "info" },
    ["message.library.import_name_failed"] = { "Could not open blueprint naming: %s", "warning" },
    ["message.library.rename_failed"] = { "Could not rename the blueprint: %s", "warning" },
    ["message.library.rename_success"] = { "Blueprint renamed: %s", "info" },
    ["message.library.load_failed"] = { "Could not load the selected blueprint: %s", "warning" },
    ["message.library.export_failed"] = { "Could not copy the blueprint code: %s", "warning" },
    ["message.library.export_success"] = { "Blueprint code copied: %s", "info" },
    ["message.library.delete_confirm_failed"] = { "Could not open the delete confirmation: %s", "warning" },
    ["message.library.delete_failed"] = { "Could not delete the blueprint: %s", "warning" },
    ["message.library.delete_success"] = { "Blueprint deleted: %s", "info" },
    ["ui.button.create"] = "Create Blueprint",
    ["ui.button.place"] = "Place Blueprint",
    ["ui.guide.select"] = "Select / Deselect",
    ["ui.guide.region"] = "Set Selection Corner",
    ["ui.guide.anchor"] = "Set Blueprint Anchor",
    ["ui.guide.camera"] = "Free Camera",
    ["ui.guide.world_snap"] = "Original Position Snap",
    ["ui.guide.exit"] = "Exit Blueprint Mode",
    ["ui.guide.save"] = "Save Blueprint",
    ["ui.library.name_heading"] = "Name Blueprint",
    ["ui.library.default_name"] = "Blueprint %d",
    ["ui.library.fallback_name"] = "Blueprint",

    ["message.region.complete"] = { "Blueprint area selection complete: %d added, %d selected.", "info" },
    ["message.region.failed_job"] = { "Blueprint area selection failed. See the UE4SS log.", "warning" },
    ["message.region.busy"] = { "Blueprint area selection is still running. Please wait.", "warning" },
    ["message.region.no_target"] = { "Blueprint area selection failed: aim at a selectable building.", "warning" },
    ["message.region.start_set"] = { "Blueprint area selection start set (%s).", "info" },
    ["message.region.start_cancelled"] = { "Blueprint area selection start cleared (%s).", "info" },
    ["message.region.started"] = { "Blueprint area selection started. Buildings will be selected in batches.", "info" },
    ["message.region.failed"] = { "Blueprint area selection could not be completed. See the UE4SS log.", "warning" },

    ["message.save.region_busy"] = { "Cannot save the blueprint while area selection is running.", "warning" },
    ["message.save.no_selection"] = { "Cannot save the blueprint: no buildings are selected.", "warning" },
    ["message.save.no_anchor"] = { "Cannot save the blueprint: set an anchor from the selected buildings first.", "warning" },
    ["message.save.anchor_invalid"] = { "Cannot save the blueprint: the selected anchor is no longer valid.", "warning" },
    ["message.save.math_unavailable"] = { "Cannot save the blueprint: transform utilities are unavailable.", "warning" },
    ["message.save.anchor_transform_unavailable"] = { "Cannot save the blueprint: the anchor transform could not be read.", "warning" },
    ["message.save.all_invalid"] = { "Cannot save the blueprint: all selected buildings are no longer valid.", "warning" },
    ["message.save.serialization_partial"] = { "Cannot save the blueprint: %d selected buildings could not be serialized.", "warning" },
    ["message.save.anchor_missing"] = { "Cannot save the blueprint: the anchor was not written to the blueprint.", "warning" },
    ["message.save.metadata_unavailable"] = { "Cannot save blueprint JSON: building type metadata is unavailable.", "warning" },
    ["message.save.compact_failed"] = { "Cannot save blueprint JSON: compact-format conversion failed.", "warning" },
    ["message.save.clipboard_failed"] = { "Cannot save blueprint JSON: the clipboard could not be written.", "warning" },
    ["message.save.deserialize_failed"] = { "Cannot save blueprint JSON: runtime verification failed.", "warning" },
    ["message.save.success"] = { "PWB9D blueprint saved: %d buildings, anchor %s, %d characters.", "info" },
    ["message.library.name_invalid"] = { "Invalid blueprint name: %s", "warning" },
    ["message.library.save_failed"] = { "Could not save the blueprint to the local library: %s", "warning" },

    ["message.selection.input_failed"] = { "Blueprint selection mode could not start: its input context is unavailable. See the UE4SS log.", "warning" },
    ["message.selection.hud_failed"] = { "Blueprint selection HUD failed to load. See the UE4SS log.", "warning" },
    ["message.selection.tick_failed"] = { "Blueprint selection update loop failed. See the UE4SS log.", "warning" },

    ["message.camera.base_only"] = { "Free camera is available only inside a base.", "warning" },
    ["message.camera.start_failed"] = { "Free camera could not start. Exit the current blueprint mode and try again.", "warning" },
    ["message.world_snap.enabled"] = { "Original-position snap enabled.", "info" },
    ["message.world_snap.disabled"] = { "Original-position snap disabled.", "info" },
    ["message.world_snap.unavailable"] = { "This blueprint has no saved world transform.", "warning" },
    ["message.world_snap.out_of_range"] = { "Original position is %.1f m away; allowed snap range is %.1f m.", "warning" },
    ["message.world_snap.failed"] = { "Original-position snap could not be changed. Exit blueprint placement and try again.", "warning" },

    ["message.placement.exit_pending"] = { "The current blueprint is still leaving build mode.", "warning" },
    ["message.placement.clipboard_invalid"] = { "Cannot place blueprint: the clipboard does not contain a valid PWB9D code or schema 9 JSON.", "warning" },
    ["message.placement.build_id_restore_failed"] = { "Cannot place blueprint: building IDs could not be restored to runtime types.", "warning" },
    ["message.placement.deserialize_failed"] = { "Cannot place blueprint: JSON deserialization failed.", "warning" },
    ["message.placement.empty"] = { "Cannot place blueprint: the blueprint contains no buildings.", "warning" },
    ["message.placement.incompatible"] = { "Cannot place blueprint: the version is incompatible or the anchor is missing.", "warning" },
    ["message.placement.input_failed"] = { "Blueprint placement input failed to initialize. Placement was cancelled; see the UE4SS log.", "warning" },
    ["message.placement.overlap_checker_failed"] = { "Blueprint overlap checking failed. Placement was cancelled.", "warning" },
    ["message.placement.collision_query_limit"] = {
        "Cannot preview blueprint: %d collision-query buildings / limit %d. Increase blueprint_collision_query_component_limit in BlueprintResearch.modconfig.json, then restart the game.",
        "warning"
    },
    ["message.placement.overlap"] = { "Cannot place blueprint: %d buildings overlap world objects.", "warning" },
    ["message.placement.overlap_detail"] = {
        "%d overlaps: %s vs %s.",
        "warning"
    },
    ["message.placement.overlap_primary_actor"] = {
        "%d overlaps: %s vs %s. Complex overlaps check only the primary blocker; remove existing or unfinished buildings in that area and retry.",
        "warning"
    },
    ["message.placement.checking"] = {
        "Checking blueprint placement. Please wait a moment.",
        "warning"
    },
    ["message.placement.blocker_pal"] = "Pal",
    ["message.placement.blocker_world_object"] = "world object",
    ["message.placement.water_building_locked"] = { "Cannot place blueprint on water: unlock the Water Building Set first.", "warning" },
    ["message.placement.water_capability_unavailable"] = { "Unable to verify the Water Building Set. Exit and re-enter blueprint placement, then try again.", "warning" },
    ["message.placement.anchor_invalid"] = { "Cannot place blueprint: the anchor cannot be built here.", "warning" },
    ["message.placement.material_check_failed"] = { "Blueprint material check failed. See the UE4SS log.", "warning" },
    ["message.placement.materials_insufficient"] = { "Insufficient materials for the complete blueprint: %s", "warning" },
    ["message.placement.hud_expired"] = { "The blueprint placement interface is no longer valid. Exit build mode and try again.", "warning" },
    ["message.placement.state_busy"] = { "The current build state has not ended; another blueprint cannot be placed yet.", "warning" },

    ["message.build.complete"] = { "Blueprint construction complete: %d buildings.", "info" },
    ["message.build.force_submit_started"] = { "Force-submit mode started: local overlap/support failures and server rejections will not stop this queue.", "warning" },
    ["message.build.force_submit_complete"] = { "Force-submit queue finished: %d accepted, %d rejected or timed out.", "warning" },
    ["message.build.stop_materials"] = { "Blueprint construction stopped: insufficient materials.", "warning" },
    ["message.build.stop_server_gate"] = { "Blueprint construction stopped: a building was rejected by the server.", "warning" },
    ["message.build.stop_timeout"] = { "Blueprint construction stopped: no server response was received; the target may be obstructed.", "warning" },
    ["message.build.stop_generic"] = { "Blueprint construction stopped. See the UE4SS log.", "warning" },
    ["message.build.request_error"] = { "A blueprint construction request failed. See the UE4SS log.", "warning" },
    ["message.build.request_submitted"] = { "Blueprint construction request submitted: %d buildings.", "info" },
    ["message.build.already_complete"] = { "Every building in this blueprint already exists. No repair is needed.", "info" },
    ["message.build.structure_unbuildable"] = { "This blueprint structure cannot currently be built. Adjust its position or supports and try again.", "warning" },
    ["message.build.start_failed"] = { "Blueprint construction could not start. Exit build mode, re-enter it, and try again.", "warning" },

    ["message.diagnostic.capture_failed"] = { "UI capture failed. See the UE4SS log.", "warning" },
    ["message.diagnostic.capture_complete"] = { "UI capture complete: %d root widgets, %d nodes.", "info" },
}

local ZH_HANS = {
    ["ui.library.title"] = "蓝图库",
    ["ui.library.code_hint"] = "在这里粘贴 PWB9D 蓝图码",
    ["ui.library.paste"] = "粘贴",
    ["ui.library.import"] = "导入",
    ["ui.library.rename"] = "重命名",
    ["ui.library.export"] = "导出",
    ["ui.library.delete"] = "删除",
    ["ui.library.delete_confirm"] = "确定要删除蓝图“%s”吗？此操作无法撤销。",
    ["ui.library.empty"] = "暂无本地蓝图",
    ["ui.library.status"] = "%d 个蓝图",
    ["ui.library.imported_name"] = "导入的蓝图 %d",
    ["ui.library.import_name_heading"] = "为导入的蓝图命名",
    ["ui.library.rename_heading"] = "重命名蓝图",
    ["ui.library.thumbnail_pending"] = "正在生成缩略图……",
    ["ui.library.thumbnail_failed"] = "无缩略图",
    ["ui.library.import_invalid_reason"] =
        "蓝图码无效、已损坏或版本不兼容",
    ["ui.library.import_invalid_status"] =
        "导入失败：蓝图码无效、损坏或版本不兼容",
    ["ui.library.import_runtime_reason"] =
        "无法恢复所需建筑数据，或无法保存本地蓝图记录",
    ["ui.library.import_runtime_status"] =
        "导入失败：无法恢复蓝图所需的建筑数据",
    ["message.library.open_failed"] = { "无法打开蓝图库：%s", "warning" },
    ["message.library.clipboard_read_failed"] = { "无法从剪贴板读取蓝图码：%s", "warning" },
    ["message.library.import_failed"] = { "无法导入蓝图：%s", "warning" },
    ["message.library.import_success"] = { "蓝图已导入：%s", "info" },
    ["message.library.import_name_failed"] = { "无法打开蓝图命名窗口：%s", "warning" },
    ["message.library.rename_failed"] = { "无法重命名蓝图：%s", "warning" },
    ["message.library.rename_success"] = { "蓝图已重命名：%s", "info" },
    ["message.library.load_failed"] = { "无法读取所选蓝图：%s", "warning" },
    ["message.library.export_failed"] = { "无法复制蓝图码：%s", "warning" },
    ["message.library.export_success"] = { "蓝图码已复制：%s", "info" },
    ["message.library.delete_confirm_failed"] = { "无法打开删除确认窗口：%s", "warning" },
    ["message.library.delete_failed"] = { "无法删除蓝图：%s", "warning" },
    ["message.library.delete_success"] = { "蓝图已删除：%s", "info" },
    ["ui.button.create"] = "创建蓝图",
    ["ui.button.place"] = "放置蓝图",
    ["ui.guide.select"] = "选择／取消选择",
    ["ui.guide.region"] = "设置框选角点",
    ["ui.guide.anchor"] = "设置蓝图锚点",
    ["ui.guide.camera"] = "自由相机",
    ["ui.guide.world_snap"] = "原位置吸附",
    ["ui.guide.exit"] = "退出创建模式",
    ["ui.guide.save"] = "保存蓝图",
    ["ui.library.name_heading"] = "为蓝图命名",
    ["ui.library.default_name"] = "蓝图 %d",
    ["ui.library.fallback_name"] = "蓝图",

    ["message.region.complete"] = { "蓝图框选完成：新增 %d 个，当前共 %d 个", "info" },
    ["message.region.failed_job"] = { "蓝图框选失败：分批选择任务异常，请查看 UE4SS 日志", "warning" },
    ["message.region.busy"] = { "蓝图框选仍在处理中，请等待本次框选完成", "warning" },
    ["message.region.no_target"] = { "蓝图框选失败：准心未指向可选择的建筑", "warning" },
    ["message.region.start_set"] = { "蓝图框选：已设置起点（%s）", "info" },
    ["message.region.start_cancelled"] = { "蓝图框选：已取消起点（%s）", "info" },
    ["message.region.started"] = { "蓝图框选已开始，建筑将分批进入选中状态", "info" },
    ["message.region.failed"] = { "蓝图框选失败：无法完成区域选择，请查看 UE4SS 日志", "warning" },

    ["message.save.region_busy"] = { "蓝图保存暂不可用：区域框选仍在处理中", "warning" },
    ["message.save.no_selection"] = { "蓝图保存失败：当前没有已选择的建筑", "warning" },
    ["message.save.no_anchor"] = { "蓝图保存失败：请先从已选建筑中设置锚点", "warning" },
    ["message.save.anchor_invalid"] = { "蓝图保存失败：已设置的锚点已经失效", "warning" },
    ["message.save.math_unavailable"] = { "蓝图保存失败：变换计算组件不可用", "warning" },
    ["message.save.anchor_transform_unavailable"] = { "蓝图保存失败：无法读取锚点变换", "warning" },
    ["message.save.all_invalid"] = { "蓝图保存失败：已选建筑均已失效", "warning" },
    ["message.save.serialization_partial"] = { "蓝图保存失败：%d 个已选建筑无法序列化", "warning" },
    ["message.save.anchor_missing"] = { "蓝图保存失败：锚点未能写入蓝图", "warning" },
    ["message.save.metadata_unavailable"] = { "蓝图 JSON 保存失败：建筑类型元数据不可用", "warning" },
    ["message.save.compact_failed"] = { "蓝图 JSON 保存失败：紧凑格式转换失败", "warning" },
    ["message.save.clipboard_failed"] = { "蓝图 JSON 保存失败：无法写入剪贴板", "warning" },
    ["message.save.deserialize_failed"] = { "蓝图 JSON 保存失败：运行时反序列化失败", "warning" },
    ["message.save.success"] = { "蓝图 PWB9D 已保存：%d 个建筑，锚点 %s，蓝图码 %d 字符", "info" },
    ["message.library.name_invalid"] = { "蓝图名称无效：%s", "warning" },
    ["message.library.save_failed"] = { "无法将蓝图保存到本地蓝图库：%s", "warning" },

    ["message.selection.input_failed"] = { "蓝图选择模式启动失败：专用输入上下文不可用，请查看 UE4SS 日志", "warning" },
    ["message.selection.hud_failed"] = { "蓝图选择界面加载失败，请查看 UE4SS 日志", "warning" },
    ["message.selection.tick_failed"] = { "蓝图选择更新循环启动失败，请查看 UE4SS 日志", "warning" },

    ["message.camera.base_only"] = { "自由观察相机只能在基地范围内使用", "warning" },
    ["message.camera.start_failed"] = { "自由观察相机启动失败，请退出当前蓝图模式后重试", "warning" },
    ["message.world_snap.enabled"] = { "已开启原世界坐标吸附", "info" },
    ["message.world_snap.disabled"] = { "已关闭原世界坐标吸附", "info" },
    ["message.world_snap.unavailable"] = { "此蓝图不包含可用的原世界坐标变换", "warning" },
    ["message.world_snap.out_of_range"] = { "原位置距离当前锚点 %.1f 米，超过 %.1f 米的吸附范围", "warning" },
    ["message.world_snap.failed"] = { "原世界坐标吸附切换失败，请退出蓝图放置模式后重试", "warning" },

    ["message.placement.exit_pending"] = { "当前蓝图正在退出建造状态", "warning" },
    ["message.placement.clipboard_invalid"] = { "无法放置蓝图：剪贴板中没有有效的 PWB9D 蓝图码或 schema 9 JSON", "warning" },
    ["message.placement.build_id_restore_failed"] = { "无法放置蓝图：建筑 ID 无法还原为运行时类型", "warning" },
    ["message.placement.deserialize_failed"] = { "无法放置蓝图：JSON 反序列化失败", "warning" },
    ["message.placement.empty"] = { "无法放置蓝图：蓝图中没有建筑", "warning" },
    ["message.placement.incompatible"] = { "无法放置蓝图：蓝图版本不兼容或缺少锚点", "warning" },
    ["message.placement.input_failed"] = { "蓝图放置输入初始化失败，已取消本次放置，请查看 UE4SS 日志", "warning" },
    ["message.placement.overlap_checker_failed"] = { "蓝图重叠检测失败，已取消本次放置", "warning" },
    ["message.placement.collision_query_limit"] = {
        "蓝图碰撞查询建筑：%d / 上限 %d，无法预览。请在 BlueprintResearch.modconfig.json 中提高 blueprint_collision_query_component_limit，重启游戏后生效。",
        "warning"
    },
    ["message.placement.overlap"] = { "蓝图无法放置：%d 个建筑与世界对象重叠", "warning" },
    ["message.placement.overlap_detail"] = {
        "%d 处重叠：%s ↔ %s",
        "warning"
    },
    ["message.placement.overlap_primary_actor"] = {
        "%d 处重叠：%s ↔ %s。复杂重叠仅检查主要对象，请拆除重叠处已有或待建建筑后重试",
        "warning"
    },
    ["message.placement.checking"] = {
        "正在检查蓝图放置位置，请稍候",
        "warning"
    },
    ["message.placement.blocker_pal"] = "帕鲁",
    ["message.placement.blocker_world_object"] = "世界对象",
    ["message.placement.water_building_locked"] = { "蓝图无法在水面放置：请先解锁水上建造套组", "warning" },
    ["message.placement.water_capability_unavailable"] = { "无法确认水上建造套组状态，请退出并重新进入蓝图放置模式后重试", "warning" },
    ["message.placement.anchor_invalid"] = { "蓝图无法放置：锚点当前不可建造", "warning" },
    ["message.placement.material_check_failed"] = { "蓝图材料检查失败，请查看 UE4SS 日志", "warning" },
    ["message.placement.materials_insufficient"] = { "蓝图总体材料不足：%s", "warning" },
    ["message.placement.hud_expired"] = { "蓝图放置界面已经失效，请退出建造模式后重试", "warning" },
    ["message.placement.state_busy"] = { "当前建造状态尚未结束，无法再次放置蓝图", "warning" },

    ["message.build.complete"] = { "蓝图自动建造完成：%d 个建筑", "info" },
    ["message.build.force_submit_started"] = { "强制提交已启动：本地重叠、支撑失败及服务器拒绝不会停止当前队列", "warning" },
    ["message.build.force_submit_complete"] = { "强制提交队列结束：%d 个成功，%d 个被拒绝或超时", "warning" },
    ["message.build.stop_materials"] = { "蓝图自动建造已停止：当前材料不足，无法继续建造", "warning" },
    ["message.build.stop_server_gate"] = { "蓝图自动建造已停止：当前建筑建造无法通过服务器门禁", "warning" },
    ["message.build.stop_timeout"] = { "蓝图自动建造已停止：目标无服务端回执，可能被物体阻挡", "warning" },
    ["message.build.stop_generic"] = { "蓝图自动建造已停止，请查看 UE4SS 日志", "warning" },
    ["message.build.request_error"] = { "蓝图建造请求发生错误，请查看 UE4SS 日志", "warning" },
    ["message.build.request_submitted"] = { "蓝图建造请求已提交：%d 个建筑", "info" },
    ["message.build.already_complete"] = { "蓝图中的建筑已全部存在，无需修复", "info" },
    ["message.build.structure_unbuildable"] = { "蓝图结构当前不可建造，请调整放置位置或支撑条件后重试", "warning" },
    ["message.build.start_failed"] = { "蓝图建造无法启动，请退出建造模式并重新进入后重试", "warning" },

    ["message.diagnostic.capture_failed"] = { "UI 捕获失败，请查看 UE4SS 日志", "warning" },
    ["message.diagnostic.capture_complete"] = { "UI 捕获完成：%d 个根控件，%d 个节点", "info" },
}

local ZH_HANT = {
    ["ui.library.title"] = "藍圖庫",
    ["ui.library.code_hint"] = "在這裡貼上 PWB9D 藍圖碼",
    ["ui.library.paste"] = "貼上",
    ["ui.library.import"] = "匯入",
    ["ui.library.rename"] = "重新命名",
    ["ui.library.export"] = "匯出",
    ["ui.library.delete"] = "刪除",
    ["ui.library.delete_confirm"] = "確定要刪除藍圖「%s」嗎？此操作無法復原。",
    ["ui.library.empty"] = "暫無本機藍圖",
    ["ui.library.status"] = "%d 個藍圖",
    ["ui.library.imported_name"] = "匯入的藍圖 %d",
    ["ui.library.import_name_heading"] = "為匯入的藍圖命名",
    ["ui.library.rename_heading"] = "重新命名藍圖",
    ["ui.library.thumbnail_pending"] = "正在產生縮圖……",
    ["ui.library.thumbnail_failed"] = "無縮圖",
    ["ui.library.import_invalid_reason"] =
        "藍圖碼無效、已損壞或版本不相容",
    ["ui.library.import_invalid_status"] =
        "匯入失敗：藍圖碼無效、損壞或版本不相容",
    ["ui.library.import_runtime_reason"] =
        "無法還原所需建築資料，或無法儲存本機藍圖記錄",
    ["ui.library.import_runtime_status"] =
        "匯入失敗：無法還原藍圖所需的建築資料",
    ["message.library.open_failed"] = { "無法開啟藍圖庫：%s", "warning" },
    ["message.library.clipboard_read_failed"] = { "無法從剪貼簿讀取藍圖碼：%s", "warning" },
    ["message.library.import_failed"] = { "無法匯入藍圖：%s", "warning" },
    ["message.library.import_success"] = { "藍圖已匯入：%s", "info" },
    ["message.library.import_name_failed"] = { "無法開啟藍圖命名視窗：%s", "warning" },
    ["message.library.rename_failed"] = { "無法重新命名藍圖：%s", "warning" },
    ["message.library.rename_success"] = { "藍圖已重新命名：%s", "info" },
    ["message.library.load_failed"] = { "無法讀取所選藍圖：%s", "warning" },
    ["message.library.export_failed"] = { "無法複製藍圖碼：%s", "warning" },
    ["message.library.export_success"] = { "藍圖碼已複製：%s", "info" },
    ["message.library.delete_confirm_failed"] = { "無法開啟刪除確認視窗：%s", "warning" },
    ["message.library.delete_failed"] = { "無法刪除藍圖：%s", "warning" },
    ["message.library.delete_success"] = { "藍圖已刪除：%s", "info" },
    ["ui.button.create"] = "建立藍圖",
    ["ui.button.place"] = "放置藍圖",
    ["ui.guide.select"] = "選擇／取消選擇",
    ["ui.guide.region"] = "設定框選角點",
    ["ui.guide.anchor"] = "設定藍圖錨點",
    ["ui.guide.camera"] = "自由相機",
    ["ui.guide.world_snap"] = "原位置吸附",
    ["ui.guide.exit"] = "退出建立模式",
    ["ui.guide.save"] = "儲存藍圖",
    ["ui.library.name_heading"] = "為藍圖命名",
    ["ui.library.default_name"] = "藍圖 %d",
    ["ui.library.fallback_name"] = "藍圖",

    ["message.region.complete"] = { "藍圖框選完成：新增 %d 個，目前共 %d 個", "info" },
    ["message.region.failed_job"] = { "藍圖框選失敗：分批選擇工作異常，請查看 UE4SS 日誌", "warning" },
    ["message.region.busy"] = { "藍圖框選仍在處理中，請等待本次框選完成", "warning" },
    ["message.region.no_target"] = { "藍圖框選失敗：準心未指向可選擇的建築", "warning" },
    ["message.region.start_set"] = { "藍圖框選：已設定起點（%s）", "info" },
    ["message.region.start_cancelled"] = { "藍圖框選：已取消起點（%s）", "info" },
    ["message.region.started"] = { "藍圖框選已開始，建築將分批進入選取狀態", "info" },
    ["message.region.failed"] = { "藍圖框選失敗：無法完成區域選擇，請查看 UE4SS 日誌", "warning" },

    ["message.save.region_busy"] = { "藍圖儲存暫不可用：區域框選仍在處理中", "warning" },
    ["message.save.no_selection"] = { "藍圖儲存失敗：目前沒有已選擇的建築", "warning" },
    ["message.save.no_anchor"] = { "藍圖儲存失敗：請先從已選建築中設定錨點", "warning" },
    ["message.save.anchor_invalid"] = { "藍圖儲存失敗：已設定的錨點已經失效", "warning" },
    ["message.save.math_unavailable"] = { "藍圖儲存失敗：變換計算元件不可用", "warning" },
    ["message.save.anchor_transform_unavailable"] = { "藍圖儲存失敗：無法讀取錨點變換", "warning" },
    ["message.save.all_invalid"] = { "藍圖儲存失敗：已選建築均已失效", "warning" },
    ["message.save.serialization_partial"] = { "藍圖儲存失敗：%d 個已選建築無法序列化", "warning" },
    ["message.save.anchor_missing"] = { "藍圖儲存失敗：錨點未能寫入藍圖", "warning" },
    ["message.save.metadata_unavailable"] = { "藍圖 JSON 儲存失敗：建築類型中繼資料不可用", "warning" },
    ["message.save.compact_failed"] = { "藍圖 JSON 儲存失敗：緊湊格式轉換失敗", "warning" },
    ["message.save.clipboard_failed"] = { "藍圖 JSON 儲存失敗：無法寫入剪貼簿", "warning" },
    ["message.save.deserialize_failed"] = { "藍圖 JSON 儲存失敗：執行階段反序列化失敗", "warning" },
    ["message.save.success"] = { "藍圖 PWB9D 已儲存：%d 個建築，錨點 %s，藍圖碼 %d 個字元", "info" },
    ["message.library.name_invalid"] = { "藍圖名稱無效：%s", "warning" },
    ["message.library.save_failed"] = { "無法將藍圖儲存到本機藍圖庫：%s", "warning" },

    ["message.selection.input_failed"] = { "藍圖選擇模式啟動失敗：專用輸入內容不可用，請查看 UE4SS 日誌", "warning" },
    ["message.selection.hud_failed"] = { "藍圖選擇介面載入失敗，請查看 UE4SS 日誌", "warning" },
    ["message.selection.tick_failed"] = { "藍圖選擇更新循環啟動失敗，請查看 UE4SS 日誌", "warning" },

    ["message.camera.base_only"] = { "自由觀察相機只能在基地範圍內使用", "warning" },
    ["message.camera.start_failed"] = { "自由觀察相機啟動失敗，請退出目前藍圖模式後重試", "warning" },
    ["message.world_snap.enabled"] = { "已開啟原世界座標吸附", "info" },
    ["message.world_snap.disabled"] = { "已關閉原世界座標吸附", "info" },
    ["message.world_snap.unavailable"] = { "此藍圖不包含可用的原世界座標變換", "warning" },
    ["message.world_snap.out_of_range"] = { "原位置距離目前錨點 %.1f 公尺，超過 %.1f 公尺的吸附範圍", "warning" },
    ["message.world_snap.failed"] = { "原世界座標吸附切換失敗，請退出藍圖放置模式後重試", "warning" },

    ["message.placement.exit_pending"] = { "目前藍圖正在退出建造狀態", "warning" },
    ["message.placement.clipboard_invalid"] = { "無法放置藍圖：剪貼簿中沒有有效的 PWB9D 藍圖碼或 schema 9 JSON", "warning" },
    ["message.placement.build_id_restore_failed"] = { "無法放置藍圖：建築 ID 無法還原為執行階段類型", "warning" },
    ["message.placement.deserialize_failed"] = { "無法放置藍圖：JSON 反序列化失敗", "warning" },
    ["message.placement.empty"] = { "無法放置藍圖：藍圖中沒有建築", "warning" },
    ["message.placement.incompatible"] = { "無法放置藍圖：藍圖版本不相容或缺少錨點", "warning" },
    ["message.placement.input_failed"] = { "藍圖放置輸入初始化失敗，已取消本次放置，請查看 UE4SS 日誌", "warning" },
    ["message.placement.overlap_checker_failed"] = { "藍圖重疊檢測失敗，已取消本次放置", "warning" },
    ["message.placement.collision_query_limit"] = {
        "藍圖碰撞查詢建築：%d / 上限 %d，無法預覽。請在 BlueprintResearch.modconfig.json 中提高 blueprint_collision_query_component_limit，重新啟動遊戲後生效。",
        "warning"
    },
    ["message.placement.overlap"] = { "藍圖無法放置：%d 個建築與世界物件重疊", "warning" },
    ["message.placement.overlap_detail"] = {
        "%d 處重疊：%s ↔ %s",
        "warning"
    },
    ["message.placement.overlap_primary_actor"] = {
        "%d 處重疊：%s ↔ %s。複雜重疊僅檢查主要物件，請拆除重疊處已有或待建建築後重試",
        "warning"
    },
    ["message.placement.checking"] = {
        "正在檢查藍圖放置位置，請稍候",
        "warning"
    },
    ["message.placement.blocker_pal"] = "帕魯",
    ["message.placement.blocker_world_object"] = "世界物件",
    ["message.placement.water_building_locked"] = { "藍圖無法在水面放置：請先解鎖水上建造套組", "warning" },
    ["message.placement.water_capability_unavailable"] = { "無法確認水上建造套組狀態，請退出並重新進入藍圖放置模式後重試", "warning" },
    ["message.placement.anchor_invalid"] = { "藍圖無法放置：錨點目前不可建造", "warning" },
    ["message.placement.material_check_failed"] = { "藍圖材料檢查失敗，請查看 UE4SS 日誌", "warning" },
    ["message.placement.materials_insufficient"] = { "藍圖總體材料不足：%s", "warning" },
    ["message.placement.hud_expired"] = { "藍圖放置介面已經失效，請退出建造模式後重試", "warning" },
    ["message.placement.state_busy"] = { "目前建造狀態尚未結束，無法再次放置藍圖", "warning" },

    ["message.build.complete"] = { "藍圖自動建造完成：%d 個建築", "info" },
    ["message.build.force_submit_started"] = { "強制提交已啟動：本地重疊、支撐失敗及伺服器拒絕不會停止目前佇列", "warning" },
    ["message.build.force_submit_complete"] = { "強制提交佇列結束：%d 個成功，%d 個被拒絕或逾時", "warning" },
    ["message.build.stop_materials"] = { "藍圖自動建造已停止：目前材料不足，無法繼續建造", "warning" },
    ["message.build.stop_server_gate"] = { "藍圖自動建造已停止：目前建築無法通過伺服器建造檢查", "warning" },
    ["message.build.stop_timeout"] = { "藍圖自動建造已停止：目標沒有伺服器回覆，可能被物體阻擋", "warning" },
    ["message.build.stop_generic"] = { "藍圖自動建造已停止，請查看 UE4SS 日誌", "warning" },
    ["message.build.request_error"] = { "藍圖建造請求發生錯誤，請查看 UE4SS 日誌", "warning" },
    ["message.build.request_submitted"] = { "藍圖建造請求已提交：%d 個建築", "info" },
    ["message.build.already_complete"] = { "藍圖中的建築已全部存在，無需修復", "info" },
    ["message.build.structure_unbuildable"] = { "藍圖結構目前無法建造，請調整放置位置或支撐條件後重試", "warning" },
    ["message.build.start_failed"] = { "藍圖建造無法啟動，請退出建造模式並重新進入後重試", "warning" },

    ["message.diagnostic.capture_failed"] = { "UI 擷取失敗，請查看 UE4SS 日誌", "warning" },
    ["message.diagnostic.capture_complete"] = { "UI 擷取完成：%d 個根控制項，%d 個節點", "info" },
}

local JA = {
    ["ui.library.title"] = "設計図ライブラリ",
    ["ui.library.code_hint"] = "PWB9D設計図コードをここに貼り付け",
    ["ui.library.paste"] = "貼り付け",
    ["ui.library.import"] = "インポート",
    ["ui.library.rename"] = "名前変更",
    ["ui.library.export"] = "エクスポート",
    ["ui.library.delete"] = "削除",
    ["ui.library.delete_confirm"] = "設計図「%s」を削除しますか？この操作は元に戻せません。",
    ["ui.library.empty"] = "ローカル設計図はありません",
    ["ui.library.status"] = "設計図：%d件",
    ["ui.library.imported_name"] = "インポートした設計図 %d",
    ["ui.library.import_name_heading"] = "インポートした設計図に名前を付ける",
    ["ui.library.rename_heading"] = "設計図の名前を変更",
    ["ui.library.thumbnail_pending"] = "サムネイルを生成中……",
    ["ui.library.thumbnail_failed"] = "サムネイルなし",
    ["ui.library.import_invalid_reason"] =
        "設計図コードが無効、破損、または未対応のバージョンです",
    ["ui.library.import_invalid_status"] =
        "インポート失敗：無効、破損、または未対応の設計図コード",
    ["ui.library.import_runtime_reason"] =
        "必要な建築データを復元できないか、ローカル記録を保存できませんでした",
    ["ui.library.import_runtime_status"] =
        "インポート失敗：必要な建築データを復元できませんでした",
    ["message.library.open_failed"] = { "設計図ライブラリを開けませんでした：%s", "warning" },
    ["message.library.clipboard_read_failed"] = { "クリップボードから設計図コードを読み取れませんでした：%s", "warning" },
    ["message.library.import_failed"] = { "設計図をインポートできませんでした：%s", "warning" },
    ["message.library.import_success"] = { "設計図をインポートしました：%s", "info" },
    ["message.library.import_name_failed"] = { "設計図の命名画面を開けませんでした：%s", "warning" },
    ["message.library.rename_failed"] = { "設計図の名前を変更できませんでした：%s", "warning" },
    ["message.library.rename_success"] = { "設計図の名前を変更しました：%s", "info" },
    ["message.library.load_failed"] = { "選択した設計図を読み込めませんでした：%s", "warning" },
    ["message.library.export_failed"] = { "設計図コードをコピーできませんでした：%s", "warning" },
    ["message.library.export_success"] = { "設計図コードをコピーしました：%s", "info" },
    ["message.library.delete_confirm_failed"] = { "削除確認を開けませんでした：%s", "warning" },
    ["message.library.delete_failed"] = { "設計図を削除できませんでした：%s", "warning" },
    ["message.library.delete_success"] = { "設計図を削除しました：%s", "info" },
    ["ui.button.create"] = "設計図を作成",
    ["ui.button.place"] = "設計図を配置",
    ["ui.guide.select"] = "選択／選択解除",
    ["ui.guide.region"] = "範囲選択の角を設定",
    ["ui.guide.anchor"] = "設計図のアンカーを設定",
    ["ui.guide.camera"] = "フリーカメラ",
    ["ui.guide.world_snap"] = "元の位置にスナップ",
    ["ui.guide.exit"] = "設計図モードを終了",
    ["ui.guide.save"] = "設計図を保存",
    ["ui.library.name_heading"] = "設計図に名前を付ける",
    ["ui.library.default_name"] = "設計図 %d",
    ["ui.library.fallback_name"] = "設計図",

    ["message.region.complete"] = { "設計図の範囲選択が完了しました：%d件追加、選択中%d件。", "info" },
    ["message.region.failed_job"] = { "設計図の範囲選択に失敗しました。UE4SSログを確認してください。", "warning" },
    ["message.region.busy"] = { "設計図の範囲選択を処理中です。しばらくお待ちください。", "warning" },
    ["message.region.no_target"] = { "設計図の範囲選択に失敗しました。選択可能な建築物に照準を合わせてください。", "warning" },
    ["message.region.start_set"] = { "設計図の範囲選択開始点を設定しました（%s）。", "info" },
    ["message.region.start_cancelled"] = { "設計図の範囲選択開始点を解除しました（%s）。", "info" },
    ["message.region.started"] = { "設計図の範囲選択を開始しました。建築物は分割して選択されます。", "info" },
    ["message.region.failed"] = { "設計図の範囲選択を完了できませんでした。UE4SSログを確認してください。", "warning" },

    ["message.save.region_busy"] = { "範囲選択の処理中は設計図を保存できません。", "warning" },
    ["message.save.no_selection"] = { "設計図を保存できません。建築物が選択されていません。", "warning" },
    ["message.save.no_anchor"] = { "設計図を保存できません。選択した建築物からアンカーを設定してください。", "warning" },
    ["message.save.anchor_invalid"] = { "設計図を保存できません。選択したアンカーは無効になっています。", "warning" },
    ["message.save.math_unavailable"] = { "設計図を保存できません。トランスフォーム処理を利用できません。", "warning" },
    ["message.save.anchor_transform_unavailable"] = { "設計図を保存できません。アンカーのトランスフォームを取得できませんでした。", "warning" },
    ["message.save.all_invalid"] = { "設計図を保存できません。選択した建築物はすべて無効になっています。", "warning" },
    ["message.save.serialization_partial"] = { "設計図を保存できません。選択した建築物%d件をシリアライズできませんでした。", "warning" },
    ["message.save.anchor_missing"] = { "設計図を保存できません。アンカーを設計図に書き込めませんでした。", "warning" },
    ["message.save.metadata_unavailable"] = { "設計図JSONを保存できません。建築タイプのメタデータを利用できません。", "warning" },
    ["message.save.compact_failed"] = { "設計図JSONを保存できません。圧縮形式への変換に失敗しました。", "warning" },
    ["message.save.clipboard_failed"] = { "設計図JSONを保存できません。クリップボードに書き込めませんでした。", "warning" },
    ["message.save.deserialize_failed"] = { "設計図JSONを保存できません。ランタイム検証に失敗しました。", "warning" },
    ["message.save.success"] = { "PWB9D設計図を保存しました：建築物%d件、アンカー%s、%d文字。", "info" },
    ["message.library.name_invalid"] = { "設計図名が無効です：%s", "warning" },
    ["message.library.save_failed"] = { "設計図をローカルライブラリに保存できませんでした：%s", "warning" },

    ["message.selection.input_failed"] = { "設計図選択モードを開始できません。入力コンテキストを利用できません。UE4SSログを確認してください。", "warning" },
    ["message.selection.hud_failed"] = { "設計図選択HUDを読み込めませんでした。UE4SSログを確認してください。", "warning" },
    ["message.selection.tick_failed"] = { "設計図選択の更新処理に失敗しました。UE4SSログを確認してください。", "warning" },

    ["message.camera.base_only"] = { "フリーカメラは拠点内でのみ使用できます。", "warning" },
    ["message.camera.start_failed"] = { "フリーカメラを開始できませんでした。現在の設計図モードを終了してから再試行してください。", "warning" },
    ["message.world_snap.enabled"] = { "元のワールド座標へのスナップを有効にしました。", "info" },
    ["message.world_snap.disabled"] = { "元のワールド座標へのスナップを無効にしました。", "info" },
    ["message.world_snap.unavailable"] = { "この設計図には利用可能なワールドトランスフォームが保存されていません。", "warning" },
    ["message.world_snap.out_of_range"] = { "元の位置まで %.1f m あり、スナップ許可範囲 %.1f m を超えています。", "warning" },
    ["message.world_snap.failed"] = { "元のワールド座標へのスナップを切り替えられませんでした。設計図配置モードを終了して再試行してください。", "warning" },

    ["message.placement.exit_pending"] = { "現在の設計図は建築モードの終了処理中です。", "warning" },
    ["message.placement.clipboard_invalid"] = { "設計図を配置できません。クリップボードに有効なPWB9Dコードまたはスキーマ9のJSONがありません。", "warning" },
    ["message.placement.build_id_restore_failed"] = { "設計図を配置できません。建築IDをランタイムタイプに復元できませんでした。", "warning" },
    ["message.placement.deserialize_failed"] = { "設計図を配置できません。JSONのデシリアライズに失敗しました。", "warning" },
    ["message.placement.empty"] = { "設計図を配置できません。設計図に建築物が含まれていません。", "warning" },
    ["message.placement.incompatible"] = { "設計図を配置できません。バージョンに互換性がないか、アンカーがありません。", "warning" },
    ["message.placement.input_failed"] = { "設計図配置の入力初期化に失敗しました。配置を中止しました。UE4SSログを確認してください。", "warning" },
    ["message.placement.overlap_checker_failed"] = { "設計図の重複判定に失敗しました。配置を中止しました。", "warning" },
    ["message.placement.collision_query_limit"] = {
        "設計図の衝突判定建築物：%d / 上限%d。プレビューできません。BlueprintResearch.modconfig.json の blueprint_collision_query_component_limit を増やし、ゲームを再起動してください。",
        "warning"
    },
    ["message.placement.overlap"] = { "設計図を配置できません。建築物%d件がワールド内のオブジェクトと重なっています。", "warning" },
    ["message.placement.overlap_detail"] = {
        "重なり%d件：%s ↔ %s",
        "warning"
    },
    ["message.placement.overlap_primary_actor"] = {
        "重なり%d件：%s ↔ %s。複雑な重なりでは主要な障害物のみを確認します。重なっている既設・建設中の建築物を撤去して再試行してください。",
        "warning"
    },
    ["message.placement.checking"] = {
        "設計図の配置位置を確認しています。少しお待ちください。",
        "warning"
    },
    ["message.placement.blocker_pal"] = "パル",
    ["message.placement.blocker_world_object"] = "ワールドオブジェクト",
    ["message.placement.water_building_locked"] = { "水上に設計図を配置できません。先に水上建築セットをアンロックしてください。", "warning" },
    ["message.placement.water_capability_unavailable"] = { "水上建築セットを確認できません。設計図配置モードを終了して入り直してから再試行してください。", "warning" },
    ["message.placement.anchor_invalid"] = { "設計図を配置できません。この場所にはアンカーを建築できません。", "warning" },
    ["message.placement.material_check_failed"] = { "設計図の材料確認に失敗しました。UE4SSログを確認してください。", "warning" },
    ["message.placement.materials_insufficient"] = { "設計図全体の材料が不足しています：%s", "warning" },
    ["message.placement.hud_expired"] = { "設計図配置画面が無効になりました。建築モードを終了してから再試行してください。", "warning" },
    ["message.placement.state_busy"] = { "現在の建築状態が終了していないため、別の設計図を配置できません。", "warning" },

    ["message.build.complete"] = { "設計図の建築が完了しました：建築物%d件。", "info" },
    ["message.build.force_submit_started"] = { "強制送信モードを開始しました。ローカルの重複・支持判定失敗やサーバー拒否では、このキューは停止しません。", "warning" },
    ["message.build.force_submit_complete"] = { "強制送信キューが終了しました：成功%d件、拒否またはタイムアウト%d件。", "warning" },
    ["message.build.stop_materials"] = { "設計図の建築を停止しました。材料が不足しています。", "warning" },
    ["message.build.stop_server_gate"] = { "設計図の建築を停止しました。建築物がサーバーに拒否されました。", "warning" },
    ["message.build.stop_timeout"] = { "設計図の建築を停止しました。サーバーから応答がありません。対象が遮られている可能性があります。", "warning" },
    ["message.build.stop_generic"] = { "設計図の建築を停止しました。UE4SSログを確認してください。", "warning" },
    ["message.build.request_error"] = { "設計図の建築リクエストに失敗しました。UE4SSログを確認してください。", "warning" },
    ["message.build.request_submitted"] = { "設計図の建築リクエストを送信しました：建築物%d件。", "info" },
    ["message.build.already_complete"] = { "この設計図の建築物はすべて既に存在します。修復は不要です。", "info" },
    ["message.build.structure_unbuildable"] = { "この設計図の構造は現在建築できません。位置または支えを調整して再試行してください。", "warning" },
    ["message.build.start_failed"] = { "設計図の建築を開始できませんでした。建築モードを終了して入り直してから再試行してください。", "warning" },

    ["message.diagnostic.capture_failed"] = { "UIキャプチャに失敗しました。UE4SSログを確認してください。", "warning" },
    ["message.diagnostic.capture_complete"] = { "UIキャプチャが完了しました：ルートウィジェット%d件、ノード%d件。", "info" },
}

local DICTIONARIES = {
    en = EN,
    ["zh-Hans"] = ZH_HANS,
    ["zh-Hant"] = ZH_HANT,
    ja = JA,
}

local function normalize_locale(language)
    local normalized = string.lower(tostring(language or ""))
    normalized = string.gsub(normalized, "_", "-")
    if string.sub(normalized, 1, 2) == "zh"
        or string.find(normalized, "chinese", 1, true) then
        if string.find(normalized, "hant", 1, true)
            or string.find(normalized, "traditional", 1, true)
            or string.find(normalized, "-tw", 1, true)
            or string.find(normalized, "-hk", 1, true)
            or string.find(normalized, "-mo", 1, true) then
            return "zh-Hant"
        end
        return "zh-Hans"
    end
    if string.sub(normalized, 1, 2) == "ja"
        or string.find(normalized, "japanese", 1, true) then
        return "ja"
    end
    return DEFAULT_LOCALE
end

function BlueprintLocalization.install(deps)
    assert(type(deps) == "table",
        "BlueprintLocalization.install requires deps")
    local log = assert(deps.log, "BlueprintLocalization requires log")
    local unwrap = assert(deps.unwrap, "BlueprintLocalization requires unwrap")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintLocalization requires is_valid_object")
    local value_to_string = assert(deps.value_to_string,
        "BlueprintLocalization requires value_to_string")

    local last_game_language = nil
    local last_locale = nil
    local missing_keys = {}

    local function detect_locale()
        local language = ""
        local library = unwrap(StaticFindObject(
            INTERNATIONALIZATION_LIBRARY_PATH
        ))
        if is_valid_object(library) then
            local ok, result = pcall(function()
                return library:GetCurrentLanguage()
            end)
            if ok then language = value_to_string(result) end
        end
        local locale = normalize_locale(language)
        if language ~= last_game_language or locale ~= last_locale then
            last_game_language = language
            last_locale = locale
            log("blueprint localization selected gameLanguage="
                .. tostring(language) .. " locale=" .. tostring(locale))
        end
        return locale
    end

    local function get_entry(key)
        local locale = detect_locale()
        local dictionary = DICTIONARIES[locale] or EN
        local entry = dictionary[key] or EN[key]
        if entry == nil and not missing_keys[key] then
            missing_keys[key] = true
            log("blueprint localization missing key=" .. tostring(key))
        end
        return entry, locale
    end

    local function format_entry(entry, ...)
        local template = type(entry) == "table" and entry[1] or entry
        if template == nil then return "" end
        if select("#", ...) == 0 then return tostring(template) end
        local ok, result = pcall(string.format, tostring(template), ...)
        if ok then return result end
        log("blueprint localization format failed template="
            .. tostring(template) .. " error=" .. tostring(result))
        return tostring(template)
    end

    local function text(key, ...)
        local entry = get_entry(key)
        if entry == nil then return tostring(key or "") end
        return format_entry(entry, ...)
    end

    local function message(key, ...)
        local entry = get_entry(key)
        if entry == nil then return tostring(key or ""), "warning" end
        local kind = type(entry) == "table" and entry[2] or "info"
        return format_entry(entry, ...), kind
    end

    return {
        text = text,
        message = message,
        get_locale = detect_locale,
        normalize_locale = normalize_locale,
    }
end

return BlueprintLocalization

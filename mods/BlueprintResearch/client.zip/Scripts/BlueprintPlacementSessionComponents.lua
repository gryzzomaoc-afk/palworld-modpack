local BlueprintPlacementSessionComponents = {}

local REFERENCES = {
    preview_root = "SBB_PreviewRoot",
    attached_anchor_root = "SBB_PreviewAttachedAnchorRoot",
    normal_material = "SBB_PreviewNormalMaterial",
    error_material = "SBB_PreviewErrorMaterial",
    terrain_anchor_effect = "SBB_TerrainAnchorEffect",
    blocker_actor = "SBB_BlockerActor",
    blocker_highlight_material = "SBB_BlockerHighlightMaterial",
    overlap_selected_component = "SBB_OverlapSelectedComponent",
}

local ARRAYS = {
    preview_meshes = "SBB_PreviewMeshComponents",
    preview_skeletal_meshes = "SBB_PreviewSkeletalMeshComponents",
    query_box = "SBB_QueryBoxComponents",
    query_sphere = "SBB_QuerySphereComponents",
    query_capsule = "SBB_QueryCapsuleComponents",
    overlap_query_components = "SBB_OverlapQueryComponents",
    overlap_ignored_actors = "SBB_OverlapIgnoredActors",
    overlap_world_names = "SBB_OverlapWorldObjectNames",
    overlap_world_build_ids = "SBB_OverlapWorldBuildIds",
    overlap_world_transforms = "SBB_OverlapWorldTransforms",
    overlap_world_is_build = "SBB_OverlapWorldIsBuildObject",
    overlap_world_is_pal = "SBB_OverlapWorldIsPal",
    overlap_pair_members = "SBB_OverlapPairMemberIndices",
    overlap_pair_world_indices = "SBB_OverlapPairWorldObjectIndices",
    overlap_pair_profiles = "SBB_OverlapPairProfiles",
    overlap_pair_component_names = "SBB_OverlapPairComponentNames",
    overlap_pair_object_types = "SBB_OverlapPairObjectTypes",
    overlap_pair_locations = "SBB_OverlapPairLocations",
    native_overlap_build_ids = "SBB_NativeOverlapBuildIds",
    native_overlap_locations = "SBB_NativeOverlapLocations",
    native_overlap_rotations = "SBB_NativeOverlapRotations",
    native_overlap_collision_transforms =
        "SBB_NativeOverlapCollisionTransforms",
    native_overlap_results = "SBB_NativeOverlapResults",
    native_overlap_candidate_member_indices =
        "SBB_NativeOverlapCandidateMemberIndices",
    native_overlap_candidate_build_ids =
        "SBB_NativeOverlapCandidateBuildIds",
    native_overlap_candidate_transforms =
        "SBB_NativeOverlapCandidateTransforms",
    native_overlap_candidate_object_names =
        "SBB_NativeOverlapCandidateObjectNames",
    native_overlap_blocker_member_indices =
        "SBB_NativeOverlapBlockerMemberIndices",
    native_overlap_blocker_build_ids =
        "SBB_NativeOverlapBlockerBuildIds",
    native_overlap_blocker_object_names =
        "SBB_NativeOverlapBlockerObjectNames",
    native_overlap_blocker_class_names =
        "SBB_NativeOverlapBlockerClassNames",
    native_overlap_blocker_is_build =
        "SBB_NativeOverlapBlockerIsBuildObject",
    blocker_meshes = "SBB_BlockerMeshComponents",
    blocker_materials = "SBB_BlockerOriginalMaterials",
    blocker_slots = "SBB_BlockerSlotIndices",
}

local QUERY_ARRAY_BY_SHAPE = {
    box = ARRAYS.query_box,
    sphere = ARRAYS.query_sphere,
    capsule = ARRAYS.query_capsule,
}

function BlueprintPlacementSessionComponents.install(deps)
    assert(type(deps) == "table",
        "BlueprintPlacementSessionComponents dependencies are required")
    local unwrap = assert(deps.unwrap, "unwrap dependency is required")
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object dependency is required"
    )
    local read_property = assert(
        deps.read_property, "read_property dependency is required"
    )
    local write_property = assert(
        deps.write_property, "write_property dependency is required"
    )

    local store = {
        references = REFERENCES,
        arrays = ARRAYS,
    }

    local function valid_session(session)
        return is_valid_object(unwrap(session))
    end

    function store.get_reference(session, key_or_property)
        session = unwrap(session)
        if not valid_session(session) then return nil end
        local property_name =
            REFERENCES[key_or_property] or key_or_property
        return unwrap(read_property(session, property_name))
    end

    function store.set_reference(session, key_or_property, value)
        session = unwrap(session)
        if not valid_session(session) then
            return false, "placement session is unavailable"
        end
        local property_name =
            REFERENCES[key_or_property] or key_or_property
        local ok, result = pcall(
            write_property, session, property_name, unwrap(value)
        )
        if not ok or result == false then
            return false, tostring(ok and result or result)
        end
        return true, nil
    end

    function store.get_array(session, key_or_property)
        session = unwrap(session)
        if not valid_session(session) then return nil end
        local property_name = ARRAYS[key_or_property] or key_or_property
        return read_property(session, property_name)
    end

    function store.array_count(session, key_or_property)
        local values = store.get_array(session, key_or_property)
        if values == nil then return 0 end
        local count = 0
        pcall(function() count = #values end)
        return count
    end

    function store.get_array_item(session, key_or_property, index)
        local values = store.get_array(session, key_or_property)
        if values == nil then return nil end
        local value = nil
        pcall(function() value = unwrap(values[index]) end)
        return value
    end

    function store.set_array_item(
        session, key_or_property, index, value
    )
        local values = store.get_array(session, key_or_property)
        if values == nil then
            return false, "placement session array is unavailable: "
                .. tostring(key_or_property)
        end
        local ok, error_value = pcall(function()
            values[index] = unwrap(value)
        end)
        if not ok then return false, tostring(error_value) end
        return true, nil
    end

    function store.empty_array(session, key_or_property)
        local values = store.get_array(session, key_or_property)
        if values == nil then
            return false, "placement session array is unavailable: "
                .. tostring(key_or_property)
        end
        local ok, error_value = pcall(function() values:Empty() end)
        if not ok then return false, tostring(error_value) end
        return true, nil
    end

    function store.for_each(session, key_or_property, callback)
        local count = store.array_count(session, key_or_property)
        for index = 1, count do
            local value = store.get_array_item(
                session, key_or_property, index
            )
            callback(value, index)
        end
        return count
    end

    function store.get_query_component(session, shape_type, index)
        local property_name = QUERY_ARRAY_BY_SHAPE[shape_type]
        if property_name == nil then return nil end
        return store.get_array_item(session, property_name, index)
    end

    function store.set_query_component(
        session, shape_type, index, component
    )
        local property_name = QUERY_ARRAY_BY_SHAPE[shape_type]
        if property_name == nil then
            return false, "unsupported query shape=" .. tostring(shape_type)
        end
        return store.set_array_item(
            session, property_name, index, component
        )
    end

    function store.reset_preview(session)
        if not valid_session(session) then
            return false, "placement session is unavailable"
        end
        local ok = true
        local terrain_effect = store.get_reference(
            session, "terrain_anchor_effect"
        )
        if is_valid_object(terrain_effect) then
            local disposed = pcall(function()
                terrain_effect:Deactivate()
                terrain_effect:SetRenderingEnabled(false)
                terrain_effect:ResetSystem()
                terrain_effect:SetHiddenInGame(true, true)
                terrain_effect:SetVisibility(false, true)
                terrain_effect:K2_DestroyComponent(session)
            end)
            ok = disposed and ok
        end
        for _, property_name in pairs({
            ARRAYS.preview_meshes,
            ARRAYS.preview_skeletal_meshes,
            ARRAYS.query_box,
            ARRAYS.query_sphere,
            ARRAYS.query_capsule,
            ARRAYS.overlap_query_components,
            ARRAYS.overlap_ignored_actors,
        }) do
            ok = store.empty_array(session, property_name) and ok
        end
        for _, property_name in pairs({
            REFERENCES.preview_root,
            REFERENCES.attached_anchor_root,
            REFERENCES.normal_material,
            REFERENCES.error_material,
            REFERENCES.terrain_anchor_effect,
            REFERENCES.overlap_selected_component,
        }) do
            ok = store.set_reference(session, property_name, nil) and ok
        end
        local scalar_ok = pcall(function()
            session.SBB_PreviewInvalidGhostIndex = -1
            session.SBB_PreviewVisible = false
        end)
        return ok and scalar_ok,
            ok and scalar_ok and nil or "preview Session reset failed"
    end

    function store.reset_blocker(session)
        if not valid_session(session) then
            return false, "placement session is unavailable"
        end
        local ok = true
        for _, property_name in pairs({
            ARRAYS.blocker_meshes,
            ARRAYS.blocker_materials,
            ARRAYS.blocker_slots,
        }) do
            ok = store.empty_array(session, property_name) and ok
        end
        ok = store.set_reference(
            session, REFERENCES.blocker_actor, nil
        ) and ok
        local scalar_ok = pcall(function()
            session.SBB_BlockerVisualActive = false
        end)
        return ok and scalar_ok,
            ok and scalar_ok and nil or "blocker Session reset failed"
    end

    function store.get_diagnostics(session)
        return {
            preview_meshes =
                store.array_count(session, ARRAYS.preview_meshes),
            preview_skeletal_meshes =
                store.array_count(
                    session, ARRAYS.preview_skeletal_meshes
                ),
            query_box = store.array_count(session, ARRAYS.query_box),
            query_sphere =
                store.array_count(session, ARRAYS.query_sphere),
            query_capsule =
                store.array_count(session, ARRAYS.query_capsule),
            blocker_meshes =
                store.array_count(session, ARRAYS.blocker_meshes),
        }
    end

    return store
end

return BlueprintPlacementSessionComponents

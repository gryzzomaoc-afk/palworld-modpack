local BlueprintNativeUIStack = {}

local PAL_UTILITY_PATH = "/Script/Pal.Default__PalUtility"
local STACKABLE_ON_CLOSE_PATH =
    "/Script/Pal.PalUserWidgetStackableUI:OnClose"

function BlueprintNativeUIStack.install(deps)
    assert(type(deps) == "table",
        "BlueprintNativeUIStack dependencies are required")
    local UEHelpers = assert(deps.UEHelpers,
        "BlueprintNativeUIStack UEHelpers is required")
    local log = assert(deps.log,
        "BlueprintNativeUIStack log is required")
    local unwrap = assert(deps.unwrap,
        "BlueprintNativeUIStack unwrap is required")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintNativeUIStack is_valid_object is required")
    local safe_object_address = assert(deps.safe_object_address,
        "BlueprintNativeUIStack safe_object_address is required")
    local register_hook = deps.register_hook or RegisterHook

    local stack = {
        entries = {},
        close_hook_registered = false,
        close_hook_callback = nil,
    }

    local function resolve(path)
        if type(StaticFindObject) ~= "function" then return nil end
        local ok, value = pcall(StaticFindObject, path)
        if not ok then return nil end
        return unwrap(value)
    end

    local function get_service()
        if type(deps.get_hud_service) == "function" then
            return unwrap(deps.get_hud_service())
        end
        local utility = resolve(PAL_UTILITY_PATH)
        local world = unwrap(select(2, pcall(UEHelpers.GetWorld)))
        if not is_valid_object(utility) or not is_valid_object(world) then
            return nil, "PalUtility or world unavailable"
        end
        local ok, value = pcall(function()
            return utility:GetHUDService(world)
        end)
        local service = ok and unwrap(value) or nil
        if not is_valid_object(service) then
            return nil, ok and "PalHUDService unavailable" or tostring(value)
        end
        return service, nil
    end

    local function notify_closed(entry, reason)
        if type(entry) ~= "table" or entry.active ~= true then return false end
        entry.active = false
        stack.entries[entry.guid_key] = nil
        local callback = entry.on_closed
        entry.on_closed = nil
        if type(callback) == "function" then
            local ok, error_value = pcall(callback, reason)
            if not ok then
                log("native UI close callback isolated error="
                    .. tostring(error_value))
            end
        end
        return true
    end

    local function copy_guid(value)
        -- UE4SS may expose returned structs as temporary RemoteUnrealParam
        -- wrappers. Never keep that wrapper past the Push call; copy FGuid into
        -- an ordinary Lua table that can safely be passed back to Pal later.
        local copied = {}
        for _, field in ipairs({ "A", "B", "C", "D" }) do
            local ok, raw = pcall(function() return value[field] end)
            local number = ok and tonumber(raw) or nil
            if number == nil then return nil end
            copied[field] = number
        end
        return copied
    end

    local function guid_key(value)
        if type(value) ~= "table" then return nil end
        local fields = {}
        for _, field in ipairs({ "A", "B", "C", "D" }) do
            local number = tonumber(value[field])
            if number == nil then return nil end
            fields[#fields + 1] = string.format(
                "%08X", number % 4294967296
            )
        end
        return table.concat(fields, "-")
    end

    local function object_full_name(value)
        value = unwrap(value)
        if not is_valid_object(value) then return nil end
        local ok, full_name = pcall(function()
            return value:GetFullName()
        end)
        return ok and full_name ~= nil and tostring(full_name) or nil
    end

    local function get_widget_from_service(service, entry)
        if type(entry) ~= "table" or entry.active ~= true
            or not is_valid_object(service) then
            return nil
        end
        local ok, widget_value = pcall(function()
            return service:GetWidget(entry.widget_id)
        end)
        local widget = ok and unwrap(widget_value) or nil
        if not is_valid_object(widget)
            or object_full_name(widget) ~= entry.widget_full_name then
            return nil
        end
        return widget
    end

    local function ensure_close_hook()
        if stack.close_hook_registered then return true, nil end
        if type(register_hook) ~= "function" then
            return false, "RegisterHook is unavailable"
        end
        local callback = function(context)
            local context_address = safe_object_address(unwrap(context))
            if context_address == nil then return end
            local service = get_service()
            if not is_valid_object(service) then return end
            for _, entry in pairs(stack.entries) do
                local widget = get_widget_from_service(service, entry)
                local widget_address = safe_object_address(widget)
                if widget_address ~= nil
                    and tostring(widget_address)
                        == tostring(context_address) then
                    notify_closed(entry, "native-on-close")
                    return
                end
            end
        end
        local retained = function(...)
            local ok, error_value = pcall(callback, ...)
            if not ok then
                log("native UI OnClose hook isolated error="
                    .. tostring(error_value))
            end
        end
        local ok, pre_id, post_id = pcall(
            register_hook, STACKABLE_ON_CLOSE_PATH, retained
        )
        if not ok then
            return false, "Pal stackable OnClose hook unavailable: "
                .. tostring(pre_id)
        end
        stack.close_hook_registered = true
        stack.close_hook_callback = retained
        log("native UI OnClose hook registered pre=" .. tostring(pre_id)
            .. " post=" .. tostring(post_id))
        return true, nil
    end

    function stack.push(widget_class, on_closed)
        widget_class = unwrap(widget_class)
        if not is_valid_object(widget_class) then
            return nil, nil, "native UI widget class unavailable"
        end
        local hook_ready, hook_error = ensure_close_hook()
        if not hook_ready then return nil, nil, hook_error end

        local service, service_error = get_service()
        if not is_valid_object(service) then
            return nil, nil, service_error
        end
        local push_ok, returned_widget_id = pcall(function()
            return service:Push(widget_class, nil)
        end)
        if not push_ok or returned_widget_id == nil then
            return nil, nil, "PalHUDService Push failed: "
                .. tostring(returned_widget_id)
        end
        local get_ok, widget_value = pcall(function()
            return service:GetWidget(returned_widget_id)
        end)
        local widget = get_ok and unwrap(widget_value) or nil
        if not is_valid_object(widget) then
            pcall(function() service:Close(returned_widget_id) end)
            return nil, nil, "PalHUDService GetWidget failed: "
                .. tostring(widget_value)
        end
        local widget_id = copy_guid(returned_widget_id)
        if widget_id == nil then
            pcall(function() service:Close(returned_widget_id) end)
            return nil, nil, "PalHUDService returned an unreadable widget ID"
        end
        local entry_guid_key = guid_key(widget_id)
        local widget_full_name = object_full_name(widget)
        if entry_guid_key == nil or widget_full_name == nil then
            pcall(function() service:Close(returned_widget_id) end)
            return nil, nil, "native UI widget scalar identity is unavailable"
        end
        local entry = {
            widget_id = widget_id,
            guid_key = entry_guid_key,
            widget_full_name = widget_full_name,
            on_closed = on_closed,
            active = true,
        }
        stack.entries[entry.guid_key] = entry
        return entry, widget, nil
    end

    function stack.close(entry, reason)
        if type(entry) ~= "table" or entry.active ~= true then
            return false, "native UI entry is inactive"
        end
        local service, service_error = get_service()
        if not is_valid_object(service) then
            notify_closed(entry, "service-unavailable:" .. tostring(reason))
            return false, service_error
        end
        local close_ok, close_error = pcall(function()
            service:Close(entry.widget_id)
        end)
        -- Pal closes stackable widgets synchronously. OnClose normally removes
        -- the entry first; this fallback guarantees exactly one notification
        -- if a game revision omits that callback.
        notify_closed(entry, "service-close:" .. tostring(reason))
        if not close_ok then return false, tostring(close_error) end
        return true, nil
    end

    function stack.copy_widget_id(value)
        return copy_guid(value)
    end

    function stack.close_widget_id(widget_id)
        local copied = copy_guid(widget_id)
        if copied == nil then
            return false, "native UI widget ID is unreadable"
        end
        local service, service_error = get_service()
        if not is_valid_object(service) then
            return false, service_error
        end
        local close_ok, close_error = pcall(function()
            service:Close(copied)
        end)
        if not close_ok then return false, tostring(close_error) end
        return true, nil
    end

    function stack.focus(entry, widget)
        if type(entry) ~= "table" or entry.active ~= true then return false end
        widget = unwrap(widget)
        if not is_valid_object(widget) then return false end
        local service = get_service()
        if not is_valid_object(service) then return false end
        return select(1, pcall(function()
            service:ActivateFocusCursor(widget)
        end))
    end

    function stack.get_widget(entry)
        if type(entry) ~= "table" or entry.active ~= true then return nil end
        local service = get_service()
        if not is_valid_object(service) then return nil end
        return get_widget_from_service(service, entry)
    end

    function stack.is_alive(entry)
        return stack.get_widget(entry) ~= nil
    end

    function stack.is_top(entry)
        if type(entry) ~= "table" or entry.active ~= true then return false end
        local service = get_service()
        if not is_valid_object(service) then return false end
        local ok, value = pcall(function()
            return service:IsTopLayerUI(entry.widget_id)
        end)
        return ok and (value == true or tonumber(value) == 1)
    end

    function stack.abandon(entry, reason)
        return notify_closed(entry, "abandon:" .. tostring(reason))
    end

    return stack
end

return BlueprintNativeUIStack

-- Pure-data blueprint wave planner.
--
-- The runtime owns all Unreal objects.  This module accepts scalar request
-- records only, so the plan can be tested without a running game and no
-- RemoteUnrealParam/UObject can escape a hook callback.

local Planner = {}

Planner.SCHEMA_VERSION = 1

-- Requests inside one wave are dispatched sequentially. Preserve Palworld's
-- natural construction order so a functional object which is already legal
-- on partial support cannot occupy the volume of a structural request that is
-- also ready in the same wave.
--
-- EPalBuildObjectInstallStrategy values:
--   4/16       foundation / triangle foundation
--   7/8/13     ground wall / ground wall V2 / pillar
--   1/2/17/22/23/26
--              wall families
--   5/6/15/18/19/20/21/25/28
--              roof, stair, fence and floor families
-- Everything else is a normal/special functional placement.
local INSTALL_STRATEGY_PRIORITY = {
    [4] = 0,
    [16] = 0,

    [7] = 1,
    [8] = 1,
    [13] = 1,

    [1] = 2,
    [2] = 2,
    [17] = 2,
    [22] = 2,
    [23] = 2,
    [26] = 2,

    [5] = 3,
    [6] = 3,
    [15] = 3,
    [18] = 3,
    [19] = 3,
    [20] = 3,
    [21] = 3,
    [25] = 3,
    [28] = 3,
}

local function contains_any(value, tokens)
    for _, token in ipairs(tokens) do
        if string.find(value, token, 1, true) ~= nil then return true end
    end
    return false
end

local function request_install_priority(request)
    local strategy = tonumber(request and request.install_strategy)
    if strategy ~= nil then
        return INSTALL_STRATEGY_PRIORITY[strategy] or 4
    end

    -- Persisted type templates normally provide InstallStrategy. Keep a
    -- conservative ID fallback for older/imported records without it.
    local build_object_id = string.lower(tostring(
        request and request.build_object_id or ""
    ))
    if contains_any(build_object_id, { "foundation" }) then return 0 end
    if contains_any(build_object_id, {
        "pillar", "column", "groundwall",
    }) then
        return 1
    end
    if contains_any(build_object_id, { "wall" }) then return 2 end
    if contains_any(build_object_id, {
        "floor", "roof", "stair", "fence",
    }) then
        return 3
    end
    return 4
end

local function is_foundation_request(request)
    local strategy = tonumber(request and request.install_strategy)
    if strategy ~= nil then return strategy == 4 or strategy == 16 end

    -- Older/imported records may not carry InstallStrategy. Keep the same
    -- conservative identity fallback used by the stable request ordering.
    local build_object_id = string.lower(tostring(
        request and request.build_object_id or ""
    ))
    return contains_any(build_object_id, { "foundation" })
end

local function stable_request_less(left, right)
    local left_priority = request_install_priority(left)
    local right_priority = request_install_priority(right)
    if left_priority ~= right_priority then
        return left_priority < right_priority
    end
    local left_index = tonumber(left and left.selection_index) or math.huge
    local right_index = tonumber(right and right.selection_index) or math.huge
    if left_index ~= right_index then return left_index < right_index end
    return tostring(left and left.source_instance_id or "")
        < tostring(right and right.source_instance_id or "")
end

local function sorted_ids(id_set, request_by_source)
    local ids = {}
    for source_id, present in pairs(id_set or {}) do
        if present then table.insert(ids, source_id) end
    end
    table.sort(ids, function(left, right)
        return stable_request_less(
            request_by_source[left], request_by_source[right]
        )
    end)
    return ids
end

local function add_neighbour(adjacency, source_id, target_id, connection)
    local neighbours = adjacency[source_id]
    local edge = neighbours[target_id]
    if edge == nil then
        edge = { connections = {} }
        neighbours[target_id] = edge
    end
    table.insert(edge.connections, connection)
end

local function make_saved_connect_graph(requests, request_by_source)
    local adjacency = {}
    for _, request in ipairs(requests) do
        adjacency[request.source_instance_id] = {}
    end

    local seen_edges = {}
    local edge_count = 0
    local directed_connection_count = 0
    for _, request in ipairs(requests) do
        local source_id = request.source_instance_id
        for _, connection in ipairs(request.connections or {}) do
            local target_id = connection.target_source_instance_id
            if target_id == nil or request_by_source[target_id] == nil then
                return nil, string.format(
                    "saved Connect edge has unknown target source=%s target=%s",
                    tostring(source_id), tostring(target_id)
                )
            end
            if target_id ~= source_id then
                directed_connection_count = directed_connection_count + 1
                -- Runtime ConnectInfo is normally present on both endpoints,
                -- but the serializer is allowed to capture only one side.  A
                -- saved physical connection is therefore indexed in both
                -- directions for reachability; the original endpoint metadata
                -- remains attached to the edge for later richer predicates.
                add_neighbour(adjacency, source_id, target_id, connection)
                add_neighbour(adjacency, target_id, source_id, connection)

                local left, right = tostring(source_id), tostring(target_id)
                if right < left then left, right = right, left end
                local edge_key = left .. "|" .. right
                if not seen_edges[edge_key] then
                    seen_edges[edge_key] = true
                    edge_count = edge_count + 1
                end
            end
        end
    end

    return {
        adjacency = adjacency,
        edge_count = edge_count,
        directed_connection_count = directed_connection_count,
    }, nil
end

local function collect_unlock_sources(source_id, built, graph)
    local unlock_sources = {}
    for neighbour_id, _ in pairs(graph.adjacency[source_id] or {}) do
        if built[neighbour_id] then
            table.insert(unlock_sources, neighbour_id)
        end
    end
    table.sort(unlock_sources)
    return unlock_sources
end

-- Force-submit bypasses support legality, but it must not flatten the saved
-- connection graph into one giant first wave.  Seed only one deterministic
-- request in each otherwise-unrooted connected component; normal frontier
-- expansion then preserves the saved connection order inside that component.
local function seed_force_submit_components(
    initial_roots, graph, request_by_source
)
    local visited = {}
    local added_roots = {}
    local all_ids = {}
    for source_id, _ in pairs(request_by_source or {}) do
        all_ids[source_id] = true
    end
    for _, start_id in ipairs(sorted_ids(all_ids, request_by_source)) do
        if not visited[start_id] then
            local component_ids = {}
            local component_set = { [start_id] = true }
            local queue = { start_id }
            local cursor = 1
            local has_root = false
            visited[start_id] = true
            while cursor <= #queue do
                local source_id = queue[cursor]
                cursor = cursor + 1
                component_ids[source_id] = true
                if initial_roots[source_id] then has_root = true end
                for neighbour_id, _ in pairs(
                    graph.adjacency[source_id] or {}
                ) do
                    if request_by_source[neighbour_id] ~= nil
                        and not component_set[neighbour_id] then
                        component_set[neighbour_id] = true
                        visited[neighbour_id] = true
                        queue[#queue + 1] = neighbour_id
                    end
                end
            end
            if not has_root then
                local component_order = sorted_ids(
                    component_ids, request_by_source
                )
                local root_id = component_order[1]
                if root_id ~= nil then
                    initial_roots[root_id] = true
                    added_roots[#added_roots + 1] = root_id
                end
            end
        end
    end
    return added_roots
end

local function classify_manual_requests(
    requests, graph, preexisting, request_by_source
)
    local connected = {}
    local isolated = {}
    for _, request in ipairs(requests) do
        local source_id = request.source_instance_id
        if request.construction_mode == "manual" then
            local connection_count = 0
            for _, _ in pairs(graph.adjacency[source_id] or {}) do
                connection_count = connection_count + 1
            end
            request.manual_internal_connection_count = connection_count
            if connection_count > 0 then
                request.manual_classification = "manual_connected"
                if not preexisting[source_id] then connected[source_id] = true end
            else
                -- Keep this classification as a shell for the later native
                -- support-legality integration. Isolated manual requests keep
                -- the established planner behaviour in this iteration.
                request.manual_classification = "manual_isolated"
                if not preexisting[source_id] then isolated[source_id] = true end
            end
        else
            request.manual_classification = nil
            request.manual_internal_connection_count = nil
        end
    end
    return {
        connected = connected,
        isolated = isolated,
        connected_source_ids = sorted_ids(connected, request_by_source),
        isolated_source_ids = sorted_ids(isolated, request_by_source),
    }
end

local function prepare_optional_support_gate(
    support_gate, anchor_request, member_requests, initial_root_ids, options
)
    if support_gate == nil then return nil, nil end
    if type(support_gate) ~= "table"
        or type(support_gate.analyze) ~= "function"
        or type(support_gate.evaluate) ~= "function" then
        return nil, "support gate must expose analyze() and evaluate()"
    end
    local support_gate_options = {}
    for key, value in pairs(options.support_gate_options or {}) do
        support_gate_options[key] = value
    end
    -- The planner owns root selection. The support analyzer must not silently
    -- reintroduce the historical rule that always made the anchor a root.
    if support_gate_options.seed_anchor == nil then
        support_gate_options.seed_anchor = false
    end
    local ok, analysis_or_error, analysis_error = pcall(
        support_gate.analyze,
        anchor_request, member_requests, initial_root_ids,
        support_gate_options
    )
    if not ok then
        return nil, "support gate analysis raised an error: "
            .. tostring(analysis_or_error)
    end
    if analysis_or_error == nil then
        return nil, "support gate analysis failed: "
            .. tostring(analysis_error)
    end
    return analysis_or_error, nil
end

local function apply_optional_support_gate(
    support_gate, support_analysis, candidate_set, built
)
    if support_gate == nil then return candidate_set, {}, nil end
    local accepted = {}
    local decisions = {}
    for source_id, present in pairs(candidate_set or {}) do
        if present then
            local ok, decision, details = pcall(
                support_gate.evaluate, support_analysis, source_id,
                { rooted_built = built }
            )
            if not ok then
                return nil, decisions,
                    "support gate evaluation raised an error source="
                        .. tostring(source_id) .. " error=" .. tostring(decision)
            end
            decisions[source_id] = {
                decision = decision,
                details = details,
            }
            if decision == "allow" or decision == "abstain" then
                accepted[source_id] = true
            elseif decision ~= "defer" and decision ~= "reject" then
                return nil, decisions,
                    "support gate returned an invalid decision source="
                        .. tostring(source_id) .. " decision="
                        .. tostring(decision)
            end
        end
    end
    return accepted, decisions, nil
end

function Planner.plan(anchor_request, member_requests, initial_root_ids, options)
    options = options or {}
    if type(options) ~= "table" then
        return nil, "planner options must be a table"
    end
    if anchor_request == nil then return nil, "anchor request is missing" end
    local anchor_id = anchor_request.source_instance_id
    if anchor_id == nil or tostring(anchor_id) == "" then
        return nil, "anchor source instance id is missing"
    end

    local requests = { anchor_request }
    local request_by_source = { [anchor_id] = anchor_request }
    for _, request in ipairs(member_requests or {}) do
        local source_id = request and request.source_instance_id
        if source_id == nil or tostring(source_id) == "" then
            return nil, "member source instance id is missing"
        end
        if request_by_source[source_id] ~= nil then
            return nil, "duplicate source instance id=" .. tostring(source_id)
        end
        request_by_source[source_id] = request
        table.insert(requests, request)
    end

    local graph, graph_error = make_saved_connect_graph(
        requests, request_by_source
    )
    if graph == nil then return nil, graph_error end

    local initial_roots = {}
    for source_id, is_root in pairs(initial_root_ids or {}) do
        if is_root and request_by_source[source_id] ~= nil then
            initial_roots[source_id] = true
        end
    end
    local foundation_roots = {}
    for source_id, request in pairs(request_by_source) do
        if is_foundation_request(request) then
            foundation_roots[source_id] = true
            initial_roots[source_id] = true
        end
    end
    local foundation_root_ids = sorted_ids(
        foundation_roots, request_by_source
    )
    local anchor_fallback_used = #foundation_root_ids == 0
    if anchor_fallback_used then initial_roots[anchor_id] = true end
    local preexisting = {}
    for source_id, request in pairs(request_by_source) do
        if request.preexisting_world_match ~= nil
            or request.preexisting == true then
            preexisting[source_id] = true
            initial_roots[source_id] = true
            request.plan_reason = "preexisting-world-match"
        end
    end
    local force_submit_component_root_ids = {}
    if options.force_submit_invalid == true then
        force_submit_component_root_ids = seed_force_submit_components(
            initial_roots, graph, request_by_source
        )
    end
    local manual = classify_manual_requests(
        requests, graph, preexisting, request_by_source
    )

    local support_gate = options.support_gate
    local support_analysis, support_error = prepare_optional_support_gate(
        support_gate, anchor_request, member_requests, initial_roots, options
    )
    if support_gate ~= nil and support_analysis == nil then
        return nil, support_error
    end

    -- A support gate may identify additional explicit roots.  This is opt-in:
    -- with no gate, the original anchor/initial-root behavior is unchanged.
    for source_id, present in pairs(
        support_analysis and support_analysis.seed_set or {}
    ) do
        if present and request_by_source[source_id] ~= nil then
            initial_roots[source_id] = true
        end
    end

    local remaining = {}
    for source_id, _ in pairs(request_by_source) do
        if not preexisting[source_id] then remaining[source_id] = true end
    end
    local built = {}
    for source_id, present in pairs(preexisting) do
        if present then built[source_id] = true end
    end
    local waves = {}
    local support_decisions_by_wave = {}
    local deferred_manual = {}
    local wave_number = 0

    while next(remaining) ~= nil do
        local candidate_set = {}
        local unlock_sources_by_id = {}

        if wave_number == 0 then
            for source_id, _ in pairs(initial_roots) do
                if remaining[source_id] then candidate_set[source_id] = true end
            end
            -- A preexisting node already participates in the saved graph, so
            -- its missing neighbours are immediately eligible in wave zero.
            for source_id, _ in pairs(remaining) do
                local unlock_sources = collect_unlock_sources(
                    source_id, built, graph
                )
                if #unlock_sources > 0 then
                    candidate_set[source_id] = true
                    unlock_sources_by_id[source_id] = unlock_sources
                end
            end
        else
            for source_id, _ in pairs(remaining) do
                local unlock_sources = collect_unlock_sources(
                    source_id, built, graph
                )
                if #unlock_sources > 0 then
                    candidate_set[source_id] = true
                    unlock_sources_by_id[source_id] = unlock_sources
                end
            end
        end


        local support_decisions = {}
        local gated_candidates, gate_error
        gated_candidates, support_decisions, gate_error =
            apply_optional_support_gate(
                support_gate, support_analysis, candidate_set,
                built
            )
        if gated_candidates == nil then return nil, gate_error end
        candidate_set = gated_candidates
        support_decisions_by_wave[wave_number + 1] = support_decisions

        -- A connected manual-build request must first be reachable through the
        -- normal frontier. Once reached, collect it for the single terminal
        -- wave without marking it built, so it cannot unlock later requests.
        local reached_manual = {}
        for source_id, present in pairs(candidate_set) do
            if present and manual.connected[source_id] then
                reached_manual[#reached_manual + 1] = source_id
            end
        end
        for _, source_id in ipairs(reached_manual) do
            deferred_manual[source_id] = true
            candidate_set[source_id] = nil
            remaining[source_id] = nil
        end

        if next(candidate_set) == nil then
            if next(remaining) == nil then break end
            local unreachable = sorted_ids(remaining, request_by_source)
            local failure_message = support_gate ~= nil
                and "support gate blocked all remaining candidates: "
                or "unreachable through SavedConnections: "
            return nil, failure_message .. table.concat(unreachable, ","), {
                    -- Preserve the established user-facing business failure
                    -- category.  The extra field distinguishes an enabled
                    -- gate without routing users to a generic start failure.
                    kind = "structure_unbuildable",
                    support_gate_stalled = support_gate ~= nil,
                    unreachable = unreachable,
                    edge_count = graph.edge_count,
                    directed_connection_count = graph.directed_connection_count,
                    support_gate_stats = support_analysis
                        and support_analysis.stats or nil,
                    support_decisions = support_decisions,
                }
        end

        local wave = {}
        local candidate_ids = sorted_ids(candidate_set, request_by_source)
        for _, source_id in ipairs(candidate_ids) do
            table.insert(wave, request_by_source[source_id])
        end

        for _, request in ipairs(wave) do
            local source_id = request.source_instance_id
            request.wave_index = wave_number
            if wave_number == 0
                and unlock_sources_by_id[source_id] ~= nil then
                request.plan_reason = "preexisting-neighbour"
            elseif wave_number == 0 then
                if foundation_roots[source_id] then
                    request.plan_reason = "initial-foundation"
                elseif source_id == anchor_id and anchor_fallback_used then
                    request.plan_reason = "fallback-anchor"
                else
                    request.plan_reason = "initial-world-root"
                end
            else
                request.plan_reason = "saved-connect"
            end
            request.unlock_source_instance_ids = unlock_sources_by_id[source_id] or {}
            built[source_id] = true
            remaining[source_id] = nil
        end
        table.insert(waves, wave)
        wave_number = wave_number + 1
    end

    local deferred_manual_source_ids = sorted_ids(
        deferred_manual, request_by_source
    )
    local manual_terminal_wave_index = nil
    if #deferred_manual_source_ids > 0 then
        local manual_wave = {}
        manual_terminal_wave_index = wave_number
        for _, source_id in ipairs(deferred_manual_source_ids) do
            local request = request_by_source[source_id]
            request.wave_index = wave_number
            request.plan_reason = "manual-terminal"
            request.unlock_source_instance_ids = collect_unlock_sources(
                source_id, built, graph
            )
            built[source_id] = true
            manual_wave[#manual_wave + 1] = request
        end
        waves[#waves + 1] = manual_wave
        wave_number = wave_number + 1
    end

    local dispatch_requests = {}
    local assigned = {}
    for _, wave in ipairs(waves) do
        for _, request in ipairs(wave) do
            local source_id = request.source_instance_id
            if assigned[source_id] then
                return nil, "request was assigned more than once source="
                    .. tostring(source_id)
            end
            assigned[source_id] = true
            table.insert(dispatch_requests, request)
        end
    end
    local unassigned = {}
    for source_id, _ in pairs(request_by_source) do
        if not preexisting[source_id] and not assigned[source_id] then
            unassigned[source_id] = true
        end
    end
    if next(unassigned) ~= nil then
        local unassigned_ids = sorted_ids(unassigned, request_by_source)
        return nil, "planner left requests unassigned: "
            .. table.concat(unassigned_ids, ","), {
                kind = "structure_unbuildable",
                unreachable = unassigned_ids,
                edge_count = graph.edge_count,
                directed_connection_count = graph.directed_connection_count,
            }
    end
    for request_index, request in ipairs(dispatch_requests) do
        request.request_index = request_index
        request.result_received = false
        request.result_success = false
        request.dispatched = false
        request.server_accepted = false
        request.spawn_observed = false
    end

    return {
        planner_schema_version = Planner.SCHEMA_VERSION,
        requests = dispatch_requests,
        all_requests = requests,
        request_by_source = request_by_source,
        waves = waves,
        edge_count = graph.edge_count,
        directed_connection_count = graph.directed_connection_count,
        initial_root_count = #sorted_ids(initial_roots, request_by_source),
        initial_root_ids = sorted_ids(initial_roots, request_by_source),
        foundation_root_count = #foundation_root_ids,
        foundation_root_ids = foundation_root_ids,
        anchor_fallback_used = anchor_fallback_used,
        support_gate_enabled = support_gate ~= nil,
        force_submit_invalid = options.force_submit_invalid == true,
        force_submit_component_root_ids = force_submit_component_root_ids,
        support_gate_stats = support_analysis and support_analysis.stats or nil,
        support_decisions_by_wave = support_decisions_by_wave,
        preexisting_count = #sorted_ids(preexisting, request_by_source),
        preexisting_source_ids =
            sorted_ids(preexisting, request_by_source),
        manual_connected_count = #manual.connected_source_ids,
        manual_connected_source_ids = manual.connected_source_ids,
        manual_isolated_count = #manual.isolated_source_ids,
        manual_isolated_source_ids = manual.isolated_source_ids,
        manual_deferred_count = #deferred_manual_source_ids,
        manual_deferred_source_ids = deferred_manual_source_ids,
        manual_terminal_wave_index = manual_terminal_wave_index,
        deferred_count = #deferred_manual_source_ids,
    }, nil
end

return Planner

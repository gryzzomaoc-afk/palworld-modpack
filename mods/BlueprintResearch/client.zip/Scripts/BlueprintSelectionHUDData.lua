local BlueprintSelectionHUDData = {}

function BlueprintSelectionHUDData.install(mode, deps)
    assert(type(mode) == "table",
        "BlueprintSelectionHUDData requires a mode table")
    assert(type(deps) == "table",
        "BlueprintSelectionHUDData requires dependencies")

    local UEHelpers = deps.UEHelpers
    local log = deps.log
    local unwrap = deps.unwrap
    local value_to_string = deps.value_to_string
    local is_valid_object = deps.is_valid_object
    local safe_property = deps.safe_property
    local find_in_instance = deps.find_in_instance
    local make_runtime_object_handle = assert(
        deps.make_runtime_object_handle,
        "BlueprintSelectionHUDData requires make_runtime_object_handle")
    local resolve_runtime_object_handle = assert(
        deps.resolve_runtime_object_handle,
        "BlueprintSelectionHUDData requires resolve_runtime_object_handle")
    local get_hud_widget = assert(
        deps.get_hud_widget,
        "BlueprintSelectionHUDData requires get_hud_widget")
    local TARGET_NAME_WIDGET = "Info_BP_PalTextBlock_C_100"

    local function usable_id(value)
        local label = value_to_string(value)
        if label == "None" or label == "<nil>" or label == "" then
            return nil
        end
        return label
    end

    local function get_world()
        return unwrap(UEHelpers.GetWorld())
    end

    local function get_ui_utility()
        return unwrap(StaticFindObject(
            "/Script/Pal.Default__PalUIUtility"
        ))
    end

    local function resolve_map_object_display_name(map_object_id)
        map_object_id = usable_id(map_object_id)
        if map_object_id == nil then return nil, "" end

        local ui_utility = get_ui_utility()
        local world = get_world()
        if not is_valid_object(ui_utility) or not is_valid_object(world) then
            return nil, ""
        end

        local output = {}
        local name_ok = pcall(function()
            ui_utility:GetMapObjectName(
                world, FName(map_object_id), output
            )
        end)
        local localized_name = output.outName or output.OutName
        local localized_label = usable_id(localized_name)
        if name_ok and localized_name ~= nil
            and localized_label ~= nil then
            return localized_name, localized_label
        end
        return nil, ""
    end

    local function resolve_build_map_object_id(build_object_id)
        build_object_id = usable_id(build_object_id)
        if build_object_id == nil then return nil end

        mode.hud_build_map_id_cache = mode.hud_build_map_id_cache or {}
        local cached = mode.hud_build_map_id_cache[build_object_id]
        if cached ~= nil then
            if cached == false then return nil end
            return cached
        end

        local utility = unwrap(StaticFindObject(
            "/Script/Pal.Default__PalMasterDataTablesUtility"
        ))
        local world = get_world()
        if not is_valid_object(utility) or not is_valid_object(world) then
            return nil
        end

        local map_object_id = nil
        pcall(function()
            local data_table = unwrap(
                utility:GetBuildObjectDataTable(world)
            )
            local row = unwrap(data_table:FindRow(build_object_id))
            map_object_id = usable_id(safe_property(row, "MapObjectId"))
        end)
        mode.hud_build_map_id_cache[build_object_id] =
            map_object_id or false
        return map_object_id
    end

    function mode.resolve_build_object_display_name(
        build_object_id, map_object_id)
        build_object_id = usable_id(build_object_id)
        map_object_id = usable_id(map_object_id)
            or resolve_build_map_object_id(build_object_id)

        mode.hud_display_name_cache =
            mode.hud_display_name_cache or {}
        local cache_key = tostring(build_object_id or "")
            .. "|" .. tostring(map_object_id or "")
        local cached_label =
            mode.hud_display_name_cache[cache_key]
        if cached_label ~= nil then
            return FText(cached_label), cached_label
        end

        local localized_name, localized_label =
            resolve_map_object_display_name(map_object_id)
        if localized_label ~= "" then
            mode.hud_display_name_cache[cache_key] =
                localized_label
            return FText(localized_label), localized_label
        end

        local fallback = build_object_id or map_object_id
        if fallback == nil then return nil, "" end
        mode.hud_display_name_cache[cache_key] = fallback
        return FText(fallback), fallback
    end

    local function resolve_character_display_name(target)
        local parameter_component = nil
        local individual_parameter = nil
        local character_id = nil
        pcall(function()
            parameter_component = unwrap(
                target:GetCharacterParameterComponent()
            )
            individual_parameter = unwrap(
                parameter_component:GetIndividualParameter()
            )
            character_id = usable_id(
                individual_parameter:GetCharacterID()
            )
        end)
        if character_id == nil then return nil, "" end

        local database = unwrap(StaticFindObject(
            "/Script/Pal.Default__PalDatabaseCharacterParameter"
        ))
        if not is_valid_object(database) then return nil, "" end

        local output = {}
        local name_ok = pcall(function()
            database:GetLocalizedCharacterName(
                FName(character_id), output
            )
        end)
        local localized_name = output.OutText or output.outText
        local localized_label = usable_id(localized_name)
        if name_ok and localized_name ~= nil
            and localized_label ~= nil then
            return localized_name, localized_label
        end
        return nil, ""
    end

    function mode.resolve_target_display_name(target)
        if type(target) == "table"
            and (
                target.build_object_id ~= nil
                or target.map_object_master_data_id ~= nil
            ) then
            return mode.resolve_build_object_display_name(
                target.build_object_id,
                target.map_object_master_data_id
            )
        end
        target = unwrap(target)
        if not is_valid_object(target) then return nil, "" end

        local model = nil
        pcall(function() model = unwrap(target:GetModel()) end)
        if is_valid_object(model) then
            local localized_name, localized_label =
                mode.resolve_build_object_display_name(
                    safe_property(model, "BuildObjectId"),
                    safe_property(model, "MapObjectMasterDataId")
                )
            if localized_label ~= "" then
                return localized_name, localized_label
            end
        end

        local localized_name, localized_label =
            resolve_character_display_name(target)
        if localized_label ~= "" then
            return localized_name, localized_label
        end
        return nil, ""
    end

    function mode.clear_hud_target_name_handle()
        -- This direct Widget reference is owned only by the active selection
        -- HUD session. HUD teardown and World abandonment both call this
        -- function, so the hot path never has to trade lifecycle safety for a
        -- full-path StaticFindObject on every ray-target transition.
        mode.hud_target_name_widget = nil
        mode.hud_target_name_handle = nil
        mode.hud_target_display_key = nil
    end

    function mode.prepare_hud_target_name(explicit_hud)
        local hud = unwrap(explicit_hud)
        if not is_valid_object(hud) then
            hud = unwrap(get_hud_widget())
        end
        if not is_valid_object(hud) then
            return false, "selection HUD is unavailable"
        end

        local name_widget = nil
        if find_in_instance ~= nil then
            name_widget = find_in_instance(
                hud, TARGET_NAME_WIDGET
            )
        end
        name_widget = unwrap(name_widget)
        if not is_valid_object(name_widget) then
            if not mode.hud_name_widget_diagnostic_emitted then
                mode.hud_name_widget_diagnostic_emitted = true
                log("blueprint selection HUD target-name widget unavailable "
                    .. "name=" .. TARGET_NAME_WIDGET)
            end
            return false, "target-name widget is unavailable"
        end

        local handle = make_runtime_object_handle(name_widget)
        if handle == nil then
            return false, "target-name widget handle is unavailable"
        end
        mode.hud_target_name_widget = name_widget
        mode.hud_target_name_handle = handle
        mode.hud_target_display_key = nil
        return true, nil
    end

    local function resolve_target_name_widget(explicit_hud)
        local name_widget = unwrap(mode.hud_target_name_widget)
        if is_valid_object(name_widget) then return name_widget end
        mode.hud_target_name_widget = nil

        -- A path handle is a cold recovery mechanism, not a hot-path lookup.
        -- It is consulted only if the session-owned direct Widget reference
        -- became unavailable unexpectedly.
        if mode.hud_target_name_handle ~= nil then
            name_widget = unwrap(resolve_runtime_object_handle(
                mode.hud_target_name_handle
            ))
            if is_valid_object(name_widget) then
                mode.hud_target_name_widget = name_widget
                return name_widget
            end
        end
        local prepared = mode.prepare_hud_target_name(explicit_hud)
        if not prepared then return nil end
        name_widget = unwrap(mode.hud_target_name_widget)
        if is_valid_object(name_widget) then return name_widget end
        return nil
    end

    local function target_display_key(target, label)
        if type(target) == "table"
            and (
                target.build_object_id ~= nil
                or target.map_object_master_data_id ~= nil
            ) then
            return tostring(target.build_object_id or "")
                .. "|" .. tostring(
                    target.map_object_master_data_id or ""
                )
        end
        if target == nil then return "<none>" end
        return tostring(label or "")
    end

    function mode.update_hud_target_name(target, source, explicit_hud)
        local display_key = target_display_key(target, nil)
        local stable_key = target == nil or (
            type(target) == "table" and (
                target.build_object_id ~= nil
                or target.map_object_master_data_id ~= nil
            )
        )
        -- Selection target identities already contain a stable display key.
        -- Reject same-label transitions before touching the Widget or any
        -- runtime object handle.
        if stable_key and display_key == mode.hud_target_display_key then
            return true, false
        end
        local display_text, display_label =
            mode.resolve_target_display_name(target)
        if type(target) ~= "table" then
            display_key = target_display_key(target, display_label)
            if display_key == mode.hud_target_display_key then
                return true, false
            end
        end
        local name_widget = resolve_target_name_widget(explicit_hud)
        if not is_valid_object(name_widget) then return false end
        local write_ok, write_error = pcall(function()
            name_widget:SetText(display_text or FText(""))
        end)
        if not write_ok then
            log("blueprint selection HUD target-name update failed source="
                .. tostring(source) .. " error=" .. tostring(write_error))
            return false
        end
        mode.hud_target_display_key = display_key
        return true, true
    end

    return mode
end

return BlueprintSelectionHUDData

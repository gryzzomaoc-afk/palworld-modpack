local BlueprintStockItemIcon = {}

local ICON_PACKAGE_PATH =
    "/Game/Pal/Blueprint/UI/Thumbnails/Item/WBP_PalCommonItemIcon"
local ICON_CLASS_PATH = ICON_PACKAGE_PATH .. ".WBP_PalCommonItemIcon_C"

function BlueprintStockItemIcon.install(mode, deps)
    assert(type(mode) == "table", "stock item icon requires mode")
    assert(type(deps) == "table", "stock item icon requires deps")

    local UEHelpers = assert(deps.UEHelpers, "UEHelpers is required")
    local log = assert(deps.log, "log is required")
    local unwrap = assert(deps.unwrap, "unwrap is required")
    local is_valid_object = assert(
        deps.is_valid_object, "is_valid_object is required"
    )
    local is_usable_class_object = assert(
        deps.is_usable_class_object, "is_usable_class_object is required"
    )
    local safe_property = assert(deps.safe_property, "safe_property is required")
    local object_name = assert(deps.object_name, "object_name is required")
    local get_player_controller = assert(
        deps.get_player_controller, "get_player_controller is required")

    local load_error_emitted = false

    local function load_icon_class()
        local icon_class = unwrap(StaticFindObject(ICON_CLASS_PATH))
        if is_usable_class_object(icon_class) then return icon_class end

        local load_ok, load_result = pcall(LoadAsset, ICON_PACKAGE_PATH)
        icon_class = unwrap(StaticFindObject(ICON_CLASS_PATH))
        if is_usable_class_object(icon_class) then return icon_class end

        local returned = unwrap(load_result)
        if load_ok and is_usable_class_object(returned) then
            icon_class = returned
            return icon_class
        end

        local generated_class = nil
        if load_ok and is_valid_object(returned) then
            generated_class = unwrap(safe_property(returned, "GeneratedClass"))
            if is_usable_class_object(generated_class) then
                icon_class = generated_class
                return icon_class
            end
        end

        if not load_error_emitted then
            load_error_emitted = true
            log(string.format(
                "stock item icon class unavailable loadOk=%s result=%s",
                tostring(load_ok), object_name(returned)
            ))
        end
        return nil
    end

    local function find_existing(placeholder)
        placeholder = unwrap(placeholder)
        if not is_valid_object(placeholder) then return nil end
        local parent = nil
        pcall(function() parent = unwrap(placeholder:GetParent()) end)
        if not is_valid_object(parent) then return nil end
        local count = 0
        pcall(function() count = tonumber(parent:GetChildrenCount()) or 0 end)
        for index = 0, count - 1 do
            local child = nil
            pcall(function()
                child = unwrap(parent:GetChildAt(index))
            end)
            if is_valid_object(child) then
                local class_name = tostring(object_name(child))
                if string.find(
                    class_name,
                    "WBP_PalCommonItemIcon_C",
                    1,
                    true
                ) then
                    return child
                end
            end
        end
        return nil
    end

    local function create(placeholder)
        placeholder = unwrap(placeholder)
        if not is_valid_object(placeholder) then
            return nil, "authored icon placeholder is unavailable"
        end

        local parent = nil
        pcall(function() parent = unwrap(placeholder:GetParent()) end)
        local placeholder_slot = unwrap(safe_property(placeholder, "Slot"))
        local class = load_icon_class()
        local widget_library = unwrap(StaticFindObject(
            "/Script/UMG.Default__WidgetBlueprintLibrary"
        ))
        local player_controller = unwrap(get_player_controller())
        if not is_valid_object(player_controller) then
            player_controller = unwrap(UEHelpers.GetPlayerController())
        end
        if not is_valid_object(parent)
            or not is_valid_object(placeholder_slot)
            or not is_usable_class_object(class)
            or not is_valid_object(widget_library)
            or not is_valid_object(player_controller) then
            return nil, "stock item icon dependencies are unavailable"
        end

        local icon = nil
        local create_ok, create_error = pcall(function()
            icon = unwrap(widget_library:Create(
                player_controller, class, player_controller
            ))
        end)
        if not create_ok or not is_valid_object(icon) then
            return nil, "stock item icon CreateWidget failed: "
                .. tostring(create_error)
        end

        local attach_ok, attach_error = pcall(function()
            local layout = placeholder_slot:GetLayout()
            local z_order = tonumber(placeholder_slot:GetZOrder()) or 0
            local icon_slot = parent:AddChildToCanvas(icon)
            icon_slot:SetLayout(layout)
            icon_slot:SetZOrder(z_order + 10)
        end)
        if not attach_ok then
            pcall(function() icon:RemoveFromParent() end)
            return nil, "stock item icon attachment failed: "
                .. tostring(attach_error)
        end

        log("stock item icon attached widget=" .. object_name(icon)
            .. " parent=" .. object_name(parent))
        return icon, nil
    end

    local function setup(placeholder, icon, item_id)
        icon = unwrap(icon)
        if not is_valid_object(icon) then
            icon = find_existing(placeholder)
        end
        if not is_valid_object(icon) then
            local create_error = nil
            icon, create_error = create(placeholder)
            if not is_valid_object(icon) then return nil, create_error end
        end

        local setup_ok, setup_error = pcall(function()
            icon:Setup(FName(tostring(item_id)))
        end)
        if not setup_ok then
            return nil, "stock item icon Setup failed: " .. tostring(setup_error)
        end
        return icon, nil
    end

    return {
        setup = setup,
    }
end

return BlueprintStockItemIcon

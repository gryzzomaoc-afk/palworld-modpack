local BlueprintWaterBuildingGate = {}

local WATER_BUILD_KIT_ID = "WaterBuildKit"

function BlueprintWaterBuildingGate.install(deps)
    assert(type(deps) == "table",
        "BlueprintWaterBuildingGate.install requires deps")
    local UEHelpers = assert(deps.UEHelpers,
        "BlueprintWaterBuildingGate requires UEHelpers")
    local unwrap = assert(deps.unwrap,
        "BlueprintWaterBuildingGate requires unwrap")
    local is_valid_object = assert(deps.is_valid_object,
        "BlueprintWaterBuildingGate requires is_valid_object")
    local value_to_string = assert(deps.value_to_string,
        "BlueprintWaterBuildingGate requires value_to_string")
    local find_object = assert(deps.find_object,
        "BlueprintWaterBuildingGate requires find_object")
    local make_name = assert(deps.make_name,
        "BlueprintWaterBuildingGate requires make_name")

    local function capture()
        local controller = unwrap(UEHelpers.GetPlayerController())
        if not is_valid_object(controller) then
            return {
                available = false,
                unlocked = false,
                count = 0,
                error = "player controller unavailable",
            }
        end

        local utility = unwrap(find_object("/Script/Pal.Default__PalUtility"))
        if not is_valid_object(utility) then
            return {
                available = false,
                unlocked = false,
                count = 0,
                error = "PalUtility unavailable",
            }
        end

        local inventory = nil
        local lookup_ok, lookup_error = pcall(function()
            inventory = unwrap(utility:GetLocalInventoryData(controller))
        end)
        if not lookup_ok or not is_valid_object(inventory) then
            return {
                available = false,
                unlocked = false,
                count = 0,
                error = "local inventory unavailable: "
                    .. tostring(lookup_error),
            }
        end

        local count = nil
        local count_ok, count_error = pcall(function()
            count = inventory:CountItemNum(make_name(WATER_BUILD_KIT_ID))
        end)
        count = count_ok and tonumber(value_to_string(count)) or nil
        if count == nil then
            return {
                available = false,
                unlocked = false,
                count = 0,
                error = "WaterBuildKit count unavailable: "
                    .. tostring(count_error),
            }
        end

        count = math.max(0, count)
        return {
            available = true,
            unlocked = count > 0,
            count = count,
            item_id = WATER_BUILD_KIT_ID,
        }
    end

    return {
        capture = capture,
        item_id = WATER_BUILD_KIT_ID,
    }
end

return BlueprintWaterBuildingGate

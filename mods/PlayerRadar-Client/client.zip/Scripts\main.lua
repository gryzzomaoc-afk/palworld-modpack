-- PlayerRadar-Client v1.0.0
-- 2026-08-02 CrazyChips.
--
-- Reads the JSON snapshot PlayerRadar-Server wrote, plus a local
-- FindAllOf fallback for replicated players. Renders in-game map
-- markers, a log-side player list, and supports teleport via hotkey
-- (T) or console command (pradar tp <idx>).
--
-- Hotkeys (listen-server / single-player only):
--   M : refresh in-game map markers + log the player list
--   T : teleport local pawn to ~200 cm behind the nearest other player
--
-- Console commands (in-game chat console):
--   pradar list                -- show list
--   pradar tp <idx> <x> <y> <z> -- teleport player #idx to coords
--   pradar bring <idx>         -- teleport local pawn to player #idx
--   pradar refresh             -- re-read server JSON + rebuild markers
--   pradar help                -- show this text
--
-- Friend-friendly: if the server JSON can't be read (e.g. the friend
-- is not the admin and has no access to the share), the mod falls back
-- to FindAllOf("PalPlayerCharacter"), so friends still see nearby players.

local CONFIG = require("config")

local PREFIX = "[PlayerRadar-Client]"

-- ---------------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------------
local function log(msg)
    print(string.format("%s %s\n", PREFIX, tostring(msg)))
end

local function is_valid(obj)
    if obj == nil then return false end
    local ok, v = pcall(function() return obj:IsValid() end)
    return ok and v == true
end

local function pcall_call(fn, ...)
    local args = { ... }
    return pcall(function() return fn(unpack(args)) end)
end

local function fmt_loc(x, y, z)
    return string.format("(%d, %d, %d)", math.floor(x + 0.5), math.floor(y + 0.5), math.floor(z + 0.5))
end

-- ---------------------------------------------------------------------------
-- Local pawn
-- ---------------------------------------------------------------------------
local function get_local_pawn()
    local ok, ctrl = pcall_call(FindFirstOf, "PalPlayerController")
    if not ok or not is_valid(ctrl) then return nil end
    local ok2, pawn = pcall(function() return ctrl:GetPawn() end)
    if not ok2 or not is_valid(pawn) then return nil end
    return pawn
end

-- ---------------------------------------------------------------------------
-- Player list (two sources, server JSON preferred)
-- ---------------------------------------------------------------------------
-- Cached snapshot of the most recent server read. Each entry:
--   { name=string, x=number, y=number, z=number, source="server"|"local" }
local cached_players = {}
local cached_source = "none"      -- "server" | "local" | "none"
local cached_ts = nil             -- server-side timestamp from JSON

local function read_server_json()
    local path = CONFIG.server_json_path
    if not path or path == "" then return nil, "no server_json_path" end
    local ok, data = pcall(function()
        local f = io.open(path, "r")
        if not f then return nil end
        local s = f:read("*a")
        f:close()
        return s
    end)
    if not ok or not data or data == "" then
        return nil, "cannot read file"
    end
    -- Minimal JSON parser: we only need the players array and the ts
    -- field. We rely on the server mod writing well-formed JSON so we
    -- can use a regex-driven scan instead of a full parser.
    local players = {}
    for name, x, y, z in string.gmatch(data, '"name"%s*:%s*"([^"]+)"%s*,%s*"x"%s*:%s*([%-%d%.]+)%s*,%s*"y"%s*:%s*([%-%d%.]+)%s*,%s*"z"%s*:%s*([%-%d%.]+)') do
        players[#players + 1] = {
            name = name,
            x = tonumber(x) or 0,
            y = tonumber(y) or 0,
            z = tonumber(z) or 0,
            source = "server",
        }
    end
    local ts = tonumber(data:match('"ts"%s*:%s*(%d+)')) or 0
    if #players == 0 then return nil, "no players in file" end
    return players, nil, ts
end

local function get_local_players()
    -- Exclude our own pawn; mirrors server's exclusion semantics.
    local local_pawn = get_local_pawn()
    local out = {}
    local ok, list = pcall_call(FindAllOf, "PalPlayerCharacter")
    if not ok or type(list) ~= "table" then return out end
    for _, p in ipairs(list) do
        if is_valid(p) and p ~= local_pawn then
            local name = "?"
            pcall(function()
                local ps = p:GetPlayerState()
                if is_valid(ps) then
                    local n = ps:GetPlayerName()
                    if n and n ~= "" then name = tostring(n) end
                end
            end)
            local loc = nil
            pcall(function()
                local v = p:K2_GetActorLocation()
                if type(v) == "table" then
                    loc = { X = tonumber(v.X) or 0, Y = tonumber(v.Y) or 0, Z = tonumber(v.Z) or 0 }
                end
            end)
            if loc then
                out[#out + 1] = {
                    name = name,
                    x = loc.X, y = loc.Y, z = loc.Z,
                    source = "local",
                }
            end
        end
    end
    return out
end

local function refresh_player_cache()
    local list, err, ts = read_server_json()
    if list and #list > 0 then
        cached_players = list
        cached_source = "server"
        cached_ts = ts
        return
    end
    -- Fallback to local FindAllOf
    local local_list = get_local_players()
    if #local_list > 0 then
        cached_players = local_list
        cached_source = "local"
        cached_ts = nil
        return
    end
    cached_players = {}
    cached_source = "none"
    cached_ts = nil
    if err then
        log(string.format("refresh: server read failed (%s); no local players either", err))
    end
end

-- ---------------------------------------------------------------------------
-- In-game map markers (simplified from BREEDER map_marks.lua)
-- ---------------------------------------------------------------------------
local map_icons = {}  -- alive icon wrappers from the current refresh

local function get_map_base()
    local base = nil
    pcall(function() base = FindFirstOf("WBP_Map_Base_C") end)
    if not (base and is_valid(base)) then return nil end
    local n = nil
    pcall(function() n = tostring(base:GetFullName()) end)
    if not n or n:find("Default__", 1, true) then return nil end
    return base
end

local function get_map_body(base)
    if not (base and is_valid(base)) then return nil end
    local body = nil
    pcall(function()
        if base.WBP_Map_Body_MW5 and is_valid(base.WBP_Map_Body_MW5) then
            body = base.WBP_Map_Body_MW5
        end
    end)
    return body
end

local function clear_old_icons()
    for _, icon in ipairs(map_icons) do
        pcall(function()
            if is_valid(icon) then icon:RemoveFromParent() end
        end)
    end
    map_icons = {}
end

local function add_player_marker(base, body, p)
    local ok, err = pcall(function()
        local point_class = StaticFindObject("/Script/Pal.PalLocationPoint_LevelObject")
        if not point_class then error("PalLocationPoint_LevelObject class missing") end
        local point = StaticConstructObject(point_class, base)
        if not point then error("location point construction failed") end
        point.InitialLocationCache = { X = p.x, Y = p.y, Z = p.z }
        point.bShouldDisplay = true
        point.bShowInMap = true
        point.bShowInCompass = false

        local setup = base["Setup Icon"]
        if not setup then error("Setup Icon missing on map base") end
        local out = {}
        setup(base, 19, point, out)
        local icon = out[1] or out.Icon
        if not (icon and is_valid(icon)) then
            error("Setup Icon yielded no icon widget")
        end

        pcall(function() icon:SetVisibility(3) end)   -- HitTestInvisible
        pcall(function() icon:SetIsEnabled(true) end)

        local add = body["Add Icon By Location"]
        if not add then error("Add Icon By Location missing") end
        local added = {}
        add(body, icon, { X = p.x, Y = p.y, Z = p.z }, true, false, added)
        if added[1] == false or added.added == false then
            error("map body rejected icon for " .. p.name)
        end
        pcall(function()
            local upd = body["Update Map Icon"]
            if upd then upd(body, icon) end
        end)
        table.insert(map_icons, icon)
    end)
    if not ok then
        log(string.format("marker FAILED for %s: %s", tostring(p.name), tostring(err)))
    end
end

local function refresh_map_markers()
    if #cached_players == 0 then
        log("refresh-markers: no cached players to draw")
        return
    end
    local base = get_map_base()
    if not base then
        log("refresh-markers: no WBP_Map_Base_C widget (is the map open?)")
        return
    end
    local body = get_map_body(base)
    if not body then
        log("refresh-markers: map base has no WBP_Map_Body_MW5")
        return
    end
    clear_old_icons()
    for _, p in ipairs(cached_players) do
        add_player_marker(base, body, p)
    end
    log(string.format("refresh-markers: %d marker(s) drawn", #cached_players))
end

-- ---------------------------------------------------------------------------
-- Operations
-- ---------------------------------------------------------------------------
local function op_list()
    if #cached_players == 0 then
        log("list: no players (cache empty; try M to refresh)")
        return
    end
    log(string.format("list: %d player(s) [source=%s%s]",
        #cached_players, cached_source,
        cached_ts and (string.format(", ts=%d", cached_ts)) or ""))
    for i, p in ipairs(cached_players) do
        log(string.format("  [%d] %-24s %s", i, p.name, fmt_loc(p.x, p.y, p.z)))
    end
end

-- Teleport self to player at cached index.
local function op_bring(idx)
    if idx < 1 or idx > #cached_players then
        log(string.format("bring: index %d out of range (have %d players)", idx, #cached_players))
        return
    end
    local target = cached_players[idx]
    -- The cached list comes from a JSON file or local FindAllOf, so we
    -- don't have a live pawn to operate on.  We use the local pawn to
    -- read the current location, then look up the matching replicated
    -- pawn (by name) to teleport to.  If no match, we just teleport to
    -- the cached coordinates (the user gets close enough to the visible
    -- representation on the map).
    local local_pawn = get_local_pawn()
    if not is_valid(local_pawn) then
        log("bring: no local pawn (dedicated server?)")
        return
    end
    -- Find the live pawn with the matching name.
    local target_pawn = nil
    pcall(function()
        local list = FindAllOf("PalPlayerCharacter") or {}
        for _, p in ipairs(list) do
            if is_valid(p) then
                local n = nil
                pcall(function()
                    local ps = p:GetPlayerState()
                    if is_valid(ps) then n = ps:GetPlayerName() end
                end)
                if n == target.name then
                    target_pawn = p
                    return
                end
            end
        end
    end)
    local new_loc = { X = target.x, Y = target.y, Z = target.z }
    if target_pawn and is_valid(target_pawn) then
        -- Snap to the LIVE pawn's position (server may have moved them
        -- since the last JSON refresh).
        pcall(function()
            local v = target_pawn:K2_GetActorLocation()
            if type(v) == "table" then
                new_loc = { X = tonumber(v.X) or new_loc.X,
                            Y = tonumber(v.Y) or new_loc.Y,
                            Z = tonumber(v.Z) or new_loc.Z }
            end
        end)
        -- Stand slightly behind the target along our current direction
        -- so we don't stack on top.
        local my_loc = nil
        pcall(function()
            local v = local_pawn:K2_GetActorLocation()
            if type(v) == "table" then
                my_loc = { X = tonumber(v.X) or 0, Y = tonumber(v.Y) or 0, Z = tonumber(v.Z) or 0 }
            end
        end)
        if my_loc then
            local dx, dy = new_loc.X - my_loc.X, new_loc.Y - my_loc.Y
            local len = math.sqrt(dx * dx + dy * dy)
            if len > 0.001 then
                dx, dy = dx / len, dy / len
                new_loc.X = new_loc.X - dx * CONFIG.teleport_offset_back
                new_loc.Y = new_loc.Y - dy * CONFIG.teleport_offset_back
            end
        end
    end
    local ok = pcall(function()
        local_pawn:K2_SetActorLocation(new_loc, false, nil, true)
    end)
    if ok then
        log(string.format("bring: teleported to %s @ %s", target.name, fmt_loc(new_loc.X, new_loc.Y, new_loc.Z)))
    else
        log("bring: K2_SetActorLocation failed (server may have rejected the move)")
    end
end

-- Teleport any pawn to coords (used by 'tp' on the local pawn, and also
-- as a tool — admin can hot-edit a target pawn reference here in the
-- future if needed).
local function op_teleport_self_to_nearest()
    local local_pawn = get_local_pawn()
    if not is_valid(local_pawn) then
        log("teleport: no local pawn (dedicated server?)")
        return
    end
    local my_loc = nil
    pcall(function()
        local v = local_pawn:K2_GetActorLocation()
        if type(v) == "table" then
            my_loc = { X = tonumber(v.X) or 0, Y = tonumber(v.Y) or 0, Z = tonumber(v.Z) or 0 }
        end
    end)
    if not my_loc then
        log("teleport: cannot read local pawn location")
        return
    end
    -- Prefer live local players; fall back to cached if the live
    -- FindAllOf returned nothing (e.g. we're on the same machine as the
    -- server and the only other player is the local admin's alt).
    local players = get_local_players()
    if #players == 0 and #cached_players > 0 then
        -- Use cached positions for the "nearest" calculation only.
        for _, c in ipairs(cached_players) do
            players[#players + 1] = { name = c.name, x = c.x, y = c.y, z = c.z }
        end
    end
    if #players == 0 then
        log("teleport: no other players visible")
        return
    end
    local nearest, nearest_dist = nil, math.huge
    for _, p in ipairs(players) do
        local dx, dy = p.x - my_loc.X, p.y - my_loc.Y
        local d = math.sqrt(dx * dx + dy * dy)
        if d < nearest_dist then nearest, nearest_dist = p, d end
    end
    local dx = nearest.x - my_loc.X
    local dy = nearest.y - my_loc.Y
    local len = math.sqrt(dx * dx + dy * dy)
    if len > 0.001 then dx, dy = dx / len, dy / len else dx, dy, len = 0, 1, 0 end
    local new_loc = {
        X = nearest.x - dx * CONFIG.teleport_offset_back,
        Y = nearest.y - dy * CONFIG.teleport_offset_back,
        Z = nearest.z,
    }
    local ok = pcall(function()
        local_pawn:K2_SetActorLocation(new_loc, false, nil, true)
    end)
    if ok then
        log(string.format("teleport: %s -> behind %s (was %d cm away) at %s",
            fmt_loc(my_loc.X, my_loc.Y, my_loc.Z),
            nearest.name,
            math.floor(nearest_dist),
            fmt_loc(new_loc.X, new_loc.Y, new_loc.Z)))
    else
        log("teleport: K2_SetActorLocation failed (server may have rejected the move)")
    end
end

-- ---------------------------------------------------------------------------
-- Console command
-- ---------------------------------------------------------------------------
local function tokenize(line)
    local tokens = {}
    for tok in string.gmatch(tostring(line or ""), "%S+") do
        tokens[#tokens + 1] = tok
    end
    return tokens
end

local function handle_console_command(line)
    local tokens = tokenize(line)
    local cmd = table.remove(tokens, 1) or ""
    if cmd == "" or cmd == "help" or cmd == "?" then
        log("commands:")
        log(string.format("  %s list                -- show player list", CONFIG.console_command))
        log(string.format("  %s bring <idx>         -- teleport local pawn to player #idx", CONFIG.console_command))
        log(string.format("  %s teleport            -- teleport to nearest other player", CONFIG.console_command))
        log(string.format("  %s refresh             -- re-read server JSON + rebuild markers", CONFIG.console_command))
        log(string.format("  %s help                -- show this text", CONFIG.console_command))
    elseif cmd == "list" then
        op_list()
    elseif cmd == "bring" then
        local idx = tonumber(table.remove(tokens, 1))
        if not idx then
            log("bring: usage: " .. CONFIG.console_command .. " bring <idx>")
            return
        end
        op_bring(idx)
    elseif cmd == "teleport" then
        op_teleport_self_to_nearest()
    elseif cmd == "refresh" then
        refresh_player_cache()
        log(string.format("refresh: %d player(s) from %s", #cached_players, cached_source))
    else
        log(string.format("unknown subcommand: %s (try 'help')", tostring(cmd)))
    end
end

-- ---------------------------------------------------------------------------
-- Hotkey registration
-- ---------------------------------------------------------------------------
local function on_list_hotkey()
    refresh_player_cache()
    op_list()
    refresh_map_markers()
end
local function on_teleport_hotkey()
    op_teleport_self_to_nearest()
end

local function try_register_hotkey(key_name, callback, label)
    local key_const = Key[key_name]
    if not key_const then
        log(string.format("hotkey %s: invalid key name (skipped)", key_name))
        return
    end
    if IsKeyBindRegistered(key_const, {}) then
        log(string.format("hotkey %s: already taken by another mod (skipped)", key_name))
        return
    end
    RegisterKeyBind(key_const, {}, callback)
    log(string.format("hotkey %s: registered (%s)", key_name, label))
end

local console_registered = false
local function try_register_console()
    if console_registered then return end
    local ok = pcall(function()
        RegisterConsoleCommandHandler(CONFIG.console_command, function(cmd_line)
            handle_console_command(cmd_line)
        end)
    end)
    if ok then
        console_registered = true
    else
        log("console: RegisterConsoleCommandHandler not available (hotkeys still work)")
    end
end

-- ---------------------------------------------------------------------------
-- Bootstrap
-- ---------------------------------------------------------------------------
log("v1.0.0 loaded")
log(string.format("server_json_path = %s", tostring(CONFIG.server_json_path)))
try_register_hotkey(CONFIG.list_hotkey, on_list_hotkey, "list + refresh map markers")
try_register_hotkey(CONFIG.teleport_hotkey, on_teleport_hotkey, "teleport to nearest other player")
try_register_console()

-- Initial refresh so the list is ready when the user hits T.
refresh_player_cache()
log(string.format("initial cache: %d player(s) from %s", #cached_players, cached_source))

-- Periodic refresh of the player cache.
do
    local ms = math.floor((CONFIG.refresh_interval_seconds or 1.0) * 1000)
    pcall(function()
        LoopInGameThreadWithDelay(ms, function()
            refresh_player_cache()
        end)
    end)
end

-- Optional periodic map-marker refresh while the map is open.
if CONFIG.map_refresh_interval_seconds and CONFIG.map_refresh_interval_seconds > 0 then
    local ms = math.floor(CONFIG.map_refresh_interval_seconds * 1000)
    pcall(function()
        LoopInGameThreadWithDelay(ms, function()
            refresh_map_markers()
        end)
    end)
end

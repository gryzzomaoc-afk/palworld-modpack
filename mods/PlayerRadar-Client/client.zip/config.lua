-- PlayerRadar-Client config
-- Installed on each player (including the admin's local client). Reads the
-- JSON snapshot PlayerRadar-Server wrote, renders markers on the in-game
-- map, exposes a list, and supports teleport.
return {
    -- Where PlayerRadar-Server writes its JSON snapshot. Default is a
    -- UNC path to a Windows share on the dedicated server; change this
    -- to your setup. The mod re-reads the file every refresh tick, so
    -- there's no need to restart the client when the server updates.
    --
    -- Examples:
    --   "\\\\192.168.1.112\\palradar$\\positions.json"   -- UNC share
    --   "C:\\palradar\\positions.json"                     -- same machine
    --   ""                                                  -- disable server read
    server_json_path = "\\\\192.168.1.112\\palradar$\\positions.json",

    -- How often the client re-reads the server JSON (seconds).
    refresh_interval_seconds = 1.0,

    -- How often the client refreshes the in-game map markers (seconds).
    -- 0 = only refresh on M press. Note: high frequency (e.g. <0.5s)
    -- may flicker on some Palworld builds.
    map_refresh_interval_seconds = 0,

    -- How often the client polls the local FindAllOf fallback (seconds).
    -- Only used when the server JSON can't be read.
    local_poll_interval_seconds = 2.0,

    -- Hotkey: refresh the in-game map markers + list (listen-server /
    -- single-player only — dedicated servers have no keyboard input).
    list_hotkey = "M",

    -- Hotkey: teleport local pawn to ~200 cm behind the nearest other
    -- player. Uses local FindAllOf (not the server JSON) so the
    -- teleport target is always a pawn we can actually reach.
    teleport_hotkey = "T",

    -- Units behind the target to stand (cm). Default 200 = 2 m.
    teleport_offset_back = 200.0,

    -- Console command (in-game or server console) for the same operations.
    console_command = "pradar",
}

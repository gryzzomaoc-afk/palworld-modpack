-- map_marks.lua — world-map habitat markers for one missing pal species (V1).
-- Design: docs/栖息地地图标记-设计.md v2 (codex round-1 findings folded in).
-- Channel recipe follows Statue Map Markers v1.1.8 (proven on Palworld 1.0):
--   PalLocationPoint_LevelObject -> mapBase["Setup Icon"] (icon captured via
--   the SetLocationData hook) -> icon brush swap -> mapBody["Add Icon By
--   Location"] -> mapBody["Update Map Icon"] -> inner-Image scale.
-- Read-only by construction: builds client-side widgets over the map UI,
-- never touches saves/server state.
--
-- Lifecycle discipline (repo memory, hard rules):
--   * generation-gated callbacks: every deferred action captures state.gen
--     and re-checks it before touching anything
--   * cached UObject wrappers are lookup keys ONLY; before any dereference
--     the object is re-resolved through FindAllOf full-name matching
--   * the build/zoom ticker is a sync.lua-discipline LoopAsync: in-flight
--     latch, 5s fail-closed breaker, two-phase park; runs only while a
--     species is marked, parks to zero threads on clear
--   * texture wrappers live for one map session only (stale brush = white
--     square / render crash)

local M = {}

local data = require("data")
local uehelpers_ok, UEHelpers = pcall(require, "UEHelpers")

local function log(msg)
    print(string.format("[BreedingHelper.marks] %s\n", tostring(msg)))
end

-- on-screen toast via the game's system-announce channel (plain FString
-- params only; renders CJK with the game font — main.lua proven recipe)
-- DISABLED in-game announce (CrazyChips 2026-08-01: per user request,
-- suppress all on-screen system messages from BreedingHelper). Log only.
function M.screen_msg(text)
    log(text)
end

M.state = {
    gen = 0,               -- monotonic mark-session generation
    species = nil,         -- marked species id, nil = idle
    marks = nil,           -- data.capture[species].marks reference
    zh = nil,              -- display name for status text
    entries = {},          -- {icon_name=, base_scale=, night=}
    map_session = nil,     -- mapBase fullname .. "|" .. mapBody fullname
    build_idx = 1,
    tex = nil,             -- icon texture wrapper (current map session only)
    tex_tried = 0,
    probe_name = nil,      -- one entry icon full name, light-probed each beat
    compass_marker_id = nil, -- official custom-marker guid (compass companion)
    compass_ok = nil,        -- last mark's companion placement verdict
    base_map_scale = 1.0,
    last_scale = nil,
    fail_count = 0,
    -- ticker (sync.lua discipline)
    ticker_armed = false,
    tick_inflight = false,
    tick_inflight_since = 0,
    tick_gen = 0,
    disabled = false,
}

local ICON_CLASSES = { "WBP_Map_IconSupply_C", "PalUIWorldMapIcon" }
local BUILD_BATCH = 8
local NIGHT_OPACITY = 0.62

-- px at initial zoom. Owner-tuned twice (28 too small, 56 too big) and now
-- player-configurable from the settings page; ui.lua pushes the persisted
-- choice through set_icon_size at load and on click.
M.icon_size = 38

function M.set_icon_size(px)
    px = tonumber(px)
    if not px or px < 8 or px > 128 or px == M.icon_size then return end
    local old = M.icon_size
    M.icon_size = px
    local st = M.state
    -- live icons carry base_scale = icon_size/designed: rescale in place and
    -- let the next ticker zoom pass push the new size to the widgets
    for _, e in ipairs(st.entries) do
        e.base_scale = e.base_scale * (px / old)
    end
    st.last_scale = nil
end

-- ---------------------------------------------------------------------------
-- small helpers (SMM-derived, pcall-armored)
-- ---------------------------------------------------------------------------

local function is_valid(o)
    if not o then return false end
    local ok, v = pcall(function() return o:IsValid() end)
    return ok and v == true
end

-- Hook/BP-call values may arrive as RemoteUnrealParam wrappers on this UE4SS
-- build; :IsValid()/GetClass() on the wrapper throws (swallowed by pcall) and
-- the candidate silently fails. SMM-proven order: :Get() -> :get() -> as-is.
local function unwrap(value)
    if value == nil then return nil end
    local ok, result = pcall(function() return value:Get() end)
    if ok and result then return result end
    ok, result = pcall(function() return value:get() end)
    if ok and result then return result end
    return value
end

local function full_name(o)
    local name = nil
    pcall(function() name = tostring(o:GetFullName()) end)
    return name
end

local function as_number(v)
    if v == nil then return nil end
    local ok, r = pcall(function() return v:get() end)
    if ok then
        local n = tonumber(r)
        if n then return n end
    end
    return tonumber(v)
end

-- live-object map for our icon classes; the ONLY gate that authorizes
-- touching a cached entry (repo rule: FindAllOf full-name matching)
local function resolve_alive_icons()
    local alive = {}
    for _, cls in ipairs(ICON_CLASSES) do
        pcall(function()
            for _, o in ipairs(FindAllOf(cls) or {}) do
                if is_valid(o) then
                    local n = full_name(o)
                    if n then alive[n] = o end
                end
            end
        end)
    end
    return alive
end

local function find_map_base()
    local base = nil
    pcall(function() base = FindFirstOf("WBP_Map_Base_C") end)
    if not base or not is_valid(base) then return nil end
    local n = full_name(base)
    if not n or n:find("Default__", 1, true) then return nil end
    return base, n
end

-- Palworld pools/pre-creates the map widget; running Setup Icon against the
-- HIDDEN instance does not go through full icon init (SMM v1.2.x learned the
-- same lesson: gate on actual visibility). Build/reattach/zoom only while
-- the map is really on screen; pending state survives until then.
local function is_map_open(base)
    local open = false
    pcall(function() if base:IsVisible() == true then open = true end end)
    if not open then
        pcall(function() if base:IsInViewport() == true then open = true end end)
    end
    return open
end

-- World anchor: the local player controller full name. Controllers are
-- rebuilt on every world/save switch but survive in-world respawns (pawns
-- do not — never anchor on the character). When the anchor vanishes from
-- the live set for two consecutive ticks, the marks belong to a dead world:
-- drop to unmarked. This covers the "marked but never opened the map, then
-- switched saves" window that the probe icon cannot see.
local function anchor_alive(name)
    if not name then return true end   -- no anchor recorded: cannot judge
    local found = false
    pcall(function()
        for _, o in ipairs(FindAllOf("PalPlayerController") or {}) do
            if is_valid(o) and full_name(o) == name then
                found = true
                return
            end
        end
    end)
    return found
end

-- Palworld 1.0 keeps overworld + World Tree bodies in one map widget; ask
-- for the displayed body when possible (SMM: GetCurrentMapBody, result in
-- the out-param or a return slot), fall back to the overworld body. Our
-- marks are overworld-only, so a non-overworld body builds nothing.
local function find_map_body(base)
    local body = nil
    pcall(function()
        local get_body = base["GetCurrentMapBody"]
        if not get_body then return end
        local out = {}
        local r1, r2, r3 = get_body(base, out)
        -- explicit slots, NOT ipairs: a nil in an early slot must not hide a
        -- valid UObject in a later one (SMM extractMapBody lesson)
        local cands = { out[1], out.MapBody, r1, r2, r3 }
        for i = 1, 5 do
            local cand = cands[i]
            if cand and is_valid(cand) then body = cand return end
        end
    end)
    if not body or not is_valid(body) then
        body = nil
        pcall(function() body = base.WBP_Map_Body_MW5 end)
    end
    if not body or not is_valid(body) then return nil end
    return body, full_name(body)
end

local function read_map_scale(body)
    local s = nil
    pcall(function() s = as_number(body.CachedMapScale) end)
    if s and s > 0 then return s end
    return nil
end

-- ---------------------------------------------------------------------------
-- icon capture hook: Setup Icon initializes the widget synchronously through
-- SetLocationData; capturing there works on UE4SS builds that cannot read
-- Blueprint out-params. Registered ONCE at module load (never re-registered).
-- ---------------------------------------------------------------------------

local pending_point = false
local captured_icon = nil
local hook_fires = 0

-- Installed lazily on the FIRST mark_species call (perf audit 2026-07-24):
-- an always-on hook makes every SetLocationData call in the game cross the
-- C++/Lua boundary, and most players never touch habitat marks — they should
-- pay zero. Once installed it stays for the session (unregistration is not
-- trusted on this UE4SS build); that residual cost lands on feature users
-- only. Install failure is non-fatal: create_icon still has its five other
-- capture candidates, same as the old load-time failure path.
local hook_state = nil   -- nil = never tried, true = installed, false = failed

local function ensure_capture_hook()
    if hook_state ~= nil then return hook_state end
    local ok, err = pcall(function()
        RegisterHook("/Script/Pal.PalUIWorldMapIcon:SetLocationData",
            function() end,
            function(self)
                hook_fires = hook_fires + 1
                if not pending_point then return end
                local icon = unwrap(self)
                if icon and is_valid(icon) then captured_icon = icon end
            end)
    end)
    hook_state = (ok == true)
    if hook_state then
        log("hook installed: PalUIWorldMapIcon:SetLocationData")
    else
        log("hook FAILED (SetLocationData): " .. tostring(err))
    end
    return hook_state
end

-- ---------------------------------------------------------------------------
-- texture: resolved per map session; never cached across sessions
-- ---------------------------------------------------------------------------

local function resolve_species_texture(species)
    local pal = nil
    for _, p in ipairs(data.pals) do
        if p.id == species then pal = p break end
    end
    if not pal or not pal.ic then return nil, "no icon path for " .. tostring(species) end
    local pkg = pal.ic                      -- /Game/..../T_X_icon_normal
    local asset = pkg:match("([^/]+)$")
    local path = pkg .. "." .. asset
    local tex = nil
    pcall(function() tex = StaticFindObject(path) end)
    if not (tex and is_valid(tex)) then
        tex = nil
        pcall(function()
            LoadAsset(path)
            tex = StaticFindObject(path)
        end)
    end
    if tex and is_valid(tex) then return tex end
    return nil, "texture not found: " .. path
end

-- ---------------------------------------------------------------------------
-- build one native icon (SMM v1.1.8 recipe)
-- ---------------------------------------------------------------------------

local point_class = nil

local function create_icon(base, body, mark, tex)
    return pcall(function()
        point_class = point_class or
            StaticFindObject("/Script/Pal.PalLocationPoint_LevelObject")
        if not point_class then error("PalLocationPoint_LevelObject class missing") end

        local point = StaticConstructObject(point_class, base)
        if not point then error("location point construction failed") end
        point.InitialLocationCache = { X = mark.wx, Y = mark.wy, Z = mark.wz or 0.0 }
        point.bShouldDisplay = true
        point.bShowInMap = true
        point.bShowInCompass = false

        local setup = base["Setup Icon"]
        if not setup then error("Setup Icon missing") end
        pending_point = true
        captured_icon = nil
        local fires_before = hook_fires
        local out = {}
        local r1, r2, r3 = setup(base, 19, point, out)
        pending_point = false

        local icon = nil
        -- explicit slots, NOT ipairs (a nil early slot must not hide later
        -- ones); every candidate is unwrapped before validation
        local cands = { captured_icon, r1, r2, r3, out[1], out.Icon }
        for i = 1, 6 do
            local cand = unwrap(cands[i])
            if cand and is_valid(cand) then
                local cls = ""
                pcall(function() cls = tostring(cand:GetClass():GetFullName()) end)
                if cls:find("PalUIWorldMapIcon", 1, true)
                    or cls:find("WBP_Map_IconSupply", 1, true) then
                    icon = cand
                    break
                end
            end
        end
        if not icon then
            -- diagnostic detail: which slots held anything, and did the
            -- capture hook fire during the synchronous Setup Icon call
            local parts = {}
            for i = 1, 6 do
                local cand = cands[i]
                if cand ~= nil then
                    local desc = "?"
                    pcall(function() desc = tostring(cand) end)
                    local u = unwrap(cand)
                    if u and u ~= cand then
                        pcall(function()
                            desc = desc .. "->" .. tostring(u)
                        end)
                    end
                    parts[#parts + 1] = i .. ":" .. desc:sub(1, 70)
                end
            end
            error(string.format(
                "Setup Icon yielded no icon widget (hook_fired=%s cands={%s})",
                tostring(hook_fires > fires_before),
                table.concat(parts, " | ")))
        end

        local image = nil
        pcall(function() image = icon.Icon end)
        if not (image and is_valid(image)) then error("icon has no inner Image") end
        local bok = pcall(function() image:SetBrushFromTexture(tex, false) end)
        if not bok then error("SetBrushFromTexture failed") end

        pcall(function() icon.bEnableHideOnZoom = false end)
        pcall(function() icon.IgnoreMask = true end)
        pcall(function() icon:SetIgnoreMask(true) end)
        pcall(function() icon:SetGeneralHiding(false) end)

        local add = body["Add Icon By Location"]
        if not add then error("Add Icon By Location missing") end
        local added = {}
        add(body, icon, { X = mark.wx, Y = mark.wy, Z = mark.wz or 0.0 }, true, false, added)
        if added[1] == false or added.added == false then
            error("map body rejected icon")
        end
        -- re-apply the current map transform: the game only calls this on
        -- zoom changes, so a pooled map reopened at a retained zoom step
        -- would otherwise show the icon at a stale size/position
        pcall(function()
            local upd = body["Update Map Icon"]
            if upd then upd(body, icon) end
        end)

        -- the game's zoom pass overwrites the root widget transform; scale
        -- the inner Image only (SMM-measured: root SetRenderScale is futile)
        local base_scale = 1.0
        pcall(function()
            image:ForceLayoutPrepass()
            local d = image:GetDesiredSize()
            local designed = math.max(tonumber(d.X) or 0, tonumber(d.Y) or 0)
            if designed <= 0 then designed = 64 end
            base_scale = M.icon_size / designed
            image:SetRenderTransformPivot({ X = 0.5, Y = 0.5 })
            image:SetRenderScale({ X = base_scale, Y = base_scale })
        end)
        pcall(function() icon:SetVisibility(3) end)   -- HitTestInvisible
        pcall(function() icon:SetIsEnabled(true) end)
        local night = (mark.t == 1)
        pcall(function() icon:SetRenderOpacity(night and NIGHT_OPACITY or 1.0) end)

        return {
            icon_name = full_name(icon),
            base_scale = base_scale,
            night = night,
            -- carried for reattach: entries and marks lose index alignment
            -- as soon as one build fails, so never join them by index
            wx = mark.wx, wy = mark.wy, wz = mark.wz or 0.0,
        }
    end)
end

-- ---------------------------------------------------------------------------
-- undo protocol (BLOCKER fix): restore -> unregister -> detach; only objects
-- re-resolved as alive are touched; dead world/map = drop state silently
-- ---------------------------------------------------------------------------

local function undo_entries(reason)
    local st = M.state
    if #st.entries == 0 then
        st.entries = {}
        return 0
    end
    local alive = resolve_alive_icons()
    local base = find_map_base()
    local removed = 0
    for _, e in ipairs(st.entries) do
        local icon = e.icon_name and alive[e.icon_name]
        if icon then
            pcall(function()
                local image = icon.Icon
                if image and is_valid(image) then
                    image:SetRenderScale({ X = e.base_scale, Y = e.base_scale })
                end
            end)
            pcall(function() icon:SetVisibility(1) end)   -- Hidden
            if base then
                pcall(function() base:RemoveWorldMapIcon(icon) end)
            end
            pcall(function() icon:RemoveFromParent() end)
            removed = removed + 1
        end
    end
    st.entries = {}
    log(string.format("undo (%s): removed=%d", tostring(reason), removed))
    return removed
end

local function reset_build_state()
    local st = M.state
    st.entries = {}
    st.map_session = nil
    st.build_idx = 1
    st.tex = nil
    st.tex_tried = 0
    st.probe_name = nil
    st.probe_miss = 0
    st.base_map_scale = 1.0
    st.last_scale = nil
end

-- ---------------------------------------------------------------------------
-- ticker body (game thread): session gate -> build batch -> detach probe ->
-- zoom follow. Every step pcall-armored; errors count toward fail budget.
-- ---------------------------------------------------------------------------

function M._tick()
    local st = M.state
    if not st.species then return end

    -- world-death gate FIRST: must run even when the map widget is gone,
    -- or a dead world's mark state would linger and leak into the next save.
    -- Throttled to one check per 5s (perf audit 2026-07-24): anchor_alive is
    -- a FindAllOf sweep of GUObjectArray, and at the 1s tick cadence it was
    -- the dominant marked-idle cost. Two consecutive misses now mean ~10s
    -- worst-case detection — still well inside a save-switch window, and the
    -- map-session/probe gates independently protect the build paths.
    local now = os.clock()
    if now >= (st.anchor_check_at or 0) then
        st.anchor_check_at = now + 5.0
        if not anchor_alive(st.world_anchor) then
            st.anchor_miss = (st.anchor_miss or 0) + 1
            -- suspicious: recheck fast and keep the shell at full cadence
            -- (codex 2026-07-24: a 5s window after miss #1 let a NEW world's
            -- map open slip past the gate and rebuild the OLD species there)
            st.anchor_check_at = now + 1.0
            st.map_idle = false
            if st.anchor_miss >= 2 then
                log("world anchor gone; clearing marks")
                M.clear("world switched")
            end
            return
        end
        st.anchor_miss = 0
        st.anchor_pending = nil
    end
    -- fail-closed while suspicious: a recorded miss, or a forced re-verify
    -- after a map-session change, blocks every build/reattach/zoom path
    -- until the anchor proves alive again
    if (st.anchor_miss or 0) > 0 or st.anchor_pending then return end

    local base, base_name = find_map_base()
    -- map closed + all icons built = nothing can progress: tell the async
    -- shell to drop to a 3s cadence until the map shows again (perf audit
    -- 2026-07-24 — these early-return beats still paid a FindFirstOf sweep
    -- every second). A pending build keeps the 1s cadence so icons appear
    -- promptly when the player first opens the map.
    if not base then                          -- map never opened yet: wait
        st.map_idle = (st.build_idx > #st.marks)
        return
    end
    if not is_map_open(base) then             -- pooled hidden widget: wait
        st.map_idle = (st.build_idx > #st.marks)
        return
    end
    st.map_idle = false
    local body, body_name = find_map_body(base)
    if not body then return end
    local session = tostring(base_name) .. "|" .. tostring(body_name)

    if st.map_session ~= session then
        -- map (or body canvas) rebuilt: old widgets are gone or foreign.
        -- Undo touches only re-resolved live objects, then rebuild fully.
        undo_entries("map session changed")
        reset_build_state()
        st.map_session = session
        st.base_map_scale = read_map_scale(body) or 1.0
        -- world-hygiene (codex 2026-07-24): a session change is exactly the
        -- moment a NEW world's map may be standing in — force an anchor
        -- verification before anything is rebuilt. One beat of delay for a
        -- benign same-world widget rebuild; the fail-closed gate above eats
        -- the foreign-world case entirely.
        if st.world_anchor then
            st.anchor_check_at = 0
            st.anchor_pending = true
            return
        end
    end

    -- overworld gate: our marks are overworld world-space; when the map
    -- shows another canvas (World Tree body), build nothing this session
    if body_name and not tostring(body_name):find("MW5", 1, true) then return end

    if st.build_idx <= #st.marks then
        if not st.tex then
            if st.tex_tried >= 3 then return end
            st.tex_tried = st.tex_tried + 1
            local tex, terr = resolve_species_texture(st.species)
            if not tex then
                log("texture resolve failed: " .. tostring(terr))
                if st.tex_tried >= 3 then
                    M.clear("texture unavailable")
                end
                return
            end
            st.tex = tex
        end
        local built = 0
        while st.build_idx <= #st.marks and built < BUILD_BATCH do
            local mark = st.marks[st.build_idx]
            st.build_idx = st.build_idx + 1
            local ok, entry = create_icon(base, body, mark, st.tex)
            if ok and entry and entry.icon_name then
                st.entries[#st.entries + 1] = entry
                st.probe_name = entry.icon_name
            else
                st.fail_count = st.fail_count + 1
                if st.fail_count <= 5 then
                    log("icon build failed: " .. tostring(entry))
                end
            end
            built = built + 1
        end
        if st.build_idx > #st.marks then
            log(string.format("marks built: %d/%d (species=%s, failed=%d)",
                #st.entries, #st.marks, tostring(st.species), st.fail_count))
            if #st.entries == 0 then
                -- nothing landed: full rollback to unmarked state
                M.clear("all icon builds failed")
                return
            end
        end
        st.last_scale = nil                    -- fold new icons into zoom pass
    end

    -- detach probe: the map detaches custom widgets on close (SMM v1.2.9);
    -- when our probe icon is alive but unparented, re-register all entries.
    -- When the probe VANISHES from the live-object set (two consecutive
    -- ticks, to ride out transients), the world/map that owned our icons is
    -- gone — same-name world reloads reuse FullNames, so object death is the
    -- reliable epoch signal. Marks do not survive a world: drop to unmarked
    -- (never carry save A's marks into save B).
    -- Cost shape (2.10.x, field report "标记时画面一抽一抽" + codex r1
    -- MAJOR on the first edge-triggered cut): the every-beat CLASS sweep
    -- (FindAllOf over PalUIWorldMapIcon = the game's own hundreds of icons
    -- through GetFullName) was the stutter; a polled close→open edge missed
    -- fast close-open cycles between beats. Final shape: every beat pays
    -- ONE hashed StaticFindObject on the probe's full name; the class sweep
    -- runs only when that light probe reports missing (second opinion
    -- before a miss counts) or unparented (reattach authorization).
    local tick_alive = nil   -- set when a sweep ran this beat (shared with
                             -- the zoom pass below)
    if st.probe_name and st.build_idx > #st.marks then
        local probe = nil
        pcall(function()
            -- GetFullName is "ClassName /Game/...Path" on this build (opus
            -- marker r1 M2, proven by the base_diag log) — StaticFindObject
            -- wants the bare PATH, so strip the class prefix before the
            -- hashed lookup
            local path = st.probe_name:match("%s(.+)$") or st.probe_name
            local o = StaticFindObject(path)
            if o and is_valid(o) then probe = o end
        end)
        if not probe then
            -- a StaticFindObject miss may be a lookup quirk, not object
            -- death: one class sweep as the second opinion before counting.
            -- Log the degradation ONCE — a silently failing light probe
            -- would reinstate the every-beat sweep this fix removed
            if not st.probe_slow_logged then
                st.probe_slow_logged = true
                log("light probe missed; falling back to a class sweep this beat")
            end
            local alive = resolve_alive_icons()
            tick_alive = alive
            probe = alive[st.probe_name]
        else
            st.probe_slow_logged = nil
        end
        if not probe then
            st.probe_miss = (st.probe_miss or 0) + 1
            if st.probe_miss >= 2 then
                log("probe icon gone; world/map torn down")
                M.clear("world torn down")
            end
            return
        end
        st.probe_miss = 0
        if probe then
            local parented = false
            pcall(function() parented = probe:GetParent() ~= nil end)
            if not parented then
                -- reattach needs the full live map (authorization gate for
                -- touching every cached entry) — sweep now if the light
                -- probe path skipped it this beat
                local alive = tick_alive or resolve_alive_icons()
                tick_alive = alive
                local add = nil
                pcall(function() add = body["Add Icon By Location"] end)
                if add then
                    local upd = nil
                    pcall(function() upd = body["Update Map Icon"] end)
                    local reattached = 0
                    for _, e in ipairs(st.entries) do
                        local icon = alive[e.icon_name]
                        if icon then
                            pcall(function()
                                local out = {}
                                add(body, icon, { X = e.wx, Y = e.wy,
                                    Z = e.wz }, true, false, out)
                                if upd then upd(body, icon) end
                                icon:SetVisibility(3)
                                icon:SetRenderOpacity(
                                    e.night and NIGHT_OPACITY or 1.0)
                            end)
                            reattached = reattached + 1
                        end
                    end
                    st.last_scale = nil
                    log("reattached after map close: " .. reattached)
                end
            end
        end
    end

    -- zoom follow (inner Image only)
    local scale = read_map_scale(body)
    if scale and scale ~= st.last_scale and #st.entries > 0 then
        st.last_scale = scale
        local ratio = scale / (st.base_map_scale > 0 and st.base_map_scale or 1.0)
        if ratio < 0.1 then ratio = 0.1 end
        if ratio > 10 then ratio = 10 end
        local mul = ratio ^ 0.5
        local alive = tick_alive or resolve_alive_icons()
        for _, e in ipairs(st.entries) do
            local icon = alive[e.icon_name]
            if icon then
                pcall(function()
                    icon.Icon:SetRenderScale({
                        X = e.base_scale * mul, Y = e.base_scale * mul })
                end)
            end
        end
    end
end

-- ---------------------------------------------------------------------------
-- ticker shell: sync.lua discipline verbatim (in-flight latch, 5s breaker,
-- generation-gated callback, two-phase park). Parks when species is nil.
-- ---------------------------------------------------------------------------

function M._arm_ticker()
    local st = M.state
    if st.ticker_armed then return true end
    if st.disabled then return false end
    st.ticker_armed = true
    local armed = pcall(function()
        LoopAsync(1000, function()
            -- idle back-off: with icons built and the map closed the game-
            -- thread beat is a no-op that still costs an object sweep — post
            -- only every 3rd second until the map reopens (flag written on
            -- the game thread; ≤1 beat of staleness is harmless)
            if st.map_idle and st.species then
                st.idle_skip = ((st.idle_skip or 0) + 1) % 3
                if st.idle_skip ~= 0 then return false end
            end
            if st.tick_inflight then
                if (os.clock() - st.tick_inflight_since) > 5.0 then
                    st.tick_gen = st.tick_gen + 1
                    st.disabled = true
                    st.species = nil
                    st.ticker_armed = false
                    log("ticker DISABLED (game-thread action stuck >5s)")
                    return true
                end
            else
                st.tick_inflight = true
                st.tick_inflight_since = os.clock()
                local mygen = st.tick_gen
                local scheduled = pcall(function()
                    ExecuteInGameThread(function()
                        if st.tick_gen == mygen then
                            pcall(M._tick)
                            st.tick_inflight = false
                        end
                    end)
                end)
                if not scheduled then
                    st.tick_inflight = false
                    st.disabled = true
                    st.species = nil
                    st.ticker_armed = false
                    return true
                end
            end
            -- two-phase park: clear armed, re-check a mark() that slipped in
            if not st.species then
                st.ticker_armed = false
                if st.species then
                    st.ticker_armed = true
                    return false
                end
                log("ticker parked")
                return true
            end
            return false
        end)
    end)
    if not armed then
        st.ticker_armed = false
        log("ticker ARM FAILED")
        return false
    end
    return true
end

-- ---------------------------------------------------------------------------
-- public API (called from ui.lua on the game thread, all pcall-wrapped there)
-- ---------------------------------------------------------------------------

-- returns: "marked" | "cleared" | "empty" | "disabled"
function M.mark_species(species, zh)
    local st = M.state
    if st.disabled then return "disabled" end
    if st.species == species then
        M.clear("toggle")
        return "cleared"
    end
    local cap = data.capture and data.capture[species]
    local marks = cap and cap.marks
    if not marks or #marks == 0 then return "empty" end
    if st.species then M.clear("replace") end
    ensure_capture_hook()   -- first mark of the session installs the hook
    st.gen = st.gen + 1
    reset_build_state()
    st.species = species
    st.zh = zh or species
    st.marks = marks
    st.fail_count = 0
    st.world_anchor = nil
    st.anchor_miss = 0
    st.anchor_check_at = 0   -- fresh mark: first tick re-verifies the anchor
    st.anchor_pending = nil
    st.map_idle = false      -- fresh mark: full 1s cadence until built
    st.idle_skip = 0
    pcall(function()
        local pc = FindFirstOf("PalPlayerController")
        if pc and is_valid(pc) then st.world_anchor = full_name(pc) end
    end)
    M._arm_ticker()
    -- compass companion: best-effort, never blocks the mark itself
    local compass_ok = false
    pcall(function() compass_ok = M._compass_place() end)
    st.compass_ok = compass_ok
    log(string.format("mark: %s (%d marks, anchor=%s, compass=%s)",
        tostring(species), #marks, tostring(st.world_anchor ~= nil),
        tostring(compass_ok)))
    return "marked"
end

function M.clear(reason)
    local st = M.state
    st.gen = st.gen + 1
    st.tick_gen = st.tick_gen + 1   -- orphan queued game-thread callbacks
    undo_entries(reason or "clear")
    pcall(function() M._compass_remove() end)
    st.compass_ok = nil
    reset_build_state()
    st.species = nil
    st.marks = nil
    st.zh = nil
    st.world_anchor = nil
    st.anchor_miss = 0
    -- ticker parks itself on the next beat (species == nil)
end

function M.status()
    local st = M.state
    return {
        species = st.species,
        zh = st.zh,
        built = #st.entries,
        total = st.marks and #st.marks or 0,
        pending = st.species ~= nil and st.build_idx <= (st.marks and #st.marks or 0),
        disabled = st.disabled,
        compass = st.compass_ok == true,
    }
end

-- allocation-free peek for poll-side callers (perf audit 2026-07-24):
-- status() builds a fresh table per call and the UI polls at 4 Hz
function M.active_species()
    return M.state.species, M.state.zh
end

-- Eight-way compass label for "which way do I run". Axis calibration
-- (2026-07-21, three-landmark proof: spawn grasslands vs snow mountains vs
-- sakurajima/desert): world X+ = NORTH, world Y+ = EAST. In-game map
-- coordinates: mapX=(worldY-68000)/1000 (east+), mapY=(worldX-131000)/1000
-- (north+) — the same numbers the game prints on its map screen.
local DIR_ZH = { "北", "东北", "东", "东南", "南", "西南", "西", "西北" }

-- nearest (to the player) mark of the active species; falls back to the
-- highest-weight mark when no player pawn is readable. nil when idle.
function M.nearest_info()
    local st = M.state
    if not st.species or not st.marks or #st.marks == 0 then return nil end
    local px, py = nil, nil
    pcall(function()
        -- position from the LOCAL controller's pawn (codex marker r2: on a
        -- multiplayer client FindFirstOf("PalPlayerCharacter") can return a
        -- REPLICATED remote player and the pin would chase their nearest
        -- cluster; controllers exist only for the local player — the same
        -- reasoning the world anchor already relies on)
        local pc = FindFirstOf("PalPlayerController")
        if not (pc and is_valid(pc)) then return end
        local pawn = pc:K2_GetPawn()
        if pawn and is_valid(pawn) then
            local loc = pawn:K2_GetActorLocation()
            px, py = tonumber(loc.X), tonumber(loc.Y)
        end
    end)
    -- origin gate (repo rule, opus marker r1: an unstreamed actor reads as
    -- the WORLD ORIGIN — no buildable spot sits within a meter of it, and
    -- this position now decides where the compass pin lands, not just
    -- display text). Unknown position falls back to the densest cluster.
    if px and py and math.abs(px) < 100 and math.abs(py) < 100 then
        px, py = nil, nil
    end
    local best, bestd = nil, nil
    for _, m in ipairs(st.marks) do
        if px and py then
            local d = (m.wx - px) ^ 2 + (m.wy - py) ^ 2
            if not bestd or d < bestd then best, bestd = m, d end
        elseif not best or (m.n or 0) > (best.n or 0) then
            best = m
        end
    end
    if not best then return nil end
    local info = {
        map_x = math.floor((best.wy - 68000) / 1000 + 0.5),
        map_y = math.floor((best.wx - 131000) / 1000 + 0.5),
        -- world coords ride along for the compass companion (2.10.x)
        wx = best.wx, wy = best.wy, wz = best.wz or 0,
        boss = best.boss == 1,
        night = best.t == 1,
        count = #st.marks,
    }
    if px and py and bestd then
        info.dist_m = math.floor(math.sqrt(bestd) / 100 + 0.5)
        local north, east = best.wx - px, best.wy - py
        -- bearing from north, clockwise; Lua 5.4 two-arg atan(y, x)
        local ang = math.deg(math.atan(east, north))
        info.dir = DIR_ZH[(math.floor((ang + 22.5) / 45) % 8) + 1]
    end
    return info
end

-- ---------------------------------------------------------------------------
-- compass companion (2.10.x, owner request "让玩家清楚知道怪在哪"): ONE
-- official custom marker at the spawn cluster nearest the player.
-- AddLocalCustomMarker is the SAME call the player's own map pin uses —
-- native on both the world map and the compass strip, locally owned (no
-- server write), removable via RemoveLocalCustomMarker and by hand in the
-- map UI. Channel discipline: FVector rides a plain table (the proven
-- Add-Icon-By-Location shape); the returned FGuid is stored opaque and
-- passed back verbatim (zero hand-built structs). Every touch pcall'd —
-- the companion failing must never break the icon pipeline.
-- Known edge (documented, accepted): custom markers persist in the SAVE;
-- a world switch that outruns our clear leaves one stray player-deletable
-- pin. The result window names the pin so the player knows it is ours.
local COMPASS_ICON_TYPE = 0

local function location_manager()
    local lm = nil
    pcall(function()
        local m = FindFirstOf("PalLocationManager")
        if m and is_valid(m) then lm = m end
    end)
    return lm
end

M._compass_place = function()
    local st = M.state
    if st.compass_marker_id then
        M._compass_remove()
        -- a failed remove keeps the handle (codex marker r1: dropping it
        -- early orphans the pin) — never stack a second pin on top
        if st.compass_marker_id then
            log("compass: stale pin handle stuck; not stacking another")
            return false
        end
    end
    local near = M.nearest_info()
    if not (near and near.wx) then return false end
    local lm = location_manager()
    if not lm then return false end
    -- the returned FGuid may be a RemoteUnrealParam view into the CALL's
    -- params buffer — freed once the call returns (opus marker r1 M3:
    -- storing it across frames is use-after-free; the repo's guid rule is
    -- serialize INSIDE the call scope). Unpack A/B/C/D to plain numbers
    -- now; Remove passes them back on the plain-table struct channel.
    -- All-zero is the null guid = the add did not land (also closes the
    -- "any non-nil return counts as success" gap).
    pcall(function()
        local raw = unwrap(lm:AddLocalCustomMarker(
            { X = near.wx, Y = near.wy, Z = near.wz or 0 }, COMPASS_ICON_TYPE))
        if raw == nil then return end
        local a = tonumber(unwrap(raw.A))
        local b = tonumber(unwrap(raw.B))
        local c = tonumber(unwrap(raw.C))
        local d = tonumber(unwrap(raw.D))
        if a and b and c and d and not (a == 0 and b == 0 and c == 0 and d == 0) then
            st.compass_marker_id = { A = a, B = b, C = c, D = d }
        end
    end)
    return st.compass_marker_id ~= nil
end

M._compass_remove = function()
    local st = M.state
    local id = st.compass_marker_id
    if not id then return end
    local lm = location_manager()
    if not lm then
        -- dead world: the manager died with the save — the handle is
        -- useless, drop it (the accepted stray-pin edge)
        st.compass_marker_id = nil
        return
    end
    -- clear the handle only AFTER the call went through (codex marker r1:
    -- a transient failure with the handle already dropped left a pin the
    -- player could only delete by hand); a kept handle retries on the next
    -- clear/replace
    if pcall(function() lm:RemoveLocalCustomMarker(id) end) then
        st.compass_marker_id = nil
    end
end

-- pure helpers exposed for tools/verify_impls.py
M._resolve_species_texture_path = function(species)
    for _, p in ipairs(data.pals) do
        if p.id == species then
            if not p.ic then return nil end
            return p.ic .. "." .. p.ic:match("([^/]+)$")
        end
    end
    return nil
end

return M

local PACKAGE = "WorldTreeDragonSuperEvolution-Server"
local VERSION = "0.9.0-rc14.R933"
local PREFIX = "[" .. PACKAGE .. "]"

if _G.__WORLD_TREE_DRAGON_SUPER_EVOLUTION_LOADED == true then
    print(PREFIX .. " duplicate bootstrap ignored\n")
    return
end
_G.__WORLD_TREE_DRAGON_SUPER_EVOLUTION_LOADED = true

local function log(message)
    print(string.format("%s %s\n", PREFIX, tostring(message)))
end

local guard_ok, guard = pcall(require, "modules.runtime_guard")
if not guard_ok then
    log("runtime guard failed to initialize; gameplay modules were not loaded: "
        .. tostring(guard))
    return
end
if guard.compatible ~= true then
    log("unsupported game revision; gameplay modules were not loaded: "
        .. tostring(guard.reason))
    return
end

local scheduler_ok, scheduler = pcall(require, "modules.runtime_scheduler")
if not scheduler_ok then
    log("runtime scheduler failed to initialize; gameplay modules were not loaded: "
        .. tostring(scheduler))
    return
end

-- WTD_Rideable split-port: dedicated server only needs the capture hook
-- (set/clear IsUncapturable, IsForceCapturable on the wild Pal).
-- Ride / transform / halo / laser / explosion all need a local player and
-- are loaded by the client-side mod on the player's machine.
local modules = {
    "modules.capture"
}

local loaded = 0
for _, module_name in ipairs(modules) do
    local ok, result = pcall(require, module_name)
    if not ok then
        log("module load failed: " .. module_name .. ": " .. tostring(result))
    else
        loaded = loaded + 1
        log("module ready: " .. module_name)
    end
end

log(string.format(
    "version %s initialized (%d/%d modules); revision=%s; ordinary WorldTreeDragon only",
    VERSION,
    loaded,
    #modules,
    tostring(guard.revision)
))

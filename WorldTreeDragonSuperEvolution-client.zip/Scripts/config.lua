-- WTD_Rideable split-port: server-side config
-- Inlined to avoid UE4SS Lua's `require("modules.configs.X")` resolution
-- failure (the experimental-palworld Lua build treats two-dot require
-- strings as package lookups instead of path lookups, so the original
-- modular config pattern from the Steam Workshop UE4SS does not work here).
local capture_config = {
    -- WTD_Rideable split-port: server-side accepts both the ordinary
    -- WorldTreeDragon and the BOSS_WorldTreeDragon as catchable.
    actor_classes = {
        "BP_WorldTreeDragon_C",
        "BP_WorldTreeDragon_BOSS_C"
    },
    -- Legacy single-class field kept for any caller that still reads it.
    actor_class = "BP_WorldTreeDragon_C",
    player_guild_group_type = 4, -- EPalGroupType::Guild
    initialize_delay_ms = 250,
    retry_delay_ms = 250,
    retry_count = 12,
    initial_scan_delays_ms = {
        1500,
        4000,
        8000
    }
}

return {
    package_name = "WorldTreeDragonSuperEvolution-Server",
    version = "0.9.0-rc14.R933",
    supported_steam_build = "100933",
    supported_project_version = "1.0.2.100933",
    minimum_revision = 619,
    -- List form used by every module; helpers below preserve the legacy
    -- singular field for any caller that still references it.
    allowed_character_ids = { "WorldTreeDragon", "BOSS_WorldTreeDragon" },
    allowed_character_id = "WorldTreeDragon",

    -- Only the capture module is loaded server-side.
    capture = capture_config,

    -- Placeholders so any other module (e.g. future direct require) sees
    -- a complete table. These are intentionally empty: the server does
    -- not run ride/transform/halo_cutter/laser_gliding/explosion_target.
    halo_cutter = {},
    transform = {},
    ride = {},
    laser_gliding = {},
    explosion_target = {}
}

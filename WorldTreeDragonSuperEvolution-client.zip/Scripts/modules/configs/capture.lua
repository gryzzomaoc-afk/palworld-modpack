return {
    -- WTD_Rideable split-port: server-side accepts both the ordinary
    -- WorldTreeDragon and the BOSS_WorldTreeDragon as catchable.
    actor_classes = {
        "BP_WorldTreeDragon_C",
        "BP_WorldTreeDragon_BOSS_C"
    },
    -- Legacy single-class field kept for any caller that still reads it.
    actor_class = "BP_WorldTreeDragon_C",
    player_guild_group_type = 4, -- EPalGroupType::Guild
    initialize_delay_ms = 250,
    retry_delay_ms = 250,
    retry_count = 12,
    initial_scan_delays_ms = {
        1500,
        4000,
        8000
    }
}

local ROOT_CONFIG = require("config")
local CONFIG = ROOT_CONFIG.capture
local SCHEDULER = require("modules.runtime_scheduler")

local PREFIX = "[WorldTreeDragonSuperEvolution/Capture]"
local INITIALIZE_HOOK =
    "/Script/Pal.PalCharacterParameterComponent:OnInitialize_AfterSetIndividualParameter"

if _G.__WTDSE_CAPTURE_MODULE_LOADED == true then
    return {
        loaded = true,
        duplicate = true
    }
end
_G.__WTDSE_CAPTURE_MODULE_LOADED = true

local function log(message)
    print(string.format("%s %s\n", PREFIX, tostring(message)))
end

local function is_valid(object)
    if object == nil then
        return false
    end
    local ok, valid = pcall(function()
        return object:IsValid()
    end)
    return ok and valid == true
end

local function unwrap(value)
    if value == nil then
        return nil
    end
    local ok, object = pcall(function()
        return value:get()
    end)
    if ok and is_valid(object) then
        return object
    end
    if is_valid(value) then
        return value
    end
    return nil
end

local function describe(object)
    if not is_valid(object) then
        return "<invalid>"
    end
    local ok, name = pcall(function()
        return object:GetFullName()
    end)
    return ok and tostring(name) or "<valid UObject>"
end

local function name_to_string(value)
    if value == nil then
        return "<nil>"
    end
    local ok, text = pcall(function()
        return value:ToString()
    end)
    return ok and tostring(text) or tostring(value)
end

local function enum_to_number(value)
    local direct = tonumber(value)
    if direct ~= nil then
        return direct
    end
    local ok, raw = pcall(function()
        return value:get()
    end)
    return ok and tonumber(raw) or nil
end

-- WTD_Rideable split-port helpers:
-- `actor_classes` is a list (BP_WorldTreeDragon_C, BP_WorldTreeDragon_BOSS_C);
-- `allowed_character_ids` is a list (WorldTreeDragon, BOSS_WorldTreeDragon).
-- These helpers accept either the new list form or the legacy single-string
-- field so old and new callers keep working.
local function get_actor_classes()
    if type(CONFIG.actor_classes) == "table" and #CONFIG.actor_classes > 0 then
        return CONFIG.actor_classes
    end
    return { CONFIG.actor_class }
end

local function get_allowed_character_ids()
    if type(ROOT_CONFIG.allowed_character_ids) == "table"
        and #ROOT_CONFIG.allowed_character_ids > 0 then
        return ROOT_CONFIG.allowed_character_ids
    end
    return { ROOT_CONFIG.allowed_character_id }
end

local function actor_name_matches(actor_name)
    for _, class_name in ipairs(get_actor_classes()) do
        if string.find(actor_name, class_name, 1, true) then
            return true
        end
    end
    return false
end

local function character_id_matches(id_text)
    for _, allowed in ipairs(get_allowed_character_ids()) do
        if id_text == allowed then
            return true
        end
    end
    return false
end

local function get_wild_target_state(actor)
    if not is_valid(actor) then
        return nil, "actor invalid"
    end

    local actor_name = describe(actor)
    if not actor_name_matches(actor_name) then
        return nil, "non-target actor class"
    end

    local component = nil
    local component_ok = pcall(function()
        component = actor:GetCharacterParameterComponent()
    end)
    if not component_ok or not is_valid(component) then
        return nil, "character parameter component unavailable"
    end

    local parameter = nil
    local parameter_ok = pcall(function()
        parameter = component:GetIndividualParameter()
    end)
    if not parameter_ok or not is_valid(parameter) then
        return nil, "individual parameter unavailable"
    end

    local character_id = nil
    local id_ok = pcall(function()
        character_id = parameter:GetCharacterID()
    end)
    if not id_ok or not character_id_matches(name_to_string(character_id)) then
        return nil, "non-target character"
    end

    local is_players_otomo = nil
    pcall(function()
        is_players_otomo = component:IsPlayersOtomo()
    end)
    if is_players_otomo == true then
        return nil, "target is player's active Pal"
    end

    local group_type = nil
    pcall(function()
        group_type = enum_to_number(parameter:GetGroupType())
    end)
    if group_type == CONFIG.player_guild_group_type then
        return nil, "target belongs to player guild"
    end

    return {
        actor = actor,
        parameter = parameter
    }, nil
end

local function apply_capture_fix(actor, source)
    local state, state_error = get_wild_target_state(actor)
    if state == nil then
        return false, state_error
    end

    local before_uncapturable = nil
    local before_force = nil
    pcall(function()
        before_uncapturable = state.parameter:IsUncapturable()
        before_force = state.parameter:IsForceCapturable()
    end)

    if before_uncapturable == false and before_force == true then
        return true, nil
    end

    local apply_ok, apply_error = pcall(function()
        state.parameter:SetUncapturable(false)
        state.parameter:SetForceCapturable(true)
    end)
    if not apply_ok then
        log(string.format(
            "apply failed source=%s actor=%s error=%s",
            tostring(source),
            describe(state.actor),
            tostring(apply_error)
        ))
        return false, tostring(apply_error)
    end

    local after_uncapturable = nil
    local after_force = nil
    local verify_ok = pcall(function()
        after_uncapturable = state.parameter:IsUncapturable()
        after_force = state.parameter:IsForceCapturable()
    end)
    if not verify_ok or after_uncapturable ~= false or after_force ~= true then
        log(string.format(
            "verification failed source=%s actor=%s uncapturable=%s force=%s",
            tostring(source),
            describe(state.actor),
            tostring(after_uncapturable),
            tostring(after_force)
        ))
        return false, "post-write verification failed"
    end

    log(string.format(
        "capture enabled source=%s actor=%s uncapturable=%s->false force=%s->true",
        tostring(source),
        describe(state.actor),
        tostring(before_uncapturable),
        tostring(before_force)
    ))
    return true, nil
end

local function schedule_actor_fix(actor, source, attempt)
    local current_attempt = attempt or 1
    local delay = current_attempt == 1
        and CONFIG.initialize_delay_ms
        or CONFIG.retry_delay_ms

    SCHEDULER.after(delay, function()
        local fixed, fix_error = apply_capture_fix(actor, source)
        if fixed then
            return
        end
        if current_attempt < CONFIG.retry_count
            and (fix_error == "actor invalid"
                or fix_error == "character parameter component unavailable"
                or fix_error == "individual parameter unavailable") then
            schedule_actor_fix(actor, source, current_attempt + 1)
        end
    end, "capture-retry-" .. tostring(current_attempt))
end

local function scan_existing(source)
    for _, class_name in ipairs(get_actor_classes()) do
        local ok, actors = pcall(function()
            return FindAllOf(class_name)
        end)
        if ok and actors ~= nil then
            for _, actor in pairs(actors) do
                if is_valid(actor) then
                    apply_capture_fix(actor, source)
                end
            end
        end
    end
end

local hook_ok, hook_pre, hook_post = pcall(function()
    return RegisterHook(INITIALIZE_HOOK, function(context)
        local component = unwrap(context)
        if not is_valid(component) then
            return
        end
        local actor = nil
        pcall(function()
            actor = component:GetOwner()
        end)
        if is_valid(actor) then
            schedule_actor_fix(actor, "initialize-hook", 1)
        end
    end)
end)

if hook_ok then
    log(string.format(
        "initialize hook registered pre=%s post=%s",
        tostring(hook_pre),
        tostring(hook_post)
    ))
else
    log("initialize hook registration failed safely: " .. tostring(hook_pre))
end

for index, delay_ms in ipairs(CONFIG.initial_scan_delays_ms) do
    SCHEDULER.after(delay_ms, function()
        scan_existing("initial-scan-" .. tostring(index))
    end, "capture-initial-scan-" .. tostring(index))
end

log(
    "loaded; wild ordinary + BOSS WorldTreeDragon catchable; "
    .. "captured/player-owned Pals excluded"
)

return {
    loaded = true,
    hook_registered = hook_ok
}

local CONFIG = require("config")
local PREFIX = "[WorldTreeDragonSuperEvolution-Server/RuntimeGuard]"
local SETTINGS_PATH =
    "/Script/EngineSettings.Default__GeneralProjectSettings"

-- WTD_Rideable split-port: server-side mod supports any build >= supported_revision
-- (originally hard-pinned to 619; we accept 933 for v1.0.2.100933 dedicated server)

local function log(message)
    print(string.format("%s %s\n", PREFIX, tostring(message)))
end

local function is_valid(object)
    return object ~= nil and object.IsValid ~= nil and object:IsValid()
end

local function read_property(object, name)
    if not is_valid(object) then
        return nil
    end
    local ok, value = pcall(function()
        return object[name]
    end)
    if ok and value ~= nil then
        return value
    end
    local reflected = nil
    pcall(function()
        reflected = object:GetPropertyValue(name)
    end)
    return reflected
end

local settings = StaticFindObject(SETTINGS_PATH)
if not is_valid(settings) then
    settings = FindFirstOf("GeneralProjectSettings")
end
if not is_valid(settings) then
    return {
        compatible = false,
        revision = nil,
        reason = "GeneralProjectSettings unavailable"
    }
end

local project_version_value = read_property(settings, "ProjectVersion")
local project_version = ""
if project_version_value ~= nil then
    local converted_ok, converted = pcall(function()
        return project_version_value:ToString()
    end)
    if converted_ok and converted ~= nil then
        project_version = converted
    else
        project_version = tostring(project_version_value)
    end
end
local revision_text = string.match(project_version, "(%d%d%d%d%d)$")
local revision = revision_text and tonumber(revision_text) or nil
if revision == nil then
    return {
        compatible = false,
        revision = nil,
        project_version = project_version,
        reason = "ProjectVersion has no five-digit revision suffix: "
            .. project_version
    }
end

if revision < CONFIG.minimum_revision then
    return {
        compatible = false,
        revision = revision,
        project_version = project_version,
        reason = string.format(
            "minimum supported revision is %05d (Steam build %s), got %05d (%s)",
            CONFIG.minimum_revision,
            CONFIG.supported_steam_build,
            revision,
            project_version
        )
    }
end

log(string.format(
    "revision accepted: %05d; project=%s; minimum=%05d; Steam build target=%s",
    revision,
    project_version,
    CONFIG.minimum_revision,
    CONFIG.supported_steam_build
))

return {
    compatible = true,
    revision = revision,
    project_version = project_version,
    reason = "compatible (>=minimum)"
}

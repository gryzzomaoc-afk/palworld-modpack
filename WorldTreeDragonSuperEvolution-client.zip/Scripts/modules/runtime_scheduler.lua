local PREFIX = "[WorldTreeDragonSuperEvolution/Scheduler]"
local TICK_INTERVAL_MS = 25

-- UE4SS experimental-palworld-6 stores every game-thread callback in one
-- shared Lua child thread. Keep exactly one session-long native loop as the
-- owner of that thread, then schedule all Mod work as ordinary Lua data.
-- This also prevents legacy ExecuteWithDelay callbacks from running on
-- UE4SS's asynchronous Lua thread while EngineTick is using the same registry.
if _G.__WTDSE_RUNTIME_SCHEDULER ~= nil then
    return _G.__WTDSE_RUNTIME_SCHEDULER
end

local scheduler = {
    interval_ms = TICK_INTERVAL_MS,
    next_id = 0,
    tasks = {},
    periodic = {},
    loop_handle = nil
}
_G.__WTDSE_RUNTIME_SCHEDULER = scheduler

local function log(message)
    print(string.format("%s %s\n", PREFIX, tostring(message)))
end

local function monotonic_time_ms()
    local ok, seconds = pcall(os.clock)
    if not ok or type(seconds) ~= "number" then
        return nil
    end
    return seconds * 1000.0
end

local function next_id()
    scheduler.next_id = scheduler.next_id + 1
    return scheduler.next_id
end

function scheduler.after(delay_ms, callback, label)
    if type(callback) ~= "function" then
        error("scheduler.after requires a Lua function")
    end
    local id = next_id()
    local normalized_delay = math.max(0, tonumber(delay_ms) or 0)
    local now_ms = monotonic_time_ms()
    scheduler.tasks[id] = {
        callback = callback,
        label = label or ("after-" .. tostring(id)),
        deadline_ms =
            now_ms ~= nil and (now_ms + normalized_delay) or nil,
        remaining_ms = normalized_delay
    }
    return id
end

function scheduler.every(interval_ms, callback, label)
    if type(callback) ~= "function" then
        error("scheduler.every requires a Lua function")
    end
    local id = next_id()
    local normalized_interval =
        math.max(TICK_INTERVAL_MS, tonumber(interval_ms) or TICK_INTERVAL_MS)
    local now_ms = monotonic_time_ms()
    scheduler.periodic[id] = {
        callback = callback,
        label = label or ("every-" .. tostring(id)),
        interval_ms = normalized_interval,
        deadline_ms =
            now_ms ~= nil and (now_ms + normalized_interval) or nil,
        remaining_ms = normalized_interval
    }
    return id
end

function scheduler.cancel(id)
    local existed = scheduler.tasks[id] ~= nil
        or scheduler.periodic[id] ~= nil
    scheduler.tasks[id] = nil
    scheduler.periodic[id] = nil
    return existed
end

local function task_is_due(task, now_ms, elapsed_ms)
    if now_ms ~= nil and task.deadline_ms ~= nil then
        return now_ms >= task.deadline_ms
    end
    task.remaining_ms = task.remaining_ms - elapsed_ms
    return task.remaining_ms <= 0
end

local function run_callback(callback, label)
    local ok, callback_error = pcall(callback)
    if not ok then
        log(string.format(
            "callback failed safely label=%s error=%s",
            tostring(label),
            tostring(callback_error)
        ))
    end
end

local function scheduler_tick()
    -- The outer pcall is deliberate: no module callback may escape into the
    -- native EngineTick hook, because UE4SS removes that shared hook after an
    -- uncaught exception.
    local tick_ok, tick_error = pcall(function()
        local now_ms = monotonic_time_ms()
        local due = {}

        for id, task in pairs(scheduler.tasks) do
            if task_is_due(task, now_ms, TICK_INTERVAL_MS) then
                scheduler.tasks[id] = nil
                due[#due + 1] = task
            end
        end

        for id, task in pairs(scheduler.periodic) do
            if task_is_due(task, now_ms, TICK_INTERVAL_MS) then
                due[#due + 1] = task
                task.remaining_ms = task.interval_ms
                task.deadline_ms =
                    now_ms ~= nil and (now_ms + task.interval_ms) or nil
            end
        end

        for _, task in ipairs(due) do
            run_callback(task.callback, task.label)
        end
    end)
    if not tick_ok then
        log("tick failed safely: " .. tostring(tick_error))
    end
end

_G.__WTDSE_CALLBACKS = _G.__WTDSE_CALLBACKS or {}
_G.__WTDSE_CALLBACKS.runtime_scheduler = scheduler_tick
scheduler.loop_handle =
    LoopInGameThreadWithDelay(
        TICK_INTERVAL_MS,
        _G.__WTDSE_CALLBACKS.runtime_scheduler
    )

log(
    "single persistent game-thread scheduler started handle="
    .. tostring(scheduler.loop_handle)
    .. " interval_ms="
    .. tostring(TICK_INTERVAL_MS)
)

return scheduler

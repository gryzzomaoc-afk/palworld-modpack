-- WTDForceAll: Force-spawn WTD at all 8 spawn points (override 1/8 random)
--
-- WTD mod 的 PalSchema Sheet spawn 在 dedicated server 只 instantiate 1/8 隨機點
-- 這個模組用 SpawnActor 指令強制在每個點都生成一隻，8 個點 = 8 隻
--
-- 配合：WorldTreeDragonSuperEvolution (capture mod) — 會自動處理 8 隻的 capture flag
--
-- 注意：
--   1. Sheet spawn 的 1 隻還是會生成（random pick），我們再補 7 隻
--   2. 但 Sheet spawn 跟 SpawnActor 會搶同一個 spawn point，可能會撞
--   3. 因此我們把 Sheet spawn 的隨機行為保留，但確保「至少有 1 隻在你附近」
--      其他 7 隻用 SpawnActor 補上

local PREFIX = "[WTDForceAll]"
local SPAWN_DELAY_MS = 30000  -- 等 30 秒讓 level 完整 load

-- 8 個點 (跟 world_tree_dragon.jsonc 一致)
-- {bp_class, x, y, z, label}
local SPAWN_POINTS = {
    { "BP_WorldTreeDragon_C",       -342040, 264212,  4051, "Common_InitialPlateau" },
    { "BP_WorldTreeDragon_BOSS_C",  -342040, 264212, 10051, "Boss_InitialPlateau"   },
    { "BP_WorldTreeDragon_C",       -150000, 450000,   600, "Common_WindsweptHills" },
    { "BP_WorldTreeDragon_C",       -250000, 650000,  1800, "Common_SnowMountain"    },
    { "BP_WorldTreeDragon_C",        220000,-250000,  1200, "Common_MountObsidian"   },
    { "BP_WorldTreeDragon_BOSS_C",   220000,-250000,  7200, "Boss_MountObsidian"     },
    { "BP_WorldTreeDragon_C",        320000,-100000,   200, "Common_BambooGrove"     },
    { "BP_WorldTreeDragon_C",         80000,-550000,   100, "Common_FishermanPoint"  },
}

local function log(msg)
    print(string.format("%s %s\n", PREFIX, tostring(msg)))
end

-- 找 KismetSystemLibrary 跟 GEngine (UE4SS 沒有 global ExecuteConsoleCommand)
local KismetSystemLibrary = StaticFindObject("/Script/Engine.KismetSystemLibrary")
local GEngine = StaticFindObject("/Script/Engine.Engine")
if KismetSystemLibrary then
    log("using KismetSystemLibrary:ExecuteConsoleCommand")
elseif GEngine then
    log("fallback to GEngine:Exec (KismetSystemLibrary not found)")
else
    log("WARN: 找不到 KismetSystemLibrary 跟 GEngine, 嘗試 SpawnActor 直呼")
end

local function spawn_at(point)
    local bp, x, y, z, label = point[1], point[2], point[3], point[4], point[5]
    local cmd = string.format("SpawnActor %s %.0f %.0f %.0f", bp, x, y, z)
    local ok, err = pcall(function()
        if KismetSystemLibrary then
            KismetSystemLibrary:ExecuteConsoleCommand(nil, cmd)
        elseif GEngine then
            GEngine:Exec(nil, cmd)
        else
            -- 最後手段: 直接找 class 然後 World:SpawnActor
            local World = StaticFindObject("/Script/Engine.World") or nil
            local Class = StaticFindObject("/Script/Pal." .. bp)
            if World and Class then
                World:SpawnActor(Class, { X = x, Y = y, Z = z }, { Pitch = 0, Yaw = 0, Roll = 0 })
            else
                error("no API available (no KismetSystemLibrary / GEngine / World+Class)")
            end
        end
    end)
    if ok then
        log(string.format("OK  [%s] @ (%.0f, %.0f, %.0f)", label, x, y, z))
    else
        log(string.format("ERR [%s] @ (%.0f, %.0f, %.0f)  err=%s", label, x, y, z, tostring(err)))
    end
end

-- 啟動 log
log(string.format("loaded; 8 WTD 將在 %d 秒後 force-spawn", SPAWN_DELAY_MS / 1000))
log("覆蓋 PalSchema Sheet 1/8 隨機邏輯 → 8/8 全點生成")

-- 延遲後 spawn (用 UE4SS 的 LoopInGameThreadWithDelay 做一次性任務)
local fired = false
LoopInGameThreadWithDelay(SPAWN_DELAY_MS, function()
    if fired then return end
    fired = true
    log("=== 開始 force-spawn 8 隻 WTD ===")
    for i, p in ipairs(SPAWN_POINTS) do
        spawn_at(p)
    end
    log("=== 完成 ===")
end)

-- WTDScaler (server edition): shrink WorldTreeDragon on spawn to a
-- configurable scale, run on the dedicated server so the smaller size
-- replicates to every client.
--
-- 2026-07-31: written for the YDESK user's dedicated server box
-- (192.168.1.112:28211).  Pure hook, no background timers, no asset
-- residency, no listeners beyond NotifyOnNewObject for /Script/Pal.PalCharacter.
--
-- Why server-side only: in a dedicated server environment the server is the
-- authoritative owner of every actor's transform.  A client-side
-- SetActorScale3D works (the native call succeeds and the client-side log
-- shows "scaled"), but the next replication tick from the server overwrites
-- the client-side value with the server's original 1.0x scale.  The only way
-- to make the smaller WTD actually visible is to run this mod on the
-- dedicated server so the server itself spawns WTD at 0.2x.
--
-- Installation:
--   1. Make sure Okaetsu RE-UE4SS is installed on the dedicated server.
--      If it isn't, see README-Server.md.
--   2. Copy the WTDScaler/ folder to:
--      <palworld_server>/Pal/Binaries/Win64/ue4ss/Mods/WTDScaler/
--   3. Add this line to <palworld_server>/Pal/Binaries/Win64/ue4ss/Mods/mods.txt:
--      WTDScaler : 1
--   4. Restart the dedicated server.
--   5. Watch the server log for "[WTDScaler-Server] scaled BP_WorldTreeDragon_C ..."
--   6. When any client spawns a WTD (active companion from sphere, etc.) the
--      server will scale it on spawn and replicate 0.2x to every client.

local CONFIG = {
    target_substring = "WorldTreeDragon",
    -- 0.2 = 20% size.  The original WTD mesh is huge; 0.2x is a comfortable
    -- handheld companion size that still looks like WTD, just not a raid boss.
    -- The 0.2 value mirrors the client-side WTDScaler that the user already
    -- has running on YDESK so the two ends stay in sync.
    scale = 0.2,
}

local PREFIX = "[WTDScaler-Server]"

local function log(message)
    print(string.format("%s %s\n", PREFIX, tostring(message)))
end

local function safe_full_name(object)
    local ok, name = pcall(function()
        return object:GetFullName()
    end)
    if not ok then
        return nil
    end
    return tostring(name)
end

local function matches_target(full_name)
    if full_name == nil then
        return false
    end
    -- Tower / raid boss variants stay full-size.
    if full_name:find("BOSS_", 1, true) ~= nil then
        return false
    end
    if full_name:find("GYM_", 1, true) ~= nil then
        return false
    end
    return full_name:find(CONFIG.target_substring, 1, true) ~= nil
end

local function apply_scale(target, full_name)
    local scale_vector = {
        X = CONFIG.scale,
        Y = CONFIG.scale,
        Z = CONFIG.scale
    }
    local set_ok, set_error = pcall(function()
        target:SetActorScale3D(scale_vector)
    end)
    if not set_ok then
        log("SetActorScale3D failed: " .. tostring(set_error))
        return false
    end
    log(string.format(
        "scaled %s to %.2fx",
        tostring(full_name),
        CONFIG.scale
    ))
    return true
end

local listener_ok, listener_error = pcall(function()
    NotifyOnNewObject("/Script/Pal.PalCharacter", function(obj)
        local full_name = safe_full_name(obj)
        if not matches_target(full_name) then
            return
        end
        apply_scale(obj, full_name)
    end)
end)

if listener_ok then
    log(string.format(
        "loaded; target_substring=%s scale=%.2f (BOSS_ and GYM_ variants are excluded)",
        CONFIG.target_substring,
        CONFIG.scale
    ))
else
    log("NotifyOnNewObject registration failed: " .. tostring(listener_error))
end
